ALTER TABLE public.payment_orders ADD COLUMN IF NOT EXISTS pay_clicked_at timestamptz;
ALTER TABLE public.notification_payment_signals ADD COLUMN IF NOT EXISTS consumed boolean NOT NULL DEFAULT false;

CREATE TABLE IF NOT EXISTS public.payment_audit_log (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  order_id uuid NOT NULL REFERENCES public.payment_orders(id) ON DELETE CASCADE,
  matched_via text NOT NULL,
  matched_at timestamptz NOT NULL DEFAULT now(),
  signal_ids uuid[] NOT NULL DEFAULT '{}',
  created_at timestamptz NOT NULL DEFAULT now()
);

GRANT SELECT ON public.payment_audit_log TO authenticated;
GRANT ALL ON public.payment_audit_log TO service_role;

ALTER TABLE public.payment_audit_log ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "Admins can view payment audit log" ON public.payment_audit_log;
CREATE POLICY "Admins can view payment audit log"
ON public.payment_audit_log FOR SELECT TO authenticated
USING (public.is_admin(auth.uid()));

-- Mark that the user actually tapped Pay and returned from the UPI app (once).
CREATE OR REPLACE FUNCTION public.mark_order_pay_clicked(_order_id uuid)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $$
BEGIN
  IF auth.uid() IS NULL THEN
    RAISE EXCEPTION 'not_authenticated';
  END IF;

  UPDATE public.payment_orders
     SET pay_clicked_at = now(), updated_at = now()
   WHERE id = _order_id
     AND user_id = auth.uid()
     AND pay_clicked_at IS NULL
     AND status IN ('created', 'awaiting_utr');
END;
$$;

REVOKE ALL ON FUNCTION public.mark_order_pay_clicked(uuid) FROM anon;
GRANT EXECUTE ON FUNCTION public.mark_order_pay_clicked(uuid) TO authenticated;

-- N/M auto-match: atomic, row-locked.
CREATE OR REPLACE FUNCTION public.try_auto_match_payment_signal(p_signal_id uuid)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $$
DECLARE
  v_amount numeric;
  v_n integer;
  v_m integer;
  v_signal_ids uuid[];
  v_order_ids uuid[];
  v_order_id uuid;
BEGIN
  SELECT amount INTO v_amount
  FROM public.notification_payment_signals
  WHERE id = p_signal_id;

  IF v_amount IS NULL THEN
    RETURN;
  END IF;

  -- lock candidate orders (N)
  SELECT array_agg(o.id ORDER BY o.created_at)
    INTO v_order_ids
  FROM public.payment_orders o
  WHERE o.amount = v_amount
    AND o.status IN ('created', 'awaiting_utr')
    AND o.pay_clicked_at IS NOT NULL
    AND o.expires_at > now()
  FOR UPDATE;

  v_n := COALESCE(array_length(v_order_ids, 1), 0);
  IF v_n = 0 THEN
    RETURN;
  END IF;

  -- lock unconsumed signals (M)
  SELECT array_agg(s.id ORDER BY s.received_at)
    INTO v_signal_ids
  FROM public.notification_payment_signals s
  WHERE s.amount = v_amount
    AND s.consumed = false
    AND s.received_at > now() - interval '15 minutes'
  FOR UPDATE;

  v_m := COALESCE(array_length(v_signal_ids, 1), 0);

  IF v_m < v_n THEN
    RETURN;
  END IF;

  FOR i IN 1..v_n LOOP
    v_order_id := v_order_ids[i];

    UPDATE public.payment_orders
       SET status = 'success',
           verification_method = 'notification_auto',
           updated_at = now()
     WHERE id = v_order_id;

    UPDATE public.notification_payment_signals
       SET consumed = true, matched_order_id = v_order_id
     WHERE id = v_signal_ids[i];

    INSERT INTO public.payment_verifications (order_id, submitted_utr, matched, verified_by, matched_via)
    VALUES (v_order_id, '', true, 'system', 'notification_auto');

    INSERT INTO public.payment_audit_log (order_id, matched_via, signal_ids)
    VALUES (v_order_id, 'notification_auto', ARRAY[v_signal_ids[i]]);

    PERFORM public.activate_subscription_from_order(v_order_id);
  END LOOP;
END;
$$;

CREATE OR REPLACE FUNCTION public.on_payment_signal_insert()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $$
BEGIN
  PERFORM public.try_auto_match_payment_signal(NEW.id);
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trg_payment_signal_auto_match ON public.notification_payment_signals;
CREATE TRIGGER trg_payment_signal_auto_match
AFTER INSERT ON public.notification_payment_signals
FOR EACH ROW EXECUTE FUNCTION public.on_payment_signal_insert();
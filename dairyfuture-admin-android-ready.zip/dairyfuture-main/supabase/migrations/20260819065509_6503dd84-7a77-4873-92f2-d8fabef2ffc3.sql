-- Re-grant EXECUTE to authenticated for RLS-internal helper functions.
-- These are called inside the USING clauses of many RLS policies,
-- and policy evaluation runs under the authenticated role.
-- anon/PUBLIC direct execution remains blocked.

GRANT EXECUTE ON FUNCTION public.get_user_dairy_id(uuid) TO authenticated;
GRANT EXECUTE ON FUNCTION public.get_supplier_dairy_id(uuid) TO authenticated;
ALTER TABLE public.owner_settings
  ADD COLUMN IF NOT EXISTS entry_receipt_fields jsonb,
  ADD COLUMN IF NOT EXISTS bhugtan_receipt_fields jsonb;
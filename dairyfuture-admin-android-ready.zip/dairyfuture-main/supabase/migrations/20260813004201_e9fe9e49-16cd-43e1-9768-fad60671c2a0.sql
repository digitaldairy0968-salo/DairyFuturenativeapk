-- 1) Dairy config bootstrap (fresh-login only, one call for 3 tables)
CREATE OR REPLACE FUNCTION public.get_dairy_config_bootstrap()
RETURNS jsonb
LANGUAGE plpgsql
STABLE SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_uid uuid := auth.uid();
  v_dairy_id uuid;
BEGIN
  IF v_uid IS NULL THEN RETURN NULL; END IF;

  SELECT d.id INTO v_dairy_id FROM public.dairies d WHERE d.owner_id = v_uid LIMIT 1;
  IF v_dairy_id IS NULL THEN
    SELECT s.dairy_id INTO v_dairy_id FROM public.suppliers s
    WHERE s.user_id = v_uid ORDER BY s.created_at DESC LIMIT 1;
  END IF;
  IF v_dairy_id IS NULL THEN RETURN NULL; END IF;

  RETURN jsonb_build_object(
    'dairy_id', v_dairy_id,
    'rate_settings', (SELECT to_jsonb(r) FROM public.rate_settings r WHERE r.dairy_id = v_dairy_id LIMIT 1),
    'fat_snf_rate_settings', (SELECT to_jsonb(f) FROM public.fat_snf_rate_settings f WHERE f.dairy_id = v_dairy_id LIMIT 1),
    'owner_settings', (SELECT to_jsonb(o) FROM public.owner_settings o WHERE o.dairy_id = v_dairy_id LIMIT 1)
  );
END;
$$;

REVOKE ALL ON FUNCTION public.get_dairy_config_bootstrap() FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.get_dairy_config_bootstrap() TO authenticated;

-- 2) Reopen status: subscription + features + (conditional) dairy code
CREATE OR REPLACE FUNCTION public.get_reopen_status()
RETURNS jsonb
LANGUAGE plpgsql
STABLE SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_uid uuid := auth.uid();
  v_dairy_id uuid;
  v_code text;
  v_features jsonb := '{}'::jsonb;
  v_sub jsonb;
  v_code_enabled boolean := false;
BEGIN
  IF v_uid IS NULL THEN RETURN NULL; END IF;

  SELECT d.id, d.code INTO v_dairy_id, v_code
  FROM public.dairies d WHERE d.owner_id = v_uid LIMIT 1;

  IF v_dairy_id IS NULL THEN
    SELECT s.dairy_id INTO v_dairy_id FROM public.suppliers s
    WHERE s.user_id = v_uid ORDER BY s.created_at DESC LIMIT 1;
    IF v_dairy_id IS NOT NULL THEN
      SELECT d.code INTO v_code FROM public.dairies d WHERE d.id = v_dairy_id;
    END IF;
  END IF;

  IF v_dairy_id IS NULL THEN RETURN NULL; END IF;

  SELECT COALESCE(jsonb_object_agg(f.feature_key, f.is_enabled), '{}'::jsonb)
    INTO v_features
  FROM public.dairy_features f WHERE f.dairy_id = v_dairy_id;

  v_code_enabled := COALESCE((v_features->>'customer_code')::boolean, false);

  SELECT jsonb_build_object('status', s.status, 'expires_at', s.expires_at)
    INTO v_sub
  FROM public.subscriptions s
  WHERE s.dairy_id = v_dairy_id
  ORDER BY (s.status = 'active') DESC, s.created_at DESC
  LIMIT 1;

  RETURN jsonb_build_object(
    'dairy_id', v_dairy_id,
    'subscription', v_sub,
    'features', v_features,
    'dairy_code', CASE WHEN v_code_enabled THEN v_code ELSE NULL END
  );
END;
$$;

REVOKE ALL ON FUNCTION public.get_reopen_status() FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.get_reopen_status() TO authenticated;

-- 3) Auth bootstrap: include owner_phone (login-time only)
CREATE OR REPLACE FUNCTION public.get_auth_bootstrap()
RETURNS jsonb
LANGUAGE plpgsql
STABLE SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_uid uuid := auth.uid();
  v_profile jsonb;
  v_role text;
  v_dairy jsonb;
  v_supplier jsonb;
  v_owner_phone text := '';
  v_owner_id uuid;
BEGIN
  IF v_uid IS NULL THEN
    RETURN NULL;
  END IF;

  SELECT to_jsonb(p) INTO v_profile
  FROM public.profiles p
  WHERE p.user_id = v_uid
  LIMIT 1;

  SELECT role::text INTO v_role
  FROM public.user_roles
  WHERE user_id = v_uid
  ORDER BY CASE role::text
    WHEN 'admin' THEN 1
    WHEN 'owner' THEN 2
    WHEN 'supplier' THEN 3
    ELSE 4
  END
  LIMIT 1;

  IF v_role = 'owner' THEN
    SELECT jsonb_build_object('id', d.id, 'name', d.name, 'code', d.code), d.owner_id
    INTO v_dairy, v_owner_id
    FROM public.dairies d
    WHERE d.owner_id = v_uid
    LIMIT 1;
  END IF;

  IF v_role = 'supplier' OR (v_role IS NULL) THEN
    SELECT jsonb_build_object(
      'id', s.id,
      'dairy_id', s.dairy_id,
      'name', s.name,
      'phone', s.phone,
      'dairy_name', d.name,
      'dairy_code', d.code
    ), d.owner_id
    INTO v_supplier, v_owner_id
    FROM public.suppliers s
    LEFT JOIN public.dairies d ON d.id = s.dairy_id
    WHERE s.user_id = v_uid
    ORDER BY s.created_at DESC
    LIMIT 1;
  END IF;

  IF v_owner_id IS NOT NULL THEN
    SELECT COALESCE(pr.phone, '') INTO v_owner_phone
    FROM public.profiles pr WHERE pr.user_id = v_owner_id LIMIT 1;
  END IF;

  RETURN jsonb_build_object(
    'profile', v_profile,
    'role', v_role,
    'dairy', v_dairy,
    'supplier', v_supplier,
    'owner_phone', COALESCE(v_owner_phone, '')
  );
END;
$$;

REVOKE ALL ON FUNCTION public.get_auth_bootstrap() FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.get_auth_bootstrap() TO authenticated;
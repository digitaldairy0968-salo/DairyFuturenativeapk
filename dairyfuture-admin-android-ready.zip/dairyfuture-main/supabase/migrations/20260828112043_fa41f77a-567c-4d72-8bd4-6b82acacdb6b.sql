ALTER TABLE public.subscription_varieties
  ADD COLUMN IF NOT EXISTS updated_at timestamptz NOT NULL DEFAULT now();

ALTER TABLE public.variety_plans
  ADD COLUMN IF NOT EXISTS updated_at timestamptz NOT NULL DEFAULT now();

DROP TRIGGER IF EXISTS set_updated_at ON public.subscription_varieties;
CREATE TRIGGER set_updated_at
BEFORE UPDATE ON public.subscription_varieties
FOR EACH ROW EXECUTE FUNCTION public.update_updated_at();

DROP TRIGGER IF EXISTS set_updated_at ON public.variety_plans;
CREATE TRIGGER set_updated_at
BEFORE UPDATE ON public.variety_plans
FOR EACH ROW EXECUTE FUNCTION public.update_updated_at();
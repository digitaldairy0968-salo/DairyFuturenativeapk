-- 1) Replace SECURITY DEFINER view with a definer function (only exposes the public auth-page image)
DROP VIEW IF EXISTS public.auth_page_image;

CREATE OR REPLACE FUNCTION public.get_auth_page_image()
RETURNS text
LANGUAGE sql
STABLE SECURITY DEFINER
SET search_path = public
AS $$
  SELECT auth_page_image_url FROM public.subscription_settings LIMIT 1
$$;
REVOKE ALL ON FUNCTION public.get_auth_page_image() FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.get_auth_page_image() TO anon, authenticated;

-- 2) subscription_settings: no direct table reads; access only via definer RPCs
DROP POLICY IF EXISTS "Authenticated users can read subscription settings" ON public.subscription_settings;
REVOKE SELECT ON public.subscription_settings FROM anon, authenticated;

-- 3) qr-codes bucket: restrict reads to admins and dairy owners (who need the payment QR)
DROP POLICY IF EXISTS "Authenticated read qr-codes" ON storage.objects;
CREATE POLICY "Admins and dairy owners read qr-codes"
ON storage.objects FOR SELECT TO authenticated
USING (
  bucket_id = 'qr-codes'
  AND (
    public.is_admin(auth.uid())
    OR EXISTS (SELECT 1 FROM public.dairies d WHERE d.owner_id = auth.uid())
  )
);

-- 4) Revoke EXECUTE from anon/PUBLIC on SECURITY DEFINER functions that require a session
REVOKE ALL ON FUNCTION public.activate_demo_subscription(uuid) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.activate_demo_subscription(uuid) TO authenticated;

REVOKE ALL ON FUNCTION public.apply_referral_reward(uuid) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.apply_referral_reward(uuid) TO authenticated;

REVOKE ALL ON FUNCTION public.confirm_supplier_payment(uuid) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.confirm_supplier_payment(uuid) TO authenticated;

REVOKE ALL ON FUNCTION public.confirm_supplier_payment(uuid, boolean) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.confirm_supplier_payment(uuid, boolean) TO authenticated;

REVOKE ALL ON FUNCTION public.get_admin_payment_contact() FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.get_admin_payment_contact() TO authenticated;

REVOKE ALL ON FUNCTION public.get_settings_bootstrap() FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.get_settings_bootstrap() TO authenticated;

REVOKE ALL ON FUNCTION public.purchase_plan_with_coins(uuid, uuid) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.purchase_plan_with_coins(uuid, uuid) TO authenticated;

REVOKE ALL ON FUNCTION public.link_supplier_to_dairy_by_code(text) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.link_supplier_to_dairy_by_code(text) TO authenticated;

REVOKE ALL ON FUNCTION public.get_app_bootstrap() FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.get_app_bootstrap() TO authenticated;

REVOKE ALL ON FUNCTION public.get_subscription_settings_admin() FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.get_subscription_settings_admin() TO authenticated;

-- 5) Internal helper definer functions: not callable from the API at all
REVOKE ALL ON FUNCTION public.has_role(uuid, public.app_role) FROM PUBLIC, anon, authenticated;
REVOKE ALL ON FUNCTION public.is_admin(uuid) FROM PUBLIC, anon, authenticated;
REVOKE ALL ON FUNCTION public.get_user_dairy_id(uuid) FROM PUBLIC, anon, authenticated;
REVOKE ALL ON FUNCTION public.get_supplier_dairy_id(uuid) FROM PUBLIC, anon, authenticated;
REVOKE ALL ON FUNCTION public.rls_auto_enable() FROM PUBLIC, anon, authenticated;

-- 6) Pre-login helpers stay callable by anon but not by PUBLIC implicitly
REVOKE ALL ON FUNCTION public.check_dairy_code_exists(text) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.check_dairy_code_exists(text) TO anon, authenticated;
REVOKE ALL ON FUNCTION public.get_dairy_by_code(text) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.get_dairy_by_code(text) TO anon, authenticated;
REVOKE ALL ON FUNCTION public.phone_exists(text) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.phone_exists(text) TO anon, authenticated;
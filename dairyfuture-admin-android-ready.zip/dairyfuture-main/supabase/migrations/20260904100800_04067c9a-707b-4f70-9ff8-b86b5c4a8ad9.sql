DROP FUNCTION IF EXISTS public.check_signup_ip_limit(integer, integer, integer);
DROP FUNCTION IF EXISTS public.check_and_record_rate_limit(text, text, integer, integer, integer);
DROP FUNCTION IF EXISTS public.reset_rate_limit(text, text);
DROP TABLE IF EXISTS public.auth_rate_limits;
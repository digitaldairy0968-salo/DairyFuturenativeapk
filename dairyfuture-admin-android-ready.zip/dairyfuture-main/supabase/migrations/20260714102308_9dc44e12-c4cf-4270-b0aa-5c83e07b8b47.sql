-- Add updated_at column + auto-update trigger to tables missing it,
-- so delta-sync (.gt('updated_at', lastSync)) can work across the app.

-- 1) announcements
ALTER TABLE public.announcements
  ADD COLUMN IF NOT EXISTS updated_at timestamptz NOT NULL DEFAULT now();

DROP TRIGGER IF EXISTS trg_announcements_updated_at ON public.announcements;
CREATE TRIGGER trg_announcements_updated_at
BEFORE UPDATE ON public.announcements
FOR EACH ROW EXECUTE FUNCTION public.update_updated_at();

-- 2) payment_history
ALTER TABLE public.payment_history
  ADD COLUMN IF NOT EXISTS updated_at timestamptz NOT NULL DEFAULT now();

DROP TRIGGER IF EXISTS trg_payment_history_updated_at ON public.payment_history;
CREATE TRIGGER trg_payment_history_updated_at
BEFORE UPDATE ON public.payment_history
FOR EACH ROW EXECUTE FUNCTION public.update_updated_at();

-- 3) notifications
ALTER TABLE public.notifications
  ADD COLUMN IF NOT EXISTS updated_at timestamptz NOT NULL DEFAULT now();

DROP TRIGGER IF EXISTS trg_notifications_updated_at ON public.notifications;
CREATE TRIGGER trg_notifications_updated_at
BEFORE UPDATE ON public.notifications
FOR EACH ROW EXECUTE FUNCTION public.update_updated_at();

-- Indexes to make delta queries fast (skip if already exist).
CREATE INDEX IF NOT EXISTS idx_announcements_dairy_updated
  ON public.announcements (dairy_id, updated_at);
CREATE INDEX IF NOT EXISTS idx_payment_history_supplier_updated
  ON public.payment_history (supplier_id, updated_at);
CREATE INDEX IF NOT EXISTS idx_payment_history_dairy_updated
  ON public.payment_history (dairy_id, updated_at);
CREATE INDEX IF NOT EXISTS idx_notifications_user_updated
  ON public.notifications (user_id, updated_at);
ALTER TABLE public.owner_settings
ADD COLUMN IF NOT EXISTS voice_supplier_select_enabled boolean NOT NULL DEFAULT true;
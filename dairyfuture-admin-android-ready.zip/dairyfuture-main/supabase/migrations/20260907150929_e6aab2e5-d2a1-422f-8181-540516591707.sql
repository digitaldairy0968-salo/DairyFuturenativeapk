
-- Keep: admin (474a80a2), JBN DAIRY owner (42c7fd79), JBN linked supplier user (3f86b1a7)
-- Keep dairy: 4aa62c79-7f28-41ca-8c3b-177f903329a3

CREATE TEMP TABLE _keep_users(id uuid);
INSERT INTO _keep_users VALUES
  ('474a80a2-3355-428c-a459-016dfddd1d96'),
  ('42c7fd79-b301-421f-8470-03432c36d45c'),
  ('3f86b1a7-4f93-49f3-a1c2-c81a59402210');

CREATE TEMP TABLE _del_dairies(id uuid);
INSERT INTO _del_dairies SELECT id FROM public.dairies WHERE id <> '4aa62c79-7f28-41ca-8c3b-177f903329a3';

-- detach signal/sms references to orders that will be deleted
UPDATE public.notification_payment_signals SET matched_order_id = NULL
 WHERE matched_order_id IN (SELECT id FROM public.payment_orders WHERE dairy_id IN (SELECT id FROM _del_dairies));
UPDATE public.sms_inbox SET matched_order_id = NULL
 WHERE matched_order_id IN (SELECT id FROM public.payment_orders WHERE dairy_id IN (SELECT id FROM _del_dairies));

DELETE FROM public.payment_verifications
 WHERE order_id IN (SELECT id FROM public.payment_orders WHERE dairy_id IN (SELECT id FROM _del_dairies));
DELETE FROM public.entry_edit_requests WHERE dairy_id IN (SELECT id FROM _del_dairies);
DELETE FROM public.milk_entries WHERE dairy_id IN (SELECT id FROM _del_dairies);
DELETE FROM public.payment_history WHERE dairy_id IN (SELECT id FROM _del_dairies);
DELETE FROM public.notifications WHERE dairy_id IN (SELECT id FROM _del_dairies);
DELETE FROM public.coin_transactions WHERE dairy_id IN (SELECT id FROM _del_dairies);
DELETE FROM public.digital_coins WHERE dairy_id IN (SELECT id FROM _del_dairies);
DELETE FROM public.dairy_features WHERE dairy_id IN (SELECT id FROM _del_dairies);
DELETE FROM public.fat_snf_rate_settings WHERE dairy_id IN (SELECT id FROM _del_dairies);
DELETE FROM public.owner_settings WHERE dairy_id IN (SELECT id FROM _del_dairies);
DELETE FROM public.rate_settings WHERE dairy_id IN (SELECT id FROM _del_dairies);
DELETE FROM public.subscriptions WHERE dairy_id IN (SELECT id FROM _del_dairies);
DELETE FROM public.payment_orders WHERE dairy_id IN (SELECT id FROM _del_dairies);
DELETE FROM public.suppliers WHERE dairy_id IN (SELECT id FROM _del_dairies);
DELETE FROM public.dairies WHERE id IN (SELECT id FROM _del_dairies);

-- suppliers of JBN linked to users we are deleting: unlink instead of delete
UPDATE public.suppliers SET user_id = NULL
 WHERE user_id IS NOT NULL AND user_id NOT IN (SELECT id FROM _keep_users);

DELETE FROM public.referrals
 WHERE referrer_user_id NOT IN (SELECT id FROM _keep_users)
    OR referred_user_id NOT IN (SELECT id FROM _keep_users);
DELETE FROM public.user_roles WHERE user_id NOT IN (SELECT id FROM _keep_users);
DELETE FROM public.profiles WHERE user_id NOT IN (SELECT id FROM _keep_users);

DELETE FROM auth.users WHERE id NOT IN (SELECT id FROM _keep_users);

-- admin audit: also expose chosen plan + variety
DROP FUNCTION IF EXISTS public.admin_list_payment_audit(integer);

CREATE OR REPLACE FUNCTION public.admin_list_payment_audit(_limit integer DEFAULT 200)
 RETURNS TABLE(order_id uuid, order_ref text, amount numeric, status text, utr_submitted text,
   matched_via text, submitted_at timestamp with time zone, dairy_id uuid, dairy_name text,
   user_name text, user_phone text, subscription_status text,
   subscription_expires_at timestamp with time zone,
   plan_name text, plan_validity_days integer, variety_name text)
 LANGUAGE sql
 STABLE SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
  SELECT o.id,
         o.order_ref,
         o.amount,
         o.status,
         o.utr_submitted,
         COALESCE(o.verification_method, 'unknown'),
         COALESCE(
           (SELECT max(v.verified_at) FROM public.payment_verifications v WHERE v.order_id = o.id),
           o.updated_at
         ),
         o.dairy_id,
         d.name,
         p.name,
         p.phone,
         s.status,
         s.expires_at,
         vp.name,
         vp.validity_days,
         sv.name
  FROM public.payment_orders o
  LEFT JOIN public.dairies d ON d.id = o.dairy_id
  LEFT JOIN public.profiles p ON p.user_id = o.user_id
  LEFT JOIN public.subscriptions s ON s.dairy_id = o.dairy_id
  LEFT JOIN public.variety_plans vp ON vp.id = o.variety_plan_id
  LEFT JOIN public.subscription_varieties sv ON sv.id = vp.variety_id
  WHERE public.is_admin(auth.uid())
  ORDER BY o.created_at DESC
  LIMIT COALESCE(_limit, 200)
$function$;

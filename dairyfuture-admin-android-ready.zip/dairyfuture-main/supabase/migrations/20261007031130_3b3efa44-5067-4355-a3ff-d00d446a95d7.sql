CREATE OR REPLACE FUNCTION public.try_auto_match_payment_signal(p_signal_id uuid)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $$
DECLARE
  v_amount numeric;
  v_n integer;
  v_m integer;
  v_signal_ids uuid[];
  v_order_ids uuid[];
  v_order_id uuid;
BEGIN
  SELECT amount INTO v_amount
  FROM public.notification_payment_signals
  WHERE id = p_signal_id;

  IF v_amount IS NULL THEN
    RETURN;
  END IF;

  WITH locked_orders AS (
    SELECT o.id, o.created_at
    FROM public.payment_orders o
    WHERE o.amount = v_amount
      AND o.status IN ('created', 'awaiting_utr')
      AND o.pay_clicked_at IS NOT NULL
      AND o.expires_at > now()
    ORDER BY o.created_at
    FOR UPDATE
  )
  SELECT array_agg(id ORDER BY created_at) INTO v_order_ids FROM locked_orders;

  v_n := COALESCE(array_length(v_order_ids, 1), 0);
  IF v_n = 0 THEN
    RETURN;
  END IF;

  WITH locked_signals AS (
    SELECT s.id, s.received_at
    FROM public.notification_payment_signals s
    WHERE s.amount = v_amount
      AND s.consumed = false
      AND s.received_at > now() - interval '15 minutes'
    ORDER BY s.received_at
    FOR UPDATE
  )
  SELECT array_agg(id ORDER BY received_at) INTO v_signal_ids FROM locked_signals;

  v_m := COALESCE(array_length(v_signal_ids, 1), 0);

  IF v_m < v_n THEN
    RETURN;
  END IF;

  FOR i IN 1..v_n LOOP
    v_order_id := v_order_ids[i];

    UPDATE public.payment_orders
       SET status = 'success',
           verification_method = 'notification_auto',
           updated_at = now()
     WHERE id = v_order_id;

    UPDATE public.notification_payment_signals
       SET consumed = true, matched_order_id = v_order_id
     WHERE id = v_signal_ids[i];

    INSERT INTO public.payment_verifications (order_id, submitted_utr, matched, verified_by, matched_via)
    VALUES (v_order_id, '', true, 'system', 'notification_auto');

    INSERT INTO public.payment_audit_log (order_id, matched_via, signal_ids)
    VALUES (v_order_id, 'notification_auto', ARRAY[v_signal_ids[i]]);

    PERFORM public.activate_subscription_from_order(v_order_id);
  END LOOP;
END;
$$;
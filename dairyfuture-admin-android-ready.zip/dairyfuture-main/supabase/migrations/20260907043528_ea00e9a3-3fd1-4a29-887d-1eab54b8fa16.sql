ALTER TABLE public.payment_verifications ADD COLUMN IF NOT EXISTS matched_via text;

UPDATE public.payment_verifications
SET matched_via = CASE
  WHEN verified_by IN ('sms', 'notification_fallback') THEN 'notification_auto'
  WHEN verified_by = 'admin' THEN 'admin_review'
  ELSE verified_by END
WHERE matched_via IS NULL;

CREATE OR REPLACE FUNCTION public.submit_payment_utr(_order_id uuid, _utr text)
 RETURNS TABLE(status text, matched boolean)
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
DECLARE
  v_uid uuid := auth.uid();
  v_order RECORD;
  v_utr text;
BEGIN
  IF v_uid IS NULL THEN
    RAISE EXCEPTION 'not_authenticated';
  END IF;

  v_utr := upper(regexp_replace(COALESCE(_utr, ''), '\s', '', 'g'));
  IF v_utr !~ '^[A-Z0-9]{8,24}$' THEN
    RAISE EXCEPTION 'invalid_utr';
  END IF;

  SELECT * INTO v_order FROM public.payment_orders WHERE id = _order_id FOR UPDATE;
  IF NOT FOUND THEN
    RAISE EXCEPTION 'order_not_found';
  END IF;

  IF v_order.user_id <> v_uid THEN
    RAISE EXCEPTION 'not_order_owner';
  END IF;

  IF v_order.status = 'success' THEN
    RETURN QUERY SELECT 'success'::text, true; RETURN;
  END IF;

  IF v_order.expires_at < now() AND v_order.status IN ('created', 'awaiting_utr') THEN
    UPDATE public.payment_orders SET status = 'expired' WHERE id = v_order.id;
    RAISE EXCEPTION 'order_expired';
  END IF;

  -- duplicate-UTR sanity check stays
  IF EXISTS (
    SELECT 1 FROM public.payment_orders
    WHERE utr_submitted = v_utr AND id <> v_order.id AND status IN ('verifying', 'success')
  ) THEN
    RAISE EXCEPTION 'duplicate_utr';
  END IF;

  -- No SMS / notification matching gate any more: accept immediately, audit it.
  UPDATE public.payment_orders
    SET status = 'success', utr_submitted = v_utr, verification_method = 'manual_utr_unverified'
  WHERE id = v_order.id;

  INSERT INTO public.payment_verifications (order_id, submitted_utr, matched, verified_by, matched_via)
  VALUES (v_order.id, v_utr, false, 'user', 'manual_utr_unverified');

  PERFORM public.activate_subscription_from_order(v_order.id);

  RETURN QUERY SELECT 'success'::text, true;
END;
$function$;

REVOKE ALL ON FUNCTION public.submit_payment_utr(uuid, text) FROM anon;
GRANT EXECUTE ON FUNCTION public.submit_payment_utr(uuid, text) TO authenticated;

CREATE OR REPLACE FUNCTION public.admin_list_payment_audit(_limit integer DEFAULT 200)
 RETURNS TABLE(
   order_id uuid,
   order_ref text,
   amount numeric,
   status text,
   utr_submitted text,
   matched_via text,
   submitted_at timestamptz,
   dairy_id uuid,
   dairy_name text,
   user_name text,
   user_phone text,
   subscription_status text,
   subscription_expires_at timestamptz
 )
 LANGUAGE sql
 STABLE SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
  SELECT o.id,
         o.order_ref,
         o.amount,
         o.status,
         o.utr_submitted,
         COALESCE(o.verification_method, 'unknown'),
         COALESCE(
           (SELECT max(v.verified_at) FROM public.payment_verifications v WHERE v.order_id = o.id),
           o.updated_at
         ),
         o.dairy_id,
         d.name,
         p.name,
         p.phone,
         s.status,
         s.expires_at
  FROM public.payment_orders o
  LEFT JOIN public.dairies d ON d.id = o.dairy_id
  LEFT JOIN public.profiles p ON p.user_id = o.user_id
  LEFT JOIN public.subscriptions s ON s.dairy_id = o.dairy_id
  WHERE public.is_admin(auth.uid())
  ORDER BY o.created_at DESC
  LIMIT COALESCE(_limit, 200)
$function$;

REVOKE ALL ON FUNCTION public.admin_list_payment_audit(integer) FROM anon;
GRANT EXECUTE ON FUNCTION public.admin_list_payment_audit(integer) TO authenticated;

CREATE OR REPLACE FUNCTION public.admin_revoke_subscription(_dairy_id uuid, _order_id uuid DEFAULT NULL)
 RETURNS boolean
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
DECLARE
  v_uid uuid := auth.uid();
BEGIN
  IF v_uid IS NULL THEN
    RAISE EXCEPTION 'not_authenticated';
  END IF;
  IF NOT public.is_admin(v_uid) THEN
    RAISE EXCEPTION 'not_admin';
  END IF;

  UPDATE public.subscriptions
    SET status = 'expired', expires_at = now(), updated_at = now()
  WHERE dairy_id = _dairy_id;

  UPDATE public.dairy_features
    SET is_enabled = false, updated_at = now()
  WHERE dairy_id = _dairy_id AND feature_key = 'customer_code';

  IF _order_id IS NOT NULL THEN
    UPDATE public.payment_orders SET status = 'failed', updated_at = now() WHERE id = _order_id;
    INSERT INTO public.payment_verifications (order_id, submitted_utr, matched, verified_by, matched_via)
    SELECT o.id, COALESCE(o.utr_submitted, ''), false, 'admin', 'admin_revoked'
    FROM public.payment_orders o WHERE o.id = _order_id;
  END IF;

  RETURN true;
END;
$function$;

REVOKE ALL ON FUNCTION public.admin_revoke_subscription(uuid, uuid) FROM anon;
GRANT EXECUTE ON FUNCTION public.admin_revoke_subscription(uuid, uuid) TO authenticated;
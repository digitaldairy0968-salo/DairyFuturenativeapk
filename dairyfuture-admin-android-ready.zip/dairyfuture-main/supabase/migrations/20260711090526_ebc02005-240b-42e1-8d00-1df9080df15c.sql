
-- 1) subscription_settings: remove anon full-row read; expose only auth image via a view
DROP POLICY IF EXISTS "Anon can read auth page image" ON public.subscription_settings;

CREATE OR REPLACE VIEW public.auth_page_image AS
  SELECT auth_page_image_url FROM public.subscription_settings LIMIT 1;

GRANT SELECT ON public.auth_page_image TO anon, authenticated;

-- 2) Storage: drop broad list-enabling SELECT policies. Public buckets still serve files via public URLs.
DROP POLICY IF EXISTS "Anyone can read QR codes" ON storage.objects;
DROP POLICY IF EXISTS "Anyone can read auth images" ON storage.objects;

-- 3) Revoke EXECUTE on internal SECURITY DEFINER functions (triggers + RLS helpers)
REVOKE EXECUTE ON FUNCTION public.handle_new_user() FROM PUBLIC, anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.update_updated_at() FROM PUBLIC, anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.auto_create_dairy_defaults() FROM PUBLIC, anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.notify_supplier_on_entry_change() FROM PUBLIC, anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.notify_supplier_on_payment() FROM PUBLIC, anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.track_referral() FROM PUBLIC, anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.notify_supplier_on_edit_request() FROM PUBLIC, anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.apply_approved_edit_request() FROM PUBLIC, anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.enforce_supplier_limit() FROM PUBLIC, anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.enforce_milk_entry_limit() FROM PUBLIC, anon, authenticated;

REVOKE EXECUTE ON FUNCTION public.has_role(uuid, public.app_role) FROM PUBLIC, anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.is_admin(uuid) FROM PUBLIC, anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.get_user_dairy_id(uuid) FROM PUBLIC, anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.get_supplier_dairy_id(uuid) FROM PUBLIC, anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.is_supplier_within_limit(uuid) FROM PUBLIC, anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.get_dairy_customer_limit(uuid) FROM PUBLIC, anon, authenticated;


DROP VIEW IF EXISTS public.auth_page_image;
CREATE VIEW public.auth_page_image
  WITH (security_invoker = true) AS
  SELECT auth_page_image_url FROM public.subscription_settings LIMIT 1;
GRANT SELECT ON public.auth_page_image TO anon, authenticated;

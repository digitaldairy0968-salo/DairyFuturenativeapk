REVOKE ALL ON FUNCTION public.try_auto_match_payment_signal(uuid) FROM anon, authenticated, PUBLIC;
REVOKE ALL ON FUNCTION public.on_payment_signal_insert() FROM anon, authenticated, PUBLIC;
GRANT EXECUTE ON FUNCTION public.try_auto_match_payment_signal(uuid) TO service_role;
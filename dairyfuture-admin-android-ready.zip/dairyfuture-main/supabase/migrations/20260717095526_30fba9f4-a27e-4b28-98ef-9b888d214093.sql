
CREATE OR REPLACE FUNCTION public.get_auth_bootstrap()
RETURNS jsonb
LANGUAGE plpgsql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_uid uuid := auth.uid();
  v_profile jsonb;
  v_role text;
  v_dairy jsonb;
  v_supplier jsonb;
BEGIN
  IF v_uid IS NULL THEN
    RETURN NULL;
  END IF;

  SELECT to_jsonb(p) INTO v_profile
  FROM public.profiles p
  WHERE p.user_id = v_uid
  LIMIT 1;

  -- Highest-priority role: admin > owner > supplier
  SELECT role::text INTO v_role
  FROM public.user_roles
  WHERE user_id = v_uid
  ORDER BY CASE role::text
    WHEN 'admin' THEN 1
    WHEN 'owner' THEN 2
    WHEN 'supplier' THEN 3
    ELSE 4
  END
  LIMIT 1;

  IF v_role = 'owner' THEN
    SELECT jsonb_build_object('id', d.id, 'name', d.name, 'code', d.code)
    INTO v_dairy
    FROM public.dairies d
    WHERE d.owner_id = v_uid
    LIMIT 1;
  END IF;

  IF v_role = 'supplier' OR (v_role IS NULL) THEN
    SELECT jsonb_build_object(
      'id', s.id,
      'dairy_id', s.dairy_id,
      'name', s.name,
      'phone', s.phone,
      'dairy_name', d.name,
      'dairy_code', d.code
    )
    INTO v_supplier
    FROM public.suppliers s
    LEFT JOIN public.dairies d ON d.id = s.dairy_id
    WHERE s.user_id = v_uid
    ORDER BY s.created_at DESC
    LIMIT 1;
  END IF;

  RETURN jsonb_build_object(
    'profile', v_profile,
    'role', v_role,
    'dairy', v_dairy,
    'supplier', v_supplier
  );
END;
$$;

GRANT EXECUTE ON FUNCTION public.get_auth_bootstrap() TO authenticated;

CREATE OR REPLACE FUNCTION public.admin_save_subscription_settings(p_patch jsonb)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_id uuid;
BEGIN
  IF NOT public.is_admin(auth.uid()) THEN
    RAISE EXCEPTION 'not authorized';
  END IF;

  SELECT id INTO v_id FROM public.subscription_settings ORDER BY created_at LIMIT 1;

  IF v_id IS NULL THEN
    INSERT INTO public.subscription_settings (monthly_price, upi_id, admin_phone)
    VALUES (
      COALESCE((p_patch->>'monthly_price')::numeric, 100),
      COALESCE(p_patch->>'upi_id', ''),
      COALESCE(p_patch->>'admin_phone', '')
    )
    RETURNING id INTO v_id;
  END IF;

  UPDATE public.subscription_settings SET
    monthly_price = COALESCE((p_patch->>'monthly_price')::numeric, monthly_price),
    upi_id = COALESCE(p_patch->>'upi_id', upi_id),
    admin_phone = COALESCE(p_patch->>'admin_phone', admin_phone),
    youtube_url = CASE WHEN p_patch ? 'youtube_url' THEN NULLIF(p_patch->>'youtube_url','') ELSE youtube_url END,
    qr_code_url = CASE WHEN p_patch ? 'qr_code_url' THEN NULLIF(p_patch->>'qr_code_url','') ELSE qr_code_url END,
    auth_page_image_url = CASE WHEN p_patch ? 'auth_page_image_url' THEN NULLIF(p_patch->>'auth_page_image_url','') ELSE auth_page_image_url END,
    default_validity_days = COALESCE((p_patch->>'default_validity_days')::int, default_validity_days),
    demo_days = COALESCE((p_patch->>'demo_days')::int, demo_days),
    updated_at = now()
  WHERE id = v_id;
END;
$$;

REVOKE ALL ON FUNCTION public.admin_save_subscription_settings(jsonb) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.admin_save_subscription_settings(jsonb) TO authenticated;
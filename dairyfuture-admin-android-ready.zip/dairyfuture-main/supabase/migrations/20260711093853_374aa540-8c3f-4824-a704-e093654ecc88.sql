
-- Restore EXECUTE on RLS helper functions. These are invoked inside RLS policies
-- by the querying role; revoking EXECUTE broke dairy creation and other flows.
GRANT EXECUTE ON FUNCTION public.has_role(uuid, app_role) TO authenticated, anon;
GRANT EXECUTE ON FUNCTION public.is_admin(uuid) TO authenticated, anon;
GRANT EXECUTE ON FUNCTION public.get_user_dairy_id(uuid) TO authenticated, anon;
GRANT EXECUTE ON FUNCTION public.get_supplier_dairy_id(uuid) TO authenticated, anon;
GRANT EXECUTE ON FUNCTION public.is_supplier_within_limit(uuid) TO authenticated, anon;
GRANT EXECUTE ON FUNCTION public.get_dairy_customer_limit(uuid) TO authenticated, anon;

-- Ensure update_updated_at() trigger function exists (already does per db-functions)
-- Attach BEFORE UPDATE triggers so client-side updates bump updated_at automatically,
-- enabling delta-sync (fetch only rows where updated_at > lastSync).

DO $$
DECLARE
  t text;
  tables text[] := ARRAY[
    'suppliers','milk_entries','announcements','payment_history',
    'rate_settings','owner_settings','fat_snf_rate_settings',
    'dairies','dairy_features','subscriptions','notifications'
  ];
BEGIN
  FOREACH t IN ARRAY tables LOOP
    -- Drop if exists (idempotent)
    EXECUTE format('DROP TRIGGER IF EXISTS set_updated_at ON public.%I', t);
    EXECUTE format(
      'CREATE TRIGGER set_updated_at BEFORE UPDATE ON public.%I FOR EACH ROW EXECUTE FUNCTION public.update_updated_at()',
      t
    );
  END LOOP;
END $$;
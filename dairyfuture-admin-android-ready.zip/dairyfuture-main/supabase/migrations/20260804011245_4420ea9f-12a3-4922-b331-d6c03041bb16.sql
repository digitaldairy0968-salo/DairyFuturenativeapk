CREATE OR REPLACE FUNCTION public.get_app_bootstrap()
RETURNS jsonb
LANGUAGE plpgsql
STABLE
SECURITY DEFINER
SET search_path TO 'public'
AS $function$
BEGIN
  IF auth.uid() IS NULL THEN
    RETURN NULL;
  END IF;

  RETURN jsonb_build_object(
    'auth', public.get_auth_bootstrap(),
    'settings', public.get_settings_bootstrap()
  );
END;
$function$;

REVOKE ALL ON FUNCTION public.get_app_bootstrap() FROM anon;
GRANT EXECUTE ON FUNCTION public.get_app_bootstrap() TO authenticated;
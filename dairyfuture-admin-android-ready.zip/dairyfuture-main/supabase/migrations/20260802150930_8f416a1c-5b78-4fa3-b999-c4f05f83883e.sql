CREATE OR REPLACE FUNCTION public.confirm_supplier_payment(_payment_id uuid, _confirmed boolean)
 RETURNS boolean
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
DECLARE
  v_payment RECORD;
  v_new_balance numeric;
BEGIN
  IF auth.uid() IS NULL THEN
    RAISE EXCEPTION 'not_authenticated';
  END IF;

  SELECT ph.* INTO v_payment
  FROM public.payment_history ph
  WHERE ph.id = _payment_id
    AND EXISTS (
      SELECT 1 FROM public.suppliers s
      WHERE s.id = ph.supplier_id AND s.user_id = auth.uid()
    )
  FOR UPDATE;

  IF NOT FOUND THEN
    RAISE EXCEPTION 'payment_not_found_or_not_authorized';
  END IF;

  -- already responded: idempotent, do not double-deduct
  IF v_payment.supplier_confirmed IS NOT NULL THEN
    RETURN true;
  END IF;

  UPDATE public.payment_history
  SET supplier_confirmed = _confirmed, confirmed_at = now()
  WHERE id = _payment_id;

  IF _confirmed AND COALESCE(v_payment.amount_paid, 0) > 0 THEN
    UPDATE public.suppliers
    SET pending_balance = COALESCE(pending_balance, 0) - COALESCE(v_payment.amount_paid, 0),
        updated_at = now()
    WHERE id = v_payment.supplier_id
    RETURNING pending_balance INTO v_new_balance;

    UPDATE public.payment_history
    SET balance_after = v_new_balance
    WHERE id = _payment_id;
  END IF;

  RETURN true;
END;
$function$;

REVOKE ALL ON FUNCTION public.confirm_supplier_payment(uuid, boolean) FROM anon, public;
GRANT EXECUTE ON FUNCTION public.confirm_supplier_payment(uuid, boolean) TO authenticated;

DROP POLICY IF EXISTS "Public read qr-codes" ON storage.objects;
DROP POLICY IF EXISTS "Public can read qr-codes" ON storage.objects;
DROP POLICY IF EXISTS "Anyone can view qr-codes" ON storage.objects;
DROP POLICY IF EXISTS "Authenticated read qr-codes" ON storage.objects;

CREATE POLICY "Authenticated read qr-codes"
ON storage.objects FOR SELECT
TO authenticated
USING (bucket_id = 'qr-codes');

CREATE TABLE public.notification_payment_signals (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  amount numeric NOT NULL,
  raw_text text,
  package_name text,
  received_at timestamptz NOT NULL DEFAULT now(),
  matched_order_id uuid REFERENCES public.payment_orders(id),
  created_at timestamptz NOT NULL DEFAULT now()
);

GRANT SELECT, UPDATE ON public.notification_payment_signals TO authenticated;
GRANT ALL ON public.notification_payment_signals TO service_role;

ALTER TABLE public.notification_payment_signals ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Admins can view notification signals"
  ON public.notification_payment_signals FOR SELECT TO authenticated
  USING (public.is_admin(auth.uid()));

CREATE POLICY "Admins can manage notification signals"
  ON public.notification_payment_signals FOR UPDATE TO authenticated
  USING (public.is_admin(auth.uid()))
  WITH CHECK (public.is_admin(auth.uid()));

CREATE INDEX idx_nps_amount_received ON public.notification_payment_signals (amount, received_at DESC);

ALTER TABLE public.payment_orders ADD COLUMN IF NOT EXISTS verification_method text;

CREATE OR REPLACE FUNCTION public.submit_payment_utr(_order_id uuid, _utr text)
 RETURNS TABLE(status text, matched boolean)
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
DECLARE
  v_uid uuid := auth.uid();
  v_order RECORD;
  v_utr text;
  v_sms RECORD;
  v_signal RECORD;
  v_plan RECORD;
  v_current_expiry timestamptz;
  v_new_expiry timestamptz;
  v_method text;
BEGIN
  IF v_uid IS NULL THEN
    RAISE EXCEPTION 'not_authenticated';
  END IF;

  v_utr := upper(regexp_replace(COALESCE(_utr, ''), '\s', '', 'g'));
  IF v_utr !~ '^[A-Z0-9]{8,24}$' THEN
    RAISE EXCEPTION 'invalid_utr';
  END IF;

  SELECT * INTO v_order FROM public.payment_orders WHERE id = _order_id FOR UPDATE;
  IF NOT FOUND THEN
    RAISE EXCEPTION 'order_not_found';
  END IF;

  IF v_order.user_id <> v_uid THEN
    RAISE EXCEPTION 'not_order_owner';
  END IF;

  IF v_order.status = 'success' THEN
    RETURN QUERY SELECT 'success'::text, true; RETURN;
  END IF;

  IF v_order.expires_at < now() AND v_order.status IN ('created', 'awaiting_utr') THEN
    UPDATE public.payment_orders SET status = 'expired' WHERE id = v_order.id;
    RAISE EXCEPTION 'order_expired';
  END IF;

  IF EXISTS (
    SELECT 1 FROM public.payment_orders
    WHERE utr_submitted = v_utr AND id <> v_order.id AND status IN ('verifying', 'success')
  ) THEN
    RAISE EXCEPTION 'duplicate_utr';
  END IF;

  -- 1) primary: match against admin SMS inbox
  SELECT * INTO v_sms
  FROM public.sms_inbox s
  WHERE upper(COALESCE(s.parsed_utr, '')) = v_utr
    AND s.parsed_amount = v_order.amount
    AND s.matched_order_id IS NULL
    AND s.received_at BETWEEN (v_order.created_at - interval '10 minutes') AND (now() + interval '1 minute')
  ORDER BY s.received_at DESC
  LIMIT 1;

  IF FOUND THEN
    v_method := 'sms';
    UPDATE public.sms_inbox SET matched_order_id = v_order.id WHERE id = v_sms.id;
  ELSE
    -- 2) fallback: amount-only match from the notification listener signals
    SELECT * INTO v_signal
    FROM public.notification_payment_signals n
    WHERE n.amount = v_order.amount
      AND n.matched_order_id IS NULL
      AND n.received_at BETWEEN (v_order.created_at - interval '10 minutes') AND (v_order.expires_at + interval '10 minutes')
    ORDER BY n.received_at DESC
    LIMIT 1;

    IF FOUND THEN
      v_method := 'notification_fallback';
      UPDATE public.notification_payment_signals SET matched_order_id = v_order.id WHERE id = v_signal.id;
    END IF;
  END IF;

  IF v_method IS NOT NULL THEN
    UPDATE public.payment_orders
      SET status = 'success', utr_submitted = v_utr, verification_method = v_method
    WHERE id = v_order.id;

    INSERT INTO public.payment_verifications (order_id, submitted_utr, matched, matched_sms_id, verified_by)
    VALUES (v_order.id, v_utr, true, CASE WHEN v_method = 'sms' THEN v_sms.id ELSE NULL END, v_method);

    SELECT * INTO v_plan FROM public.variety_plans WHERE id = v_order.variety_plan_id;
    SELECT expires_at INTO v_current_expiry FROM public.subscriptions WHERE dairy_id = v_order.dairy_id;
    IF v_current_expiry IS NOT NULL AND v_current_expiry > now() THEN
      v_new_expiry := v_current_expiry + (v_plan.validity_days || ' days')::interval;
    ELSE
      v_new_expiry := now() + (v_plan.validity_days || ' days')::interval;
    END IF;

    INSERT INTO public.subscriptions (dairy_id, status, started_at, expires_at)
    VALUES (v_order.dairy_id, 'active', now(), v_new_expiry)
    ON CONFLICT (dairy_id)
    DO UPDATE SET status = 'active', expires_at = v_new_expiry, updated_at = now();

    RETURN QUERY SELECT 'success'::text, true;
  ELSE
    UPDATE public.payment_orders
      SET status = 'verifying', utr_submitted = v_utr
    WHERE id = v_order.id;

    INSERT INTO public.payment_verifications (order_id, submitted_utr, matched, verified_by)
    VALUES (v_order.id, v_utr, false, 'auto');

    RETURN QUERY SELECT 'verifying'::text, false;
  END IF;
END;
$function$;
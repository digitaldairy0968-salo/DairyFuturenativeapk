-- 1) Protect admin role in complete_google_signup
CREATE OR REPLACE FUNCTION public.complete_google_signup(p_name text, p_phone text, p_role text)
 RETURNS void
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
DECLARE
  v_uid uuid := auth.uid();
  v_name text := btrim(COALESCE(p_name, ''));
  v_phone text := btrim(COALESCE(p_phone, ''));
BEGIN
  IF v_uid IS NULL THEN
    RAISE EXCEPTION 'not_authenticated';
  END IF;

  IF p_role NOT IN ('owner', 'supplier') THEN
    RAISE EXCEPTION 'invalid_role';
  END IF;

  IF v_name = '' OR v_phone = '' THEN
    RAISE EXCEPTION 'invalid_profile';
  END IF;

  UPDATE public.profiles
     SET name = v_name, phone = v_phone, updated_at = now()
   WHERE user_id = v_uid;

  IF NOT FOUND THEN
    INSERT INTO public.profiles (user_id, name, phone)
    VALUES (v_uid, v_name, v_phone)
    ON CONFLICT (user_id) DO UPDATE
      SET name = EXCLUDED.name, phone = EXCLUDED.phone, updated_at = now();
  END IF;

  -- Never remove an admin role here
  IF public.is_admin(v_uid) THEN
    RETURN;
  END IF;

  DELETE FROM public.user_roles
   WHERE user_id = v_uid
     AND role <> p_role::public.app_role
     AND role <> 'admin'::public.app_role;

  INSERT INTO public.user_roles (user_id, role)
  VALUES (v_uid, p_role::public.app_role)
  ON CONFLICT (user_id, role) DO NOTHING;
END;
$function$;

-- 2) Restore admin role for the admin account
INSERT INTO public.user_roles (user_id, role)
SELECT u.id, 'admin'::public.app_role
FROM auth.users u
WHERE u.email = 'vishnugurjarsimal0968@gmail.com'
ON CONFLICT (user_id, role) DO NOTHING;

DELETE FROM public.user_roles ur
USING auth.users u
WHERE ur.user_id = u.id
  AND u.email = 'vishnugurjarsimal0968@gmail.com'
  AND ur.role = 'owner'::public.app_role;
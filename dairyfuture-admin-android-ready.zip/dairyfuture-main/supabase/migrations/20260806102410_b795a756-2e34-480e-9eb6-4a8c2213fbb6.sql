CREATE OR REPLACE FUNCTION public.get_app_bootstrap()
RETURNS jsonb
LANGUAGE plpgsql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  _auth jsonb;
BEGIN
  IF auth.uid() IS NULL THEN
    RETURN jsonb_build_object('auth', NULL);
  END IF;

  _auth := public.get_auth_bootstrap();

  RETURN jsonb_build_object('auth', _auth);
END;
$$;
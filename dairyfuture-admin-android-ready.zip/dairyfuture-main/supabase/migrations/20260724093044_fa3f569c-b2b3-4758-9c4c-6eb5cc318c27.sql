-- Undo realtime setup
DO $$
DECLARE
  t text;
BEGIN
  FOREACH t IN ARRAY ARRAY['milk_entries','suppliers','payment_history','notifications','announcements'] LOOP
    BEGIN
      EXECUTE format('ALTER TABLE public.%I REPLICA IDENTITY DEFAULT', t);
    EXCEPTION WHEN OTHERS THEN NULL;
    END;
    BEGIN
      EXECUTE format('ALTER PUBLICATION supabase_realtime DROP TABLE public.%I', t);
    EXCEPTION WHEN OTHERS THEN NULL;
    END;
  END LOOP;
END $$;

-- Composite indexes for delta-sync
CREATE INDEX IF NOT EXISTS idx_suppliers_dairy_updated ON public.suppliers (dairy_id, updated_at);
CREATE INDEX IF NOT EXISTS idx_milk_entries_supplier_updated ON public.milk_entries (supplier_id, updated_at);
CREATE INDEX IF NOT EXISTS idx_milk_entries_dairy_updated ON public.milk_entries (dairy_id, updated_at);
CREATE OR REPLACE FUNCTION public.phone_exists(_phone text)
RETURNS boolean
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1 FROM public.profiles
    WHERE RIGHT(regexp_replace(COALESCE(phone, ''), '\D', '', 'g'), 10)
        = RIGHT(regexp_replace(COALESCE(_phone, ''), '\D', '', 'g'), 10)
      AND length(RIGHT(regexp_replace(COALESCE(_phone, ''), '\D', '', 'g'), 10)) = 10
  );
$$;

GRANT EXECUTE ON FUNCTION public.phone_exists(text) TO anon, authenticated;
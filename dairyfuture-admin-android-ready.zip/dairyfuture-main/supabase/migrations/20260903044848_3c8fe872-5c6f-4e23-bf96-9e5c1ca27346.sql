DROP FUNCTION IF EXISTS public._tmp_debug_headers();

CREATE OR REPLACE FUNCTION public.check_and_record_rate_limit(p_identifier text, p_action_type text, p_max_attempts integer, p_window_minutes integer, p_lockout_minutes integer)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
DECLARE
  v_row public.auth_rate_limits%ROWTYPE;
  v_id text := lower(trim(COALESCE(p_identifier, '')));
  v_now timestamptz := now();
BEGIN
  IF v_id = '' OR p_action_type NOT IN ('login', 'signup', 'signup_ip') THEN
    RETURN jsonb_build_object('allowed', true);
  END IF;

  SELECT * INTO v_row FROM public.auth_rate_limits
  WHERE identifier = v_id AND action_type = p_action_type
  FOR UPDATE;

  -- Currently blocked: do not increment
  IF FOUND AND v_row.blocked_until IS NOT NULL AND v_row.blocked_until > v_now THEN
    RETURN jsonb_build_object(
      'allowed', false,
      'retry_after_seconds', GREATEST(1, CEIL(EXTRACT(EPOCH FROM (v_row.blocked_until - v_now)))::integer)
    );
  END IF;

  -- No row, or window expired (or block just expired): reset
  IF NOT FOUND
     OR v_row.first_attempt_at < v_now - make_interval(mins => p_window_minutes)
     OR v_row.blocked_until IS NOT NULL THEN
    INSERT INTO public.auth_rate_limits (identifier, action_type, attempt_count, first_attempt_at, blocked_until, updated_at)
    VALUES (v_id, p_action_type, 1, v_now, NULL, v_now)
    ON CONFLICT (identifier, action_type) DO UPDATE
      SET attempt_count = 1, first_attempt_at = v_now, blocked_until = NULL, updated_at = v_now;
    RETURN jsonb_build_object('allowed', true);
  END IF;

  -- Within window: increment
  UPDATE public.auth_rate_limits
  SET attempt_count = attempt_count + 1, updated_at = v_now
  WHERE identifier = v_id AND action_type = p_action_type
  RETURNING * INTO v_row;

  IF v_row.attempt_count > p_max_attempts THEN
    UPDATE public.auth_rate_limits
    SET blocked_until = v_now + make_interval(mins => p_lockout_minutes), updated_at = v_now
    WHERE identifier = v_id AND action_type = p_action_type;
    RETURN jsonb_build_object('allowed', false, 'retry_after_seconds', p_lockout_minutes * 60);
  END IF;

  RETURN jsonb_build_object('allowed', true);
END;
$function$;
DROP FUNCTION IF EXISTS public.activate_subscription_code(text, uuid);
DROP TABLE IF EXISTS public.activation_codes CASCADE;
DROP TABLE IF EXISTS public.payment_plans CASCADE;

CREATE OR REPLACE FUNCTION public.activate_demo_subscription(_dairy_id uuid)
 RETURNS boolean
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
DECLARE
  v_demo_days integer;
  v_expires_at timestamptz;
BEGIN
  IF auth.uid() IS NULL THEN
    RAISE EXCEPTION 'not_authenticated';
  END IF;

  IF NOT EXISTS (SELECT 1 FROM public.dairies WHERE id = _dairy_id AND owner_id = auth.uid()) THEN
    RAISE EXCEPTION 'not_dairy_owner';
  END IF;

  IF EXISTS (
    SELECT 1 FROM public.subscriptions
    WHERE dairy_id = _dairy_id AND status = 'active' AND started_at IS NOT NULL
  ) THEN
    RAISE EXCEPTION 'demo_already_used';
  END IF;

  SELECT COALESCE(ss.demo_days, 9) INTO v_demo_days
  FROM public.subscription_settings ss
  LIMIT 1;

  v_expires_at := now() + (v_demo_days || ' days')::interval;

  INSERT INTO public.subscriptions (dairy_id, status, started_at, expires_at)
  VALUES (_dairy_id, 'active', now(), v_expires_at)
  ON CONFLICT (dairy_id)
  DO UPDATE SET status = 'active', started_at = now(), expires_at = v_expires_at, updated_at = now();

  RETURN true;
END;
$function$;

CREATE OR REPLACE FUNCTION public.get_settings_bootstrap()
 RETURNS jsonb
 LANGUAGE plpgsql
 STABLE SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
DECLARE
  v_uid uuid := auth.uid();
  v_dairy_id uuid;
  v_dairy jsonb;
  v_owner_id uuid;
  v_owner_phone text := '';
  v_sub jsonb;
  v_settings jsonb := '{}'::jsonb;
  v_contact jsonb := '{}'::jsonb;
  v_varieties jsonb := '[]'::jsonb;
  v_variety_plans jsonb := '[]'::jsonb;
  v_features jsonb := '{}'::jsonb;
  v_is_owner boolean := false;
BEGIN
  IF v_uid IS NULL THEN
    RETURN NULL;
  END IF;

  SELECT jsonb_build_object('id', d.id, 'name', d.name, 'code', d.code,
                            'owner_id', d.owner_id, 'customer_limit', d.customer_limit),
         d.id, d.owner_id
    INTO v_dairy, v_dairy_id, v_owner_id
  FROM public.dairies d
  WHERE d.owner_id = v_uid
  LIMIT 1;

  IF v_dairy_id IS NOT NULL THEN
    v_is_owner := true;
  ELSE
    SELECT s.dairy_id INTO v_dairy_id
    FROM public.suppliers s
    WHERE s.user_id = v_uid
    ORDER BY s.created_at DESC
    LIMIT 1;

    IF v_dairy_id IS NOT NULL THEN
      SELECT jsonb_build_object('id', d.id, 'name', d.name, 'code', d.code,
                                'owner_id', d.owner_id, 'customer_limit', d.customer_limit),
             d.owner_id
        INTO v_dairy, v_owner_id
      FROM public.dairies d WHERE d.id = v_dairy_id;
    END IF;
  END IF;

  IF v_dairy_id IS NOT NULL THEN
    SELECT jsonb_build_object('status', s.status, 'expires_at', s.expires_at)
      INTO v_sub
    FROM public.subscriptions s
    WHERE s.dairy_id = v_dairy_id
    ORDER BY (s.status = 'active') DESC, s.created_at DESC
    LIMIT 1;

    SELECT COALESCE(jsonb_object_agg(f.feature_key, f.is_enabled), '{}'::jsonb)
      INTO v_features
    FROM public.dairy_features f
    WHERE f.dairy_id = v_dairy_id;
  END IF;

  SELECT jsonb_build_object(
           'id', ss.id,
           'monthly_price', ss.monthly_price,
           'demo_days', ss.demo_days,
           'default_validity_days', ss.default_validity_days,
           'qr_code_url', ss.qr_code_url,
           'auth_page_image_url', ss.auth_page_image_url,
           'created_at', ss.created_at,
           'updated_at', ss.updated_at
         ),
         CASE WHEN v_is_owner OR public.is_admin(v_uid)
              THEN jsonb_build_object('admin_phone', ss.admin_phone, 'upi_id', ss.upi_id)
              ELSE '{}'::jsonb END
    INTO v_settings, v_contact
  FROM public.subscription_settings ss
  LIMIT 1;

  SELECT COALESCE(jsonb_agg(to_jsonb(v) ORDER BY v.created_at), '[]'::jsonb) INTO v_varieties
  FROM public.subscription_varieties v WHERE v.is_active = true;

  SELECT COALESCE(jsonb_agg(to_jsonb(vp) ORDER BY vp.price), '[]'::jsonb) INTO v_variety_plans
  FROM public.variety_plans vp WHERE vp.is_active = true;

  IF v_owner_id IS NOT NULL THEN
    SELECT COALESCE(pr.phone, '') INTO v_owner_phone
    FROM public.profiles pr WHERE pr.user_id = v_owner_id LIMIT 1;
  END IF;

  RETURN jsonb_build_object(
    'dairy', v_dairy,
    'subscription', v_sub,
    'settings', COALESCE(v_settings, '{}'::jsonb),
    'contact', COALESCE(v_contact, '{}'::jsonb),
    'varieties', v_varieties,
    'variety_plans', v_variety_plans,
    'features', v_features,
    'owner_phone', COALESCE(v_owner_phone, '')
  );
END;
$function$;
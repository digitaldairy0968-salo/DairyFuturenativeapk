ALTER TABLE public.subscription_settings ADD COLUMN IF NOT EXISTS youtube_url text;

CREATE OR REPLACE FUNCTION public.get_settings_bootstrap()
 RETURNS jsonb
 LANGUAGE plpgsql
 STABLE SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
DECLARE
  v_uid uuid := auth.uid();
  v_dairy_id uuid;
  v_dairy jsonb;
  v_owner_id uuid;
  v_owner_phone text := '';
  v_sub jsonb;
  v_settings jsonb := '{}'::jsonb;
  v_contact jsonb := '{}'::jsonb;
  v_varieties jsonb := '[]'::jsonb;
  v_variety_plans jsonb := '[]'::jsonb;
  v_features jsonb := '{}'::jsonb;
  v_is_owner boolean := false;
BEGIN
  IF v_uid IS NULL THEN
    RETURN NULL;
  END IF;

  SELECT jsonb_build_object('id', d.id, 'name', d.name, 'code', d.code, 'owner_id', d.owner_id),
         d.id, d.owner_id
    INTO v_dairy, v_dairy_id, v_owner_id
  FROM public.dairies d
  WHERE d.owner_id = v_uid
  LIMIT 1;

  IF v_dairy_id IS NOT NULL THEN
    v_is_owner := true;
  ELSE
    SELECT s.dairy_id INTO v_dairy_id
    FROM public.suppliers s
    WHERE s.user_id = v_uid
    ORDER BY s.created_at DESC
    LIMIT 1;

    IF v_dairy_id IS NOT NULL THEN
      SELECT jsonb_build_object('id', d.id, 'name', d.name, 'code', d.code, 'owner_id', d.owner_id),
             d.owner_id
        INTO v_dairy, v_owner_id
      FROM public.dairies d WHERE d.id = v_dairy_id;
    END IF;
  END IF;

  IF v_dairy_id IS NOT NULL THEN
    SELECT jsonb_build_object('status', s.status, 'expires_at', s.expires_at)
      INTO v_sub
    FROM public.subscriptions s
    WHERE s.dairy_id = v_dairy_id
    ORDER BY (s.status = 'active') DESC, s.created_at DESC
    LIMIT 1;

    SELECT COALESCE(jsonb_object_agg(f.feature_key, f.is_enabled), '{}'::jsonb)
      INTO v_features
    FROM public.dairy_features f
    WHERE f.dairy_id = v_dairy_id;
  END IF;

  SELECT jsonb_build_object(
           'id', ss.id,
           'monthly_price', ss.monthly_price,
           'demo_days', ss.demo_days,
           'default_validity_days', ss.default_validity_days,
           'qr_code_url', ss.qr_code_url,
           'auth_page_image_url', ss.auth_page_image_url,
           'youtube_url', ss.youtube_url,
           'created_at', ss.created_at,
           'updated_at', ss.updated_at
         ),
         CASE WHEN v_is_owner OR public.is_admin(v_uid)
              THEN jsonb_build_object('admin_phone', ss.admin_phone, 'upi_id', ss.upi_id)
              ELSE '{}'::jsonb END
    INTO v_settings, v_contact
  FROM public.subscription_settings ss
  LIMIT 1;

  SELECT COALESCE(jsonb_agg(to_jsonb(v) ORDER BY v.created_at), '[]'::jsonb) INTO v_varieties
  FROM public.subscription_varieties v WHERE v.is_active = true;

  SELECT COALESCE(jsonb_agg(to_jsonb(vp) ORDER BY vp.price), '[]'::jsonb) INTO v_variety_plans
  FROM public.variety_plans vp WHERE vp.is_active = true;

  IF v_owner_id IS NOT NULL THEN
    SELECT COALESCE(pr.phone, '') INTO v_owner_phone
    FROM public.profiles pr WHERE pr.user_id = v_owner_id LIMIT 1;
  END IF;

  RETURN jsonb_build_object(
    'dairy', v_dairy,
    'subscription', v_sub,
    'settings', COALESCE(v_settings, '{}'::jsonb),
    'contact', COALESCE(v_contact, '{}'::jsonb),
    'varieties', v_varieties,
    'variety_plans', v_variety_plans,
    'features', v_features,
    'owner_phone', COALESCE(v_owner_phone, '')
  );
END;
$function$;
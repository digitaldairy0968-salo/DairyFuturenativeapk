ALTER TABLE public.owner_settings
  DROP COLUMN IF EXISTS voice_supplier_code;
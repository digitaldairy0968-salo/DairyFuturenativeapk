CREATE OR REPLACE FUNCTION public.submit_payment_utr(_order_id uuid, _utr text)
 RETURNS TABLE(status text, matched boolean)
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
#variable_conflict use_column
DECLARE
  v_uid uuid := auth.uid();
  v_order RECORD;
  v_utr text;
BEGIN
  IF v_uid IS NULL THEN
    RAISE EXCEPTION 'not_authenticated';
  END IF;

  v_utr := upper(regexp_replace(COALESCE(_utr, ''), '\s', '', 'g'));
  IF v_utr !~ '^[A-Z0-9]{8,24}$' THEN
    RAISE EXCEPTION 'invalid_utr';
  END IF;

  SELECT * INTO v_order FROM public.payment_orders po WHERE po.id = _order_id FOR UPDATE;
  IF NOT FOUND THEN
    RAISE EXCEPTION 'order_not_found';
  END IF;

  IF v_order.user_id <> v_uid THEN
    RAISE EXCEPTION 'not_order_owner';
  END IF;

  IF v_order.status = 'success' THEN
    RETURN QUERY SELECT 'success'::text, true; RETURN;
  END IF;

  IF v_order.expires_at < now() AND v_order.status IN ('created', 'awaiting_utr') THEN
    UPDATE public.payment_orders po SET status = 'expired' WHERE po.id = v_order.id;
    RAISE EXCEPTION 'order_expired';
  END IF;

  IF EXISTS (
    SELECT 1 FROM public.payment_orders po2
    WHERE po2.utr_submitted = v_utr
      AND po2.id <> v_order.id
      AND po2.status IN ('verifying', 'success')
  ) THEN
    RAISE EXCEPTION 'duplicate_utr';
  END IF;

  UPDATE public.payment_orders po
    SET status = 'success', utr_submitted = v_utr, verification_method = 'manual_utr_unverified'
  WHERE po.id = v_order.id;

  INSERT INTO public.payment_verifications (order_id, submitted_utr, matched, verified_by, matched_via)
  VALUES (v_order.id, v_utr, false, 'user', 'manual_utr_unverified');

  PERFORM public.activate_subscription_from_order(v_order.id);

  RETURN QUERY SELECT 'success'::text, true;
END;
$function$;

REVOKE ALL ON FUNCTION public.submit_payment_utr(uuid, text) FROM anon;
GRANT EXECUTE ON FUNCTION public.submit_payment_utr(uuid, text) TO authenticated;
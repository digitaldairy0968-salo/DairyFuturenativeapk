-- =========================================================
-- UPI payment orders + UTR verification
-- =========================================================

CREATE TABLE public.payment_orders (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL,
  dairy_id uuid NOT NULL REFERENCES public.dairies(id) ON DELETE CASCADE,
  variety_plan_id uuid NOT NULL REFERENCES public.variety_plans(id),
  amount numeric NOT NULL,
  order_ref text NOT NULL UNIQUE,
  status text NOT NULL DEFAULT 'created',
  utr_submitted text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  expires_at timestamptz NOT NULL DEFAULT (now() + interval '15 minutes')
);

GRANT SELECT, INSERT, UPDATE ON public.payment_orders TO authenticated;
GRANT ALL ON public.payment_orders TO service_role;
ALTER TABLE public.payment_orders ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users view own orders" ON public.payment_orders
  FOR SELECT TO authenticated
  USING (user_id = auth.uid() OR public.is_admin(auth.uid()));
CREATE POLICY "Admins update orders" ON public.payment_orders
  FOR UPDATE TO authenticated
  USING (public.is_admin(auth.uid()))
  WITH CHECK (public.is_admin(auth.uid()));

CREATE INDEX idx_payment_orders_user ON public.payment_orders(user_id, created_at DESC);
CREATE INDEX idx_payment_orders_dairy ON public.payment_orders(dairy_id, created_at DESC);
CREATE INDEX idx_payment_orders_status ON public.payment_orders(status, created_at DESC);

CREATE TRIGGER trg_payment_orders_updated_at
  BEFORE UPDATE ON public.payment_orders
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at();

-- ---------------------------------------------------------

CREATE TABLE public.sms_inbox (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  sender text,
  body text NOT NULL,
  parsed_utr text,
  parsed_amount numeric,
  received_at timestamptz NOT NULL DEFAULT now(),
  matched_order_id uuid REFERENCES public.payment_orders(id) ON DELETE SET NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.sms_inbox TO authenticated;
GRANT ALL ON public.sms_inbox TO service_role;
ALTER TABLE public.sms_inbox ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Admins manage sms inbox" ON public.sms_inbox
  FOR ALL TO authenticated
  USING (public.is_admin(auth.uid()))
  WITH CHECK (public.is_admin(auth.uid()));

CREATE INDEX idx_sms_inbox_utr ON public.sms_inbox(parsed_utr);
CREATE INDEX idx_sms_inbox_received ON public.sms_inbox(received_at DESC);

-- ---------------------------------------------------------

CREATE TABLE public.payment_verifications (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  order_id uuid NOT NULL REFERENCES public.payment_orders(id) ON DELETE CASCADE,
  submitted_utr text NOT NULL,
  matched boolean NOT NULL DEFAULT false,
  matched_sms_id uuid REFERENCES public.sms_inbox(id) ON DELETE SET NULL,
  verified_by text NOT NULL DEFAULT 'auto',
  verified_at timestamptz NOT NULL DEFAULT now(),
  created_at timestamptz NOT NULL DEFAULT now()
);

GRANT SELECT ON public.payment_verifications TO authenticated;
GRANT ALL ON public.payment_verifications TO service_role;
ALTER TABLE public.payment_verifications ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users view own verifications" ON public.payment_verifications
  FOR SELECT TO authenticated
  USING (
    public.is_admin(auth.uid())
    OR EXISTS (
      SELECT 1 FROM public.payment_orders o
      WHERE o.id = payment_verifications.order_id AND o.user_id = auth.uid()
    )
  );

CREATE INDEX idx_payment_verifications_order ON public.payment_verifications(order_id, created_at DESC);

-- =========================================================
-- Plans: public read, admin write
-- =========================================================
DROP POLICY IF EXISTS "Admins manage varieties" ON public.subscription_varieties;
CREATE POLICY "Admins manage varieties" ON public.subscription_varieties
  FOR ALL TO authenticated
  USING (public.is_admin(auth.uid()))
  WITH CHECK (public.is_admin(auth.uid()));

DROP POLICY IF EXISTS "Admins manage variety plans" ON public.variety_plans;
CREATE POLICY "Admins manage variety plans" ON public.variety_plans
  FOR ALL TO authenticated
  USING (public.is_admin(auth.uid()))
  WITH CHECK (public.is_admin(auth.uid()));

-- =========================================================
-- create_payment_order: amount always derived server-side
-- =========================================================
CREATE OR REPLACE FUNCTION public.create_payment_order(_plan_id uuid)
RETURNS TABLE(order_id uuid, order_ref text, amount numeric, expires_at timestamptz)
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $$
DECLARE
  v_uid uuid := auth.uid();
  v_dairy_id uuid;
  v_plan RECORD;
  v_ref text;
  v_id uuid;
  v_exp timestamptz;
BEGIN
  IF v_uid IS NULL THEN
    RAISE EXCEPTION 'not_authenticated';
  END IF;

  -- caller must own a dairy
  SELECT id INTO v_dairy_id FROM public.dairies WHERE owner_id = v_uid LIMIT 1;
  IF v_dairy_id IS NULL THEN
    RAISE EXCEPTION 'not_dairy_owner';
  END IF;

  SELECT * INTO v_plan FROM public.variety_plans WHERE id = _plan_id AND is_active = true;
  IF NOT FOUND THEN
    RAISE EXCEPTION 'plan_not_found';
  END IF;

  -- expire stale open orders for this user (query-time expiry, no cron)
  UPDATE public.payment_orders
    SET status = 'expired'
  WHERE user_id = v_uid
    AND status IN ('created', 'awaiting_utr')
    AND expires_at < now();

  v_ref := 'DF' || to_char(now(), 'YYMMDDHH24MISS') || upper(substring(md5(gen_random_uuid()::text) from 1 for 4));
  v_exp := now() + interval '15 minutes';

  INSERT INTO public.payment_orders (user_id, dairy_id, variety_plan_id, amount, order_ref, status, expires_at)
  VALUES (v_uid, v_dairy_id, _plan_id, v_plan.price, v_ref, 'awaiting_utr', v_exp)
  RETURNING id INTO v_id;

  RETURN QUERY SELECT v_id, v_ref, v_plan.price, v_exp;
END;
$$;

REVOKE ALL ON FUNCTION public.create_payment_order(uuid) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.create_payment_order(uuid) TO authenticated;

-- =========================================================
-- submit_payment_utr: server-side SMS match, no client trust
-- =========================================================
CREATE OR REPLACE FUNCTION public.submit_payment_utr(_order_id uuid, _utr text)
RETURNS TABLE(status text, matched boolean)
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $$
DECLARE
  v_uid uuid := auth.uid();
  v_order RECORD;
  v_utr text;
  v_sms RECORD;
  v_plan RECORD;
  v_current_expiry timestamptz;
  v_new_expiry timestamptz;
BEGIN
  IF v_uid IS NULL THEN
    RAISE EXCEPTION 'not_authenticated';
  END IF;

  v_utr := upper(regexp_replace(COALESCE(_utr, ''), '\s', '', 'g'));
  IF v_utr !~ '^[A-Z0-9]{8,24}$' THEN
    RAISE EXCEPTION 'invalid_utr';
  END IF;

  SELECT * INTO v_order FROM public.payment_orders WHERE id = _order_id FOR UPDATE;
  IF NOT FOUND THEN
    RAISE EXCEPTION 'order_not_found';
  END IF;

  -- ownership: user can only verify their own order
  IF v_order.user_id <> v_uid THEN
    RAISE EXCEPTION 'not_order_owner';
  END IF;

  IF v_order.status = 'success' THEN
    RETURN QUERY SELECT 'success'::text, true; RETURN;
  END IF;

  -- 15 min expiry check
  IF v_order.expires_at < now() AND v_order.status IN ('created', 'awaiting_utr') THEN
    UPDATE public.payment_orders SET status = 'expired' WHERE id = v_order.id;
    RAISE EXCEPTION 'order_expired';
  END IF;

  -- duplicate UTR guard: same UTR must not be used by another order
  IF EXISTS (
    SELECT 1 FROM public.payment_orders
    WHERE utr_submitted = v_utr AND id <> v_order.id AND status IN ('verifying', 'success')
  ) THEN
    RAISE EXCEPTION 'duplicate_utr';
  END IF;

  -- server-side match against admin SMS inbox
  SELECT * INTO v_sms
  FROM public.sms_inbox s
  WHERE upper(COALESCE(s.parsed_utr, '')) = v_utr
    AND s.parsed_amount = v_order.amount
    AND s.matched_order_id IS NULL
    AND s.received_at BETWEEN (v_order.created_at - interval '10 minutes') AND (now() + interval '1 minute')
  ORDER BY s.received_at DESC
  LIMIT 1;

  IF FOUND THEN
    UPDATE public.sms_inbox SET matched_order_id = v_order.id WHERE id = v_sms.id;
    UPDATE public.payment_orders
      SET status = 'success', utr_submitted = v_utr
    WHERE id = v_order.id;

    INSERT INTO public.payment_verifications (order_id, submitted_utr, matched, matched_sms_id, verified_by)
    VALUES (v_order.id, v_utr, true, v_sms.id, 'auto');

    -- extend subscription
    SELECT * INTO v_plan FROM public.variety_plans WHERE id = v_order.variety_plan_id;
    SELECT expires_at INTO v_current_expiry FROM public.subscriptions WHERE dairy_id = v_order.dairy_id;
    IF v_current_expiry IS NOT NULL AND v_current_expiry > now() THEN
      v_new_expiry := v_current_expiry + (v_plan.validity_days || ' days')::interval;
    ELSE
      v_new_expiry := now() + (v_plan.validity_days || ' days')::interval;
    END IF;

    INSERT INTO public.subscriptions (dairy_id, status, started_at, expires_at)
    VALUES (v_order.dairy_id, 'active', now(), v_new_expiry)
    ON CONFLICT (dairy_id)
    DO UPDATE SET status = 'active', expires_at = v_new_expiry, updated_at = now();

    RETURN QUERY SELECT 'success'::text, true;
  ELSE
    UPDATE public.payment_orders
      SET status = 'verifying', utr_submitted = v_utr
    WHERE id = v_order.id;

    INSERT INTO public.payment_verifications (order_id, submitted_utr, matched, verified_by)
    VALUES (v_order.id, v_utr, false, 'auto');

    RETURN QUERY SELECT 'verifying'::text, false;
  END IF;
END;
$$;

REVOKE ALL ON FUNCTION public.submit_payment_utr(uuid, text) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.submit_payment_utr(uuid, text) TO authenticated;

-- =========================================================
-- admin_review_payment: admin-only manual approve/reject
-- =========================================================
CREATE OR REPLACE FUNCTION public.admin_review_payment(_order_id uuid, _approve boolean)
RETURNS boolean
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $$
DECLARE
  v_uid uuid := auth.uid();
  v_order RECORD;
  v_plan RECORD;
  v_current_expiry timestamptz;
  v_new_expiry timestamptz;
BEGIN
  IF v_uid IS NULL THEN
    RAISE EXCEPTION 'not_authenticated';
  END IF;
  IF NOT public.is_admin(v_uid) THEN
    RAISE EXCEPTION 'not_admin';
  END IF;

  SELECT * INTO v_order FROM public.payment_orders WHERE id = _order_id FOR UPDATE;
  IF NOT FOUND THEN
    RAISE EXCEPTION 'order_not_found';
  END IF;

  IF NOT _approve THEN
    UPDATE public.payment_orders SET status = 'failed' WHERE id = v_order.id;
    INSERT INTO public.payment_verifications (order_id, submitted_utr, matched, verified_by)
    VALUES (v_order.id, COALESCE(v_order.utr_submitted, ''), false, 'admin');
    RETURN true;
  END IF;

  IF v_order.status = 'success' THEN
    RETURN true;
  END IF;

  UPDATE public.payment_orders SET status = 'success' WHERE id = v_order.id;
  INSERT INTO public.payment_verifications (order_id, submitted_utr, matched, verified_by)
  VALUES (v_order.id, COALESCE(v_order.utr_submitted, ''), true, 'admin');

  SELECT * INTO v_plan FROM public.variety_plans WHERE id = v_order.variety_plan_id;
  SELECT expires_at INTO v_current_expiry FROM public.subscriptions WHERE dairy_id = v_order.dairy_id;
  IF v_current_expiry IS NOT NULL AND v_current_expiry > now() THEN
    v_new_expiry := v_current_expiry + (v_plan.validity_days || ' days')::interval;
  ELSE
    v_new_expiry := now() + (v_plan.validity_days || ' days')::interval;
  END IF;

  INSERT INTO public.subscriptions (dairy_id, status, started_at, expires_at)
  VALUES (v_order.dairy_id, 'active', now(), v_new_expiry)
  ON CONFLICT (dairy_id)
  DO UPDATE SET status = 'active', expires_at = v_new_expiry, updated_at = now();

  RETURN true;
END;
$$;

REVOKE ALL ON FUNCTION public.admin_review_payment(uuid, boolean) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.admin_review_payment(uuid, boolean) TO authenticated;

-- =========================================================
-- get_payment_order: order + UPI payee details for the owner only
-- =========================================================
CREATE OR REPLACE FUNCTION public.get_payment_order(_order_id uuid)
RETURNS jsonb
LANGUAGE plpgsql
STABLE
SECURITY DEFINER
SET search_path TO 'public'
AS $$
DECLARE
  v_uid uuid := auth.uid();
  v_order RECORD;
  v_upi text;
  v_name text;
BEGIN
  IF v_uid IS NULL THEN
    RAISE EXCEPTION 'not_authenticated';
  END IF;

  SELECT * INTO v_order FROM public.payment_orders WHERE id = _order_id;
  IF NOT FOUND THEN
    RAISE EXCEPTION 'order_not_found';
  END IF;

  IF v_order.user_id <> v_uid AND NOT public.is_admin(v_uid) THEN
    RAISE EXCEPTION 'not_order_owner';
  END IF;

  SELECT ss.upi_id, ss.admin_phone INTO v_upi, v_name
  FROM public.subscription_settings ss LIMIT 1;

  RETURN jsonb_build_object(
    'order', to_jsonb(v_order),
    'plan', (SELECT to_jsonb(p) FROM public.variety_plans p WHERE p.id = v_order.variety_plan_id),
    'upi_id', v_upi,
    'admin_phone', v_name
  );
END;
$$;

REVOKE ALL ON FUNCTION public.get_payment_order(uuid) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.get_payment_order(uuid) TO authenticated;

-- =========================================================
-- SECURITY REVIEW
-- =========================================================
-- 1. has_role()/is_admin() remain SECURITY DEFINER, read-only (SELECT EXISTS only),
--    and are used from RLS policies; no role write capability is exposed.
-- 2. Every SECURITY DEFINER function above starts with an auth.uid() NULL check and
--    enforces ownership (auth.uid() = order.user_id) or is_admin(auth.uid()).
--    - create_payment_order derives amount from variety_plans server-side (client amount ignored).
--    - submit_payment_utr validates UTR format, checks the 15-minute order expiry,
--      blocks duplicate UTR reuse across orders, and matches the UTR against sms_inbox
--      server-side (amount + unmatched + time window). User input alone never activates.
--    - admin_review_payment is admin-only.
-- 3. EXECUTE on all new sensitive functions is REVOKEd from PUBLIC/anon and granted
--    only to authenticated.
-- 4. RLS: payment_orders and payment_verifications are user-scoped (user_id = auth.uid())
--    with admin-wide read; sms_inbox is admin-only for all operations; plans are public
--    read / admin write; subscription_settings (UPI ID) has no direct authenticated read
--    and is only exposed through SECURITY DEFINER RPCs.
-- 5. No new storage buckets; existing buckets keep their private/signed-URL model.

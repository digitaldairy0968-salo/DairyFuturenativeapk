-- Restrict direct reads of admin payment contact details (upi_id, admin_phone)
-- Non-admin users get these only through the SECURITY DEFINER RPCs
-- (get_admin_payment_contact / get_settings_bootstrap).
REVOKE SELECT ON public.subscription_settings FROM authenticated;
GRANT SELECT (id, monthly_price, qr_code_url, default_validity_days, created_at, updated_at, auth_page_image_url, demo_days)
  ON public.subscription_settings TO authenticated;
GRANT ALL ON public.subscription_settings TO service_role;

-- Admins keep full read access through a SECURITY DEFINER helper
CREATE OR REPLACE FUNCTION public.get_subscription_settings_admin()
RETURNS public.subscription_settings
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT s.* FROM public.subscription_settings s
  WHERE public.is_admin(auth.uid())
  LIMIT 1;
$$;
REVOKE EXECUTE ON FUNCTION public.get_subscription_settings_admin() FROM anon;
GRANT EXECUTE ON FUNCTION public.get_subscription_settings_admin() TO authenticated;
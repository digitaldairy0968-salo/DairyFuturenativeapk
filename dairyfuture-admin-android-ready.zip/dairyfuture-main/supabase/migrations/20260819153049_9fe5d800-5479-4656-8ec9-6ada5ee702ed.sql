ALTER TABLE public.suppliers
  ADD COLUMN IF NOT EXISTS rate_system text NOT NULL DEFAULT 'default';

CREATE OR REPLACE FUNCTION public.validate_supplier_rate_system()
RETURNS trigger
LANGUAGE plpgsql
SET search_path = public
AS $$
BEGIN
  IF NEW.rate_system NOT IN ('default', 'fat', 'fat_snf') THEN
    RAISE EXCEPTION 'invalid rate_system: %', NEW.rate_system;
  END IF;
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS validate_supplier_rate_system_trg ON public.suppliers;
CREATE TRIGGER validate_supplier_rate_system_trg
  BEFORE INSERT OR UPDATE ON public.suppliers
  FOR EACH ROW EXECUTE FUNCTION public.validate_supplier_rate_system();

ALTER TABLE public.owner_settings
  ADD COLUMN IF NOT EXISTS voice_supplier_code boolean NOT NULL DEFAULT false;
CREATE OR REPLACE FUNCTION public.get_dairy_config_bootstrap()
 RETURNS jsonb
 LANGUAGE plpgsql
 STABLE SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
DECLARE
  v_uid uuid := auth.uid();
  v_dairy_id uuid;
  v_is_owner boolean := false;
  v_caller_supplier jsonb := NULL;
BEGIN
  IF v_uid IS NULL THEN RETURN NULL; END IF;

  SELECT d.id INTO v_dairy_id FROM public.dairies d WHERE d.owner_id = v_uid LIMIT 1;
  IF v_dairy_id IS NOT NULL THEN
    v_is_owner := true;
  ELSE
    SELECT s.dairy_id INTO v_dairy_id FROM public.suppliers s
    WHERE s.user_id = v_uid ORDER BY s.created_at DESC LIMIT 1;
  END IF;
  IF v_dairy_id IS NULL THEN RETURN NULL; END IF;

  IF NOT v_is_owner THEN
    SELECT jsonb_build_object(
      'id', s.id,
      'can_see_calculations', s.can_see_calculations,
      'personal_rate', s.personal_rate,
      'rate_system', s.rate_system
    )
    INTO v_caller_supplier
    FROM public.suppliers s
    WHERE s.user_id = v_uid AND s.dairy_id = v_dairy_id AND s.deleted_at IS NULL
    ORDER BY s.created_at DESC LIMIT 1;
  END IF;

  RETURN jsonb_build_object(
    'dairy_id', v_dairy_id,
    'rate_settings', (SELECT to_jsonb(r) FROM public.rate_settings r WHERE r.dairy_id = v_dairy_id LIMIT 1),
    'fat_snf_rate_settings', (SELECT to_jsonb(f) FROM public.fat_snf_rate_settings f WHERE f.dairy_id = v_dairy_id LIMIT 1),
    'owner_settings', (SELECT to_jsonb(o) FROM public.owner_settings o WHERE o.dairy_id = v_dairy_id LIMIT 1),
    'caller_supplier', v_caller_supplier
  );
END;
$function$;
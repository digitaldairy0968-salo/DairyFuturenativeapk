
-- Soft-delete: add deleted_at to tables that support user-driven deletion
ALTER TABLE public.suppliers ADD COLUMN IF NOT EXISTS deleted_at timestamptz;
ALTER TABLE public.milk_entries ADD COLUMN IF NOT EXISTS deleted_at timestamptz;
ALTER TABLE public.announcements ADD COLUMN IF NOT EXISTS deleted_at timestamptz;
ALTER TABLE public.payment_history ADD COLUMN IF NOT EXISTS deleted_at timestamptz;
ALTER TABLE public.notifications ADD COLUMN IF NOT EXISTS deleted_at timestamptz;

-- Indexes to keep delta queries snappy
CREATE INDEX IF NOT EXISTS idx_suppliers_deleted_at ON public.suppliers(deleted_at);
CREATE INDEX IF NOT EXISTS idx_milk_entries_deleted_at ON public.milk_entries(deleted_at);
CREATE INDEX IF NOT EXISTS idx_announcements_deleted_at ON public.announcements(deleted_at);
CREATE INDEX IF NOT EXISTS idx_payment_history_deleted_at ON public.payment_history(deleted_at);
CREATE INDEX IF NOT EXISTS idx_notifications_deleted_at ON public.notifications(deleted_at);

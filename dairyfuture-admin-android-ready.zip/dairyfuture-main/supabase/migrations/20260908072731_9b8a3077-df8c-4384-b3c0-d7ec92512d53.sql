ALTER TABLE public.notification_payment_signals
  ADD COLUMN IF NOT EXISTS source text NOT NULL DEFAULT 'admin_user';
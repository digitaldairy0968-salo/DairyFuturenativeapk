
REVOKE SELECT (admin_phone, upi_id) ON public.subscription_settings FROM PUBLIC;
REVOKE SELECT (admin_phone, upi_id) ON public.subscription_settings FROM anon;
REVOKE SELECT (admin_phone, upi_id) ON public.subscription_settings FROM authenticated;

GRANT SELECT (id, monthly_price, demo_days, default_validity_days, auth_page_image_url, qr_code_url, created_at, updated_at)
  ON public.subscription_settings TO authenticated;

CREATE OR REPLACE FUNCTION public.get_admin_payment_contact()
RETURNS TABLE(admin_phone text, upi_id text)
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT ss.admin_phone, ss.upi_id
  FROM public.subscription_settings ss
  WHERE auth.uid() IS NOT NULL
    AND (
      public.is_admin(auth.uid())
      OR EXISTS (SELECT 1 FROM public.dairies WHERE owner_id = auth.uid())
    )
  LIMIT 1
$$;

GRANT EXECUTE ON FUNCTION public.get_admin_payment_contact() TO authenticated;

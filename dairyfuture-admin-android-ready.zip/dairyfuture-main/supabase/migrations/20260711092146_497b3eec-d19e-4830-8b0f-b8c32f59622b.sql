
-- 1) Fix signup role escalation
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $function$
DECLARE
  v_referral text;
  v_role_text text;
  v_role app_role;
BEGIN
  v_referral := upper(substring(md5(NEW.id::text || now()::text) from 1 for 8));

  INSERT INTO public.profiles (user_id, name, phone, referral_code, referred_by)
  VALUES (
    NEW.id,
    COALESCE(NEW.raw_user_meta_data->>'name', ''),
    COALESCE(NEW.raw_user_meta_data->>'phone', ''),
    v_referral,
    CASE WHEN NEW.raw_user_meta_data->>'referred_by_code' IS NOT NULL
         THEN upper(NEW.raw_user_meta_data->>'referred_by_code')
         ELSE NULL
    END
  )
  ON CONFLICT (user_id) DO NOTHING;

  v_role_text := NEW.raw_user_meta_data->>'role';
  IF v_role_text IN ('owner', 'supplier') THEN
    v_role := v_role_text::app_role;
  ELSE
    v_role := 'owner'::app_role;
  END IF;

  INSERT INTO public.user_roles (user_id, role)
  VALUES (NEW.id, v_role)
  ON CONFLICT (user_id, role) DO NOTHING;

  RETURN NEW;
END;
$function$;

-- 2) Fix referral reward abuse
CREATE OR REPLACE FUNCTION public.apply_referral_reward(_referred_user_id uuid)
RETURNS boolean
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $function$
DECLARE
  v_referrer_code text;
  v_referrer_user_id uuid;
  v_referrer_dairy_id uuid;
BEGIN
  IF auth.uid() IS NULL OR auth.uid() <> _referred_user_id THEN
    RAISE EXCEPTION 'not_authorized';
  END IF;

  SELECT referred_by INTO v_referrer_code FROM public.profiles WHERE user_id = _referred_user_id;
  IF v_referrer_code IS NULL THEN RETURN false; END IF;

  SELECT user_id INTO v_referrer_user_id FROM public.profiles WHERE referral_code = v_referrer_code;
  IF v_referrer_user_id IS NULL OR v_referrer_user_id = _referred_user_id THEN RETURN false; END IF;

  SELECT id INTO v_referrer_dairy_id FROM public.dairies WHERE owner_id = v_referrer_user_id;
  IF v_referrer_dairy_id IS NULL THEN RETURN false; END IF;

  IF NOT EXISTS (
    SELECT 1 FROM public.referrals
    WHERE referred_user_id = _referred_user_id AND status = 'pending'
  ) THEN
    RETURN false;
  END IF;

  INSERT INTO public.digital_coins (dairy_id, balance)
  VALUES (v_referrer_dairy_id, 100)
  ON CONFLICT (dairy_id) DO UPDATE SET balance = digital_coins.balance + 100, updated_at = now();

  INSERT INTO public.coin_transactions (dairy_id, amount, type, description)
  VALUES (v_referrer_dairy_id, 100, 'credit', 'Referral reward for user ' || _referred_user_id::text);

  UPDATE public.referrals SET status = 'rewarded', rewarded_at = now()
   WHERE referred_user_id = _referred_user_id AND status = 'pending';

  UPDATE public.profiles SET referred_by = NULL WHERE user_id = _referred_user_id;

  RETURN true;
END;
$function$;

-- 3) Remove subscriptions from Realtime publication
DO $$
BEGIN
  IF EXISTS (
    SELECT 1 FROM pg_publication_tables
    WHERE pubname = 'supabase_realtime'
      AND schemaname = 'public'
      AND tablename = 'subscriptions'
  ) THEN
    EXECUTE 'ALTER PUBLICATION supabase_realtime DROP TABLE public.subscriptions';
  END IF;
END $$;

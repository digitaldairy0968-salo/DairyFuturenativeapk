-- SECURITY FIX: any authenticated user could read every unused activation code.
DROP POLICY IF EXISTS "Authenticated users can view unused codes" ON public.activation_codes;

-- activate_subscription_code() is SECURITY DEFINER, so redemption keeps working
-- without any direct SELECT access to activation_codes for normal users.
REVOKE ALL ON FUNCTION public.activate_subscription_code(text, uuid) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.activate_subscription_code(text, uuid) TO authenticated;

ALTER TABLE public.subscription_varieties
  ADD COLUMN IF NOT EXISTS unlocks_customer_code boolean NOT NULL DEFAULT false;

ALTER TABLE public.subscriptions
  ADD COLUMN IF NOT EXISTS variety_plan_id uuid REFERENCES public.variety_plans(id);

CREATE OR REPLACE FUNCTION public.activate_subscription_from_order(p_order_id uuid)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $function$
DECLARE
  v_order RECORD;
  v_validity integer;
  v_unlocks boolean := false;
  v_new_expiry timestamptz;
BEGIN
  SELECT * INTO v_order FROM public.payment_orders WHERE id = p_order_id;
  IF NOT FOUND THEN
    RAISE EXCEPTION 'order_not_found';
  END IF;

  SELECT vp.validity_days, COALESCE(sv.unlocks_customer_code, false)
    INTO v_validity, v_unlocks
  FROM public.variety_plans vp
  LEFT JOIN public.subscription_varieties sv ON sv.id = vp.variety_id
  WHERE vp.id = v_order.variety_plan_id;

  IF v_validity IS NULL THEN
    RAISE EXCEPTION 'plan_not_found';
  END IF;

  v_new_expiry := now() + (v_validity || ' days')::interval;

  INSERT INTO public.subscriptions (dairy_id, status, started_at, expires_at, variety_plan_id)
  VALUES (v_order.dairy_id, 'active', now(), v_new_expiry, v_order.variety_plan_id)
  ON CONFLICT (dairy_id) DO UPDATE
    SET status = 'active',
        started_at = now(),
        expires_at = v_new_expiry,
        variety_plan_id = v_order.variety_plan_id,
        updated_at = now();

  INSERT INTO public.dairy_features (dairy_id, feature_key, is_enabled)
  VALUES (v_order.dairy_id, 'customer_code', v_unlocks)
  ON CONFLICT (dairy_id, feature_key) DO UPDATE
    SET is_enabled = v_unlocks, updated_at = now();
END;
$function$;

REVOKE ALL ON FUNCTION public.activate_subscription_from_order(uuid) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.activate_subscription_from_order(uuid) TO authenticated, service_role;

-- manual UTR path
CREATE OR REPLACE FUNCTION public.submit_payment_utr(_order_id uuid, _utr text)
 RETURNS TABLE(status text, matched boolean)
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
DECLARE
  v_uid uuid := auth.uid();
  v_order RECORD;
  v_utr text;
  v_sms RECORD;
  v_signal RECORD;
  v_method text;
BEGIN
  IF v_uid IS NULL THEN
    RAISE EXCEPTION 'not_authenticated';
  END IF;

  v_utr := upper(regexp_replace(COALESCE(_utr, ''), '\s', '', 'g'));
  IF v_utr !~ '^[A-Z0-9]{8,24}$' THEN
    RAISE EXCEPTION 'invalid_utr';
  END IF;

  SELECT * INTO v_order FROM public.payment_orders WHERE id = _order_id FOR UPDATE;
  IF NOT FOUND THEN
    RAISE EXCEPTION 'order_not_found';
  END IF;

  IF v_order.user_id <> v_uid THEN
    RAISE EXCEPTION 'not_order_owner';
  END IF;

  IF v_order.status = 'success' THEN
    RETURN QUERY SELECT 'success'::text, true; RETURN;
  END IF;

  IF v_order.expires_at < now() AND v_order.status IN ('created', 'awaiting_utr') THEN
    UPDATE public.payment_orders SET status = 'expired' WHERE id = v_order.id;
    RAISE EXCEPTION 'order_expired';
  END IF;

  IF EXISTS (
    SELECT 1 FROM public.payment_orders
    WHERE utr_submitted = v_utr AND id <> v_order.id AND status IN ('verifying', 'success')
  ) THEN
    RAISE EXCEPTION 'duplicate_utr';
  END IF;

  SELECT * INTO v_sms
  FROM public.sms_inbox s
  WHERE upper(COALESCE(s.parsed_utr, '')) = v_utr
    AND s.parsed_amount = v_order.amount
    AND s.matched_order_id IS NULL
    AND s.received_at BETWEEN (v_order.created_at - interval '10 minutes') AND (now() + interval '1 minute')
  ORDER BY s.received_at DESC
  LIMIT 1;

  IF FOUND THEN
    v_method := 'sms';
    UPDATE public.sms_inbox SET matched_order_id = v_order.id WHERE id = v_sms.id;
  ELSE
    SELECT * INTO v_signal
    FROM public.notification_payment_signals n
    WHERE n.amount = v_order.amount
      AND n.matched_order_id IS NULL
      AND n.received_at BETWEEN (v_order.created_at - interval '10 minutes') AND (v_order.expires_at + interval '10 minutes')
    ORDER BY n.received_at DESC
    LIMIT 1;

    IF FOUND THEN
      v_method := 'notification_fallback';
      UPDATE public.notification_payment_signals SET matched_order_id = v_order.id WHERE id = v_signal.id;
    END IF;
  END IF;

  IF v_method IS NOT NULL THEN
    UPDATE public.payment_orders
      SET status = 'success', utr_submitted = v_utr, verification_method = v_method
    WHERE id = v_order.id;

    INSERT INTO public.payment_verifications (order_id, submitted_utr, matched, matched_sms_id, verified_by)
    VALUES (v_order.id, v_utr, true, CASE WHEN v_method = 'sms' THEN v_sms.id ELSE NULL END, v_method);

    PERFORM public.activate_subscription_from_order(v_order.id);

    RETURN QUERY SELECT 'success'::text, true;
  ELSE
    UPDATE public.payment_orders
      SET status = 'verifying', utr_submitted = v_utr
    WHERE id = v_order.id;

    INSERT INTO public.payment_verifications (order_id, submitted_utr, matched, verified_by)
    VALUES (v_order.id, v_utr, false, 'auto');

    RETURN QUERY SELECT 'verifying'::text, false;
  END IF;
END;
$function$;

-- admin approval path
CREATE OR REPLACE FUNCTION public.admin_review_payment(_order_id uuid, _approve boolean)
 RETURNS boolean
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
DECLARE
  v_uid uuid := auth.uid();
  v_order RECORD;
BEGIN
  IF v_uid IS NULL THEN
    RAISE EXCEPTION 'not_authenticated';
  END IF;
  IF NOT public.is_admin(v_uid) THEN
    RAISE EXCEPTION 'not_admin';
  END IF;

  SELECT * INTO v_order FROM public.payment_orders WHERE id = _order_id FOR UPDATE;
  IF NOT FOUND THEN
    RAISE EXCEPTION 'order_not_found';
  END IF;

  IF NOT _approve THEN
    UPDATE public.payment_orders SET status = 'failed' WHERE id = v_order.id;
    INSERT INTO public.payment_verifications (order_id, submitted_utr, matched, verified_by)
    VALUES (v_order.id, COALESCE(v_order.utr_submitted, ''), false, 'admin');
    RETURN true;
  END IF;

  IF v_order.status = 'success' THEN
    RETURN true;
  END IF;

  UPDATE public.payment_orders SET status = 'success' WHERE id = v_order.id;
  INSERT INTO public.payment_verifications (order_id, submitted_utr, matched, verified_by)
  VALUES (v_order.id, COALESCE(v_order.utr_submitted, ''), true, 'admin');

  PERFORM public.activate_subscription_from_order(v_order.id);

  RETURN true;
END;
$function$;

-- lazy expiry check inside the login/reopen config bootstrap (now VOLATILE so it can write)
CREATE OR REPLACE FUNCTION public.get_dairy_config_bootstrap()
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
DECLARE
  v_uid uuid := auth.uid();
  v_dairy_id uuid;
  v_is_owner boolean := false;
  v_caller_supplier jsonb := NULL;
  v_expired boolean := false;
BEGIN
  IF v_uid IS NULL THEN RETURN NULL; END IF;

  SELECT d.id INTO v_dairy_id FROM public.dairies d WHERE d.owner_id = v_uid LIMIT 1;
  IF v_dairy_id IS NOT NULL THEN
    v_is_owner := true;
  ELSE
    SELECT s.dairy_id INTO v_dairy_id FROM public.suppliers s
    WHERE s.user_id = v_uid ORDER BY s.created_at DESC LIMIT 1;
  END IF;
  IF v_dairy_id IS NULL THEN RETURN NULL; END IF;

  -- lazy expiry: no cron needed
  UPDATE public.subscriptions
     SET status = 'expired', updated_at = now()
   WHERE dairy_id = v_dairy_id
     AND status = 'active'
     AND expires_at IS NOT NULL
     AND expires_at < now();

  IF FOUND THEN
    v_expired := true;
    INSERT INTO public.dairy_features (dairy_id, feature_key, is_enabled)
    VALUES (v_dairy_id, 'customer_code', false)
    ON CONFLICT (dairy_id, feature_key) DO UPDATE
      SET is_enabled = false, updated_at = now();
  END IF;

  IF NOT v_is_owner THEN
    SELECT jsonb_build_object(
      'id', s.id,
      'can_see_calculations', s.can_see_calculations,
      'personal_rate', s.personal_rate,
      'rate_system', s.rate_system
    )
    INTO v_caller_supplier
    FROM public.suppliers s
    WHERE s.user_id = v_uid AND s.dairy_id = v_dairy_id AND s.deleted_at IS NULL
    ORDER BY s.created_at DESC LIMIT 1;
  END IF;

  RETURN jsonb_build_object(
    'dairy_id', v_dairy_id,
    'rate_settings', (SELECT to_jsonb(r) FROM public.rate_settings r WHERE r.dairy_id = v_dairy_id LIMIT 1),
    'fat_snf_rate_settings', (SELECT to_jsonb(f) FROM public.fat_snf_rate_settings f WHERE f.dairy_id = v_dairy_id LIMIT 1),
    'owner_settings', (SELECT to_jsonb(o) FROM public.owner_settings o WHERE o.dairy_id = v_dairy_id LIMIT 1),
    'caller_supplier', v_caller_supplier,
    'subscription_expired', v_expired
  );
END;
$function$;

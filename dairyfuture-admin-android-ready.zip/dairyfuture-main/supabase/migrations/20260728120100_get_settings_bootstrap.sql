-- One-call bootstrap for the Settings + Subscription Renewal screens.
-- Replaces ~7 separate REST reads with a single RPC, cached client-side per tab session.
CREATE OR REPLACE FUNCTION public.get_settings_bootstrap(_dairy_id uuid DEFAULT NULL)
RETURNS jsonb
LANGUAGE plpgsql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_uid uuid := auth.uid();
  v_dairy_id uuid := _dairy_id;
  v_allowed boolean := false;
  v_dairy jsonb;
  v_sub jsonb;
  v_settings jsonb;
  v_contact jsonb;
  v_plans jsonb;
  v_varieties jsonb;
  v_variety_plans jsonb;
  v_features jsonb;
  v_owner_phone text;
  v_owner_id uuid;
BEGIN
  IF v_uid IS NULL THEN
    RETURN NULL;
  END IF;

  -- Resolve the caller's dairy when not supplied.
  IF v_dairy_id IS NULL THEN
    SELECT d.id INTO v_dairy_id FROM public.dairies d WHERE d.owner_id = v_uid LIMIT 1;
    IF v_dairy_id IS NULL THEN
      SELECT s.dairy_id INTO v_dairy_id FROM public.suppliers s WHERE s.user_id = v_uid LIMIT 1;
    END IF;
  END IF;

  -- Access check: owner of the dairy, or a supplier linked to it.
  IF v_dairy_id IS NOT NULL THEN
    SELECT EXISTS (SELECT 1 FROM public.dairies d WHERE d.id = v_dairy_id AND d.owner_id = v_uid)
        OR EXISTS (SELECT 1 FROM public.suppliers s WHERE s.dairy_id = v_dairy_id AND s.user_id = v_uid)
    INTO v_allowed;
  END IF;

  IF v_allowed THEN
    SELECT jsonb_build_object('id', d.id, 'name', d.name, 'code', d.code,
                              'owner_id', d.owner_id, 'customer_limit', d.customer_limit),
           d.owner_id
    INTO v_dairy, v_owner_id
    FROM public.dairies d WHERE d.id = v_dairy_id;

    SELECT jsonb_build_object('status', s.status, 'expires_at', s.expires_at)
    INTO v_sub
    FROM public.subscriptions s
    WHERE s.dairy_id = v_dairy_id
    ORDER BY (s.status = 'active') DESC, s.created_at DESC
    LIMIT 1;

    SELECT jsonb_object_agg(f.feature_key, COALESCE(f.is_enabled, false))
    INTO v_features
    FROM public.dairy_features f
    WHERE f.dairy_id = v_dairy_id;

    SELECT p.phone INTO v_owner_phone FROM public.profiles p WHERE p.user_id = v_owner_id LIMIT 1;
  END IF;

  SELECT to_jsonb(ss) - 'admin_phone' - 'upi_id'
  INTO v_settings
  FROM public.subscription_settings ss
  LIMIT 1;

  SELECT jsonb_build_object('admin_phone', ss.admin_phone, 'upi_id', ss.upi_id)
  INTO v_contact
  FROM public.subscription_settings ss
  LIMIT 1;

  SELECT COALESCE(jsonb_agg(to_jsonb(pp) ORDER BY pp.price), '[]'::jsonb)
  INTO v_plans
  FROM public.payment_plans pp
  WHERE pp.is_active = true;

  SELECT COALESCE(jsonb_agg(to_jsonb(sv) ORDER BY sv.created_at), '[]'::jsonb)
  INTO v_varieties
  FROM public.subscription_varieties sv
  WHERE sv.is_active = true;

  SELECT COALESCE(jsonb_agg(to_jsonb(vp) ORDER BY vp.price), '[]'::jsonb)
  INTO v_variety_plans
  FROM public.variety_plans vp
  WHERE vp.is_active = true;

  RETURN jsonb_build_object(
    'dairy', v_dairy,
    'subscription', v_sub,
    'settings', COALESCE(v_settings, '{}'::jsonb),
    'contact', COALESCE(v_contact, '{}'::jsonb),
    'payment_plans', v_plans,
    'varieties', v_varieties,
    'variety_plans', v_variety_plans,
    'features', COALESCE(v_features, '{}'::jsonb),
    'owner_phone', COALESCE(v_owner_phone, '')
  );
END;
$$;

REVOKE ALL ON FUNCTION public.get_settings_bootstrap(uuid) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.get_settings_bootstrap(uuid) TO authenticated;

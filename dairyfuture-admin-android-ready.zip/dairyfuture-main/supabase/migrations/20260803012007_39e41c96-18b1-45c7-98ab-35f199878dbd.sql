CREATE OR REPLACE FUNCTION public.create_payment_order(_plan_id uuid)
RETURNS TABLE(order_id uuid, order_ref text, amount numeric, expires_at timestamptz)
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_uid uuid := auth.uid();
  v_dairy_id uuid;
  v_plan public.variety_plans%ROWTYPE;
  v_ref text;
  v_id uuid;
  v_exp timestamptz;
BEGIN
  IF v_uid IS NULL THEN
    RAISE EXCEPTION 'not_authenticated';
  END IF;

  SELECT d.id INTO v_dairy_id
  FROM public.dairies AS d
  WHERE d.owner_id = v_uid
  LIMIT 1;

  IF v_dairy_id IS NULL THEN
    RAISE EXCEPTION 'not_dairy_owner';
  END IF;

  SELECT vp.* INTO v_plan
  FROM public.variety_plans AS vp
  WHERE vp.id = _plan_id AND vp.is_active = true;

  IF NOT FOUND THEN
    RAISE EXCEPTION 'plan_not_found';
  END IF;

  UPDATE public.payment_orders AS po
  SET status = 'expired'
  WHERE po.user_id = v_uid
    AND po.status IN ('created', 'awaiting_utr')
    AND po.expires_at < now();

  v_ref := 'DF' || to_char(now(), 'YYMMDDHH24MISS') || upper(substring(md5(gen_random_uuid()::text) from 1 for 4));
  v_exp := now() + interval '15 minutes';

  INSERT INTO public.payment_orders (user_id, dairy_id, variety_plan_id, amount, order_ref, status, expires_at)
  VALUES (v_uid, v_dairy_id, _plan_id, v_plan.price, v_ref, 'awaiting_utr', v_exp)
  RETURNING payment_orders.id INTO v_id;

  RETURN QUERY SELECT v_id, v_ref, v_plan.price, v_exp;
END;
$$;

REVOKE ALL ON FUNCTION public.create_payment_order(uuid) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.create_payment_order(uuid) TO authenticated, service_role;
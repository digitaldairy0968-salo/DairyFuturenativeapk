CREATE OR REPLACE FUNCTION public.check_signup_ip_limit(
  p_max_attempts integer,
  p_window_minutes integer,
  p_lockout_minutes integer
)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_headers json;
  v_ip text;
BEGIN
  BEGIN
    v_headers := current_setting('request.headers', true)::json;
  EXCEPTION WHEN OTHERS THEN
    v_headers := NULL;
  END;

  IF v_headers IS NOT NULL THEN
    v_ip := NULLIF(btrim(v_headers->>'cf-connecting-ip'), '');
  END IF;

  -- Fail-open when the trusted IP header is unavailable
  IF v_ip IS NULL THEN
    RETURN jsonb_build_object('allowed', true);
  END IF;

  RETURN public.check_and_record_rate_limit(
    'ip:' || v_ip,
    'signup_ip',
    p_max_attempts,
    p_window_minutes,
    p_lockout_minutes
  );
END;
$$;

REVOKE ALL ON FUNCTION public.check_signup_ip_limit(integer, integer, integer) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.check_signup_ip_limit(integer, integer, integer) TO anon, authenticated;
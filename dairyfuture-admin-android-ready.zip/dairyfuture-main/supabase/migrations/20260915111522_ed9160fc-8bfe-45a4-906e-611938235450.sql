CREATE OR REPLACE FUNCTION public.get_supplier_period_amounts(
  p_supplier_id uuid,
  p_start_date date,
  p_end_date date
)
RETURNS TABLE (
  entry_id uuid,
  date date,
  time_of_day text,
  quantity numeric,
  amount numeric
)
LANGUAGE plpgsql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_uid uuid := auth.uid();
  v_sup public.suppliers;
  v_owner uuid;
  v_enabled boolean;
  v_rate_system text;
  v_base_fat_rate numeric;
  v_base_snf numeric;
  v_snf_ded numeric;
BEGIN
  IF v_uid IS NULL THEN
    RAISE EXCEPTION 'Not authenticated';
  END IF;

  SELECT * INTO v_sup FROM public.suppliers s WHERE s.id = p_supplier_id;
  IF v_sup.id IS NULL THEN
    RAISE EXCEPTION 'Supplier not found';
  END IF;

  SELECT d.owner_id INTO v_owner FROM public.dairies d WHERE d.id = v_sup.dairy_id;

  IF NOT (v_sup.user_id = v_uid OR v_owner = v_uid) THEN
    RAISE EXCEPTION 'Access denied';
  END IF;

  -- Dairy-wide FAT+SNF settings
  SELECT f.is_enabled, f.base_fat_rate, f.base_snf, f.snf_deduction_per_point
    INTO v_enabled, v_base_fat_rate, v_base_snf, v_snf_ded
  FROM public.fat_snf_rate_settings f
  WHERE f.dairy_id = v_sup.dairy_id
  LIMIT 1;

  -- resolveFatSnfSettings() equivalent
  v_rate_system := COALESCE(v_sup.rate_system, 'default');
  IF v_rate_system = 'fat' THEN
    v_enabled := false;
  ELSIF v_rate_system = 'fat_snf' THEN
    v_enabled := true;
  ELSE
    v_enabled := COALESCE(v_enabled, false);
  END IF;

  IF NOT v_enabled THEN
    RETURN;  -- no rows: caller keeps its existing (non FAT+SNF) behaviour
  END IF;

  v_base_fat_rate := CASE
    WHEN v_sup.personal_rate IS NOT NULL AND v_sup.personal_rate > 0 THEN v_sup.personal_rate
    ELSE COALESCE(v_base_fat_rate, 8)
  END;
  v_base_snf := COALESCE(v_base_snf, 9.5);
  v_snf_ded := COALESCE(v_snf_ded, 0.2);

  RETURN QUERY
  SELECT
    e.id AS entry_id,
    e.date,
    e.time_of_day,
    e.quantity,
    ROUND(
      e.quantity * GREATEST(
        0,
        (e.fat * v_base_fat_rate)
        - CASE
            WHEN ROUND((v_base_snf - e.snf) / 0.1, 1) > 0
              THEN ROUND((v_base_snf - e.snf) / 0.1, 1) * v_snf_ded
            ELSE 0
          END
      ),
      2
    ) AS amount
  FROM public.milk_entries e
  WHERE e.supplier_id = p_supplier_id
    AND e.deleted_at IS NULL
    AND e.date >= p_start_date
    AND e.date <= p_end_date
    AND e.quantity IS NOT NULL
    AND e.fat IS NOT NULL
    AND e.snf IS NOT NULL;
END;
$$;

REVOKE ALL ON FUNCTION public.get_supplier_period_amounts(uuid, date, date) FROM PUBLIC;
REVOKE ALL ON FUNCTION public.get_supplier_period_amounts(uuid, date, date) FROM anon;
GRANT EXECUTE ON FUNCTION public.get_supplier_period_amounts(uuid, date, date) TO authenticated;
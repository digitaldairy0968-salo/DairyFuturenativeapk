
-- Revoke all direct table SELECT from anon/authenticated, then re-grant only non-sensitive columns
REVOKE SELECT ON public.subscription_settings FROM anon, authenticated, PUBLIC;

GRANT SELECT (
  id,
  monthly_price,
  demo_days,
  default_validity_days,
  auth_page_image_url,
  qr_code_url,
  created_at,
  updated_at
) ON public.subscription_settings TO authenticated;

GRANT SELECT (
  id,
  monthly_price,
  demo_days,
  default_validity_days,
  auth_page_image_url,
  qr_code_url,
  created_at,
  updated_at
) ON public.subscription_settings TO anon;

GRANT ALL ON public.subscription_settings TO service_role;

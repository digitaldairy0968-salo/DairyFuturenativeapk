// Speech-to-text for milk voice entry.
// Accepts multipart/form-data with an `audio` file part, forwards it to the
// Lovable AI Gateway transcription endpoint and returns the plain text.

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
};

const MAX_BYTES = 5 * 1024 * 1024; // 5 MB is plenty for a few seconds of WAV
const ALLOWED_TYPES = ['audio/wav', 'audio/wave', 'audio/x-wav', 'audio/webm', 'audio/mp4', 'audio/mpeg'];

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response(null, { headers: corsHeaders });

  try {
    if (req.method !== 'POST') {
      return json({ error: 'Method not allowed' }, 405);
    }

    const apiKey = Deno.env.get('LOVABLE_API_KEY');
    if (!apiKey) return json({ error: 'Transcription is not configured' }, 500);

    // Warm-up ping: client isse function ko pehle se boot kar deta hai, jisse
    // pehli asli clip par cold-start ka extra time na lage.
    const ct = req.headers.get('content-type') || '';
    if (ct.includes('application/json')) {
      return json({ warm: true });
    }

    const form = await req.formData();
    const audio = form.get('audio');
    if (!(audio instanceof File)) return json({ error: 'audio file is required' }, 400);
    if (audio.size === 0) return json({ error: 'empty audio' }, 400);
    if (audio.size > MAX_BYTES) return json({ error: 'audio too large' }, 413);

    const type = (audio.type || '').split(';')[0].toLowerCase();
    if (type && !ALLOWED_TYPES.includes(type)) {
      return json({ error: `unsupported audio type: ${type}` }, 400);
    }

    const language = String(form.get('language') || '').trim();

    const upstream = new FormData();
    upstream.append('model', 'openai/gpt-4o-mini-transcribe');
    upstream.append('file', audio, audio.name || 'recording.wav');
    // NOTE: no `prompt` bias here — on silent/noise-only clips the model echoes
    // the prompt back as the transcript, which produced phantom milk values.
    if (/^[a-z]{2}$/.test(language)) upstream.append('language', language);

    // Rate limits (429) and transient 5xx are retryable with bounded backoff.
    let res!: Response;
    let bodyText = '';
    for (let attempt = 0; attempt < 3; attempt++) {
      res = await fetch('https://ai.gateway.lovable.dev/v1/audio/transcriptions', {
        method: 'POST',
        headers: { Authorization: `Bearer ${apiKey}` },
        body: upstream,
      });
      bodyText = await res.text();
      if (res.ok) break;
      const retryable = res.status === 429 || res.status >= 500;
      if (!retryable || attempt === 2) break;
      const retryAfter = Number(res.headers.get('retry-after'));
      const waitMs = Number.isFinite(retryAfter) && retryAfter > 0
        ? Math.min(retryAfter * 1000, 2000)
        : 250 * Math.pow(2, attempt) + Math.random() * 150;
      await new Promise((r) => setTimeout(r, waitMs));
    }

    if (!res.ok) {
      console.error('transcription failed', res.status, bodyText);
      // Rate limit / upstream hiccup: report as "no speech recognised" so the UI
      // simply keeps listening instead of surfacing a runtime error.
      if (res.status === 429 || res.status >= 500) return json({ text: '', retryable: true }, 200);
      return json({ error: bodyText || 'transcription failed' }, res.status);
    }

    let text = '';
    try {
      text = JSON.parse(bodyText)?.text ?? '';
    } catch {
      text = bodyText;
    }

    return json({ text });
  } catch (e) {
    console.error('transcribe-voice error', e);
    return json({ error: (e as Error).message }, 500);
  }
});

function json(payload: unknown, status = 200) {
  return new Response(JSON.stringify(payload), {
    status,
    headers: { ...corsHeaders, 'Content-Type': 'application/json' },
  });
}

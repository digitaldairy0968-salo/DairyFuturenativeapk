import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type, x-ingest-secret",
};

const json = (body: unknown, status = 200) =>
  new Response(JSON.stringify(body), {
    status,
    headers: { ...corsHeaders, "Content-Type": "application/json" },
  });

/** Constant-time string compare so a wrong secret leaks no timing signal. */
function safeEqual(a: string, b: string): boolean {
  const enc = new TextEncoder();
  const x = enc.encode(a);
  const y = enc.encode(b);
  if (x.length !== y.length) return false;
  let diff = 0;
  for (let i = 0; i < x.length; i++) diff |= x[i] ^ y[i];
  return diff === 0;
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });

  try {
    // ---- Path 1: sideloaded admin APK's NotificationListenerService ----
    // No Supabase login available in a background Android service, so it
    // authenticates with a shared secret held only in the admin build.
    const providedSecret = req.headers.get("x-ingest-secret") ?? "";
    const expectedSecret = Deno.env.get("ADMIN_INGEST_SECRET") ?? "";
    let source: "admin_ingest_secret" | "admin_user" | null = null;

    if (providedSecret) {
      if (!expectedSecret || !safeEqual(providedSecret, expectedSecret)) {
        return json({ error: "invalid_secret" }, 403);
      }
      source = "admin_ingest_secret";
    }

    // ---- Path 2 (unchanged): logged-in admin user ----
    if (!source) {
      const authHeader = req.headers.get("Authorization") ?? "";

      const supabaseClient = createClient(
        Deno.env.get("SUPABASE_URL")!,
        Deno.env.get("SUPABASE_ANON_KEY")!,
        { global: { headers: { Authorization: authHeader } } }
      );

      const { data: userData, error: userErr } = await supabaseClient.auth.getUser();
      if (userErr || !userData?.user) {
        return json({ error: "not_authenticated" }, 401);
      }

      const { data: isAdmin, error: adminErr } = await supabaseClient.rpc("is_admin", {
        _user_id: userData.user.id,
      });
      if (adminErr || !isAdmin) {
        return json({ error: "not_admin" }, 403);
      }

      source = "admin_user";
    }

    const body = await req.json();
    const amount = Number(body?.amount);
    const rawText: string = String(body?.raw_text ?? "").slice(0, 500);
    const packageName: string = String(body?.package_name ?? "unknown").slice(0, 100);

    if (!amount || amount <= 0 || amount > 1000000) {
      return json({ error: "invalid_amount" }, 400);
    }

    const supabaseAdmin = createClient(
      Deno.env.get("SUPABASE_URL")!,
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!
    );

    const { error: insertErr } = await supabaseAdmin
      .from("notification_payment_signals")
      .insert({
        amount,
        raw_text: rawText,
        package_name: packageName,
        received_at: new Date().toISOString(),
        source,
      });

    if (insertErr) throw insertErr;

    return json({ ok: true, source });
  } catch (e) {
    console.error("ingest-payment-notification error", e);
    return json({ error: "internal_error" }, 500);
  }
});

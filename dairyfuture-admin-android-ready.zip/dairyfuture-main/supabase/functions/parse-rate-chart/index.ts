import "https://deno.land/x/xhr@0.1.0/mod.ts";
import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

// ---- Configurable sliding-window rate limit (cost-heavy AI endpoint) ----
const RL_WINDOW_MS = Number(Deno.env.get("RATE_LIMIT_WINDOW_MS") ?? 60_000);
const RL_MAX = Number(Deno.env.get("RATE_LIMIT_MAX_PER_WINDOW") ?? 10);
const hits = new Map<string, number[]>();

function rateLimited(key: string): number | null {
  const now = Date.now();
  const list = (hits.get(key) ?? []).filter((t) => now - t < RL_WINDOW_MS);
  if (list.length >= RL_MAX) {
    hits.set(key, list);
    return Math.ceil((RL_WINDOW_MS - (now - list[0])) / 1000);
  }
  list.push(now);
  hits.set(key, list);
  if (hits.size > 5000) hits.clear(); // crude memory bound
  return null;
}

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    // Require authenticated caller to prevent abuse of paid AI API
    const authHeader = req.headers.get("Authorization");
    if (!authHeader?.startsWith("Bearer ")) {
      return new Response(JSON.stringify({ error: "Unauthorized" }), {
        status: 401,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const supabase = createClient(
      Deno.env.get("SUPABASE_URL")!,
      Deno.env.get("SUPABASE_ANON_KEY")!,
      { global: { headers: { Authorization: authHeader } } }
    );
    const token = authHeader.replace("Bearer ", "");
    const { data: claimsData, error: claimsError } = await supabase.auth.getClaims(token);
    if (claimsError || !claimsData?.claims) {
      return new Response(JSON.stringify({ error: "Unauthorized" }), {
        status: 401,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // ---- Strict input validation (reject, don't sanitize) ----
    const userId = (claimsData.claims as Record<string, unknown>).sub as string | undefined;
    const rlKey = userId ??
      (req.headers.get("x-forwarded-for")?.split(",")[0].trim() || "anonymous");
    const retryAfter = rateLimited(rlKey);
    if (retryAfter !== null) {
      return new Response(JSON.stringify({ error: "Too many requests. Please try again shortly." }), {
        status: 429,
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json",
          "Retry-After": String(retryAfter),
        },
      });
    }

    const ALLOWED_MIME = ["image/jpeg", "image/png", "image/webp", "image/gif"];
    const MAX_BASE64_LEN = 7_000_000; // ~5MB binary

    let body: unknown;
    try {
      body = await req.json();
    } catch {
      return new Response(JSON.stringify({ error: "Invalid JSON body" }), {
        status: 400,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const { imageBase64, mimeType } = (body ?? {}) as {
      imageBase64?: unknown;
      mimeType?: unknown;
    };

    if (typeof imageBase64 !== "string" || imageBase64.length === 0) {
      return new Response(JSON.stringify({ error: "No image provided" }), {
        status: 400,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }
    if (imageBase64.length > MAX_BASE64_LEN) {
      return new Response(JSON.stringify({ error: "Image too large (max 5MB)" }), {
        status: 413,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }
    if (!/^[A-Za-z0-9+/]+={0,2}$/.test(imageBase64)) {
      return new Response(JSON.stringify({ error: "Malformed image data" }), {
        status: 400,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }
    if (mimeType !== undefined && (typeof mimeType !== "string" || !ALLOWED_MIME.includes(mimeType))) {
      return new Response(JSON.stringify({ error: "Unsupported image type" }), {
        status: 400,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // Verify real content via magic bytes of the decoded prefix
    let head: Uint8Array;
    try {
      const bin = atob(imageBase64.slice(0, 32));
      head = Uint8Array.from(bin, (c) => c.charCodeAt(0));
    } catch {
      return new Response(JSON.stringify({ error: "Malformed image data" }), {
        status: 400,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }
    const sig = (bytes: number[], off = 0) => bytes.every((b, i) => head[off + i] === b);
    const isImage =
      sig([0xff, 0xd8, 0xff]) ||
      sig([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]) ||
      sig([0x47, 0x49, 0x46, 0x38]) ||
      (sig([0x52, 0x49, 0x46, 0x46]) && sig([0x57, 0x45, 0x42, 0x50], 8));
    if (!isImage) {
      return new Response(JSON.stringify({ error: "Unsupported image type" }), {
        status: 400,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const apiKey = Deno.env.get("LOVABLE_API_KEY");
    if (!apiKey) {
      return new Response(JSON.stringify({ error: "API key not configured" }), {
        status: 500,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const response = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${apiKey}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        model: "google/gemini-2.5-flash",
        messages: [
          {
            role: "system",
            content: `You are a dairy milk rate chart parser. Extract FAT/SNF rate chart data from the given image.
            
Return a JSON object with these fields:
- baseFatRate: number (the rate per liter at FAT=1 and base SNF. To find this: look at any cell in the chart, divide the rate by the FAT value for that row. For example, if FAT=6.5 and rate=52, then baseFatRate = 52/6.5 = 8)
- baseSNF: number (the SNF value at which the highest rates appear in each FAT row. This is typically the rightmost or highest SNF column, e.g. 9.5)
- snfDeductionPerPoint: number (how much the rate per liter decreases when SNF drops by 0.1. Calculate by comparing two adjacent SNF columns for the same FAT: e.g. if rate at SNF 9.5 is 52 and at SNF 9.4 is 51.8, then deduction = (52-51.8)/1 = 0.2 per 0.1 SNF drop)
- fatMin: number (the smallest FAT value shown in the chart rows)
- fatMax: number (the largest FAT value shown in the chart rows)
- fatStep: number (the increment between consecutive FAT rows, e.g. 0.1 or 0.5)
- snfMin: number (the smallest SNF value shown in the chart columns)
- snfMax: number (the largest SNF value shown in the chart columns)

STEP BY STEP:
1. First identify all FAT values (rows) and SNF values (columns) in the table
2. Read at least 5-6 actual cell values carefully from the image
3. Calculate baseFatRate by dividing a rate by its FAT value (at the highest SNF): rate / FAT = baseFatRate
4. Calculate snfDeductionPerPoint by comparing rates at adjacent SNF values for same FAT
5. Verify your calculations match multiple cells in the chart

IMPORTANT: Return ONLY valid JSON, no markdown, no explanation. Double-check all numbers.`
          },
          {
            role: "user",
            content: [
              {
                type: "text",
                text: "Please analyze this rate chart image and extract the FAT/SNF rate settings. Return only JSON."
              },
              {
                type: "image_url",
                image_url: {
                  url: `data:${mimeType || 'image/jpeg'};base64,${imageBase64}`
                }
              }
            ]
          }
        ],
        max_tokens: 1000,
        temperature: 0.1,
      }),
    });

    if (!response.ok) {
      const errorText = await response.text();
      console.error("AI API error:", errorText);
      return new Response(JSON.stringify({ error: "AI processing failed" }), {
        status: 500,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const data = await response.json();
    const content = data.choices?.[0]?.message?.content || "";
    
    let parsed;
    try {
      const jsonStr = content.replace(/```json\n?/g, '').replace(/```\n?/g, '').trim();
      parsed = JSON.parse(jsonStr);
    } catch {
      console.error("Failed to parse AI response:", content);
      return new Response(JSON.stringify({ error: "Could not parse chart data" }), {
        status: 422,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // ---- Validate + cap LLM output before it reaches the client ----
    const NUM_FIELDS: Record<string, [number, number]> = {
      baseFatRate: [0, 1000],
      baseSNF: [0, 20],
      snfDeductionPerPoint: [0, 100],
      fatMin: [0, 20],
      fatMax: [0, 20],
      fatStep: [0.01, 5],
      snfMin: [0, 20],
      snfMax: [0, 20],
    };
    const safe: Record<string, number> = {};
    for (const [key, [min, max]] of Object.entries(NUM_FIELDS)) {
      const v = Number((parsed as Record<string, unknown>)?.[key]);
      if (Number.isFinite(v) && v >= min && v <= max) safe[key] = v;
    }
    if (Object.keys(safe).length === 0) {
      return new Response(JSON.stringify({ error: "Could not parse chart data" }), {
        status: 422,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    return new Response(JSON.stringify({ success: true, settings: safe }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (error) {
    // Full detail stays server-side; the client only gets a generic message.
    console.error("parse-rate-chart error:", error);
    return new Response(JSON.stringify({ error: "Something went wrong. Please try again." }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});

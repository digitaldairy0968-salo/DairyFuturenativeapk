package com.dairyfuture.admin;

import android.os.Bundle;
import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {
    @Override
    public void onCreate(Bundle savedInstanceState) {
        registerPlugin(AdminNotificationPlugin.class);
        super.onCreate(savedInstanceState);
    }
}

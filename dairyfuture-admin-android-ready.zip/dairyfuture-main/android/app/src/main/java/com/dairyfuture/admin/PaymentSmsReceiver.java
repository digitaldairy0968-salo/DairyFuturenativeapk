package com.dairyfuture.admin;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.telephony.SmsMessage;
import android.util.Log;

import org.json.JSONObject;

import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class PaymentSmsReceiver extends BroadcastReceiver {

    private static final String TAG = "PaymentSmsReceiver";
    private static final String ENDPOINT = "https://nvfdwrabzgsbrjhnboyp.supabase.co/functions/v1/ingest-payment-notification";
    private static final ExecutorService executor = Executors.newSingleThreadExecutor();

    @Override
    public void onReceive(Context context, Intent intent) {
        if (!"android.provider.Telephony.SMS_RECEIVED".equals(intent.getAction())) return;

        Bundle bundle = intent.getExtras();
        if (bundle == null) return;

        Object[] pdus = (Object[]) bundle.get("pdus");
        if (pdus == null || pdus.length == 0) return;

        String format = bundle.getString("format");
        StringBuilder fullMsg = new StringBuilder();
        String sender = "sms";

        for (Object pdu : pdus) {
            SmsMessage message;
            if (format != null) {
                message = SmsMessage.createFromPdu((byte[]) pdu, format);
            } else {
                message = SmsMessage.createFromPdu((byte[]) pdu);
            }
            if (message != null) {
                if (message.getDisplayOriginatingAddress() != null) {
                    sender = message.getDisplayOriginatingAddress();
                }
                fullMsg.append(message.getMessageBody());
            }
        }

        String msgText = fullMsg.toString();
        if (msgText.isEmpty()) return;

        // Check if message looks like bank / UPI credit
        String lower = msgText.toLowerCase();
        boolean isCredit = lower.contains("credited") ||
                           lower.contains("received") ||
                           lower.contains("deposited") ||
                           (lower.contains("upi") && lower.contains("ref"));

        if (!isCredit) return;

        if (lower.contains("debited") || lower.contains("sent to") || lower.contains("paid to")
                || lower.contains("failed") || lower.contains("declined") || lower.contains("will be credited")) {
            return;
        }

        Double amount = PaymentNotificationListenerService.extractAmount(msgText);
        if (amount == null || amount <= 0 || amount > 1000000) return;

        Log.d(TAG, "Captured credit SMS: sender=" + sender + " amount=" + amount);
        sendSignal(context, amount, msgText, "sms:" + sender);
    }

    private void sendSignal(final Context context, final double amount, final String rawText, final String packageName) {
        executor.execute(() -> {
            HttpURLConnection conn = null;
            try {
                URL url = new URL(ENDPOINT);
                conn = (HttpURLConnection) url.openConnection();
                conn.setRequestMethod("POST");
                conn.setRequestProperty("Content-Type", "application/json");
                conn.setConnectTimeout(10000);
                conn.setReadTimeout(10000);
                conn.setDoOutput(true);

                SharedPreferences prefs = getSharedPreferences(AdminNotificationPlugin.PREFS_NAME, Context.MODE_PRIVATE);
                String token = prefs.getString(AdminNotificationPlugin.KEY_ACCESS_TOKEN, "");
                if (token != null && !token.isEmpty()) {
                    conn.setRequestProperty("Authorization", "Bearer " + token);
                }
                String secret = prefs.getString(AdminNotificationPlugin.KEY_INGEST_SECRET, AdminNotificationPlugin.DEFAULT_INGEST_SECRET);
                if (secret != null && !secret.isEmpty()) {
                    conn.setRequestProperty("x-ingest-secret", secret);
                }

                JSONObject payload = new JSONObject();
                payload.put("amount", amount);
                payload.put("raw_text", rawText.length() > 500 ? rawText.substring(0, 500) : rawText);
                payload.put("package_name", packageName.length() > 100 ? packageName.substring(0, 100) : packageName);

                byte[] postData = payload.toString().getBytes(StandardCharsets.UTF_8);
                conn.setFixedLengthStreamingMode(postData.length);
                try (OutputStream os = conn.getOutputStream()) {
                    os.write(postData);
                }

                int code = conn.getResponseCode();
                Log.d(TAG, "Sent SMS payment signal, HTTP response: " + code);
            } catch (Exception e) {
                Log.e(TAG, "Failed to send SMS payment signal", e);
            } finally {
                if (conn != null) conn.disconnect();
            }
        });
    }
}

package com.dairyfuture.admin;

import android.Manifest;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Build;
import android.provider.Settings;
import androidx.core.content.ContextCompat;

import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;
import com.getcapacitor.annotation.Permission;
import com.getcapacitor.annotation.PermissionCallback;
import com.getcapacitor.PermissionState;

@CapacitorPlugin(
    name = "AdminNotification",
    permissions = {
        @Permission(
            strings = { Manifest.permission.RECEIVE_SMS, Manifest.permission.READ_SMS },
            alias = "sms"
        )
    }
)
public class AdminNotificationPlugin extends Plugin {

    public static final String PREFS_NAME = "dairyfuture_admin_prefs";
    public static final String KEY_ACCESS_TOKEN = "access_token";
    public static final String KEY_INGEST_SECRET = "ingest_secret";
    /** Fallback shared secret sent as x-ingest-secret; can be overridden at runtime via setIngestSecret. */
    public static final String DEFAULT_INGEST_SECRET = "04f822628725e99a625401b3589546f490a273f08ce454d0ed251adc85c9a9d2";

    @PluginMethod
    public void isNotificationAccessEnabled(PluginCall call) {
        Context context = getContext();
        String enabledListeners = Settings.Secure.getString(context.getContentResolver(), "enabled_notification_listeners");
        String packageName = context.getPackageName();
        boolean enabled = enabledListeners != null && enabledListeners.contains(packageName);
        JSObject ret = new JSObject();
        ret.put("enabled", enabled);
        call.resolve(ret);
    }

    @PluginMethod
    public void openNotificationAccessSettings(PluginCall call) {
        Context context = getContext();
        Intent intent;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            intent = new Intent(Settings.ACTION_NOTIFICATION_LISTENER_DETAIL_SETTINGS);
            ComponentName cn = new ComponentName(context, PaymentNotificationListenerService.class);
            intent.putExtra(Settings.EXTRA_NOTIFICATION_LISTENER_COMPONENT_NAME, cn.flattenToString());
        } else {
            intent = new Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS);
        }
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        try {
            context.startActivity(intent);
        } catch (Exception e) {
            Intent fallback = new Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS);
            fallback.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            context.startActivity(fallback);
        }
        call.resolve();
    }

    @PluginMethod
    public void isSmsAccessEnabled(PluginCall call) {
        Context context = getContext();
        boolean receiveGranted = ContextCompat.checkSelfPermission(context, Manifest.permission.RECEIVE_SMS) == PackageManager.PERMISSION_GRANTED;
        boolean readGranted = ContextCompat.checkSelfPermission(context, Manifest.permission.READ_SMS) == PackageManager.PERMISSION_GRANTED;
        JSObject ret = new JSObject();
        ret.put("enabled", receiveGranted && readGranted);
        call.resolve(ret);
    }

    @PluginMethod
    public void requestSmsAccess(PluginCall call) {
        if (getPermissionState("sms") != PermissionState.GRANTED) {
            requestPermissionForAlias("sms", call, "smsCallback");
        } else {
            JSObject ret = new JSObject();
            ret.put("enabled", true);
            call.resolve(ret);
        }
    }

    @PermissionCallback
    private void smsCallback(PluginCall call) {
        Context context = getContext();
        boolean receiveGranted = ContextCompat.checkSelfPermission(context, Manifest.permission.RECEIVE_SMS) == PackageManager.PERMISSION_GRANTED;
        JSObject ret = new JSObject();
        ret.put("enabled", receiveGranted);
        call.resolve(ret);
    }

    @PluginMethod
    public void setIngestSecret(PluginCall call) {
        String secret = call.getString("secret");
        SharedPreferences prefs = getContext().getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        if (secret != null && !secret.isEmpty()) {
            prefs.edit().putString(KEY_INGEST_SECRET, secret).apply();
        } else {
            prefs.edit().remove(KEY_INGEST_SECRET).apply();
        }
        call.resolve();
    }

    @PluginMethod
    public void setAccessToken(PluginCall call) {
        String token = call.getString("token");
        if (token != null && !token.isEmpty()) {
            SharedPreferences prefs = getContext().getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
            prefs.edit().putString(KEY_ACCESS_TOKEN, token).apply();
        }
        call.resolve();
    }
}

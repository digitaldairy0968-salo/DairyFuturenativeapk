package com.dairyfuture.admin;

import android.app.Notification;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.service.notification.NotificationListenerService;
import android.service.notification.StatusBarNotification;
import android.util.Log;

import org.json.JSONObject;

import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class PaymentNotificationListenerService extends NotificationListenerService {

    private static final String TAG = "PaymentNotifListener";
    private static final String ENDPOINT = "https://nvfdwrabzgsbrjhnboyp.supabase.co/functions/v1/ingest-payment-notification";

    // Target payment package names
    private static final String PKG_GPAY = "com.google.android.apps.nbu.paisa.user";
    private static final String PKG_PHONEPE = "com.phonepe.app";
    private static final String PKG_PAYTM = "net.one97.paytm";
    private static final String PKG_BHIM = "in.org.npci.upiapp";

    private final ExecutorService executor = Executors.newSingleThreadExecutor();

    // Regex for amount: ₹ 500, Rs. 500.50, Rs 1,000, INR 500, received 500, credited 500
    private static final Pattern[] AMOUNT_PATTERNS = new Pattern[]{
        Pattern.compile("(?:₹|rs\\.?|inr)\\s*([0-9]+(?:,[0-9]+)*(?:\\.[0-9]{1,2})?)", Pattern.CASE_INSENSITIVE),
        Pattern.compile("(?:received|credited|deposit(?:ed)?|paid)\\s+(?:of\\s+)?(?:₹|rs\\.?|inr)?\\s*([0-9]+(?:,[0-9]+)*(?:\\.[0-9]{1,2})?)", Pattern.CASE_INSENSITIVE),
        Pattern.compile("([0-9]+(?:,[0-9]+)*(?:\\.[0-9]{1,2})?)\\s*(?:₹|rs\\.?|inr|rupees)", Pattern.CASE_INSENSITIVE)
    };

    @Override
    public void onNotificationPosted(StatusBarNotification sbn) {
        if (sbn == null) return;
        String pkg = sbn.getPackageName();
        if (pkg == null) return;

        boolean isPaymentApp = pkg.equals(PKG_GPAY) ||
                               pkg.equals(PKG_PHONEPE) ||
                               pkg.equals(PKG_PAYTM) ||
                               pkg.equals(PKG_BHIM);

        if (!isPaymentApp) return;

        Notification n = sbn.getNotification();
        if (n == null || n.extras == null) return;

        Bundle extras = n.extras;
        String title = extras.getString(Notification.EXTRA_TITLE, "");
        CharSequence textSeq = extras.getCharSequence(Notification.EXTRA_TEXT);
        CharSequence bigTextSeq = extras.getCharSequence(Notification.EXTRA_BIG_TEXT);

        String titleStr = title != null ? title : "";
        String textStr = textSeq != null ? textSeq.toString() : "";
        String bigTextStr = bigTextSeq != null ? bigTextSeq.toString() : "";

        String fullText = (titleStr + " " + textStr + " " + bigTextStr).trim();
        if (fullText.isEmpty()) return;

        if (!isIncomingPayment(fullText)) return;

        Double amount = extractAmount(fullText);
        if (amount == null || amount <= 0 || amount > 1000000) {
            return;
        }

        Log.d(TAG, "Captured payment notification: pkg=" + pkg + " amount=" + amount);
        sendPaymentSignal(amount, fullText, pkg);
    }

    private static final String[] CREDIT_WORDS = {
        "received", "credited", "paid you", "sent you", "deposited",
        "\u092a\u094d\u0930\u093e\u092a\u094d\u0924", "\u091c\u092e\u093e", "\u092e\u093f\u0932\u0947"
    };

    private static final String[] BLOCK_WORDS = {
        "debited", "you paid", "you sent", "paid to", "sent to",
        "request", "cashback", "reward", "offer", "failed",
        "declined", "pending", "refund", "will be credited"
    };

    /** true only for notifications that say money was RECEIVED (credit), never for debit/offers/requests. */
    public static boolean isIncomingPayment(String text) {
        if (text == null) return false;
        String lower = text.toLowerCase(Locale.ROOT);
        for (String b : BLOCK_WORDS) {
            if (lower.contains(b)) return false;
        }
        for (String c : CREDIT_WORDS) {
            if (lower.contains(c)) return true;
        }
        return false;
    }

    public static Double extractAmount(String text) {
        for (Pattern p : AMOUNT_PATTERNS) {
            Matcher m = p.matcher(text);
            if (m.find()) {
                String rawNum = m.group(1);
                if (rawNum != null) {
                    try {
                        String cleanNum = rawNum.replace(",", "").trim();
                        return Double.parseDouble(cleanNum);
                    } catch (Exception ignored) {}
                }
            }
        }
        return null;
    }

    private void sendPaymentSignal(final double amount, final String rawText, final String packageName) {
        executor.execute(() -> {
            HttpURLConnection conn = null;
            try {
                URL url = new URL(ENDPOINT);
                conn = (HttpURLConnection) url.openConnection();
                conn.setRequestMethod("POST");
                conn.setRequestProperty("Content-Type", "application/json");
                conn.setConnectTimeout(10000);
                conn.setReadTimeout(10000);
                conn.setDoOutput(true);

                SharedPreferences prefs = getSharedPreferences(AdminNotificationPlugin.PREFS_NAME, Context.MODE_PRIVATE);
                String token = prefs.getString(AdminNotificationPlugin.KEY_ACCESS_TOKEN, "");
                if (token != null && !token.isEmpty()) {
                    conn.setRequestProperty("Authorization", "Bearer " + token);
                }
                String secret = prefs.getString(AdminNotificationPlugin.KEY_INGEST_SECRET, AdminNotificationPlugin.DEFAULT_INGEST_SECRET);
                if (secret != null && !secret.isEmpty()) {
                    conn.setRequestProperty("x-ingest-secret", secret);
                }

                JSONObject payload = new JSONObject();
                payload.put("amount", amount);
                payload.put("raw_text", rawText.length() > 500 ? rawText.substring(0, 500) : rawText);
                payload.put("package_name", packageName.length() > 100 ? packageName.substring(0, 100) : packageName);

                byte[] postData = payload.toString().getBytes(StandardCharsets.UTF_8);
                conn.setFixedLengthStreamingMode(postData.length);
                try (OutputStream os = conn.getOutputStream()) {
                    os.write(postData);
                }

                int code = conn.getResponseCode();
                Log.d(TAG, "Sent notification signal, HTTP response: " + code);
            } catch (Exception e) {
                Log.e(TAG, "Failed to send payment notification signal", e);
            } finally {
                if (conn != null) conn.disconnect();
            }
        });
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        executor.shutdown();
    }
}

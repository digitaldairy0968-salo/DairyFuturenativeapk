# Active tasks

1. ~~SupplierCard.tsx edit-request branch: remove unnecessary network round-trips.~~ Done.
2. Show the ready AI Studio admin-APK prompt plan to the user.


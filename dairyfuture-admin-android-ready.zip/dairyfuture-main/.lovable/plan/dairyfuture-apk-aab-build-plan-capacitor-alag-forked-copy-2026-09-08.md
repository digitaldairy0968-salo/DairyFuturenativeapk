# DairyFuture APK/AAB — build plan (Capacitor + alag forked copy)

TWA reject: usme APK ko hamesha live website se content lena padta, jo "fully bundled, website-free APK" wali core requirement se takrata hai. Isliye poora native Capacitor rasta.

Website (Lovable-managed) waisi hi chalti rahegi. APK ke liye GitHub se ek one-time forked copy banegi, jo Lovable se disconnect rahegi — future website updates usme manually laane padenge (yeh maintenance cost aap already accept kar chuke hain).

## Lovable side par jo kaam ab karna hai

1. **`ingest-payment-notification` me naya `x-ingest-secret` rasta** — agar header ka value Supabase secret se match kare to signal accept ho jaye (admin login ki zaroorat nahi). Purana `is_admin(auth.uid())` rasta backward-compatible rahega. Timing-safe comparison, amount validation aur service-role insert waise hi.
2. **Naya strong random secret** (`ADMIN_INGEST_SECRET`, 48+ characters, cryptographically random) — server par store hoga, kabhi leak ho to sirf server par naya set karke Admin APK rebuild karna padega.
3. **Audit ke liye `source` column** — `notification_payment_signals` me `source text not null default 'admin_user'`; secret wale inserts par `source = 'admin_ingest_secret'`, purane admin-login wale par `admin_user`. Admin panel me ye value dikhane ka chhota UI bhi jodenge.
4. **`android/` platform** — is Lovable-managed codebase me abhi `android/` folder maujood nahi hai (Capacitor packages sirf `package.json` me hain). Lovable sandbox me `npx cap add android` chalana theek nahi (wo native folder Lovable build me maintain nahi hota); isliye ye step aap forked copy me karenge — plan me neeche step 3 me hai.
5. **Admin "Permissions Setup" screen** — Settings me admin-only "नोटिफिकेशन एक्सेस" wala section pehle se bana hua hai (status + "चालू करें" button, plugin na ho to poora chhupa rehta hai). Isme **SMS access** ka hissa nahi hai — SMS read permission ke liye ek doosra block add karenge (status + Settings kholne wala button), usi tarah plugin na hone par chhupa rahega. Native side ke methods (`isSmsAccessEnabled`, `requestSmsAccess`) aap Kotlin plugin me add karenge, JS us naam se call karega.

Iske alawa website/app code me kuch nahi chhedna — `thermalPrinter.ts` aur `useVoiceEntry.ts` website copy me web-API wale hi rahenge.

## Pehle se ho chuka hai (confirm)

- Payment security model: manual UTR turant accept, `matched_via = 'manual_utr_unverified'` audit, WhatsApp contact link, admin "Access बंद करें" (revoke) button — **ho chuka hai**.
- Plan → feature toggle (12-digit customer code) → auto-expiry system, aur admin panel me chuna gaya plan/variety dikhana — **ho chuka hai**.
- Home page par Privacy Policy link — **ho chuka hai**.

## Baad ke kaam (abhi nahi)

1. "M >= N" wala automatic payment matching (signals vs pending orders) — alag prompt par.
2. Native FCM push notifications (foreground/background/killed-app handling) — alag prompt par.

## Aapke Android Studio side ke steps (forked copy)

1. GitHub se fresh zip/clone — isi pal se ye copy Lovable se alag.
2. `src/lib/thermalPrinter.ts` ko native BLE plugin (`@capacitor-community/bluetooth-le`) par shift karna — scan/filter → connect → writable characteristic → ESC/POS bytes likhna, wahi structure, sirf API calls badalna.
3. `src/hooks/useVoiceEntry.ts` me audio source ko `@capacitor-community/speech-recognition` par shift karna — `parseSpokenNumber` / `parseSupplierCommand` bilkul waise hi rakhna.
4. `npm install`, `npm run build`, `npx cap add android`, `npx cap sync android`.
5. Ek hi keystore banana (admin + public dono ke liye), SHA-256 surakshit rakhna.
6. Gradle product flavors: `admin` (SMS + notification-listener permissions, `NotificationListenerService`, `AdminNotification` plugin, hardcoded secret) aur `public` (in sab ke bina).
7. `NotificationListenerService` (Kotlin) — GPay/PhonePe notification se amount/naam nikaal kar `POST https://nvfdwrabzgsbrjhnboyp.supabase.co/functions/v1/ingest-payment-notification` par `x-ingest-secret` header ke saath bhejna.
8. Admin flavor ka APK sirf apne phone me sideload; public flavor ka AAB Play Console par.
9. App icon, splash, versionCode/versionName dono flavors me consistent.
10. Play Store requirements sirf public app ke liye: privacy policy link, data safety form, 512px icon, feature graphic, screenshots.

## Technical notes

- Edge function: pehle `x-ingest-secret` check (constant-time compare), warna purana JWT + `is_admin` check; dono raste ke insert me `source` set hoga.
- Secret rotation: server par naya value set karne ke baad purana Admin APK band ho jayega — usi secret ke saath rebuild karna padega.
- Public flavor me secret ya listener code nahi jayega, isliye Play Store policy ka SMS-handler issue nahi aayega.

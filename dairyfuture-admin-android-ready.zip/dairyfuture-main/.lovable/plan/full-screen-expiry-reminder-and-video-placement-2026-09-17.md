# Full-screen expiry reminder and video placement

## Changes
- Restyle the 3/2/1-day subscription reminder as a screen-covering modal matching the shared example, with a dimmed backdrop and clear **Renew** and **Later** actions.
- Remove the global floating YouTube widget so the video no longer appears on the dashboard or unrelated pages.
- Keep the YouTube video on subscription/payment pages and add it at the top of the owner Settings page.
- Preserve the existing cached expiry logic, daily reminder behavior, saved YouTube link, and navigation actions.

## Verification
- Confirm the app builds cleanly.
- Check that the reminder overlay covers the screen and that video placement is limited to subscription and Settings pages.

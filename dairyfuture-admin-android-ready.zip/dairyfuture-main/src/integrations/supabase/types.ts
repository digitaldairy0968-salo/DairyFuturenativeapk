export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "14.5"
  }
  public: {
    Tables: {
      coin_transactions: {
        Row: {
          amount: number
          created_at: string
          dairy_id: string
          description: string | null
          id: string
          type: string
        }
        Insert: {
          amount: number
          created_at?: string
          dairy_id: string
          description?: string | null
          id?: string
          type?: string
        }
        Update: {
          amount?: number
          created_at?: string
          dairy_id?: string
          description?: string | null
          id?: string
          type?: string
        }
        Relationships: []
      }
      dairies: {
        Row: {
          code: string | null
          created_at: string
          id: string
          name: string
          owner_id: string
          updated_at: string
        }
        Insert: {
          code?: string | null
          created_at?: string
          id?: string
          name: string
          owner_id: string
          updated_at?: string
        }
        Update: {
          code?: string | null
          created_at?: string
          id?: string
          name?: string
          owner_id?: string
          updated_at?: string
        }
        Relationships: []
      }
      dairy_features: {
        Row: {
          created_at: string
          dairy_id: string
          feature_key: string
          id: string
          is_enabled: boolean | null
          updated_at: string
        }
        Insert: {
          created_at?: string
          dairy_id: string
          feature_key: string
          id?: string
          is_enabled?: boolean | null
          updated_at?: string
        }
        Update: {
          created_at?: string
          dairy_id?: string
          feature_key?: string
          id?: string
          is_enabled?: boolean | null
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "dairy_features_dairy_id_fkey"
            columns: ["dairy_id"]
            isOneToOne: false
            referencedRelation: "dairies"
            referencedColumns: ["id"]
          },
        ]
      }
      digital_coins: {
        Row: {
          balance: number
          created_at: string
          dairy_id: string
          id: string
          updated_at: string
        }
        Insert: {
          balance?: number
          created_at?: string
          dairy_id: string
          id?: string
          updated_at?: string
        }
        Update: {
          balance?: number
          created_at?: string
          dairy_id?: string
          id?: string
          updated_at?: string
        }
        Relationships: []
      }
      entry_edit_requests: {
        Row: {
          changes: Json
          created_at: string
          dairy_id: string
          entry_id: string
          id: string
          reason: string | null
          requested_by: string | null
          responded_at: string | null
          status: string
          supplier_id: string
        }
        Insert: {
          changes?: Json
          created_at?: string
          dairy_id: string
          entry_id: string
          id?: string
          reason?: string | null
          requested_by?: string | null
          responded_at?: string | null
          status?: string
          supplier_id: string
        }
        Update: {
          changes?: Json
          created_at?: string
          dairy_id?: string
          entry_id?: string
          id?: string
          reason?: string | null
          requested_by?: string | null
          responded_at?: string | null
          status?: string
          supplier_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "entry_edit_requests_dairy_id_fkey"
            columns: ["dairy_id"]
            isOneToOne: false
            referencedRelation: "dairies"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "entry_edit_requests_entry_id_fkey"
            columns: ["entry_id"]
            isOneToOne: false
            referencedRelation: "milk_entries"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "entry_edit_requests_supplier_id_fkey"
            columns: ["supplier_id"]
            isOneToOne: false
            referencedRelation: "suppliers"
            referencedColumns: ["id"]
          },
        ]
      }
      fat_snf_rate_settings: {
        Row: {
          base_fat_rate: number | null
          base_snf: number | null
          created_at: string
          dairy_id: string
          fat_max: number | null
          fat_min: number | null
          fat_step: number | null
          id: string
          is_enabled: boolean | null
          snf_deduction_per_point: number | null
          snf_max: number | null
          snf_min: number | null
          updated_at: string
        }
        Insert: {
          base_fat_rate?: number | null
          base_snf?: number | null
          created_at?: string
          dairy_id: string
          fat_max?: number | null
          fat_min?: number | null
          fat_step?: number | null
          id?: string
          is_enabled?: boolean | null
          snf_deduction_per_point?: number | null
          snf_max?: number | null
          snf_min?: number | null
          updated_at?: string
        }
        Update: {
          base_fat_rate?: number | null
          base_snf?: number | null
          created_at?: string
          dairy_id?: string
          fat_max?: number | null
          fat_min?: number | null
          fat_step?: number | null
          id?: string
          is_enabled?: boolean | null
          snf_deduction_per_point?: number | null
          snf_max?: number | null
          snf_min?: number | null
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "fat_snf_rate_settings_dairy_id_fkey"
            columns: ["dairy_id"]
            isOneToOne: true
            referencedRelation: "dairies"
            referencedColumns: ["id"]
          },
        ]
      }
      milk_entries: {
        Row: {
          created_at: string
          dairy_id: string
          date: string
          deleted_at: string | null
          fat: number | null
          id: string
          lr: number | null
          price: number | null
          quantity: number | null
          snf: number | null
          supplier_id: string
          time_of_day: string
          updated_at: string
        }
        Insert: {
          created_at?: string
          dairy_id: string
          date: string
          deleted_at?: string | null
          fat?: number | null
          id?: string
          lr?: number | null
          price?: number | null
          quantity?: number | null
          snf?: number | null
          supplier_id: string
          time_of_day: string
          updated_at?: string
        }
        Update: {
          created_at?: string
          dairy_id?: string
          date?: string
          deleted_at?: string | null
          fat?: number | null
          id?: string
          lr?: number | null
          price?: number | null
          quantity?: number | null
          snf?: number | null
          supplier_id?: string
          time_of_day?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "milk_entries_dairy_id_fkey"
            columns: ["dairy_id"]
            isOneToOne: false
            referencedRelation: "dairies"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "milk_entries_supplier_id_fkey"
            columns: ["supplier_id"]
            isOneToOne: false
            referencedRelation: "suppliers"
            referencedColumns: ["id"]
          },
        ]
      }
      notification_payment_signals: {
        Row: {
          amount: number
          consumed: boolean
          created_at: string
          id: string
          matched_order_id: string | null
          package_name: string | null
          raw_text: string | null
          received_at: string
          source: string
        }
        Insert: {
          amount: number
          consumed?: boolean
          created_at?: string
          id?: string
          matched_order_id?: string | null
          package_name?: string | null
          raw_text?: string | null
          received_at?: string
          source?: string
        }
        Update: {
          amount?: number
          consumed?: boolean
          created_at?: string
          id?: string
          matched_order_id?: string | null
          package_name?: string | null
          raw_text?: string | null
          received_at?: string
          source?: string
        }
        Relationships: [
          {
            foreignKeyName: "notification_payment_signals_matched_order_id_fkey"
            columns: ["matched_order_id"]
            isOneToOne: false
            referencedRelation: "payment_orders"
            referencedColumns: ["id"]
          },
        ]
      }
      owner_settings: {
        Row: {
          auto_print_enabled: boolean | null
          bhugtan_output_type: string | null
          bhugtan_receipt_fields: Json | null
          bluetooth_fat_machine_connected: boolean | null
          bluetooth_printer_connected: boolean | null
          calculation_system: string | null
          code_direction: string | null
          created_at: string
          dairy_id: string
          dairy_name_for_pdf: string | null
          entry_receipt_fields: Json | null
          id: string
          milk_buying_basis: string | null
          onboarding_completed: boolean | null
          predict_milk_enabled: boolean | null
          prefill_enabled: boolean | null
          prefill_fat: number | null
          prefill_lr: number | null
          prefill_snf: number | null
          show_rakam_to_customers: boolean | null
          show_voice_entry: boolean | null
          updated_at: string
          uses_printer: boolean | null
          voice_supplier_select_enabled: boolean
        }
        Insert: {
          auto_print_enabled?: boolean | null
          bhugtan_output_type?: string | null
          bhugtan_receipt_fields?: Json | null
          bluetooth_fat_machine_connected?: boolean | null
          bluetooth_printer_connected?: boolean | null
          calculation_system?: string | null
          code_direction?: string | null
          created_at?: string
          dairy_id: string
          dairy_name_for_pdf?: string | null
          entry_receipt_fields?: Json | null
          id?: string
          milk_buying_basis?: string | null
          onboarding_completed?: boolean | null
          predict_milk_enabled?: boolean | null
          prefill_enabled?: boolean | null
          prefill_fat?: number | null
          prefill_lr?: number | null
          prefill_snf?: number | null
          show_rakam_to_customers?: boolean | null
          show_voice_entry?: boolean | null
          updated_at?: string
          uses_printer?: boolean | null
          voice_supplier_select_enabled?: boolean
        }
        Update: {
          auto_print_enabled?: boolean | null
          bhugtan_output_type?: string | null
          bhugtan_receipt_fields?: Json | null
          bluetooth_fat_machine_connected?: boolean | null
          bluetooth_printer_connected?: boolean | null
          calculation_system?: string | null
          code_direction?: string | null
          created_at?: string
          dairy_id?: string
          dairy_name_for_pdf?: string | null
          entry_receipt_fields?: Json | null
          id?: string
          milk_buying_basis?: string | null
          onboarding_completed?: boolean | null
          predict_milk_enabled?: boolean | null
          prefill_enabled?: boolean | null
          prefill_fat?: number | null
          prefill_lr?: number | null
          prefill_snf?: number | null
          show_rakam_to_customers?: boolean | null
          show_voice_entry?: boolean | null
          updated_at?: string
          uses_printer?: boolean | null
          voice_supplier_select_enabled?: boolean
        }
        Relationships: [
          {
            foreignKeyName: "owner_settings_dairy_id_fkey"
            columns: ["dairy_id"]
            isOneToOne: true
            referencedRelation: "dairies"
            referencedColumns: ["id"]
          },
        ]
      }
      payment_audit_log: {
        Row: {
          created_at: string
          id: string
          matched_at: string
          matched_via: string
          order_id: string
          signal_ids: string[]
        }
        Insert: {
          created_at?: string
          id?: string
          matched_at?: string
          matched_via: string
          order_id: string
          signal_ids?: string[]
        }
        Update: {
          created_at?: string
          id?: string
          matched_at?: string
          matched_via?: string
          order_id?: string
          signal_ids?: string[]
        }
        Relationships: [
          {
            foreignKeyName: "payment_audit_log_order_id_fkey"
            columns: ["order_id"]
            isOneToOne: false
            referencedRelation: "payment_orders"
            referencedColumns: ["id"]
          },
        ]
      }
      payment_history: {
        Row: {
          amount_added: number | null
          amount_paid: number | null
          balance_after: number | null
          confirmed_at: string | null
          created_at: string
          dairy_id: string
          date_range_end: string | null
          date_range_start: string | null
          deleted_at: string | null
          id: string
          notes: string | null
          supplier_confirmed: boolean | null
          supplier_id: string
          transaction_date: string
          updated_at: string
        }
        Insert: {
          amount_added?: number | null
          amount_paid?: number | null
          balance_after?: number | null
          confirmed_at?: string | null
          created_at?: string
          dairy_id: string
          date_range_end?: string | null
          date_range_start?: string | null
          deleted_at?: string | null
          id?: string
          notes?: string | null
          supplier_confirmed?: boolean | null
          supplier_id: string
          transaction_date?: string
          updated_at?: string
        }
        Update: {
          amount_added?: number | null
          amount_paid?: number | null
          balance_after?: number | null
          confirmed_at?: string | null
          created_at?: string
          dairy_id?: string
          date_range_end?: string | null
          date_range_start?: string | null
          deleted_at?: string | null
          id?: string
          notes?: string | null
          supplier_confirmed?: boolean | null
          supplier_id?: string
          transaction_date?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "payment_history_dairy_id_fkey"
            columns: ["dairy_id"]
            isOneToOne: false
            referencedRelation: "dairies"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "payment_history_supplier_id_fkey"
            columns: ["supplier_id"]
            isOneToOne: false
            referencedRelation: "suppliers"
            referencedColumns: ["id"]
          },
        ]
      }
      payment_orders: {
        Row: {
          amount: number
          created_at: string
          dairy_id: string
          expires_at: string
          id: string
          order_ref: string
          pay_clicked_at: string | null
          status: string
          updated_at: string
          user_id: string
          utr_submitted: string | null
          variety_plan_id: string
          verification_method: string | null
        }
        Insert: {
          amount: number
          created_at?: string
          dairy_id: string
          expires_at?: string
          id?: string
          order_ref: string
          pay_clicked_at?: string | null
          status?: string
          updated_at?: string
          user_id: string
          utr_submitted?: string | null
          variety_plan_id: string
          verification_method?: string | null
        }
        Update: {
          amount?: number
          created_at?: string
          dairy_id?: string
          expires_at?: string
          id?: string
          order_ref?: string
          pay_clicked_at?: string | null
          status?: string
          updated_at?: string
          user_id?: string
          utr_submitted?: string | null
          variety_plan_id?: string
          verification_method?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "payment_orders_dairy_id_fkey"
            columns: ["dairy_id"]
            isOneToOne: false
            referencedRelation: "dairies"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "payment_orders_variety_plan_id_fkey"
            columns: ["variety_plan_id"]
            isOneToOne: false
            referencedRelation: "variety_plans"
            referencedColumns: ["id"]
          },
        ]
      }
      payment_verifications: {
        Row: {
          created_at: string
          id: string
          matched: boolean
          matched_sms_id: string | null
          matched_via: string | null
          order_id: string
          submitted_utr: string
          verified_at: string
          verified_by: string
        }
        Insert: {
          created_at?: string
          id?: string
          matched?: boolean
          matched_sms_id?: string | null
          matched_via?: string | null
          order_id: string
          submitted_utr: string
          verified_at?: string
          verified_by?: string
        }
        Update: {
          created_at?: string
          id?: string
          matched?: boolean
          matched_sms_id?: string | null
          matched_via?: string | null
          order_id?: string
          submitted_utr?: string
          verified_at?: string
          verified_by?: string
        }
        Relationships: [
          {
            foreignKeyName: "payment_verifications_matched_sms_id_fkey"
            columns: ["matched_sms_id"]
            isOneToOne: false
            referencedRelation: "sms_inbox"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "payment_verifications_order_id_fkey"
            columns: ["order_id"]
            isOneToOne: false
            referencedRelation: "payment_orders"
            referencedColumns: ["id"]
          },
        ]
      }
      profiles: {
        Row: {
          created_at: string
          id: string
          name: string
          phone: string
          referral_code: string | null
          referred_by: string | null
          updated_at: string
          user_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          name?: string
          phone?: string
          referral_code?: string | null
          referred_by?: string | null
          updated_at?: string
          user_id: string
        }
        Update: {
          created_at?: string
          id?: string
          name?: string
          phone?: string
          referral_code?: string | null
          referred_by?: string | null
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      rate_settings: {
        Row: {
          calculation_method: string | null
          created_at: string
          dairy_id: string
          id: string
          liter_rate: number | null
          rate_type: string
          rate_value: number
          show_calculations_to_suppliers: boolean | null
          updated_at: string
        }
        Insert: {
          calculation_method?: string | null
          created_at?: string
          dairy_id: string
          id?: string
          liter_rate?: number | null
          rate_type?: string
          rate_value?: number
          show_calculations_to_suppliers?: boolean | null
          updated_at?: string
        }
        Update: {
          calculation_method?: string | null
          created_at?: string
          dairy_id?: string
          id?: string
          liter_rate?: number | null
          rate_type?: string
          rate_value?: number
          show_calculations_to_suppliers?: boolean | null
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "rate_settings_dairy_id_fkey"
            columns: ["dairy_id"]
            isOneToOne: true
            referencedRelation: "dairies"
            referencedColumns: ["id"]
          },
        ]
      }
      referrals: {
        Row: {
          created_at: string
          id: string
          referral_code: string
          referred_user_id: string
          referrer_user_id: string
          reward_days: number | null
          rewarded_at: string | null
          status: string
        }
        Insert: {
          created_at?: string
          id?: string
          referral_code: string
          referred_user_id: string
          referrer_user_id: string
          reward_days?: number | null
          rewarded_at?: string | null
          status?: string
        }
        Update: {
          created_at?: string
          id?: string
          referral_code?: string
          referred_user_id?: string
          referrer_user_id?: string
          reward_days?: number | null
          rewarded_at?: string | null
          status?: string
        }
        Relationships: []
      }
      sms_inbox: {
        Row: {
          body: string
          created_at: string
          id: string
          matched_order_id: string | null
          parsed_amount: number | null
          parsed_utr: string | null
          received_at: string
          sender: string | null
        }
        Insert: {
          body: string
          created_at?: string
          id?: string
          matched_order_id?: string | null
          parsed_amount?: number | null
          parsed_utr?: string | null
          received_at?: string
          sender?: string | null
        }
        Update: {
          body?: string
          created_at?: string
          id?: string
          matched_order_id?: string | null
          parsed_amount?: number | null
          parsed_utr?: string | null
          received_at?: string
          sender?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "sms_inbox_matched_order_id_fkey"
            columns: ["matched_order_id"]
            isOneToOne: false
            referencedRelation: "payment_orders"
            referencedColumns: ["id"]
          },
        ]
      }
      subscription_settings: {
        Row: {
          admin_phone: string
          auth_page_image_url: string | null
          created_at: string
          default_validity_days: number | null
          demo_days: number
          id: string
          monthly_price: number
          qr_code_url: string | null
          updated_at: string
          upi_id: string
          youtube_url: string | null
        }
        Insert: {
          admin_phone?: string
          auth_page_image_url?: string | null
          created_at?: string
          default_validity_days?: number | null
          demo_days?: number
          id?: string
          monthly_price?: number
          qr_code_url?: string | null
          updated_at?: string
          upi_id?: string
          youtube_url?: string | null
        }
        Update: {
          admin_phone?: string
          auth_page_image_url?: string | null
          created_at?: string
          default_validity_days?: number | null
          demo_days?: number
          id?: string
          monthly_price?: number
          qr_code_url?: string | null
          updated_at?: string
          upi_id?: string
          youtube_url?: string | null
        }
        Relationships: []
      }
      subscription_varieties: {
        Row: {
          created_at: string
          description: string | null
          excluded_features: Json
          features: Json | null
          id: string
          is_active: boolean | null
          name: string
          unlocks_customer_code: boolean
          updated_at: string
        }
        Insert: {
          created_at?: string
          description?: string | null
          excluded_features?: Json
          features?: Json | null
          id?: string
          is_active?: boolean | null
          name: string
          unlocks_customer_code?: boolean
          updated_at?: string
        }
        Update: {
          created_at?: string
          description?: string | null
          excluded_features?: Json
          features?: Json | null
          id?: string
          is_active?: boolean | null
          name?: string
          unlocks_customer_code?: boolean
          updated_at?: string
        }
        Relationships: []
      }
      subscriptions: {
        Row: {
          created_at: string
          dairy_id: string
          expires_at: string | null
          id: string
          started_at: string | null
          status: string
          updated_at: string
          variety_plan_id: string | null
        }
        Insert: {
          created_at?: string
          dairy_id: string
          expires_at?: string | null
          id?: string
          started_at?: string | null
          status?: string
          updated_at?: string
          variety_plan_id?: string | null
        }
        Update: {
          created_at?: string
          dairy_id?: string
          expires_at?: string | null
          id?: string
          started_at?: string | null
          status?: string
          updated_at?: string
          variety_plan_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "subscriptions_dairy_id_fkey"
            columns: ["dairy_id"]
            isOneToOne: true
            referencedRelation: "dairies"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "subscriptions_variety_plan_id_fkey"
            columns: ["variety_plan_id"]
            isOneToOne: false
            referencedRelation: "variety_plans"
            referencedColumns: ["id"]
          },
        ]
      }
      suppliers: {
        Row: {
          address: string | null
          animal_name: string | null
          animal_type: string
          can_see_calculations: boolean | null
          code: string | null
          created_at: string
          dairy_id: string
          deleted_at: string | null
          id: string
          name: string
          pending_balance: number | null
          personal_rate: number | null
          phone: string
          rate_system: string
          updated_at: string
          user_id: string | null
          village_name: string | null
        }
        Insert: {
          address?: string | null
          animal_name?: string | null
          animal_type?: string
          can_see_calculations?: boolean | null
          code?: string | null
          created_at?: string
          dairy_id: string
          deleted_at?: string | null
          id?: string
          name: string
          pending_balance?: number | null
          personal_rate?: number | null
          phone?: string
          rate_system?: string
          updated_at?: string
          user_id?: string | null
          village_name?: string | null
        }
        Update: {
          address?: string | null
          animal_name?: string | null
          animal_type?: string
          can_see_calculations?: boolean | null
          code?: string | null
          created_at?: string
          dairy_id?: string
          deleted_at?: string | null
          id?: string
          name?: string
          pending_balance?: number | null
          personal_rate?: number | null
          phone?: string
          rate_system?: string
          updated_at?: string
          user_id?: string | null
          village_name?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "suppliers_dairy_id_fkey"
            columns: ["dairy_id"]
            isOneToOne: false
            referencedRelation: "dairies"
            referencedColumns: ["id"]
          },
        ]
      }
      user_roles: {
        Row: {
          created_at: string
          id: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Update: {
          created_at?: string
          id?: string
          role?: Database["public"]["Enums"]["app_role"]
          user_id?: string
        }
        Relationships: []
      }
      variety_plans: {
        Row: {
          created_at: string
          id: string
          is_active: boolean | null
          name: string
          price: number
          updated_at: string
          validity_days: number
          variety_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          is_active?: boolean | null
          name: string
          price: number
          updated_at?: string
          validity_days?: number
          variety_id: string
        }
        Update: {
          created_at?: string
          id?: string
          is_active?: boolean | null
          name?: string
          price?: number
          updated_at?: string
          validity_days?: number
          variety_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "variety_plans_variety_id_fkey"
            columns: ["variety_id"]
            isOneToOne: false
            referencedRelation: "subscription_varieties"
            referencedColumns: ["id"]
          },
        ]
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      activate_demo_subscription: {
        Args: { _dairy_id: string }
        Returns: boolean
      }
      activate_subscription_from_order: {
        Args: { p_order_id: string }
        Returns: undefined
      }
      admin_list_payment_audit: {
        Args: { _limit?: number }
        Returns: {
          amount: number
          dairy_id: string
          dairy_name: string
          matched_via: string
          order_id: string
          order_ref: string
          plan_name: string
          plan_validity_days: number
          status: string
          submitted_at: string
          subscription_expires_at: string
          subscription_status: string
          user_name: string
          user_phone: string
          utr_submitted: string
          variety_name: string
        }[]
      }
      admin_review_payment: {
        Args: { _approve: boolean; _order_id: string }
        Returns: boolean
      }
      admin_revoke_subscription: {
        Args: { _dairy_id: string; _order_id?: string }
        Returns: boolean
      }
      admin_save_subscription_settings: {
        Args: { p_patch: Json }
        Returns: undefined
      }
      apply_referral_reward: {
        Args: { _referred_user_id: string }
        Returns: boolean
      }
      check_dairy_code_exists: {
        Args: { dairy_code: string }
        Returns: boolean
      }
      complete_google_signup: {
        Args: { p_name: string; p_phone: string; p_role: string }
        Returns: undefined
      }
      confirm_supplier_payment:
        | { Args: { _payment_id: string }; Returns: boolean }
        | {
            Args: { _confirmed: boolean; _payment_id: string }
            Returns: boolean
          }
      create_payment_order: {
        Args: { _plan_id: string }
        Returns: {
          amount: number
          expires_at: string
          order_id: string
          order_ref: string
        }[]
      }
      get_admin_payment_contact: {
        Args: never
        Returns: {
          admin_phone: string
          upi_id: string
        }[]
      }
      get_app_bootstrap: { Args: never; Returns: Json }
      get_auth_bootstrap: { Args: never; Returns: Json }
      get_auth_page_image: { Args: never; Returns: string }
      get_dairy_by_code: {
        Args: { dairy_code: string }
        Returns: {
          code: string
          id: string
          name: string
          owner_id: string
        }[]
      }
      get_dairy_config_bootstrap: { Args: never; Returns: Json }
      get_payment_order: { Args: { _order_id: string }; Returns: Json }
      get_reopen_status: { Args: never; Returns: Json }
      get_settings_bootstrap: { Args: never; Returns: Json }
      get_subscription_settings_admin: {
        Args: never
        Returns: {
          admin_phone: string
          auth_page_image_url: string | null
          created_at: string
          default_validity_days: number | null
          demo_days: number
          id: string
          monthly_price: number
          qr_code_url: string | null
          updated_at: string
          upi_id: string
          youtube_url: string | null
        }
        SetofOptions: {
          from: "*"
          to: "subscription_settings"
          isOneToOne: true
          isSetofReturn: false
        }
      }
      get_supplier_dairy_id: { Args: { _user_id: string }; Returns: string }
      get_user_dairy_id: { Args: { _user_id: string }; Returns: string }
      has_role: {
        Args: {
          _role: Database["public"]["Enums"]["app_role"]
          _user_id: string
        }
        Returns: boolean
      }
      is_admin: { Args: { _user_id: string }; Returns: boolean }
      link_supplier_to_dairy_by_code: {
        Args: { _dairy_code: string }
        Returns: {
          error_code: string
          linked: boolean
        }[]
      }
      mark_order_pay_clicked: {
        Args: { _order_id: string }
        Returns: undefined
      }
      phone_exists: { Args: { _phone: string }; Returns: boolean }
      purchase_plan_with_coins: {
        Args: { _dairy_id: string; _plan_id: string }
        Returns: boolean
      }
      submit_payment_utr: {
        Args: { _order_id: string; _utr: string }
        Returns: {
          matched: boolean
          status: string
        }[]
      }
      try_auto_match_payment_signal: {
        Args: { p_signal_id: string }
        Returns: undefined
      }
    }
    Enums: {
      app_role: "admin" | "owner" | "supplier"
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends (DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never) = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends (PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never) = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {
      app_role: ["admin", "owner", "supplier"],
    },
  },
} as const

import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Lock } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';
import { useLanguage } from '@/contexts/LanguageContext';

const ResetPassword = () => {
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [isSaving, setIsSaving] = useState(false);
  const [ready, setReady] = useState(false);
  const { toast } = useToast();
  const { language } = useLanguage();
  const navigate = useNavigate();

  useEffect(() => {
    let mounted = true;

    const { data: { subscription } } = supabase.auth.onAuthStateChange((_event, session) => {
      if (mounted && session) setReady(true);
    });

    supabase.auth.getSession().then(({ data: { session } }) => {
      if (!mounted) return;
      if (session) {
        setReady(true);
      } else {
        // Give the client a moment to process the recovery link, then bail out.
        setTimeout(async () => {
          const { data } = await supabase.auth.getSession();
          if (!mounted) return;
          if (data.session) {
            setReady(true);
          } else {
            sessionStorage.removeItem('pw_recovery');
            toast({
              title: language === 'hi' ? 'लिंक अमान्य' : 'Invalid link',
              description: language === 'hi'
                ? 'रीसेट लिंक expire हो गया है। दोबारा भेजें।'
                : 'This reset link has expired. Please request a new one.',
              variant: 'destructive',
            });
            navigate('/auth', { replace: true });
          }
        }, 2500);
      }
    });

    return () => {
      mounted = false;
      subscription.unsubscribe();
    };
  }, []);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (newPassword.length < 6) {
      toast({
        title: language === 'hi' ? 'त्रुटि' : 'Error',
        description: language === 'hi' ? 'पासवर्ड कम से कम 6 अक्षर का होना चाहिए' : 'Password must be at least 6 characters',
        variant: 'destructive',
      });
      return;
    }
    if (newPassword !== confirmPassword) {
      toast({
        title: language === 'hi' ? 'त्रुटि' : 'Error',
        description: language === 'hi' ? 'पासवर्ड मेल नहीं खाता' : 'Passwords do not match',
        variant: 'destructive',
      });
      return;
    }
    setIsSaving(true);
    try {
      const { error } = await supabase.auth.updateUser({ password: newPassword });
      if (error) throw error;
      sessionStorage.removeItem('pw_recovery');
      toast({
        title: language === 'hi' ? 'सफल' : 'Success',
        description: language === 'hi' ? '✅ पासवर्ड बदल गया! अब लॉगिन करें' : '✅ Password changed! Please login now',
      });
      await supabase.auth.signOut();
      window.location.replace('/auth');
    } catch (error: any) {
      toast({
        title: language === 'hi' ? 'त्रुटि' : 'Error',
        description: error?.message || 'Failed to update password',
        variant: 'destructive',
      });
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-background via-background to-dairy-cream flex flex-col items-center justify-center px-4">
      <div className="dairy-card max-w-md w-full p-5 animate-slide-up">
        <div className="text-center mb-4">
          <div className="flex justify-center mb-2">
            <div className="w-12 h-12 bg-gradient-to-br from-primary to-primary/80 rounded-xl flex items-center justify-center shadow-lg shadow-primary/20">
              <Lock className="w-6 h-6 text-primary-foreground" />
            </div>
          </div>
          <h1 className="text-xl font-bold">
            {language === 'hi' ? 'नया पासवर्ड बनाएं' : 'Create New Password'}
          </h1>
        </div>

        <form onSubmit={handleSubmit} className="space-y-3">
          <div className="relative">
            <Lock className="absolute left-4 top-1/2 -translate-y-1/2 h-5 w-5 text-muted-foreground" />
            <Input
              type="password"
              placeholder={language === 'hi' ? 'नया पासवर्ड *' : 'New Password *'}
              value={newPassword}
              onChange={(e) => setNewPassword(e.target.value)}
              className="dairy-input pl-11 h-11"
              minLength={6}
              required
            />
          </div>
          <div className="relative">
            <Lock className="absolute left-4 top-1/2 -translate-y-1/2 h-5 w-5 text-muted-foreground" />
            <Input
              type="password"
              placeholder={language === 'hi' ? 'पासवर्ड दोबारा डालें *' : 'Confirm Password *'}
              value={confirmPassword}
              onChange={(e) => setConfirmPassword(e.target.value)}
              className="dairy-input pl-11 h-11"
              minLength={6}
              required
            />
          </div>
          <Button type="submit" className="w-full h-11" disabled={isSaving || !ready}>
            {isSaving
              ? (language === 'hi' ? 'सहेजा जा रहा है...' : 'Saving...')
              : (language === 'hi' ? 'पासवर्ड बदलें' : 'Change Password')}
          </Button>
        </form>
      </div>
    </div>
  );
};

export default ResetPassword;
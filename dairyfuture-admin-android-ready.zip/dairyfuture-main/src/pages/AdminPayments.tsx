import React, { useCallback, useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { ArrowLeft, Check, X, Loader2, Inbox, ReceiptText, Save, Wallet, AlertTriangle, RefreshCw, ShieldOff } from 'lucide-react';
import { toast } from 'sonner';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { supabase } from '@/integrations/supabase/client';
import { useLanguage } from '@/contexts/LanguageContext';
import type { PaymentOrderRow } from '@/lib/payments';
import { deltaFetch, readAdminCache, readAdminObject, writeAdminObject } from '@/lib/adminCache';

const CACHE_ORDERS = 'payment_orders';
const CACHE_SMS = 'sms_inbox';
const CACHE_UPI = 'payments_upi_settings';
// sms_inbox has no updated_at; matched_order_id can change on an existing row,
// so we always re-fetch the last 24h window on top of the created_at watermark.
const SMS_OVERLAP_MS = 24 * 60 * 60 * 1000;

interface SmsRow {
  id: string;
  sender: string | null;
  body: string;
  parsed_utr: string | null;
  parsed_amount: number | null;
  received_at: string;
  matched_order_id: string | null;
}

interface SignalRow {
  id: string;
  amount: number;
  package_name: string | null;
  raw_text: string | null;
  received_at: string;
  source: string | null;
  matched_order_id: string | null;
}

interface AuditRow {
  order_id: string;
  order_ref: string;
  amount: number;
  status: string;
  utr_submitted: string | null;
  matched_via: string;
  submitted_at: string;
  dairy_id: string;
  dairy_name: string | null;
  user_name: string | null;
  user_phone: string | null;
  subscription_status: string | null;
  subscription_expires_at: string | null;
  plan_name: string | null;
  plan_validity_days: number | null;
  variety_name: string | null;
}


const AdminPayments: React.FC = () => {
  const { language } = useLanguage();
  const hi = language === 'hi';
  const navigate = useNavigate();

  const [orders, setOrders] = useState<PaymentOrderRow[]>(
    () => readAdminCache<PaymentOrderRow>(CACHE_ORDERS) ?? []
  );
  const [sms, setSms] = useState<SmsRow[]>(() => readAdminCache<SmsRow>(CACHE_SMS) ?? []);
  const [signals, setSignals] = useState<SignalRow[]>([]);
  const [audit, setAudit] = useState<AuditRow[]>([]);

  const [loading, setLoading] = useState(() => !readAdminCache(CACHE_ORDERS));
  const [syncing, setSyncing] = useState(false);
  const [busyId, setBusyId] = useState<string | null>(null);
  const [upiId, setUpiId] = useState('');
  const [settingsId, setSettingsId] = useState<string | null>(null);
  const [savingUpi, setSavingUpi] = useState(false);

  const load = useCallback(async (force = false) => {
    setSyncing(true);
    try {
      // payment_orders + sms_inbox: doosre users / SMS webhook se data aata hai → delta-sync.
      // subscription_settings (UPI id): purely admin-controlled → cache-only, sirf pehli baar / force.
      const cachedUpi = readAdminObject<{ id: string; upi_id: string }>(CACHE_UPI);
      const needSettings = force || !cachedUpi;
      if (cachedUpi) { setUpiId(cachedUpi.upi_id ?? ''); setSettingsId(cachedUpi.id ?? null); }

      const [o, sm, st, ad, sg] = await Promise.all([
        deltaFetch<PaymentOrderRow>({
          name: CACHE_ORDERS,
          force,
          buildQuery: () =>
            supabase.from('payment_orders').select('*').order('created_at', { ascending: false }),
        }),
        deltaFetch<SmsRow>({
          name: CACHE_SMS,
          force,
          tsColumn: 'created_at',
          overlapMs: SMS_OVERLAP_MS,
          buildQuery: () =>
            supabase.from('sms_inbox').select('*').order('received_at', { ascending: false }),
        }),
        needSettings ? supabase.rpc('get_subscription_settings_admin') : Promise.resolve({ data: null } as any),
        supabase.rpc('admin_list_payment_audit' as any, { _limit: 200 } as any),
        supabase
          .from('notification_payment_signals')
          .select('*')
          .order('received_at', { ascending: false })
          .limit(50),
      ]);
      setOrders(
        [...o.rows].sort((a, b) => (a.created_at < b.created_at ? 1 : -1)).slice(0, 200)
      );
      setSms(
        [...sm.rows].sort((a, b) => (a.received_at < b.received_at ? 1 : -1)).slice(0, 100)
      );
      setAudit((ad?.data as unknown as AuditRow[]) ?? []);
      setSignals((sg?.data as unknown as SignalRow[]) ?? []);

      const row: any = Array.isArray(st.data) ? st.data[0] : st.data;
      if (row) {
        setUpiId(row.upi_id ?? '');
        setSettingsId(row.id ?? null);
        writeAdminObject(CACHE_UPI, { id: row.id, upi_id: row.upi_id ?? '' });
      }
    } catch (e) {
      console.error('[AdminPayments] sync failed', e);
    } finally {
      setLoading(false);
      setSyncing(false);
    }
  }, []);


  useEffect(() => { load(); }, [load]);

  const review = async (orderId: string, approve: boolean) => {
    setBusyId(orderId);
    try {
      const { error } = await supabase.rpc('admin_review_payment', { _order_id: orderId, _approve: approve });
      if (error) throw error;
      toast.success(approve ? (hi ? 'मंज़ूर किया गया' : 'Approved') : (hi ? 'अस्वीकार किया गया' : 'Rejected'));
      await load(true);
    } catch (e: any) {
      toast.error(e?.message?.includes('not_admin') ? (hi ? 'एडमिन अधिकार नहीं' : 'Not an admin') : (hi ? 'कार्रवाई विफल' : 'Action failed'));
    } finally {
      setBusyId(null);
    }
  };

  const revoke = async (row: AuditRow) => {
    if (!window.confirm(hi ? 'इस डेयरी का access तुरंत बंद कर दें?' : 'Revoke this dairy access now?')) return;
    setBusyId(row.order_id);
    try {
      const { error } = await supabase.rpc('admin_revoke_subscription' as any, {
        _dairy_id: row.dairy_id,
        _order_id: row.order_id,
      } as any);
      if (error) throw error;
      toast.success(hi ? 'Access बंद कर दिया गया' : 'Access revoked');
      await load(true);
    } catch (e: any) {
      toast.error(e?.message?.includes('not_admin') ? (hi ? 'एडमिन अधिकार नहीं' : 'Not an admin') : (hi ? 'कार्रवाई विफल' : 'Action failed'));
    } finally {
      setBusyId(null);
    }
  };

  const saveUpi = async () => {
    if (!settingsId) return;
    const clean = upiId.trim();
    if (!/^[\w.\-]{2,64}@[a-zA-Z]{2,32}$/.test(clean)) {
      toast.error(hi ? 'UPI ID सही नहीं है' : 'Invalid UPI ID');
      return;
    }
    setSavingUpi(true);
    try {
      const { error } = await supabase.from('subscription_settings').update({ upi_id: clean }).eq('id', settingsId);
      if (error) throw error;
      writeAdminObject(CACHE_UPI, { id: settingsId, upi_id: clean });
      toast.success(hi ? 'UPI ID सेव हो गई' : 'UPI ID saved');
    } catch {
      toast.error(hi ? 'सेव नहीं हो सका' : 'Could not save');
    } finally {
      setSavingUpi(false);
    }
  };

  const pending = orders.filter((o) => o.status === 'verifying');
  // Manual UTR = accepted without any verification → needs a human look.
  const manualRows = audit.filter((r) => r.matched_via === 'manual_utr_unverified' && r.status === 'success');
  const autoRows = audit.filter(
    (r) => r.status === 'success' && (r.matched_via === 'notification_auto' || r.matched_via === 'notification_fallback' || r.matched_via === 'sms')
  );


  return (
    <div className="min-h-screen bg-gradient-to-b from-background to-muted/30">
      <div className="relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-primary via-primary/90 to-accent/80" />
        <div className="relative px-4 py-5 flex items-center gap-3">
          <Button variant="ghost" size="icon" onClick={() => navigate('/admin')} className="text-primary-foreground hover:bg-primary-foreground/20">
            <ArrowLeft className="h-5 w-5" />
          </Button>
          <h1 className="text-xl font-bold text-primary-foreground flex-1">
            {hi ? 'UPI भुगतान' : 'UPI Payments'}
          </h1>
          <Button
            variant="ghost"
            size="icon"
            onClick={() => load(true)}
            disabled={syncing}
            className="text-primary-foreground hover:bg-primary-foreground/20"
          >
            <RefreshCw className={`h-5 w-5 ${syncing ? 'animate-spin' : ''}`} />
          </Button>
        </div>
      </div>

      <main className="px-4 py-5 max-w-2xl mx-auto space-y-4 -mt-2">
        {loading && (
          <div className="p-6 flex justify-center"><Loader2 className="h-6 w-6 animate-spin text-primary" /></div>
        )}

        {/* UPI settings */}
        <div className="bg-card rounded-3xl shadow-xl border border-border/50 overflow-hidden">
          <div className="bg-gradient-to-r from-primary/5 to-accent/5 p-4 border-b border-border/50 flex items-center gap-2">
            <Wallet className="h-4 w-4 text-primary" />
            <h2 className="font-bold">{hi ? 'भुगतान UPI ID' : 'Payment UPI ID'}</h2>
          </div>
          <div className="p-4 flex gap-2">
            <Input value={upiId} onChange={(e) => setUpiId(e.target.value)} placeholder="name@bank" className="h-11 rounded-xl" />
            <Button onClick={saveUpi} disabled={savingUpi || !settingsId} className="h-11 rounded-xl gap-1">
              {savingUpi ? <Loader2 className="h-4 w-4 animate-spin" /> : <Save className="h-4 w-4" />}
              {hi ? 'सेव' : 'Save'}
            </Button>
          </div>
        </div>

        {/* Pending verifications */}
        <div className="bg-card rounded-3xl shadow-xl border-2 border-primary/20 overflow-hidden">
          <div className="bg-gradient-to-r from-primary/5 to-accent/5 p-4 border-b border-border/50 flex items-center gap-2">
            <ReceiptText className="h-4 w-4 text-primary" />
            <h2 className="font-bold">{hi ? 'जांच के लिए बाकी' : 'Pending verifications'}</h2>
            <span className="ml-auto text-xs font-bold bg-primary/10 text-primary px-2 py-1 rounded-full">{pending.length}</span>
          </div>
          {pending.length === 0 ? (
            <p className="p-5 text-sm text-muted-foreground text-center">{hi ? 'कुछ बाकी नहीं' : 'Nothing pending'}</p>
          ) : (
            <ul className="divide-y divide-border/50">
              {pending.map((o) => (
                <li key={o.id} className="p-4 flex items-center gap-3">
                  <div className="flex-1 min-w-0">
                    <p className="font-mono text-xs text-muted-foreground truncate">{o.order_ref}</p>
                    <p className="font-bold text-foreground">₹{o.amount}</p>
                    <p className="text-[11px] text-muted-foreground">UTR: {o.utr_submitted || '—'}</p>
                    <p className="text-[11px] text-muted-foreground">{new Date(o.created_at).toLocaleString('en-IN')}</p>
                  </div>
                  <Button size="icon" variant="outline" disabled={busyId === o.id} onClick={() => review(o.id, true)} className="border-primary/40">
                    <Check className="h-4 w-4 text-primary" />
                  </Button>
                  <Button size="icon" variant="outline" disabled={busyId === o.id} onClick={() => review(o.id, false)} className="border-destructive/40">
                    <X className="h-4 w-4 text-destructive" />
                  </Button>
                </li>
              ))}
            </ul>
          )}
        </div>

        {/* Manual UTR — accepted without verification, needs admin review */}
        {manualRows.length > 0 && (
          <div className="bg-card rounded-3xl shadow-xl border-2 border-amber-300 dark:border-amber-800 overflow-hidden">
            <div className="bg-amber-50 dark:bg-amber-950/30 p-4 border-b border-border/50 flex items-center gap-2">
              <AlertTriangle className="h-4 w-4 text-amber-600" />
              <h2 className="font-bold text-amber-900 dark:text-amber-200">
                {hi ? '⚠️ Manual UTR — जांच बाकी' : '⚠️ Manual UTR — needs review'}
              </h2>
              <span className="ml-auto text-xs font-bold bg-amber-100 dark:bg-amber-900/50 text-amber-800 dark:text-amber-200 px-2 py-1 rounded-full">
                {manualRows.length}
              </span>
            </div>
            <ul className="divide-y divide-border/50">
              {manualRows.map((r) => (
                <li key={r.order_id} className="p-4 space-y-1">
                  <div className="flex items-center gap-2">
                    <p className="font-bold text-foreground flex-1 truncate">{r.user_name || '—'}</p>
                    <p className="font-bold text-foreground">₹{r.amount}</p>
                  </div>
                  <p className="text-xs text-muted-foreground">
                    {hi ? 'डेयरी' : 'Dairy'}: {r.dairy_name || '—'} • 📞 {r.user_phone || '—'}
                  </p>
                  <p className="text-xs font-mono text-foreground">UTR: {r.utr_submitted || '—'}</p>
                  <p className="text-xs text-foreground">
                    {hi ? 'प्लान' : 'Plan'}: <span className="font-semibold">{r.plan_name || '—'}</span>
                    {r.variety_name ? ` (${r.variety_name})` : ''}
                    {r.plan_validity_days ? ` • ${r.plan_validity_days} ${hi ? 'दिन' : 'days'}` : ''}
                  </p>
                  <p className="text-[11px] text-muted-foreground">
                    {r.order_ref} • {new Date(r.submitted_at).toLocaleString('en-IN')}
                  </p>
                  <p className="text-[11px] text-muted-foreground">
                    {hi ? 'सब्सक्रिप्शन' : 'Subscription'}: {r.subscription_status || '—'}
                    {r.subscription_expires_at ? ` → ${new Date(r.subscription_expires_at).toLocaleDateString('en-IN')}` : ''}
                  </p>
                  <div className="flex gap-2 pt-1">
                    <Button
                      size="sm"
                      variant="outline"
                      disabled={busyId === r.order_id}
                      onClick={() => revoke(r)}
                      className="border-destructive/40 text-destructive gap-1 rounded-xl"
                    >
                      {busyId === r.order_id ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <ShieldOff className="h-3.5 w-3.5" />}
                      {hi ? 'Access बंद करें' : 'Revoke access'}
                    </Button>
                  </div>
                </li>
              ))}
            </ul>
          </div>
        )}

        {/* Auto-verified via notification match */}
        {autoRows.length > 0 && (
          <div className="bg-card rounded-3xl shadow-xl border border-border/50 overflow-hidden">
            <div className="bg-gradient-to-r from-primary/5 to-accent/5 p-4 border-b border-border/50 flex items-center gap-2">
              <Check className="h-4 w-4 text-primary" />
              <h2 className="font-bold">
                {hi ? '✅ Auto-verified (notification match)' : '✅ Auto-verified (notification match)'}
              </h2>
              <span className="ml-auto text-xs font-bold bg-primary/10 text-primary px-2 py-1 rounded-full">{autoRows.length}</span>
            </div>
            <ul className="divide-y divide-border/50">
              {autoRows.map((r) => (
                <li key={r.order_id} className="p-4 space-y-1">
                  <div className="flex items-center gap-2">
                    <p className="font-bold text-foreground flex-1 truncate">{r.user_name || '—'}</p>
                    <p className="font-bold text-foreground">₹{r.amount}</p>
                  </div>
                  <p className="text-xs text-muted-foreground">
                    {hi ? 'डेयरी' : 'Dairy'}: {r.dairy_name || '—'} • 📞 {r.user_phone || '—'}
                  </p>
                  <p className="text-xs text-foreground">
                    {hi ? 'प्लान' : 'Plan'}: <span className="font-semibold">{r.plan_name || '—'}</span>
                    {r.variety_name ? ` (${r.variety_name})` : ''}
                    {r.plan_validity_days ? ` • ${r.plan_validity_days} ${hi ? 'दिन' : 'days'}` : ''}
                  </p>
                  <p className="text-[11px] text-muted-foreground">
                    {hi ? 'ऑटो-मैच' : 'Auto-matched'}: {r.matched_via} • {r.order_ref} • {new Date(r.submitted_at).toLocaleString('en-IN')}
                  </p>
                  <p className="text-[11px] text-muted-foreground">
                    UTR: {r.utr_submitted || '—'} • {hi ? 'सब्सक्रिप्शन' : 'Subscription'}: {r.subscription_status || '—'}
                    {r.subscription_expires_at ? ` → ${new Date(r.subscription_expires_at).toLocaleDateString('en-IN')}` : ''}
                  </p>
                  <div className="flex gap-2 pt-1">
                    <Button
                      size="sm"
                      variant="outline"
                      disabled={busyId === r.order_id}
                      onClick={() => revoke(r)}
                      className="border-destructive/40 text-destructive gap-1 rounded-xl"
                    >
                      {busyId === r.order_id ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <ShieldOff className="h-3.5 w-3.5" />}
                      {hi ? 'Access बंद करें' : 'Revoke access'}
                    </Button>
                  </div>
                </li>
              ))}
            </ul>

          </div>
        )}

        <div className="bg-card rounded-3xl shadow-xl border border-border/50 overflow-hidden">
          <div className="bg-gradient-to-r from-primary/5 to-accent/5 p-4 border-b border-border/50 flex items-center gap-2">
            <Inbox className="h-4 w-4 text-primary" />
            <h2 className="font-bold">{hi ? 'पेमेंट नोटिफिकेशन सिग्नल' : 'Payment notification signals'}</h2>
          </div>
          {signals.length === 0 ? (
            <p className="p-5 text-sm text-muted-foreground text-center">{hi ? 'कोई सिग्नल नहीं' : 'No signals yet'}</p>
          ) : (
            <ul className="divide-y divide-border/50">
              {signals.map((s) => (
                <li key={s.id} className="p-4">
                  <div className="flex items-center justify-between gap-2">
                    <p className="text-sm font-bold text-foreground">₹{s.amount}</p>
                    <p className="text-[11px] text-muted-foreground">{new Date(s.received_at).toLocaleString('en-IN')}</p>
                  </div>
                  <div className="flex flex-wrap gap-2 mt-1 text-[11px]">
                    <span className="px-2 py-0.5 rounded-full bg-muted text-foreground font-medium">
                      {s.source === 'admin_ingest_secret'
                        ? (hi ? '📱 एडमिन ऐप (सीक्रेट)' : '📱 Admin app (secret)')
                        : (hi ? '👤 एडमिन लॉगिन' : '👤 Admin login')}
                    </span>
                    <span className="text-muted-foreground">{s.package_name || '—'}</span>
                    {s.matched_order_id && (
                      <span className="text-primary font-semibold">{hi ? 'मैच' : 'matched'}</span>
                    )}
                  </div>
                  {s.raw_text && <p className="text-xs text-muted-foreground mt-1 line-clamp-2">{s.raw_text}</p>}
                </li>
              ))}
            </ul>
          )}
        </div>


        <div className="bg-card rounded-3xl shadow-xl border border-border/50 overflow-hidden">
          <div className="bg-gradient-to-r from-primary/5 to-accent/5 p-4 border-b border-border/50 flex items-center gap-2">
            <Inbox className="h-4 w-4 text-primary" />
            <h2 className="font-bold">{hi ? 'SMS इनबॉक्स' : 'SMS inbox'}</h2>
          </div>
          {sms.length === 0 ? (
            <p className="p-5 text-sm text-muted-foreground text-center">{hi ? 'कोई SMS नहीं' : 'No SMS yet'}</p>
          ) : (
            <ul className="divide-y divide-border/50">
              {sms.map((m) => (
                <li key={m.id} className="p-4">
                  <div className="flex items-center justify-between gap-2">
                    <p className="text-xs font-semibold text-foreground">{m.sender || '—'}</p>
                    <p className="text-[11px] text-muted-foreground">{new Date(m.received_at).toLocaleString('en-IN')}</p>
                  </div>
                  <p className="text-xs text-muted-foreground mt-1 line-clamp-2">{m.body}</p>
                  <div className="flex gap-3 mt-1 text-[11px]">
                    <span className="font-mono text-foreground">UTR: {m.parsed_utr || '—'}</span>
                    <span className="font-semibold text-foreground">₹{m.parsed_amount ?? '—'}</span>
                    {m.matched_order_id && <span className="text-primary font-semibold">{hi ? 'मैच' : 'matched'}</span>}
                  </div>
                </li>
              ))}
            </ul>
          )}
        </div>

        {/* All orders */}
        <div className="bg-card rounded-3xl shadow-xl border border-border/50 overflow-hidden">
          <div className="bg-gradient-to-r from-primary/5 to-accent/5 p-4 border-b border-border/50">
            <h2 className="font-bold">{hi ? 'सभी ऑर्डर' : 'All orders'}</h2>
          </div>
          <ul className="divide-y divide-border/50">
            {orders.map((o) => (
              <li key={o.id} className="p-3 flex items-center gap-3 text-xs">
                <span className="font-mono text-muted-foreground flex-1 truncate">{o.order_ref}</span>
                <span className="font-bold text-foreground">₹{o.amount}</span>
                <span className="font-semibold text-muted-foreground">{o.status}</span>
                {(o as any).verification_method === 'manual_utr_unverified' ? (
                  <span className="font-bold text-amber-600" title="Manual UTR — needs review">⚠️</span>
                ) : (o as any).verification_method ? (
                  <span className="font-bold text-primary" title="Auto-verified">✅</span>
                ) : null}

              </li>
            ))}
          </ul>
        </div>
      </main>
    </div>
  );
};

export default AdminPayments;

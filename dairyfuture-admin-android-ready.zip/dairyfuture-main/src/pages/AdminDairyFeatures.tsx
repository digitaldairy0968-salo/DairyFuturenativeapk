import React, { useState, useEffect } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { ArrowLeft, Shield, ToggleLeft, ToggleRight, Hash } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Switch } from '@/components/ui/switch';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';

const CUSTOMER_CODE_KEY = 'customer_code';

const AdminDairyFeatures: React.FC = () => {
  const { dairyId } = useParams<{ dairyId: string }>();
  const navigate = useNavigate();
  const [dairyName, setDairyName] = useState('');
  const [dairyCode, setDairyCode] = useState<string | null>(null);
  const [features, setFeatures] = useState<Record<string, boolean>>({});
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState<string | null>(null);

  useEffect(() => {
    if (dairyId) fetchData();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [dairyId]);

  const fetchData = async () => {
    setLoading(true);
    try {
      const { data: dairy } = await supabase
        .from('dairies')
        .select('name, code')
        .eq('id', dairyId!)
        .single();

      if (dairy) {
        setDairyName(dairy.name);
        setDairyCode(dairy.code);
      }

      const { data: featureData } = await supabase
        .from('dairy_features')
        .select('feature_key, is_enabled')
        .eq('dairy_id', dairyId!);

      const featureMap: Record<string, boolean> = { [CUSTOMER_CODE_KEY]: false };
      featureData?.forEach((f: any) => { featureMap[f.feature_key] = f.is_enabled; });
      setFeatures(featureMap);
    } catch (error) {
      console.error('Error:', error);
    } finally {
      setLoading(false);
    }
  };

  const upsertFeature = async (featureKey: string, enabled: boolean) => {
    const { error } = await supabase
      .from('dairy_features')
      .upsert({ dairy_id: dairyId!, feature_key: featureKey, is_enabled: enabled }, { onConflict: 'dairy_id,feature_key' });
    if (error) throw error;
  };

  const toggleCustomerCode = async (enabled: boolean) => {
    setSaving(CUSTOMER_CODE_KEY);
    try {
      await upsertFeature(CUSTOMER_CODE_KEY, enabled);

      if (enabled) {
        const { data: dairyData } = await supabase
          .from('dairies')
          .select('code')
          .eq('id', dairyId!)
          .single();

        if (!dairyData?.code || dairyData.code.length !== 12) {
          const newCode = Math.floor(100000000000 + Math.random() * 900000000000).toString();
          const { error: codeError } = await supabase
            .from('dairies')
            .update({ code: newCode })
            .eq('id', dairyId!);
          if (!codeError) {
            setDairyCode(newCode);
            toast.success(`12-digit code generated: ${newCode}`);
          }
        } else {
          setDairyCode(dairyData.code);
        }
      }

      setFeatures(prev => ({ ...prev, [CUSTOMER_CODE_KEY]: enabled }));
      toast.success(`${enabled ? 'Enabled' : 'Disabled'}: 12-Digit Customer Code`);
    } catch (error) {
      console.error('Error toggling feature:', error);
      toast.error('Failed to update feature');
    } finally {
      setSaving(null);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <div className="w-12 h-12 border-4 border-primary border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  const codeEnabled = !!features[CUSTOMER_CODE_KEY];

  return (
    <div className="min-h-screen bg-background">
      <header className="dairy-header px-4 py-4">
        <div className="flex items-center gap-3">
          <Button
            variant="ghost"
            size="icon"
            onClick={() => navigate('/admin')}
            className="text-primary-foreground hover:bg-primary-foreground/20"
          >
            <ArrowLeft className="h-5 w-5" />
          </Button>
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-primary-foreground/20 rounded-full flex items-center justify-center">
              <Shield className="w-5 h-5" />
            </div>
            <div>
              <h1 className="text-xl font-bold">{dairyName}</h1>
              <p className="text-primary-foreground/70 text-sm">Feature Control</p>
            </div>
          </div>
        </div>
      </header>

      <main className="px-4 py-6 max-w-2xl mx-auto space-y-4">
        {dairyCode && codeEnabled && (
          <div className="dairy-card bg-green-50 dark:bg-green-950/20 border-green-200">
            <div className="flex items-center gap-3">
              <Hash className="h-5 w-5 text-green-600" />
              <div>
                <p className="font-semibold text-green-700 dark:text-green-400">12-Digit Customer Code</p>
                <p className="text-lg font-mono font-bold tracking-wider">{dairyCode}</p>
              </div>
            </div>
          </div>
        )}

        <div className="dairy-card">
          <div className="flex items-start justify-between gap-4">
            <div className="flex-1">
              <div className="flex items-center gap-2">
                {codeEnabled ? (
                  <ToggleRight className="h-5 w-5 text-green-600" />
                ) : (
                  <ToggleLeft className="h-5 w-5 text-muted-foreground" />
                )}
                <h3 className="font-semibold">12-Digit Customer Code</h3>
              </div>
              <p className="text-sm text-muted-foreground mt-1">
                Suppliers can join this dairy with a 12-digit code and view their milk card.
              </p>
            </div>
            <Switch
              checked={codeEnabled}
              onCheckedChange={toggleCustomerCode}
              disabled={saving === CUSTOMER_CODE_KEY}
            />
          </div>
        </div>
      </main>
    </div>
  );
};

export default AdminDairyFeatures;

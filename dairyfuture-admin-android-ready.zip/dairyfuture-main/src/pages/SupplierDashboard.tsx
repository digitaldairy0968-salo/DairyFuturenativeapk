import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { format } from 'date-fns';
import { ChevronLeft, ChevronRight, CalendarIcon, Filter, History, ArrowDownCircle, ArrowUpCircle, Banknote, Shield, CheckCircle, XCircle, BellRing, ChevronDown, RefreshCw } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Calendar } from '@/components/ui/calendar';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import Header from '@/components/Header';
import BottomNav from '@/components/BottomNav';
import { useLanguage } from '@/contexts/LanguageContext';
import { useDairy, MilkEntry } from '@/contexts/DairyContext';
import { useAuth } from '@/contexts/AuthContext';
import { cn } from '@/lib/utils';
import { supabase } from '@/integrations/supabase/client';
import { fetchAllRows } from '@/lib/supabasePagination';
import { resolveFatSnfSettings } from '@/utils/fatSnfCalculation';
import { calculateSupplierStats } from '@/utils/supplierCalculation';
import { useCachedQuery, useCachedSingle } from '@/hooks/useCachedQuery';
import { getCachedAuthImage, fetchAndCacheAuthImage } from '@/utils/authImageCache';

interface PaymentHistoryEntry {
  id: string;
  transaction_date: string;
  amount_added: number;
  amount_paid: number;
  balance_after: number;
  notes: string | null;
  created_at: string;
  supplier_confirmed: boolean | null;
}

interface EditRequest {
  id: string;
  entry_id: string;
  changes: Record<string, unknown>;
  reason: string | null;
  created_at: string;
  milk_entries?: { date?: string; time_of_day?: string } | null;
}

/** Build a short readable summary of an edit request's requested values. */
function summarizeEntryChanges(changes: Record<string, unknown> | null | undefined, language: string): string {
  if (!changes) return '';
  const pick = (a: string, b: string): string | null => {
    const raw = (changes as Record<string, unknown>)[a] ?? (changes as Record<string, unknown>)[b];
    if (raw === null || raw === undefined || raw === '') return null;
    return String(raw);
  };
  const parts: string[] = [];
  const milk = pick('morningMilk', 'eveningMilk');
  const fat = pick('morningFat', 'eveningFat');
  const lr = pick('morningLR', 'eveningLR');
  if (milk !== null) parts.push(`${language === 'hi' ? 'दूध' : 'Milk'}: ${milk} ${language === 'hi' ? 'ली' : 'L'}`);
  if (fat !== null) parts.push(`${language === 'hi' ? 'फैट' : 'Fat'}: ${fat}`);
  if (lr !== null) parts.push(`LR: ${lr}`);
  return parts.join(' • ');
}

const SupplierDashboard: React.FC = () => {
  const { t, language } = useLanguage();
  const { getSupplierByPhone, getSupplierStats, rateSettings: ctxRateSettings, suppliers, refreshData, fatSnfSettings: dairyFatSnfSettings, ownerSettings, patchSupplierLocal } = useDairy();
  const { user, logout } = useAuth();
  const navigate = useNavigate();

  // Fresh config fetched ONLY when the "हिसाब (तारीख अनुसार)" button is clicked.
  const [freshConfig, setFreshConfig] = useState<{
    canSeeCalculations?: boolean | null;
    personalRate?: number | null;
    rateSettings?: Partial<typeof ctxRateSettings> | null;
  } | null>(null);

  const rateSettings = freshConfig?.rateSettings
    ? { ...ctxRateSettings, ...freshConfig.rateSettings }
    : ctxRateSettings;

  const supplier = user ? getSupplierByPhone(user.phone) : undefined;
  const stats = supplier ? getSupplierStats(supplier.id, 10) : null;
  const supplierRow = supplier ? suppliers.find(s => s.id === supplier.id) : undefined;
  const supplierData = supplierRow && freshConfig?.personalRate !== undefined
    ? { ...supplierRow, personalRate: freshConfig.personalRate ?? undefined }
    : supplierRow;
  const fatSnfSettings = resolveFatSnfSettings(dairyFatSnfSettings, supplierData ?? supplier);

  const rate = rateSettings.fatRate;
  const showCalculations = freshConfig?.canSeeCalculations
    ?? supplier?.canSeeCalculations
    ?? rateSettings.showCalculationsToSuppliers;
  const calculationMethod = rateSettings.calculationMethod || 'avg_fat';

  // Month navigation
  const [currentMonth, setCurrentMonth] = useState(new Date());
  const [editRequests, setEditRequests] = useState<EditRequest[]>([]);
  const [hisaabOpen, setHisaabOpen] = useState(false);
  const [hisaabRefreshing, setHisaabRefreshing] = useState(false);
  const [requestsRefreshing, setRequestsRefreshing] = useState(false);

  const fetchFreshConfig = async () => {
    try {
      const { data, error } = await supabase.rpc('get_dairy_config_bootstrap' as any);
      if (error || !data) return;
      const boot = data as any;
      const rs = boot.rate_settings;
      const cs = boot.caller_supplier;
      setFreshConfig({
        canSeeCalculations: cs ? (cs.can_see_calculations ?? null) : undefined,
        personalRate: cs ? (cs.personal_rate != null ? Number(cs.personal_rate) : null) : undefined,
        rateSettings: rs
          ? {
              fatRate: Number(rs.rate_value) || ctxRateSettings.fatRate,
              literRate: Number(rs.liter_rate) || ctxRateSettings.literRate || 50,
              showCalculationsToSuppliers: rs.show_calculations_to_suppliers ?? ctxRateSettings.showCalculationsToSuppliers,
              calculationMethod: (rs.calculation_method as 'avg_fat' | 'daily_total') || ctxRateSettings.calculationMethod || 'avg_fat',
            }
          : null,
      });
    } catch {
      /* keep existing values on failure */
    }
  };

  const handleHisaabToggle = async () => {
    setHisaabOpen(o => !o);
    if (hisaabRefreshing) return;
    setHisaabRefreshing(true);
    try {
      await fetchFreshConfig();
    } finally {
      setHisaabRefreshing(false);
    }
  };

  // Auth image (top-left of the customer header)
  const [authImageUrl, setAuthImageUrl] = useState<string | null>(getCachedAuthImage);
  useEffect(() => {
    if (!authImageUrl) {
      fetchAndCacheAuthImage().then(url => { if (url) setAuthImageUrl(url); });
    }
  }, [authImageUrl]);

  // Date range filter
  const [startDate, setStartDate] = useState<Date | undefined>(undefined);
  const [endDate, setEndDate] = useState<Date | undefined>(undefined);
  const [timeFilter, setTimeFilter] = useState<'morning' | 'evening' | 'both'>('both');

  const fatSnfEnabled = fatSnfSettings.isEnabled;




  // Cache-first: dairy_features (customer_code)
  const { data: featureRow } = useCachedSingle<{ is_enabled: boolean }>({
    cacheKey: 'dairy_feature_customer_code',
    scope: user?.dairyId,
    table: 'dairy_features',
    buildQuery: () => supabase
      .from('dairy_features')
      .select('is_enabled')
      .eq('dairy_id', user!.dairyId!)
      .eq('feature_key', 'customer_code'),
    enabled: !!user?.dairyId,
  });
  const customerCodeEnabled: boolean | null = featureRow?.is_enabled ?? null;

  // Owner settings come from the centralized DairyContext state (fresh-login sync).
  const showRakamToCustomers = ownerSettings.showRakamToCustomers ?? true;

  // Cache-first: payment_history (delta by updated_at)
  const {
    data: paymentHistory,
    loading: loadingHistory,
    refetch: refetchPaymentHistory,
    upsertLocal: upsertPayment,
  } = useCachedQuery<PaymentHistoryEntry>({
    cacheKey: 'payment_history_supplier',
    scope: supplierData?.id,
    table: 'payment_history',
    buildQuery: () => supabase
      .from('payment_history')
      .select('*')
      .eq('supplier_id', supplierData!.id)
      .order('transaction_date', { ascending: false })
      .order('created_at', { ascending: false }),
    enabled: !!supplierData?.id,
    sessionGuard: true,
  });

  // Pending payment confirmations - only for actual bhugtan (amount_paid > 0), not for bakaya additions.
  // Seeded from the login-time cached history, then refreshed by a small dedicated
  // query whenever the requests panel is opened.
  const [pendingPayments, setPendingPayments] = useState<PaymentHistoryEntry[]>([]);
  useEffect(() => {
    setPendingPayments(
      paymentHistory.filter(p => (p.amount_paid || 0) > 0 && p.supplier_confirmed === null)
    );
  }, [paymentHistory]);

  // Cache-first: pending edit requests (one fetch per supplier per tab-session)
  const {
    data: cachedEditRequests,
    removeLocal: removeEditRequestLocal,
    refetch: refetchEditRequests,
  } = useCachedQuery<EditRequest>({
    cacheKey: 'entry_edit_requests_pending',
    scope: supplierData?.id,
    table: 'entry_edit_requests',
    buildQuery: () => supabase
      .from('entry_edit_requests')
      .select('id, entry_id, changes, reason, created_at, milk_entries!entry_edit_requests_entry_id_fkey(date, time_of_day)')
      .eq('supplier_id', supplierData!.id)
      .eq('status', 'pending')
      .order('created_at', { ascending: false }),
    enabled: !!supplierData?.id,
    sessionGuard: true,
  });

  // Lightweight: only the calculation_method value (used to decide the रकम column).
  const fetchCalculationMethodOnly = async () => {
    if (!user?.dairyId) return;
    try {
      const { data, error } = await supabase
        .from('rate_settings')
        .select('calculation_method')
        .eq('dairy_id', user.dairyId)
        .maybeSingle();
      if (error || !data) return;
      const method = (data.calculation_method as 'avg_fat' | 'daily_total') || 'avg_fat';
      setFreshConfig(prev => ({
        ...(prev ?? {}),
        rateSettings: { ...(prev?.rateSettings ?? {}), calculationMethod: method },
      }));
    } catch { /* keep existing value */ }
  };

  // Delta-check for ALL payment_history changes of this supplier (bhugtan + bakaya additions).
  const fetchPaymentHistoryDelta = async () => {
    const sid = supplierData?.id;
    if (!sid) return;
    const watermarkKey = `dairy_sup_ph_delta_v1_${sid}`;
    try {
      let q = supabase
        .from('payment_history')
        .select('*')
        .eq('supplier_id', sid)
        .order('updated_at', { ascending: true });
      const since = localStorage.getItem(watermarkKey);
      if (since) q = q.gt('updated_at', since);
      const { data, error } = await q;
      if (error || !data || data.length === 0) return;

      let maxUpdated: string | null = null;
      for (const row of data as any[]) {
        if (!row?.deleted_at) upsertPayment(row as PaymentHistoryEntry);
        if (row?.updated_at && (!maxUpdated || row.updated_at > maxUpdated)) maxUpdated = row.updated_at;
      }
      if (maxUpdated) localStorage.setItem(watermarkKey, maxUpdated);

      // Latest record's balance_after → local pendingBalance patch
      const live = (data as any[]).filter(r => !r?.deleted_at && r?.balance_after != null);
      if (live.length > 0) {
        const latest = live.reduce((a, b) => {
          const ka = `${a.transaction_date}|${a.created_at}`;
          const kb = `${b.transaction_date}|${b.created_at}`;
          return kb > ka ? b : a;
        });
        patchSupplierLocal(sid, { pendingBalance: Number(latest.balance_after) || 0 });
      }
    } catch { /* offline → keep cache */ }
  };

  const handleRefreshRequests = async () => {
    if (requestsRefreshing) return;
    setRequestsRefreshing(true);
    try {
      const pendingPromise = supplierData?.id
        ? supabase
            .from('payment_history')
            .select('id, transaction_date, amount_paid, amount_added, balance_after, notes, supplier_confirmed, date_range_start, date_range_end, created_at')
            .eq('supplier_id', supplierData.id)
            .gt('amount_paid', 0)
            .is('supplier_confirmed', null)
            .order('transaction_date', { ascending: false })
            .then(({ data, error }) => {
              if (!error && data) setPendingPayments(data as unknown as PaymentHistoryEntry[]);
            })
        : Promise.resolve();

      await Promise.all([
        pendingPromise,
        fetchPaymentHistoryDelta(),
        refetchEditRequests(),
        fetchCalculationMethodOnly(),
      ]);
    } catch { /* offline → keep cached lists */ } finally {
      setRequestsRefreshing(false);
    }
  };



  useEffect(() => {
    setEditRequests(cachedEditRequests);
  }, [cachedEditRequests]);

  const handleConfirmPayment = async (paymentId: string, confirmed: boolean) => {
    try {
      const payment = paymentHistory.find(p => p.id === paymentId)
        || pendingPayments.find(p => p.id === paymentId);
      
      const { error: rpcError } = await supabase.rpc('confirm_supplier_payment', { _payment_id: paymentId, _confirmed: confirmed });
      if (rpcError) throw rpcError;

      // Balance deduction + balance_after update happen server-side inside the RPC
      // (supplier RLS forbids writing pending_balance from the client).

      upsertPayment({ ...(payment as PaymentHistoryEntry), supplier_confirmed: confirmed });
      setPendingPayments(prev => prev.filter(p => p.id !== paymentId));

      // Lightweight targeted refresh: sirf is supplier ka pending_balance fresh karo
      // (poora refreshData — suppliers+milk_entries+config — yahan zaroori nahi hai).
      if (supplierData?.id) {
        const { data: balRow } = await supabase
          .from('suppliers')
          .select('pending_balance')
          .eq('id', supplierData.id)
          .maybeSingle();
        if (balRow) {
          patchSupplierLocal(supplierData.id, { pendingBalance: Number((balRow as any).pending_balance) || 0 });
        }
      }
    } catch (error) {
      console.error('Error confirming payment:', error);
    }
  };

  const handleEditRequest = async (requestId: string, approved: boolean) => {
    const { error } = await supabase
      .from('entry_edit_requests')
      .update({ status: approved ? 'approved' : 'rejected', responded_at: new Date().toISOString() })
      .eq('id', requestId);
    if (error) return;
    setEditRequests(prev => prev.filter(request => request.id !== requestId));
    removeEditRequestLocal(requestId);
    if (approved) await refreshData();
  };


  const getDaysInMonth = (date: Date) => {
    return new Date(date.getFullYear(), date.getMonth() + 1, 0).getDate();
  };

  const getMonthDates = () => {
    const days = getDaysInMonth(currentMonth);
    const dates: string[] = [];
    for (let i = 1; i <= days; i++) {
      const d = new Date(currentMonth.getFullYear(), currentMonth.getMonth(), i);
      dates.push(format(d, 'yyyy-MM-dd'));
    }
    return dates;
  };

  const getEntryForDate = (date: string): MilkEntry | undefined => {
    return supplierData?.entries.find(e => e.date === date);
  };

  const changeMonth = (delta: number) => {
    setCurrentMonth(prev => {
      const newDate = new Date(prev);
      newDate.setMonth(newDate.getMonth() + delta);
      return newDate;
    });
  };

  const monthNames = [
    'January', 'February', 'March', 'April', 'May', 'June',
    'July', 'August', 'September', 'October', 'November', 'December'
  ];

  // Custom range stats
  const getCustomRangeStats = () => {
    if (!startDate || !endDate || !supplierData) return null;
    const startStr = format(startDate, 'yyyy-MM-dd');
    const endStr = format(endDate, 'yyyy-MM-dd');
    
    const stats = calculateSupplierStats({
      entries: supplierData.entries,
      startDate: startStr,
      endDate: endStr,
      shiftFilter: timeFilter,
      rate,
      calculationMethod,
      fatSnfSettings,
      animalType: supplierData.animalType,
      literRate: rateSettings.literRate || 50,
    });

    return { totalMilk: stats.totalMilk, avgFat: stats.avgFat, totalAmount: stats.totalAmount, morningTotalAmount: 0, eveningTotalAmount: 0 };
  };

  const customRangeStats = getCustomRangeStats();

  // Auto-logout if customer_code feature is disabled
  useEffect(() => {
    if (customerCodeEnabled === false) {
      const doLogout = async () => {
        await logout();
        navigate('/auth');
      };
      doLogout();
    }
  }, [customerCodeEnabled, logout, navigate]);

  if (customerCodeEnabled === false) {
    return null;
  }

  if (!supplier || !supplierData) {
    return (
      <div className="min-h-screen bg-background pb-24">
        <Header />
        <main className="px-4 py-6 max-w-4xl mx-auto">
          <div className="dairy-card text-center py-12 animate-fade-in">
            <div className="text-6xl mb-4">📋</div>
            <p className="text-muted-foreground">{t('noData')}</p>
            <p className="text-sm text-muted-foreground mt-2">
              कृपया डेयरी मालिक से संपर्क करें
            </p>
          </div>
        </main>
        <BottomNav />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background pb-24">
      {/* Header with Supplier Info */}
      <header className="dairy-header px-3 py-1">
        <div className="flex items-center gap-3 max-w-4xl mx-auto">
          <div className="w-10 h-10 rounded-xl bg-primary-foreground/20 overflow-hidden flex items-center justify-center shrink-0">
            {authImageUrl ? (
              <img src={authImageUrl} alt="Dairy" className="w-10 h-10 rounded-xl object-cover" />
            ) : (
              <span className="text-xl">🥛</span>
            )}
          </div>
          <div className="flex-1 min-w-0">
            <h1 className="text-base font-bold text-primary-foreground truncate">{supplier.name}</h1>
            <p className="text-[11px] text-primary-foreground/70 truncate">
              {user?.dairyName}{supplier.code ? ` • #${supplier.code}` : ''}
            </p>
           </div>
           <button
             onClick={() => void handleRefreshRequests()}
             disabled={requestsRefreshing}
             aria-label={language === 'hi' ? 'रिफ्रेश करें' : 'Refresh'}
             className="shrink-0 h-10 w-10 rounded-full bg-primary-foreground/25 hover:bg-primary-foreground/40 border border-primary-foreground/30 shadow-[0_2px_10px_rgba(0,0,0,0.18)] flex items-center justify-center active:scale-[0.92] transition-all duration-200 disabled:opacity-80"
           >
             <RefreshCw className={cn("h-4 w-4 text-primary-foreground", requestsRefreshing && "animate-spin")} />
           </button>
         </div>
       </header>


       <main className="px-3 py-3 max-w-4xl mx-auto space-y-3">
         {/* Top strip: baki amount */}
         {supplierData && (
           <div className="animate-fade-in">
             <div className="rounded-xl border border-amber-200 dark:border-amber-800 bg-gradient-to-r from-amber-50 to-orange-50 dark:from-amber-900/20 dark:to-orange-900/20 px-3 py-2">
               <p className="text-[11px] text-muted-foreground">{language === 'hi' ? 'बाकी राशि' : 'Balance due'}</p>
               <p className={cn("text-xl font-bold leading-tight", (supplierData.pendingBalance || 0) > 0 ? "text-amber-600" : "text-green-600")}>
                 ₹{Math.abs(supplierData.pendingBalance || 0).toLocaleString()}
               </p>
             </div>
           </div>
         )}

         <button
           onClick={handleHisaabToggle}
           className="w-full rounded-xl border border-border bg-card px-3 py-2 flex items-center justify-between active:scale-[0.99] transition"
         >
           <span className="flex items-center gap-2 text-sm font-semibold">
             <Filter className="h-4 w-4 text-primary" />
             {language === 'hi' ? 'हिसाब (तारीख अनुसार)' : 'Hisaab (by date range)'}
           </span>
           <ChevronDown className={cn('h-4 w-4 transition-transform', hisaabOpen && 'rotate-180')} />
         </button>

         {hisaabOpen && !showCalculations && (
           <p className="rounded-xl border border-border bg-card px-3 py-2 text-center text-sm text-muted-foreground">
             {language === 'hi'
               ? 'यह सुविधा अभी बंद है। डेयरी मालिक से संपर्क करें।'
               : 'This feature is currently disabled. Contact the dairy owner.'}
           </p>
         )}

        {/* Payment Confirmation Banner */}
        {pendingPayments.length > 0 && (
          <div className="dairy-card animate-fade-in border-2 border-amber-300 dark:border-amber-700 bg-amber-50 dark:bg-amber-900/20">
            <div className="flex items-center gap-2 mb-3">
              <Banknote className="h-5 w-5 text-amber-600" />
              <h3 className="font-bold text-amber-700 dark:text-amber-400">
                {language === 'hi' ? '💰 क्या आपने पैसे प्राप्त किए?' : '💰 Did you receive the money?'}
              </h3>
            </div>
            <div className="space-y-2">
              {pendingPayments.map(p => (
                <div key={p.id} className="p-3 bg-card rounded-xl border flex items-center gap-3">
                  <div className="flex-1">
                    <p className="font-bold text-lg">₹{((p.amount_paid || 0) > 0 ? (p.amount_paid || 0) : (p.amount_added || 0)).toLocaleString()}</p>
                    <p className="text-xs text-muted-foreground">
                      {format(new Date(p.transaction_date), 'dd/MM/yyyy')}
                      {p.notes && ` • ${p.notes}`}
                    </p>
                  </div>
                  <div className="flex gap-8">
                    <Button size="sm" className="bg-green-600 hover:bg-green-700 text-xs px-4" onClick={() => handleConfirmPayment(p.id, true)}>
                      {language === 'hi' ? 'हां' : 'Yes'}
                    </Button>
                    <Button size="sm" variant="destructive" className="text-xs px-4" onClick={() => handleConfirmPayment(p.id, false)}>
                      {language === 'hi' ? 'नहीं' : 'No'}
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

          {editRequests.length > 0 && (
           <div className="dairy-card animate-fade-in border-2 border-primary/30">
             <div className="flex items-center gap-2 mb-3">
               <Shield className="h-5 w-5 text-primary" />
               <h3 className="font-bold">{language === 'hi' ? 'एंट्री बदलाव अनुरोध' : 'Entry update requests'}</h3>
             </div>
             <div className="space-y-3">
               {editRequests.map(request => (
                 <div key={request.id} className="rounded-xl border bg-muted/40 p-3">
                   <p className="text-sm font-medium">
                     {request.milk_entries?.date ? format(new Date(`${request.milk_entries.date}T00:00:00`), 'dd/MM/yyyy') : ''}
                     {request.milk_entries?.time_of_day ? ` • ${request.milk_entries.time_of_day}` : ''}
                   </p>
                   {summarizeEntryChanges(request.changes, language) && (
                     <p className="mt-1 text-sm font-bold text-primary">
                       {summarizeEntryChanges(request.changes, language)}
                     </p>
                   )}
                   {request.reason && <p className="mt-1 text-xs text-muted-foreground">{request.reason}</p>}
                   <div className="mt-3 grid grid-cols-2 gap-3">
                     <Button size="sm" className="gap-1" onClick={() => void handleEditRequest(request.id, true)}>
                       <CheckCircle className="h-4 w-4" /> {language === 'hi' ? 'स्वीकार' : 'Approve'}
                     </Button>
                     <Button size="sm" variant="destructive" className="gap-1" onClick={() => void handleEditRequest(request.id, false)}>
                       <XCircle className="h-4 w-4" /> {language === 'hi' ? 'अस्वीकार' : 'Reject'}
                     </Button>
                   </div>
                 </div>
               ))}
             </div>
           </div>
         )}

        {/* Custom Date Range Stats */}
        {showCalculations && hisaabOpen && (
          <div className="dairy-card animate-fade-in">
            <div className="flex items-center gap-2 mb-3">
              <Filter className="h-4 w-4 text-primary" />
              <h3 className="font-semibold">{t('customDateRange')}</h3>
            </div>

            <div className="grid grid-cols-2 gap-3 mb-3">
              <div>
                <label className="text-sm text-muted-foreground mb-1 block">{t('fromDate')}</label>
                <Popover>
                  <PopoverTrigger asChild>
                    <Button variant="outline" className={cn("w-full justify-start text-left font-normal", !startDate && "text-muted-foreground")}>
                      <CalendarIcon className="mr-2 h-4 w-4" />
                      {startDate ? format(startDate, "dd/MM/yyyy") : t('selectDate')}
                    </Button>
                  </PopoverTrigger>
                  <PopoverContent className="w-auto p-0" align="start">
                    <Calendar mode="single" selected={startDate} onSelect={setStartDate} initialFocus className="pointer-events-auto" />
                  </PopoverContent>
                </Popover>
              </div>
              <div>
                <label className="text-sm text-muted-foreground mb-1 block">{t('toDate')}</label>
                <Popover>
                  <PopoverTrigger asChild>
                    <Button variant="outline" className={cn("w-full justify-start text-left font-normal", !endDate && "text-muted-foreground")}>
                      <CalendarIcon className="mr-2 h-4 w-4" />
                      {endDate ? format(endDate, "dd/MM/yyyy") : t('selectDate')}
                    </Button>
                  </PopoverTrigger>
                  <PopoverContent className="w-auto p-0" align="start">
                    <Calendar mode="single" selected={endDate} onSelect={setEndDate} initialFocus className="pointer-events-auto" />
                  </PopoverContent>
                </Popover>
              </div>
            </div>

            <div className="flex gap-2 mb-3">
              <Button variant={timeFilter === 'morning' ? 'default' : 'outline'} size="sm" className="flex-1" onClick={() => setTimeFilter('morning')}>🌅 {t('morning')}</Button>
              <Button variant={timeFilter === 'evening' ? 'default' : 'outline'} size="sm" className="flex-1" onClick={() => setTimeFilter('evening')}>🌙 {t('evening')}</Button>
              <Button variant={timeFilter === 'both' ? 'default' : 'outline'} size="sm" className="flex-1" onClick={() => setTimeFilter('both')}>{t('both')}</Button>
            </div>

            {customRangeStats && startDate && endDate && (
              <div className="grid grid-cols-2 gap-3 p-3 bg-muted/50 rounded-xl">
                <div className="text-center">
                  <p className="text-xs text-muted-foreground">{t('totalMilk')}</p>
                  <p className="text-lg font-bold text-primary">{customRangeStats.totalMilk.toFixed(1)} L</p>
                </div>
                <div className="text-center">
                  <p className="text-xs text-muted-foreground">{t('avgFat')}</p>
                  <p className="text-lg font-bold text-accent">{customRangeStats.avgFat.toFixed(2)}</p>
                </div>
                <div className="col-span-2 text-center p-2 bg-primary/10 rounded-lg">
                  <p className="text-xs text-muted-foreground">{t('totalAmount')}</p>
                  <p className="text-xl font-bold text-primary">₹{customRangeStats.totalAmount.toFixed(0)}</p>
                </div>
              </div>
            )}

            {(!startDate || !endDate) && (
              <p className="text-center text-sm text-muted-foreground py-4">{t('selectDate')}</p>
            )}
          </div>
        )}

        {/* Month Card Table */}
        <div className="dairy-card animate-fade-in" style={{ animationDelay: '100ms' }}>
          <div className="flex items-center justify-between mb-4">
            <Button variant="ghost" size="icon" onClick={() => changeMonth(-1)}>
              <ChevronLeft className="h-5 w-5" />
            </Button>
            <h2 className="text-lg font-semibold">
              {monthNames[currentMonth.getMonth()]} {currentMonth.getFullYear()}
            </h2>
            <Button variant="ghost" size="icon" onClick={() => changeMonth(1)}>
              <ChevronRight className="h-5 w-5" />
            </Button>
          </div>

          <div className="overflow-x-auto -mx-5 px-1">
            <table className="milk-table text-[11px] w-full">
              <thead>
                 {(() => {
                   const isBuyer = supplierData?.animalType === 'buyer';
                    const showRakam = showCalculations && (isBuyer || (calculationMethod === 'daily_total' && showRakamToCustomers));
                    const colCount = isBuyer ? (showRakam ? 2 : 1) : (showRakam ? 3 : 2);
                   return (
                   <>
                   <tr>
                   <th rowSpan={2} className="w-6 px-0.5">{language === 'hi' ? 'दि' : 'D'}</th>
                   <th colSpan={colCount} className="bg-primary/10 px-0.5">🌅</th>
                   <th colSpan={colCount} className="border-l-4 border-dairy-divider shadow-[inset_4px_0_8px_-4px_hsl(0_80%_55%/0.4)] bg-accent/10 px-0.5">🌙</th>
                 </tr>
                 <tr>
                   <th className="px-0.5">{language === 'hi' ? 'दूध' : 'M'}</th>
                   {!isBuyer && <th className="px-0.5">{language === 'hi' ? 'फैट' : 'F'}</th>}
                    {showRakam && (
                     <th className="text-primary font-bold px-0.5">₹</th>
                   )}
                   <th className="border-l-4 border-dairy-divider shadow-[inset_4px_0_8px_-4px_hsl(0_80%_55%/0.4)] px-0.5">{language === 'hi' ? 'दूध' : 'M'}</th>
                   {!isBuyer && <th className="px-0.5">{language === 'hi' ? 'फैट' : 'F'}</th>}
                    {showRakam && (
                     <th className="text-primary font-bold px-0.5">₹</th>
                   )}
                 </tr>
                   </>
                   );
                 })()}
              </thead>
              <tbody>
                {getMonthDates().map(date => {
                  const entry = getEntryForDate(date);
                  const dayNum = Number(date.split('-')[2]);
                  const isToday = date === format(new Date(), 'yyyy-MM-dd');
                  const isBuyer = supplierData?.animalType === 'buyer';
                  const literRate = rateSettings.literRate || 50;

                  // FAT+SNF ON → stored entry price use karo (owner ne entry ke waqt calculateFatSnfEntry se save kiya hai).
                  // Avg_fat / daily_total ke liye purana logic waisa hi.
                  const morningAmount = isBuyer
                    ? (entry?.morningMilk ? entry.morningMilk * literRate : null)
                    : fatSnfEnabled
                      ? (entry?.morningPrice ?? null)
                      : (entry?.morningMilk && entry?.morningFat
                        ? entry.morningMilk * entry.morningFat * rate
                        : null);
                  const eveningAmount = isBuyer
                    ? (entry?.eveningMilk ? entry.eveningMilk * literRate : null)
                    : fatSnfEnabled
                      ? (entry?.eveningPrice ?? null)
                      : (entry?.eveningMilk && entry?.eveningFat
                        ? entry.eveningMilk * entry.eveningFat * rate
                        : null);

                  return (
                    <tr key={date} className={cn(isToday && 'bg-primary/5')}>
                      <td className="font-medium">{dayNum}</td>
                      <td>{entry?.morningMilk ?? '-'}</td>
                       {!isBuyer && <td>{entry?.morningFat ?? '-'}</td>}
                        {showCalculations && (isBuyer || (calculationMethod === 'daily_total' && showRakamToCustomers)) && (
                          <td className="text-primary font-bold">{morningAmount !== null ? `₹${morningAmount.toFixed(0)}` : '-'}</td>
                        )}
                        <td className="border-l-4 border-dairy-divider shadow-[inset_4px_0_8px_-4px_hsl(0_80%_55%/0.4)]">{entry?.eveningMilk ?? '-'}</td>
                        {!isBuyer && <td>{entry?.eveningFat ?? '-'}</td>}
                        {showCalculations && (isBuyer || (calculationMethod === 'daily_total' && showRakamToCustomers)) && (
                          <td className="text-primary font-bold">{eveningAmount !== null ? `₹${eveningAmount.toFixed(0)}` : '-'}</td>
                        )}
                    </tr>
                  );
                })}
                {/* Supplier's own dashboard never shows total/average summary rows. */}
              </tbody>
            </table>
          </div>
        </div>

        {/* Payment History Section */}
        <div className="dairy-card animate-fade-in" style={{ animationDelay: '200ms' }}>
          <div className="flex items-center gap-2 mb-4">
            <History className="h-5 w-5 text-primary" />
            <h3 className="font-bold">{language === 'hi' ? 'भुगतान हिस्ट्री' : 'Payment History'}</h3>
          </div>

          {loadingHistory ? (
            <p className="text-center text-sm text-muted-foreground py-4">
              {language === 'hi' ? 'लोड हो रहा है...' : 'Loading...'}
            </p>
          ) : (() => {
            // Filter: payment records (amount_paid > 0) only show after supplier confirms
            const visibleHistory = paymentHistory.filter(entry => {
              const isPaid = (entry.amount_paid || 0) > 0;
              // For bhugtan records: only show if supplier confirmed
              if (isPaid) return entry.supplier_confirmed === true;
              // For bakaya additions: always show
              return true;
            }).sort((a, b) => {
              const byCreated = new Date(b.created_at).getTime() - new Date(a.created_at).getTime();
              return byCreated || b.transaction_date.localeCompare(a.transaction_date);
            });
            return visibleHistory.length === 0 ? (
              <p className="text-center text-sm text-muted-foreground py-4">
                {language === 'hi' ? 'कोई भुगतान हिस्ट्री नहीं' : 'No payment history'}
              </p>
            ) : (
              <div className="space-y-2">
                {visibleHistory.map(entry => {
                  const isPaid = (entry.amount_paid || 0) > 0;
                  return (
                    <div key={entry.id} className={cn(
                      "flex items-center gap-3 p-3 rounded-xl border",
                      isPaid ? "bg-green-50 dark:bg-green-900/20 border-green-200 dark:border-green-800" : "bg-amber-50 dark:bg-amber-900/20 border-amber-200 dark:border-amber-800"
                    )}>
                      {isPaid ? (
                        <ArrowUpCircle className="h-5 w-5 text-green-600 shrink-0" />
                      ) : (
                        <ArrowDownCircle className="h-5 w-5 text-amber-600 shrink-0" />
                      )}
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-medium">
                          {isPaid
                            ? `${language === 'hi' ? 'भुगतान' : 'Paid'}: ₹${(entry.amount_paid || 0).toLocaleString()}`
                            : `${language === 'hi' ? 'बकाया जोड़ा' : 'Added'}: ₹${(entry.amount_added || 0).toLocaleString()}`
                          }
                        </p>
                        <p className="text-xs text-muted-foreground">
                          {format(new Date(entry.transaction_date), 'dd/MM/yyyy')}
                          {entry.notes && ` • ${entry.notes}`}
                        </p>
                      </div>
                      <div className="text-right shrink-0">
                        <p className="text-xs text-muted-foreground">{language === 'hi' ? 'शेष' : 'Bal'}</p>
                        <p className={cn("text-sm font-bold", entry.balance_after > 0 ? "text-amber-600" : "text-green-600")}>
                          ₹{Math.abs(entry.balance_after).toLocaleString()}
                        </p>
                      </div>
                    </div>
                  );
                })}
              </div>
            );
          })()}
        </div>
      </main>

      <BottomNav />
    </div>
  );
};

export default SupplierDashboard;

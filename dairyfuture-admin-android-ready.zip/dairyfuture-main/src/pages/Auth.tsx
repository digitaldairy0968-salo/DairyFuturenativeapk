import React, { useState, useEffect } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { User, Phone, ArrowLeft, Droplets } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { useAuth } from '@/contexts/AuthContext';
import { useLanguage } from '@/contexts/LanguageContext';
import { useToast } from '@/hooks/use-toast';
import { supabase } from '@/integrations/supabase/client';
import { getCachedAuthImage, fetchAndCacheAuthImage } from '@/utils/authImageCache';

import { z } from 'zod';
import LanguageSelect from './LanguageSelect';
import RateSetup from './RateSetup';
import OwnerOnboarding from './OwnerOnboarding';
import farmerImage from '@/assets/farmer-welcome.webp';
import cowImage from '@/assets/cow-illustration.webp';
import {
  startGoogleSignIn,
  clearGoogleOAuthPending,
  consumeWebOAuthError,
  GOOGLE_OAUTH_PENDING_KEY,
  GOOGLE_OAUTH_ROLE_KEY,
  PENDING_GOOGLE_PROFILE_KEY,
} from '@/lib/googleAuth';

type AuthMode = 'login' | 'signup';
type UserRole = 'owner' | 'supplier';
type AuthStep = 'language-selection' | 'role-selection' | 'auth-form' | 'rate-setup' | 'owner-onboarding' | 'google-profile' | 'google-resolving';
const POST_LOGOUT_AUTH_ROLE_KEY = 'post_logout_auth_role';

const getPostLogoutRole = (): UserRole | null => {
  try {
    const saved = sessionStorage.getItem(POST_LOGOUT_AUTH_ROLE_KEY);
    return saved === 'owner' || saved === 'supplier' ? saved : null;
  } catch {
    return null;
  }
};

// Google brand mark (official brand colors are required by Google's sign-in guidelines)
const GoogleIcon = () => (
  <svg viewBox="0 0 48 48" className="w-5 h-5" aria-hidden="true">
    <path fill="#EA4335" d="M24 9.5c3.5 0 6.6 1.2 9.1 3.6l6.8-6.8C35.8 2.4 30.3 0 24 0 14.6 0 6.5 5.4 2.6 13.2l7.9 6.1C12.4 13.6 17.7 9.5 24 9.5z" />
    <path fill="#4285F4" d="M46.5 24.5c0-1.6-.1-3.1-.4-4.5H24v9h12.7c-.6 3-2.3 5.5-4.8 7.2l7.6 5.9c4.5-4.1 7-10.2 7-17.6z" />
    <path fill="#FBBC05" d="M10.5 28.7c-.5-1.5-.8-3-.8-4.7s.3-3.2.8-4.7l-7.9-6.1C1 16.5 0 20.1 0 24s1 7.5 2.6 10.8l7.9-6.1z" />
    <path fill="#34A853" d="M24 48c6.3 0 11.7-2.1 15.6-5.7l-7.6-5.9c-2.1 1.4-4.8 2.3-8 2.3-6.3 0-11.6-4.1-13.5-9.8l-7.9 6.1C6.5 42.6 14.6 48 24 48z" />
  </svg>
);

// Validation schemas (Google profile completion step)
const phoneSchema = z.string().regex(/^\d{10}$/, 'कृपया 10 अंकों का फोन नंबर दर्ज करें / Please enter 10-digit phone number');
const nameSchema = z.string().min(2, 'कृपया नाम दर्ज करें / Please enter name');

const Auth: React.FC = () => {
  const [authPageImageUrl, setAuthPageImageUrl] = useState<string | null>(getCachedAuthImage);

  // Determine initial step based on pending state
  const getInitialStep = (): AuthStep => {
    // A Google round-trip is in progress — show a dedicated spinner instead of
    // flashing whatever step would otherwise match while the async check runs.
    if (localStorage.getItem(GOOGLE_OAUTH_PENDING_KEY) === '1') return 'google-resolving';
    if (localStorage.getItem(PENDING_GOOGLE_PROFILE_KEY) === 'true') return 'google-profile';
    if (localStorage.getItem('pending_owner_onboarding') === 'true') return 'owner-onboarding';
    if (localStorage.getItem('pending_rate_setup') === 'true') return 'rate-setup';
    if (getPostLogoutRole()) return 'auth-form';
    return 'role-selection';
  };

  const getInitialRole = (): UserRole => {
    const postLogoutRole = getPostLogoutRole();
    if (postLogoutRole) return postLogoutRole;
    const saved = localStorage.getItem(GOOGLE_OAUTH_ROLE_KEY);
    return saved === 'supplier' ? 'supplier' : 'owner';
  };

  const [step, setStep] = useState<AuthStep>(getInitialStep);
  const [mode, setMode] = useState<AuthMode>(() => getPostLogoutRole() ? 'login' : 'signup');
  const [role, setRole] = useState<UserRole>(getInitialRole);
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  
  const [isLoading, setIsLoading] = useState(false);
  const [isGoogleLoading, setIsGoogleLoading] = useState(false);

  const { isAuthenticated, user, authUser, authDiagnostics, refreshProfile } = useAuth();
  const { t, language } = useLanguage();
  const { toast } = useToast();
  const navigate = useNavigate();

  // The hint is needed only while this Auth instance initializes. Removing it
  // prevents a later direct visit to /auth from skipping role selection.
  useEffect(() => {
    try { sessionStorage.removeItem(POST_LOGOUT_AUTH_ROLE_KEY); } catch { /* ignore */ }
  }, []);

  // Fetch admin-uploaded auth page image
  useEffect(() => {
    if (!authPageImageUrl) {
      fetchAndCacheAuthImage().then((url) => {
        if (url) setAuthPageImageUrl(url);
      });
    }
  }, []);

  // Google OAuth: surface provider/linking errors returned on the callback URL
  useEffect(() => {
    const oauthError = consumeWebOAuthError();
    if (oauthError) {
      clearGoogleOAuthPending();
      toast({ title: t('error'), description: oauthError, variant: 'destructive' });
    }
  }, []);

  // Google OAuth: after the session lands, decide existing-user vs new-user
  const googleResolvedRef = React.useRef(false);

  // Safety net: never leave the user stuck on the Google spinner if they
  // abandoned the Google flow before it completed.
  useEffect(() => {
    if (step !== 'google-resolving') return;
    const timer = window.setTimeout(() => {
      if (googleResolvedRef.current) return;
      clearGoogleOAuthPending();
      setStep('role-selection');
    }, 10000);
    return () => window.clearTimeout(timer);
  }, [step]);

  useEffect(() => {
    if (googleResolvedRef.current) return;
    if (localStorage.getItem(GOOGLE_OAUTH_PENDING_KEY) !== '1') return;
    if (!authUser) return;
    googleResolvedRef.current = true;

    const resolve = async () => {
      setIsGoogleLoading(true);
      try {
        const [{ data: profileRow }, { data: roleRow }] = await Promise.all([
          supabase.from('profiles').select('name, phone').eq('user_id', authUser.id).maybeSingle(),
          supabase.from('user_roles').select('role').eq('user_id', authUser.id).maybeSingle(),
        ]);

        // A DB trigger creates an EMPTY profile row for every new auth user
        // (including Google), so "profile exists" alone isn't enough — a real
        // registered user always has a role row and a phone number.
        const isExisting = !!roleRow?.role && !!profileRow?.phone;

        if (isExisting) {
          // Case A — go straight to that user's own dashboard (role from DB, not Step-2 choice)
          clearGoogleOAuthPending();
          localStorage.removeItem(PENDING_GOOGLE_PROFILE_KEY);
          await refreshProfile();
          toast({ title: t('success'), description: `${t('welcome')}!` });
          navigate('/', { replace: true });
          return;
        }

        // Case B — first Google sign-in: ask Name + Phone before anything else
        localStorage.removeItem(GOOGLE_OAUTH_PENDING_KEY);
        localStorage.setItem(PENDING_GOOGLE_PROFILE_KEY, 'true');
        const meta = (authUser.user_metadata || {}) as Record<string, string>;
        setName(profileRow?.name || meta.full_name || meta.name || '');
        setPhone('');
        setStep('google-profile');
      } catch {
        clearGoogleOAuthPending();
        toast({ title: t('error'), description: 'कुछ गलत हो गया / Something went wrong', variant: 'destructive' });
      } finally {
        setIsGoogleLoading(false);
      }
    };
    resolve();
  }, [authUser]);

  const handleGoogleSignIn = async () => {
    if (authDiagnostics.preAuthFetchStatus === 'failed') {
      toast({
        title: t('error'),
        description: authDiagnostics.preAuthFetchError || 'Network error - please check your internet connection',
        variant: 'destructive',
      });
      return;
    }
    setIsGoogleLoading(true);
    try {
      const { error } = await startGoogleSignIn(role);
      if (error) {
        toast({ title: t('error'), description: error, variant: 'destructive' });
        setIsGoogleLoading(false);
      }
      // On web the page redirects away; on native the deep-link handler resumes the flow.
    } catch {
      clearGoogleOAuthPending();
      toast({ title: t('error'), description: 'कुछ गलत हो गया / Something went wrong', variant: 'destructive' });
      setIsGoogleLoading(false);
    }
  };

  // Case B submit: save Name + Phone (+ role), then continue the existing role flow
  const handleGoogleProfileSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!authUser) return;

    const nameResult = nameSchema.safeParse(name.trim());
    if (!nameResult.success) {
      toast({ title: t('error'), description: nameResult.error.errors[0].message, variant: 'destructive' });
      return;
    }
    const phoneResult = phoneSchema.safeParse(phone.trim());
    if (!phoneResult.success) {
      toast({ title: t('error'), description: phoneResult.error.errors[0].message, variant: 'destructive' });
      return;
    }

    setIsLoading(true);
    try {
      const cleanName = name.trim();
      const cleanPhone = phone.trim();

      // Profile + role are set server-side via a SECURITY DEFINER RPC.
      // Direct client inserts into user_roles are blocked by RLS (anti privilege-escalation).
      const { error: rpcErr } = await supabase.rpc('complete_google_signup', {
        p_name: cleanName,
        p_phone: cleanPhone,
        p_role: role,
      });
      if (rpcErr) throw rpcErr;


      // Keep auth metadata consistent with email/password signups
      await supabase.auth.updateUser({ data: { name: cleanName, phone: cleanPhone, role } });

      localStorage.removeItem(PENDING_GOOGLE_PROFILE_KEY);
      clearGoogleOAuthPending();
      if (role === 'owner') {
        // MUST be set before the await: refreshProfile() re-renders AuthRedirect
        // mid-await, and without this flag it would navigate to /dairy-setup and
        // unmount Auth, skipping rate-setup + owner-onboarding entirely.
        localStorage.setItem('pending_rate_setup', 'true');
      }
      await refreshProfile();

      toast({ title: t('success'), description: `${t('welcome')}!` });

      if (role === 'owner') {
        setStep('rate-setup');
      } else {
        // Supplier: phone-link happened in refreshProfile; Index routes to dashboard or joinDairy (/dairy-setup)
        navigate('/', { replace: true });
      }
    } catch (error: any) {
      toast({ title: t('error'), description: error?.message || 'कुछ गलत हो गया / Something went wrong', variant: 'destructive' });
    } finally {
      setIsLoading(false);
    }
  };

  // Password recovery links always go to the dedicated reset page
  useEffect(() => {
    const hashParams = new URLSearchParams(window.location.hash.substring(1));
    if (sessionStorage.getItem('pw_recovery') === '1' || hashParams.get('type') === 'recovery') {
      navigate('/reset-password', { replace: true });
      return;
    }
    const { data: { subscription } } = supabase.auth.onAuthStateChange((event) => {
      if (event === 'PASSWORD_RECOVERY') {
        sessionStorage.setItem('pw_recovery', '1');
        navigate('/reset-password', { replace: true });
      }
    });
    return () => subscription.unsubscribe();
  }, []);

  // After login, redirect based on role
  useEffect(() => {
    // Google flow is resolved by its own effect above (existing vs new user)
    if (localStorage.getItem(GOOGLE_OAUTH_PENDING_KEY) === '1' || localStorage.getItem(PENDING_GOOGLE_PROFILE_KEY) === 'true') return;
    if (isAuthenticated && user && step === 'auth-form' && mode === 'login') {
      if (user.role === 'admin') {
        navigate('/admin', { replace: true });
      } else if (user.role === 'supplier') {
        navigate(user.dairyId ? '/supplier-dashboard' : '/dairy-setup', { replace: true });
      } else if (user.role === 'owner') {
        if (user.dairyId) {
          navigate('/dashboard', { replace: true });
        } else {
          // Owner without dairy - start onboarding
          const pendingRateSetup = localStorage.getItem('pending_rate_setup');
          const pendingOnboarding = localStorage.getItem('pending_owner_onboarding');
          if (pendingOnboarding === 'true') {
            setStep('owner-onboarding');
          } else if (pendingRateSetup === 'true') {
            setStep('rate-setup');
          } else {
            navigate('/dairy-setup', { replace: true });
          }
        }
      }
    }
  }, [isAuthenticated, user, step, mode]);

  const handleLanguageComplete = () => {
    setStep('role-selection');
  };

  const handleRoleSelect = (selectedRole: UserRole) => {
    setRole(selectedRole);
    setStep('auth-form');
  };

  const handleBack = () => {
    if (step === 'auth-form') {
      setStep('role-selection');
      return;
    }
    if (step === 'role-selection') {
      setStep('language-selection');
    }
  };

  const handleRateSetupComplete = () => {
    localStorage.removeItem('pending_rate_setup');
    localStorage.setItem('pending_owner_onboarding', 'true');
    setStep('owner-onboarding');
  };

  const handleOwnerOnboardingComplete = () => {
    localStorage.removeItem('pending_owner_onboarding');
    navigate('/dairy-setup');
  };

  const handleRateSetupBack = () => {
    localStorage.removeItem('pending_rate_setup');
    setStep('auth-form');
  };

  const handleOwnerOnboardingBack = () => {
    localStorage.setItem('pending_rate_setup', 'true');
    localStorage.removeItem('pending_owner_onboarding');
    setStep('rate-setup');
  };

  // Google round-trip in progress — dedicated spinner, nothing else
  if (step === 'google-resolving') {
    return (
      <div className="min-h-screen bg-gradient-to-b from-background via-background to-dairy-cream flex flex-col items-center justify-center px-4">
        <GoogleIcon />
        <div className="w-8 h-8 border-2 border-primary/30 border-t-primary rounded-full animate-spin mt-5" />
        <p className="mt-5 text-base font-medium text-muted-foreground text-center">
          {language === 'hi'
            ? 'Google से साइन इन हो रहा है...'
            : language === 'gu'
            ? 'Google થી સાઇન ઇન થઈ રહ્યું છે...'
            : 'Signing in with Google...'}
        </p>
      </div>
    );
  }

  if (step === 'language-selection') {
    return <LanguageSelect onComplete={handleLanguageComplete} />;
  }

  if (step === 'rate-setup') {
    return (
      <RateSetup 
        onComplete={handleRateSetupComplete}
        onBack={handleRateSetupBack}
      />
    );
  }
 
  if (step === 'owner-onboarding') {
    return (
      <OwnerOnboarding
        onComplete={handleOwnerOnboardingComplete}
        onBack={handleOwnerOnboardingBack}
      />
    );
  }

  // Google Sign-In: Name + Phone step for first-time Google users (Case B)
  if (step === 'google-profile') {
    return (
      <div className="min-h-screen bg-gradient-to-b from-background via-background to-dairy-cream flex flex-col items-center justify-center px-4">
        <div className="dairy-card max-w-md w-full p-5 animate-slide-up">
          <div className="text-center mb-4">
            <div className="flex justify-center mb-2">
              <div className="w-12 h-12 bg-gradient-to-br from-primary to-primary/80 rounded-xl flex items-center justify-center shadow-lg shadow-primary/20">
                <User className="w-6 h-6 text-primary-foreground" />
              </div>
            </div>
            <h1 className="text-xl font-bold">
              {language === 'hi' ? 'एक आखिरी कदम' : language === 'gu' ? 'એક છેલ્લું પગલું' : 'One last step'}
            </h1>
            <p className="text-sm text-muted-foreground mt-1">
              {language === 'hi' ? 'अपना नाम और फोन नंबर बताएं' : language === 'gu' ? 'તમારું નામ અને ફોન નંબર આપો' : 'Tell us your name and phone number'}
            </p>
            {authUser?.email && (
              <p className="text-xs text-muted-foreground mt-1 truncate">{authUser.email}</p>
            )}
            <div className="flex items-center justify-center gap-1.5 mt-2">
              <span className="text-lg">{role === 'owner' ? '👨‍🌾' : '🐄'}</span>
              <span className="text-sm text-muted-foreground">
                {role === 'owner'
                  ? (language === 'hi' ? 'डेयरी मालिक' : 'Dairy Owner')
                  : (language === 'hi' ? 'ग्राहक' : 'Customer')}
              </span>
            </div>
          </div>

          <form onSubmit={handleGoogleProfileSubmit} className="space-y-3">
            <div className="relative">
              <User className="absolute left-4 top-1/2 -translate-y-1/2 h-5 w-5 text-muted-foreground" />
              <Input
                type="text"
                placeholder={language === 'hi' ? 'नाम *' : 'Name *'}
                value={name}
                onChange={e => setName(e.target.value)}
                className="dairy-input pl-10 h-11"
                required
              />
            </div>

            <div className="relative">
              <Phone className="absolute left-4 top-1/2 -translate-y-1/2 h-5 w-5 text-muted-foreground" />
              <Input
                type="tel"
                inputMode="numeric"
                placeholder={language === 'hi' ? 'फोन नंबर (10 अंक) *' : 'Phone (10 digits) *'}
                value={phone}
                onChange={e => setPhone(e.target.value.replace(/\D/g, '').slice(0, 10))}
                className="dairy-input pl-10 h-11"
                required
                maxLength={10}
              />
            </div>

            {role === 'supplier' && (
              <div className="flex items-start gap-2 p-3 bg-accent/10 rounded-2xl">
                <span className="text-lg">💡</span>
                <p className="text-xs text-muted-foreground">
                  {language === 'hi'
                    ? 'नोट: यह वही फोन नंबर होना चाहिए जो डेयरी मालिक ने जोड़ा है'
                    : 'Note: This must be the same phone number the dairy owner added'}
                </p>
              </div>
            )}

            <Button type="submit" variant="dairy" className="w-full h-11 text-base" disabled={isLoading}>
              {isLoading ? (
                <span className="flex items-center gap-2">
                  <span className="w-5 h-5 border-2 border-primary-foreground/30 border-t-primary-foreground rounded-full animate-spin" />
                  {language === 'hi' ? 'प्रतीक्षा करें...' : 'Please wait...'}
                </span>
              ) : (language === 'hi' ? 'आगे बढ़ें' : language === 'gu' ? 'આગળ વધો' : 'Continue')}
            </Button>
          </form>
        </div>
      </div>
    );
  }

  // Role Selection Screen
  if (step === 'role-selection') {
    return (
      <div className="min-h-screen bg-gradient-to-b from-background via-background to-dairy-cream flex flex-col">
        <div className="relative pt-4 pb-4 px-4">
          <button
            onClick={() => setStep('language-selection')}
            className="absolute left-4 top-4 w-9 h-9 rounded-xl bg-card border border-border/50 shadow-sm flex items-center justify-center hover:bg-muted transition-colors z-10"
          >
            <ArrowLeft className="w-4 h-4 text-foreground" />
          </button>
          <div className="text-center pt-2">
            {authPageImageUrl && (
              <div className="mb-2 relative mx-auto w-28 h-28">
                <img 
                  src={authPageImageUrl} 
                  alt="Dairy" 
                  className="w-full h-full object-contain rounded-2xl animate-bounce-gentle"
                />
              </div>
            )}
            {!authPageImageUrl && (
              <div className="flex justify-center mb-2">
                <div className="w-12 h-12 bg-gradient-to-br from-primary to-primary/80 rounded-xl flex items-center justify-center shadow-lg shadow-primary/20 animate-bounce-gentle">
                  <Droplets className="w-6 h-6 text-primary-foreground" />
                </div>
              </div>
            )}
            <h1 className="text-xl font-bold">{t('appName')}</h1>
            <p className="text-sm text-muted-foreground mt-1">
              {language === 'hi'
                ? 'दूध संग्रह, फैट/SNF दर गणना और भुगतान ट्रैकिंग'
                : language === 'gu'
                ? 'દૂધ સંગ્રહ, ફેટ/SNF દર ગણતરી અને ચુકવણી ટ્રેકિંગ'
                : 'Milk collection, fat/SNF rate calculation and payment tracking'}
            </p>
            <p className="text-sm text-muted-foreground mt-0.5">
              {language === 'hi' ? 'आप कौन हैं?' : language === 'gu' ? 'તમે કોણ છો?' : 'Who are you?'}
            </p>

          </div>
        </div>

        <div className="flex-1 px-4 py-2">
          <div className="max-w-md mx-auto space-y-3 animate-slide-up">
            {/* Dairy Owner Card */}
            <button
              onClick={() => handleRoleSelect('owner')}
              className="w-full dairy-card p-0 overflow-hidden hover:shadow-xl active:scale-[0.98] transition-all duration-300 border-2 border-transparent hover:border-primary/30 group"
            >
              <div className="flex">
                <div className="w-22 h-24 flex-shrink-0 overflow-hidden" style={{width: '88px', height: '96px'}}>
                  <img 
                    src={farmerImage} 
                    alt="Dairy Owner" 
                    width="88"
                    height="96"
                    loading="lazy"
                    decoding="async"
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                  />
                </div>
                <div className="flex-1 p-3 flex flex-col justify-center">
                  <div className="flex items-center gap-1.5 mb-0.5">
                    <span className="text-xl">👨‍🌾</span>
                    <h3 className="text-lg font-bold text-foreground">
                      {language === 'hi' ? 'डेयरी मालिक' : language === 'gu' ? 'ડેરી માલિક' : 'Dairy Owner'}
                    </h3>
                  </div>
                  <p className="text-xs text-muted-foreground">
                    {language === 'hi' ? 'डेयरी बनाएं और ग्राहक जोड़ें' : language === 'gu' ? 'ડેરી બનાવો અને ગ્રાહક ઉમેરો' : 'Create dairy and add customers'}
                  </p>
                </div>
                <div className="flex items-center pr-3">
                  <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center group-hover:bg-primary group-hover:text-primary-foreground transition-all">
                    <span className="text-sm">→</span>
                  </div>
                </div>
              </div>
            </button>

            {/* Customer Card */}
            <button
              onClick={() => handleRoleSelect('supplier')}
              className="w-full dairy-card p-0 overflow-hidden hover:shadow-xl active:scale-[0.98] transition-all duration-300 border-2 border-transparent hover:border-accent/30 group"
            >
              <div className="flex">
                <div className="w-22 h-24 flex-shrink-0 overflow-hidden" style={{width: '88px', height: '96px'}}>
                  <img 
                    src={cowImage} 
                    alt="Customer" 
                    width="88"
                    height="96"
                    loading="lazy"
                    decoding="async"
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                  />
                </div>
                <div className="flex-1 p-3 flex flex-col justify-center">
                  <div className="flex items-center gap-1.5 mb-0.5">
                    <span className="text-xl">🐄</span>
                    <h3 className="text-lg font-bold text-foreground">
                      {language === 'hi' ? 'ग्राहक' : language === 'gu' ? 'ગ્રાહક' : 'Customer'}
                    </h3>
                  </div>
                  <p className="text-xs text-muted-foreground">
                    {language === 'hi' ? 'डेयरी से जुड़ें और अपना कार्ड देखें' : language === 'gu' ? 'ડેરી સાથે જોડાવ અને તમારું કાર્ડ જુઓ' : 'Join dairy and view your card'}
                  </p>
                </div>
                <div className="flex items-center pr-3">
                  <div className="w-8 h-8 rounded-full bg-accent/10 flex items-center justify-center group-hover:bg-accent group-hover:text-accent-foreground transition-all">
                    <span className="text-sm">→</span>
                  </div>
                </div>
              </div>
            </button>
          </div>

          <div className="max-w-md mx-auto mt-4 text-center animate-fade-in" style={{ animationDelay: '300ms' }}>
            <div className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-primary/8 rounded-full">
              <span className="text-sm">🥛</span>
              <span className="text-xs text-muted-foreground">
                {language === 'hi' ? 'सही विकल्प चुनें' : language === 'gu' ? 'યોગ્ય વિકલ્પ પસંદ કરો' : 'Choose the right option'}
              </span>
          </div>
        </div>

        <div className="pb-4 text-center">
          <Link
            to="/privacy-policy"
            className="text-xs text-muted-foreground hover:text-foreground underline underline-offset-2"
          >
            {language === 'hi' ? 'गोपनीयता नीति' : language === 'gu' ? 'ગોપનીયતા નીતિ' : 'Privacy Policy'}
          </Link>
        </div>
      </div>
    </div>
  );
}

// Auth Form Screen

  return (
    <div className="min-h-screen bg-gradient-to-b from-background via-background to-dairy-cream flex flex-col">
      <div className="relative pt-4 pb-3 px-4">
        <button
          onClick={handleBack}
          className="absolute left-4 top-4 w-9 h-9 rounded-xl bg-card border border-border/50 shadow-sm flex items-center justify-center hover:bg-muted transition-colors"
        >
          <ArrowLeft className="w-4 h-4 text-foreground" />
        </button>
        
        <div className="text-center pt-6">
          {authPageImageUrl ? (
            <div className="mb-2 relative mx-auto w-28 h-28">
              <img 
                src={authPageImageUrl} 
                alt="Dairy" 
                className="w-full h-full object-contain rounded-2xl animate-bounce-gentle"
              />
            </div>
          ) : (
            <div className="flex justify-center mb-2">
              <div className="w-12 h-12 bg-gradient-to-br from-primary to-primary/80 rounded-xl flex items-center justify-center shadow-lg shadow-primary/20">
                <Droplets className="w-6 h-6 text-primary-foreground" />
              </div>
            </div>
          )}
          <h1 className="text-xl font-bold">{t('appName')}</h1>
          <p className="text-sm text-muted-foreground mt-1">
            {language === 'hi'
              ? 'दूध संग्रह, फैट/SNF दर गणना और भुगतान ट्रैकिंग'
              : language === 'gu'
              ? 'દૂધ સંગ્રહ, ફેટ/SNF દર ગણતરી અને ચુકવણી ટ્રેકિંગ'
              : 'Milk collection, fat/SNF rate calculation and payment tracking'}
          </p>
          <div className="flex items-center justify-center gap-1.5 mt-1">
            <span className="text-lg">{role === 'owner' ? '👨‍🌾' : '🐄'}</span>
            <span className="text-sm text-muted-foreground">
              {role === 'owner' 
                ? (language === 'hi' ? 'डेयरी मालिक' : 'Dairy Owner')
                : (language === 'hi' ? 'ग्राहक' : 'Customer')}
            </span>
          </div>

        </div>
      </div>

      <div className="flex-1 px-4 pb-4">
        <div className="dairy-card max-w-md mx-auto animate-slide-up p-4">

          {/* Google Sign-In — the only sign-in method */}
          <Button
            type="button"
            variant="outline"
            onClick={handleGoogleSignIn}
            disabled={isGoogleLoading || isLoading}
            className="w-full h-11 text-base font-semibold gap-2 rounded-xl border-border/60 bg-card hover:bg-muted"
          >
            {isGoogleLoading ? (
              <span className="flex items-center gap-2">
                <span className="w-5 h-5 border-2 border-primary/30 border-t-primary rounded-full animate-spin" />
                {language === 'hi' ? 'प्रतीक्षा करें...' : 'Please wait...'}
              </span>
            ) : (
              <>
                <GoogleIcon />
                {language === 'hi' ? 'Google से साइन इन करें' : language === 'gu' ? 'Google થી સાઇન ઇન કરો' : 'Sign in with Google'}
              </>
            )}
          </Button>

          <p className="text-xs text-muted-foreground text-center mt-3">
            {language === 'hi'
              ? 'सुरक्षित साइन इन — कोई पासवर्ड याद रखने की जरूरत नहीं'
              : language === 'gu'
              ? 'સુરક્ષિત સાઇન ઇન — પાસવર્ડ યાદ રાખવાની જરૂર નથી'
              : 'Secure sign-in — no password to remember'}
          </p>

        </div>

        <div className="max-w-md mx-auto mt-4 text-center">
          <Link
            to="/privacy-policy"
            className="text-xs text-muted-foreground hover:text-foreground underline underline-offset-2"
          >
            {language === 'hi' ? 'गोपनीयता नीति' : language === 'gu' ? 'ગોપનીયતા નીતિ' : 'Privacy Policy'}
          </Link>
        </div>
      </div>
    </div>
  );
};

export default Auth;


import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { ArrowLeft, Settings, CreditCard, RefreshCw, Users, Clock, Edit3, Ban } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/integrations/supabase/client';
import { fetchAllRows } from '@/lib/supabasePagination';
import { toast } from 'sonner';
import { validateImageFile, imageValidationMessage } from '@/lib/imageValidation';
import {
  readAdminCache, writeAdminCache, clearAdminDelta,
  readAdminObject, writeAdminObject,
} from '@/lib/adminCache';

const CACHE_SETTINGS = 'subscription_settings';
const CACHE_SUBS = 'subscriptions_admin';

interface SubscriptionSettings {
  id: string;
  monthly_price: number;
  upi_id: string;
  qr_code_url: string | null;
  admin_phone: string;
  default_validity_days: number;
  auth_page_image_url: string | null;
  demo_days?: number;
  youtube_url?: string | null;
}

interface Subscription {
  id: string;
  dairy_id: string;
  status: string;
  started_at: string | null;
  expires_at: string | null;
  created_at: string;
  dairy_name?: string;
}

const AdminSubscriptions: React.FC = () => {
  const { user } = useAuth();
  const navigate = useNavigate();
  const cachedSettings = readAdminObject<SubscriptionSettings>(CACHE_SETTINGS);
  const [settings, setSettings] = useState<SubscriptionSettings | null>(cachedSettings);
  const [subscriptions, setSubscriptions] = useState<Subscription[]>(
    () => readAdminCache<Subscription>(CACHE_SUBS) ?? []
  );
  const [loading, setLoading] = useState(() => !cachedSettings);
  const [syncing, setSyncing] = useState(false);
  const [saving, setSaving] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [activeTab, setActiveTab] = useState<string>('settings');
  const [qrSignedUrl, setQrSignedUrl] = useState<string | null>(null);
  const [subView, setSubView] = useState<'active' | 'expired'>('active');
  const [expiredRange, setExpiredRange] = useState<string>('all');

  useEffect(() => {
    const signQr = async () => {
      if (!settings?.qr_code_url) { setQrSignedUrl(null); return; }
      const marker = '/object/';
      const idx = settings.qr_code_url.indexOf(marker);
      if (idx === -1) { setQrSignedUrl(settings.qr_code_url); return; }
      const rest = settings.qr_code_url.slice(idx + marker.length).split('/');
      const path = rest.slice(2).join('/').split('?')[0];
      const { data } = await supabase.storage.from('qr-codes').createSignedUrl(path, 3600);
      setQrSignedUrl(data?.signedUrl || null);
    };
    signQr();
  }, [settings?.qr_code_url]);

  // Form state
  const [monthlyPrice, setMonthlyPrice] = useState(cachedSettings?.monthly_price?.toString() ?? '');
  const [upiId, setUpiId] = useState(cachedSettings?.upi_id ?? '');
  const [adminPhone, setAdminPhone] = useState(cachedSettings?.admin_phone ?? '');
  const [youtubeUrl, setYoutubeUrl] = useState(cachedSettings?.youtube_url ?? '');
  const [defaultValidityDays, setDefaultValidityDays] = useState(
    cachedSettings?.default_validity_days?.toString() ?? '30'
  );
  const [defaultValidityPreset, setDefaultValidityPreset] = useState(() => {
    const d = cachedSettings?.default_validity_days?.toString() ?? '30';
    return ['1', '7', '15', '30', '90', '180', '365'].includes(d) ? d : 'custom';
  });
  const [demoDays, setDemoDays] = useState(cachedSettings?.demo_days?.toString() ?? '9');

  useEffect(() => {
    fetchData();
  }, []);

  /**
   * Cache-only load. Subscriptions sirf admin hi manage karta hai, isliye koi
   * background delta-check nahi — cache khaali ho (ya manual force refresh) tabhi
   * ek full fetch hota hai. Mutations cache ko locally patch karte hain.
   */
  const refreshSubscriptions = async (force = false) => {
    const cached = force ? null : readAdminCache<Subscription>(CACHE_SUBS);
    if (cached && cached.length > 0) {
      setSubscriptions(cached);
      return;
    }

    clearAdminDelta(CACHE_SUBS);
    const { data, error } = await supabase
      .from('subscriptions')
      .select('*')
      .order('created_at', { ascending: false });
    if (error) throw error;
    const rows = (data as Subscription[]) || [];

    let merged = rows;
    if (rows.length > 0) {
      const { data: dairies } = await supabase
        .from('dairies')
        .select('id, name')
        .in('id', Array.from(new Set(rows.map(r => r.dairy_id))));
      const dairyMap = new Map(dairies?.map(d => [d.id, d.name]));
      merged = rows.map(r => ({ ...r, dairy_name: dairyMap.get(r.dairy_id) || r.dairy_name || 'Unknown' }));
    }
    merged = [...merged].sort((a, b) => (a.created_at < b.created_at ? 1 : -1));
    setSubscriptions(merged);
    writeAdminCache(CACHE_SUBS, merged);
  };


  const applySettings = (settingsData: any) => {
    if (!settingsData) return;
    setSettings(settingsData);
    writeAdminObject(CACHE_SETTINGS, settingsData);
    setMonthlyPrice(settingsData.monthly_price?.toString() || '');
    setUpiId(settingsData.upi_id || '');
    setAdminPhone(settingsData.admin_phone || '');
    setYoutubeUrl(settingsData.youtube_url || '');
    const days = settingsData.default_validity_days?.toString() || '30';
    setDefaultValidityDays(days);
    setDefaultValidityPreset(['1', '7', '15', '30', '90', '180', '365'].includes(days) ? days : 'custom');
    setDemoDays(settingsData.demo_days?.toString() || '9');
  };

  const refreshSettings = async () => {
    const { data } = await supabase.rpc('get_subscription_settings_admin');
    const row: any = Array.isArray(data) ? data[0] : data;
    if (row) applySettings(row);
  };


  const fetchData = async (force = false) => {
    setSyncing(true);
    try {
      // subscription_settings: purely admin-controlled → cache-only (pehli baar / force par hi).
      // subscriptions: dairy owner ke payment/demo se bhi badalti hai → delta-sync chalu.
      const needSettings = force || !readAdminObject(CACHE_SETTINGS);
      await Promise.all([
        needSettings ? refreshSettings() : Promise.resolve(),
        refreshSubscriptions(force),
      ]);
    } catch (error) {
      console.error('Error fetching data:', error);
    } finally {
      setLoading(false);
      setSyncing(false);
    }
  };


  const saveSettings = async () => {
    setSaving(true);
    try {
      const { error } = await supabase.rpc('admin_save_subscription_settings' as any, {
        p_patch: {
          monthly_price: parseFloat(monthlyPrice) || 100,
          upi_id: upiId,
          admin_phone: adminPhone,
          youtube_url: youtubeUrl.trim(),
          default_validity_days: parseInt(defaultValidityDays) || 30,
          demo_days: parseInt(demoDays) || 9,
        },
      });
      if (error) throw error;

      toast.success('Settings saved');
      await refreshSettings();
    } catch (error) {
      console.error('Error saving:', error);
      toast.error('Failed to save');
    } finally {
      setSaving(false);
    }
  };


  const uploadQRCode = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file || !settings?.id) return;

    const validation = await validateImageFile(file);
    if (!validation.ok) {
      toast.error(imageValidationMessage(validation.error));
      e.target.value = '';
      return;
    }

    setUploading(true);
    try {
      const fileName = validation.image!.buildFileName('qr-code');

      const { error: uploadError } = await supabase.storage
        .from('qr-codes')
        .upload(fileName, file, { contentType: validation.image!.type, upsert: false });

      if (uploadError) throw uploadError;

      const { data: { publicUrl } } = supabase.storage
        .from('qr-codes')
        .getPublicUrl(fileName);

      const { error: updateError } = await supabase.rpc('admin_save_subscription_settings' as any, {
        p_patch: { qr_code_url: publicUrl },
      });


      if (updateError) throw updateError;
      toast.success('QR Code uploaded');
      await refreshSettings();
    } catch (error) {
      console.error('Upload error:', error);
      toast.error('Failed to upload');
    } finally {
      setUploading(false);
      e.target.value = '';
    }
  };

  const handleDefaultValidityPresetChange = (value: string) => {
    setDefaultValidityPreset(value);
    if (value !== 'custom') {
      setDefaultValidityDays(value);
    }
  };


  const banDairy = async (dairyId: string, dairyName: string) => {
    if (!confirm(`Are you sure you want to PERMANENTLY BAN "${dairyName}"? This will set expiry to past and mark as banned.`)) {
      return;
    }

    const bannedExpiry = new Date('2000-01-01').toISOString();
    const snapshot = subscriptions;
    setSubscriptions(prev => prev.map(s => s.dairy_id === dairyId ? { ...s, status: 'banned', expires_at: bannedExpiry } : s));
    try {
      const { error } = await supabase
        .from('subscriptions')
        .update({
          status: 'banned',
          expires_at: bannedExpiry
        })
        .eq('dairy_id', dairyId);

      if (error) throw error;
      setSubscriptions(prev => {
        writeAdminCache(CACHE_SUBS, prev);
        return prev;
      });
      toast.success(`${dairyName} has been banned permanently`);
    } catch (error) {
      console.error('Error banning dairy:', error);
      toast.error('Failed to ban dairy');
      setSubscriptions(snapshot);
    }
  };

  const extendSubscriptionByMonths = async (dairyId: string, dairyName: string, months: number) => {
    const sub = subscriptions.find(s => s.dairy_id === dairyId);
    const currentExpiry = sub?.expires_at ? new Date(sub.expires_at) : new Date();
    const newExpiry = new Date(Math.max(currentExpiry.getTime(), Date.now()));
    newExpiry.setMonth(newExpiry.getMonth() + months);
    const iso = newExpiry.toISOString();
    const snapshot = subscriptions;
    setSubscriptions(prev => prev.map(s => s.dairy_id === dairyId ? { ...s, status: 'active', expires_at: iso } : s));
    try {
      const { error } = await supabase
        .from('subscriptions')
        .update({ status: 'active', expires_at: iso })
        .eq('dairy_id', dairyId);

      if (error) throw error;
      setSubscriptions(prev => {
        writeAdminCache(CACHE_SUBS, prev);
        return prev;
      });
      toast.success(`${dairyName} extended by ${months} month(s)`);
    } catch (error) {
      console.error('Error extending subscription:', error);
      toast.error('Failed to extend subscription');
      setSubscriptions(snapshot);
    }
  };

  const extendSubscription = async (dairyId: string, dairyName: string, days: number) => {
    const sub = subscriptions.find(s => s.dairy_id === dairyId);
    const currentExpiry = sub?.expires_at ? new Date(sub.expires_at) : new Date();
    const newExpiry = new Date(Math.max(currentExpiry.getTime(), Date.now()));
    newExpiry.setDate(newExpiry.getDate() + days);
    const iso = newExpiry.toISOString();
    const snapshot = subscriptions;
    setSubscriptions(prev => prev.map(s => s.dairy_id === dairyId ? { ...s, status: 'active', expires_at: iso } : s));
    try {
      const { error } = await supabase
        .from('subscriptions')
        .update({ status: 'active', expires_at: iso })
        .eq('dairy_id', dairyId);

      if (error) throw error;
      setSubscriptions(prev => {
        writeAdminCache(CACHE_SUBS, prev);
        return prev;
      });
      toast.success(`${dairyName} extended by ${days} days`);
    } catch (error) {
      console.error('Error extending subscription:', error);
      toast.error('Failed to extend subscription');
      setSubscriptions(snapshot);
    }
  };

  /** Real status — DB me status 'active' reh sakta hai jabki expires_at nikal chuki ho. */
  const effectiveStatus = (sub: Subscription) => {
    if (sub.status === 'banned') return 'banned';
    if (sub.expires_at && new Date(sub.expires_at).getTime() < Date.now()) return 'expired';
    return sub.status;
  };

  const expiredSubs = subscriptions.filter(s => effectiveStatus(s) === 'expired');
  const activeSubs = subscriptions.filter(s => effectiveStatus(s) !== 'expired');
  const monthsAgo = (n: number) => {
    const d = new Date();
    d.setMonth(d.getMonth() - n);
    return d.getTime();
  };
  const visibleSubs = subView === 'active'
    ? activeSubs
    : expiredRange === 'all'
      ? expiredSubs
      : expiredSubs.filter(s =>
          s.expires_at ? new Date(s.expires_at).getTime() >= monthsAgo(parseInt(expiredRange)) : false
        );

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <div className="w-12 h-12 border-4 border-primary border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="dairy-header px-4 py-4">
        <div className="flex items-center gap-3">
          <Button
            variant="ghost"
            size="icon"
            onClick={() => navigate('/admin')}
            className="text-primary-foreground hover:bg-primary-foreground/20"
          >
            <ArrowLeft className="h-5 w-5" />
          </Button>
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-primary-foreground/20 rounded-full flex items-center justify-center">
              <CreditCard className="w-5 h-5" />
            </div>
            <div>
              <h1 className="text-xl font-bold">Subscription Management</h1>
              <p className="text-primary-foreground/70 text-sm">Manage payments & subscriptions</p>
            </div>
          </div>
        </div>
      </header>

      <main className="px-4 py-6 max-w-2xl mx-auto">
        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="settings" className="gap-1 text-xs">
              <Settings className="h-3 w-3" />
              Settings
            </TabsTrigger>
            <TabsTrigger value="subscriptions" className="gap-1 text-xs">
              <Users className="h-3 w-3" />
              Active
            </TabsTrigger>
          </TabsList>

          {/* Settings Tab */}
          <TabsContent value="settings" className="space-y-4 mt-4">
            <div className="dairy-card space-y-4">
              <h3 className="font-semibold">Payment Settings</h3>

              <div className="space-y-2">
                <Label>UPI ID</Label>
                <Input
                  type="text"
                  value={upiId}
                  onChange={(e) => setUpiId(e.target.value)}
                  placeholder="yourname@upi"
                />
              </div>

              <div className="space-y-2">
                <Label>Admin Phone (with country code)</Label>
                <Input
                  type="text"
                  value={adminPhone}
                  onChange={(e) => setAdminPhone(e.target.value)}
                  placeholder="919876543210"
                />
                <p className="text-xs text-muted-foreground">Owner ke WhatsApp button me yahi number use hoga</p>
              </div>

              <div className="space-y-2">
                <Label>YouTube Video Link (help video)</Label>
                <Input
                  type="text"
                  value={youtubeUrl}
                  onChange={(e) => setYoutubeUrl(e.target.value)}
                  placeholder="https://www.youtube.com/watch?v=XXXXXXXXXXX"
                />
                <p className="text-xs text-muted-foreground">
                  Ye video thumbnail ke saath owner ko subscription page par aur har page par niche-right corner me dikhega. Khali chhodne par kahi nahi dikhega.
                </p>
              </div>


              <div className="space-y-2">
                <Label>QR Code</Label>
                {settings?.qr_code_url && qrSignedUrl && (
                  <img 
                    src={qrSignedUrl} 
                    alt="QR Code" 
                    className="w-32 h-32 border rounded-lg mb-2"
                  />
                )}
                <Input
                  type="file"
                  accept="image/*"
                  onChange={uploadQRCode}
                  disabled={uploading}
                />
                {uploading && <p className="text-sm text-muted-foreground">Uploading...</p>}
              </div>

              {/* Auth Page Image Upload */}
              <div className="space-y-2">
                <Label>Auth Page Image (above डेयरी प्रबंधक)</Label>
                <p className="text-xs text-muted-foreground">This image will animate on the role selection page</p>
                {settings?.auth_page_image_url && (
                  <img 
                    src={settings.auth_page_image_url} 
                    alt="Auth Page Image" 
                    className="w-24 h-24 border rounded-lg mb-2 object-contain"
                  />
                )}
                <Input
                  type="file"
                  accept="image/*"
                  onChange={async (e) => {
                    const file = e.target.files?.[0];
                    if (!file || !settings?.id) return;
                    const validation = await validateImageFile(file);
                    if (!validation.ok) {
                      toast.error(imageValidationMessage(validation.error));
                      e.target.value = '';
                      return;
                    }
                    setUploading(true);
                    try {
                      const fileName = validation.image!.buildFileName('auth-image');
                      const { error: uploadError } = await supabase.storage
                        .from('auth-images')
                        .upload(fileName, file, { contentType: validation.image!.type, upsert: false });
                      if (uploadError) throw uploadError;
                      const { data: { publicUrl } } = supabase.storage
                        .from('auth-images')
                        .getPublicUrl(fileName);
                      const { error: updateError } = await supabase.rpc('admin_save_subscription_settings' as any, {
                        p_patch: { auth_page_image_url: publicUrl },
                      });

                      if (updateError) throw updateError;
                      toast.success('Auth page image uploaded');
                      await refreshSettings();
                    } catch (error) {
                      console.error('Upload error:', error);
                      toast.error('Failed to upload');
                    } finally {
                      setUploading(false);
                      e.target.value = '';
                    }
                  }}
                  disabled={uploading}
                />
              </div>

              <div className="space-y-2">
                <Label>Demo Days (Free Trial)</Label>
                <Input
                  type="number"
                  value={demoDays}
                  onChange={(e) => setDemoDays(e.target.value)}
                  placeholder="9"
                  min="1"
                />
                <p className="text-xs text-muted-foreground">New users ko kitne din ka free demo milega</p>
              </div>

              <Button 
                onClick={saveSettings} 
                disabled={saving}
                className="w-full"
              >
                {saving ? 'Saving...' : 'Save Settings'}
              </Button>
            </div>
          </TabsContent>

          {/* Subscriptions Tab */}
          <TabsContent value="subscriptions" className="space-y-4 mt-4">
            <div className="dairy-card">
              <div className="flex items-center justify-between mb-4">
                <h3 className="font-semibold">
                  {subView === 'active' ? 'Active Subscriptions' : 'Expired Subscriptions'}
                </h3>
                <Button variant="outline" size="sm" onClick={() => fetchData(true)} disabled={syncing}>
                  <RefreshCw className={`h-4 w-4 ${syncing ? 'animate-spin' : ''}`} />
                </Button>
              </div>

              <div className="flex flex-wrap items-center gap-2 mb-4">
                <Button
                  variant={subView === 'active' ? 'default' : 'outline'}
                  size="sm"
                  className="text-xs"
                  onClick={() => setSubView('active')}
                >
                  Active ({activeSubs.length})
                </Button>
                <Button
                  variant={subView === 'expired' ? 'default' : 'outline'}
                  size="sm"
                  className="text-xs"
                  onClick={() => setSubView('expired')}
                >
                  Expired ({expiredSubs.length})
                </Button>
                {subView === 'expired' && (
                  <Select value={expiredRange} onValueChange={setExpiredRange}>
                    <SelectTrigger className="h-8 w-[180px] text-xs">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All expired</SelectItem>
                      <SelectItem value="1">Expired in last 1 month</SelectItem>
                      <SelectItem value="2">Expired in last 2 months</SelectItem>
                      <SelectItem value="3">Expired in last 3 months</SelectItem>
                      <SelectItem value="6">Expired in last 6 months</SelectItem>
                    </SelectContent>
                  </Select>
                )}
              </div>

              {visibleSubs.length === 0 ? (
                <p className="text-muted-foreground text-sm">
                  {subView === 'active' ? 'No active subscriptions' : 'No expired subscriptions in this range'}
                </p>
              ) : (
                <div className="space-y-3">
                  {visibleSubs.map(sub => (
                    <div key={sub.id} className="p-3 bg-muted/50 rounded-lg space-y-2">
                      <div className="flex items-center justify-between">
                        <div>
                          <p className="font-medium">{sub.dairy_name}</p>
                          <p className="text-xs text-muted-foreground">
                            Expires: {sub.expires_at ? new Date(sub.expires_at).toLocaleDateString() : 'N/A'}
                          </p>
                        </div>
                        <span className={`px-2 py-1 rounded text-xs font-medium ${
                          effectiveStatus(sub) === 'active' ? 'bg-green-100 text-green-700' :
                          effectiveStatus(sub) === 'banned' ? 'bg-black text-white' :
                          effectiveStatus(sub) === 'expired' ? 'bg-red-100 text-red-700' :
                          'bg-yellow-100 text-yellow-700'
                        }`}>
                          {effectiveStatus(sub)}
                        </span>
                      </div>
                      
                      {/* Admin Actions */}
                      <div className="flex flex-wrap gap-2 pt-2 border-t border-muted">
                        <Button
                          variant="outline"
                          size="sm"
                          className="text-xs gap-1"
                          onClick={() => extendSubscriptionByMonths(sub.dairy_id, sub.dairy_name || '', 1)}
                        >
                          <Clock className="h-3 w-3" />
                          +1 Month
                        </Button>
                        <Button
                          variant="outline"
                          size="sm"
                          className="text-xs gap-1"
                          onClick={() => extendSubscriptionByMonths(sub.dairy_id, sub.dairy_name || '', 6)}
                        >
                          <Clock className="h-3 w-3" />
                          +6 Months
                        </Button>
                        <Button
                          variant="outline"
                          size="sm"
                          className="text-xs gap-1"
                          onClick={() => extendSubscriptionByMonths(sub.dairy_id, sub.dairy_name || '', 12)}
                        >
                          <Clock className="h-3 w-3" />
                          +1 Year
                        </Button>
                        {effectiveStatus(sub) !== 'banned' && (
                          <Button
                            variant="destructive"
                            size="sm"
                            className="text-xs gap-1"
                            onClick={() => banDairy(sub.dairy_id, sub.dairy_name || '')}
                          >
                            <Ban className="h-3 w-3" />
                            Ban Permanently
                          </Button>
                        )}
                      </div>
                      
                      {/* Custom Days Extension */}
                      <div className="flex items-center gap-2 pt-2">
                        <Input
                          type="number"
                          placeholder="Days (+/-)"
                          className="w-24 h-8 text-xs"
                          id={`custom-days-${sub.dairy_id}`}
                        />
                        <Button
                          variant="secondary"
                          size="sm"
                          className="text-xs gap-1"
                          onClick={() => {
                            const input = document.getElementById(`custom-days-${sub.dairy_id}`) as HTMLInputElement;
                            const days = parseInt(input?.value || '0');
                            if (days !== 0) {
                              extendSubscription(sub.dairy_id, sub.dairy_name || '', days);
                              input.value = '';
                            }
                          }}
                        >
                          Apply Custom Days
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </TabsContent>
        </Tabs>
      </main>
    </div>
  );
};

export default AdminSubscriptions;

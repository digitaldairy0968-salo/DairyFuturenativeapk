import React, { useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { ArrowLeft, Wallet, ShieldCheck } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useLanguage } from '@/contexts/LanguageContext';
import { useSettingsBootstrap } from '@/lib/settingsBootstrap';
import { durationLabel } from '@/components/PlanCards';
import { startUpiPayment, orderErrorMessage } from '@/lib/payments';
import { toast } from 'sonner';

/** Step 2 of the purchase flow: instructions + a single Pay button. */
const Checkout: React.FC = () => {
  const { planId } = useParams<{ planId: string }>();
  const { language } = useLanguage();
  const hi = language === 'hi';
  const navigate = useNavigate();
  const { data: boot } = useSettingsBootstrap();
  const [loadingPay, setLoadingPay] = useState(false);

  const option = (boot?.variety_plans ?? []).find((v: any) => v.id === planId) ?? null;
  const plan = (boot?.varieties ?? []).find((p: any) => p.id === option?.variety_id) ?? null;

  const pay = async () => {
    if (!option) return;
    setLoadingPay(true);
    try {
      const id = await startUpiPayment(option.id);
      navigate(`/pay/${id}`);
    } catch (e: any) {
      toast.error(orderErrorMessage(e?.message ?? '', hi));
    } finally {
      setLoadingPay(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-background to-muted/30">
      <div className="bg-gradient-to-br from-primary via-primary/90 to-accent/80 px-4 py-5">
        <div className="flex items-center gap-3">
          <Button variant="ghost" size="icon" onClick={() => navigate(-1)} className="text-primary-foreground hover:bg-primary-foreground/20">
            <ArrowLeft className="h-5 w-5" />
          </Button>
          <h1 className="text-xl font-bold text-primary-foreground">
            {hi ? 'भुगतान' : 'Payment'}
          </h1>
        </div>
      </div>

      <main className="px-4 py-6 max-w-md mx-auto space-y-4">
        {!option ? (
          <p className="text-center text-sm text-muted-foreground py-10">
            {hi ? 'प्लान नहीं मिला' : 'Plan not found'}
          </p>
        ) : (
          <>
            <div className="bg-card rounded-3xl border-2 border-primary/30 p-5">
              <p className="text-xs text-muted-foreground mb-1">{hi ? 'चुना हुआ प्लान' : 'Selected plan'}</p>
              <div className="flex items-center justify-between">
                <div>
                  <p className="font-bold text-lg text-foreground">{plan?.name ?? '-'}</p>
                  <p className="text-sm text-muted-foreground">
                    {durationLabel(Number(option.validity_days) || 0, hi)}
                  </p>
                </div>
                <p className="text-3xl font-black text-primary">₹{option.price}</p>
              </div>
            </div>

            <div className="bg-amber-50 dark:bg-amber-950/20 border-2 border-amber-200 dark:border-amber-800 rounded-2xl p-4">
              <p className="font-bold text-amber-800 dark:text-amber-300 mb-2 text-sm">
                {hi ? '📋 निर्देश:' : '📋 Instructions:'}
              </p>
              <ol className="space-y-1.5 text-sm text-amber-900 dark:text-amber-200 list-decimal list-inside">
                <li>{hi ? '"पेमेंट करें" पर क्लिक करें — UPI ऐप खुलेगा' : 'Tap "Pay Now" — your UPI app opens'}</li>
                <li>{hi ? 'भुगतान पूरा करें' : 'Complete the payment'}</li>
                <li>{hi ? 'वापस आकर UTR / ट्रांज़ैक्शन ID डालें' : 'Come back and enter the UTR / transaction ID'}</li>
                <li>{hi ? 'मैच होने पर प्लान तुरंत चालू' : 'Plan activates instantly on match'}</li>
              </ol>
            </div>

            <Button
              onClick={pay}
              disabled={loadingPay}
              className="w-full gap-2 h-14 rounded-2xl text-lg font-bold bg-gradient-to-r from-primary to-accent shadow-glow"
            >
              {loadingPay
                ? <div className="w-5 h-5 border-2 border-primary-foreground border-t-transparent rounded-full animate-spin" />
                : <><Wallet className="h-5 w-5" />{hi ? `पेमेंट करें ₹${option.price}` : `Pay Now ₹${option.price}`}</>}
            </Button>
            <p className="flex items-center justify-center gap-1.5 text-xs text-muted-foreground">
              <ShieldCheck className="h-3.5 w-3.5" />
              {hi ? 'UPI से सुरक्षित भुगतान' : 'Secure UPI payment'}
            </p>
          </>
        )}
      </main>
    </div>
  );
};

export default Checkout;

import React, { useState, useMemo, useEffect } from 'react';
import { Search, Plus, History, Wallet, ArrowDownCircle, ArrowUpCircle, Save } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { useLanguage } from '@/contexts/LanguageContext';
import { useDairy } from '@/contexts/DairyContext';
import { useAuth } from '@/contexts/AuthContext';
import { cn } from '@/lib/utils';
import { format } from 'date-fns';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import Header from '@/components/Header';
import BottomNav from '@/components/BottomNav';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';


interface PaymentHistoryEntry {
  id: string;
  transaction_date: string;
  amount_added: number;
  amount_paid: number;
  balance_after: number;
  notes: string | null;
  created_at: string;
}

const toNumber = (v: unknown) => {
  const n = typeof v === 'string' ? parseFloat(v) : Number(v);
  return Number.isFinite(n) ? n : 0;
};

const CustomerHistory: React.FC = () => {
  const { language } = useLanguage();
  const { suppliers, patchSupplierLocal, getSupplierPayments, upsertPaymentLocal, loading: dairyLoading, syncPaymentHistoryDelta } = useDairy();
  const { user } = useAuth();
  const { toast } = useToast();
  

  const [searchCode, setSearchCode] = useState('');
  const [searchType, setSearchType] = useState<'code' | 'name'>('code');
  const [selectedSupplierId, setSelectedSupplierId] = useState<string>('');
  const [initialPendingAmount, setInitialPendingAmount] = useState<string>('');
  const [paidAmount, setPaidAmount] = useState<string>('');
  const [isSaving, setIsSaving] = useState(false);
  const [hasInitialBalance, setHasInitialBalance] = useState(false);


  // Debounced search term — while the owner is still typing, partial codes can
  // match different suppliers on every keystroke and each match would trigger a
  // payment_history fetch. Only settle 450ms after typing stops.
  const [debouncedCode, setDebouncedCode] = useState('');
  useEffect(() => {
    const t = setTimeout(() => setDebouncedCode(searchCode), 450);
    return () => clearTimeout(t);
  }, [searchCode]);

  // Find selected supplier (explicit dropdown pick is instant; typing is debounced)
  const selectedSupplier = useMemo(() => {
    if (selectedSupplierId) {
      return suppliers.find(s => s.id === selectedSupplierId);
    }
    if (debouncedCode.length >= 1) {
      if (searchType === 'code') {
        return suppliers.find(s => s.code === debouncedCode);
      } else {
        return suppliers.find(s => s.name.toLowerCase().includes(debouncedCode.toLowerCase()));
      }
    }
    return undefined;
  }, [suppliers, debouncedCode, selectedSupplierId, searchType]);

  // Only a selected customer triggers a payment_history network call, and it is
  // scoped to that customer (per-supplier delta watermark).
  useEffect(() => {
    const sid = selectedSupplier?.id;
    if (!sid) return;
    void syncPaymentHistoryDelta(sid);

    // On-demand fresh balance check for THIS supplier only. An app-user supplier
    // can confirm a payment from their own device (confirm_supplier_payment RPC
    // updates suppliers.pending_balance server-side), which the owner's in-memory
    // cache never learns about. One tiny targeted query keeps the shown balance
    // correct without resyncing the whole suppliers list.
    (async () => {
      try {
        const { data, error } = await supabase
          .from('suppliers')
          .select('pending_balance')
          .eq('id', sid)
          .maybeSingle();
        if (error || !data) return;
        patchSupplierLocal(sid, { pendingBalance: toNumber((data as any).pending_balance) });
      } catch { /* offline → keep cached balance */ }
    })();
  }, [selectedSupplier?.id, syncPaymentHistoryDelta, patchSupplierLocal]);

  // Filter suppliers for dropdown
  const filteredSuppliers = useMemo(() => {
    if (!searchCode) return suppliers;
    if (searchType === 'code') {
      return suppliers.filter(s => s.code?.includes(searchCode));
    } else {
      return suppliers.filter(s => s.name.toLowerCase().includes(searchCode.toLowerCase()));
    }
  }, [suppliers, searchCode, searchType]);

  // Payment history now comes from the app-wide DairyContext sync (one query for
  // all suppliers on first load, delta-only afterwards). Searching a supplier
  // never triggers a network call — it just filters what's already in memory.
  const historyRaw = useMemo<PaymentHistoryEntry[]>(
    () => (selectedSupplier ? (getSupplierPayments(selectedSupplier.id) as unknown as PaymentHistoryEntry[]) : []),
    [selectedSupplier, getSupplierPayments]
  );
  const isLoading = dairyLoading;
  const upsertHistoryLocal = upsertPaymentLocal as unknown as (row: PaymentHistoryEntry) => void;

  // Sort newest-first (transaction_date desc, then created_at desc)
  const history = useMemo(() => {
    return [...historyRaw].sort((a, b) => {
      const d = (b.transaction_date || '').localeCompare(a.transaction_date || '');
      if (d !== 0) return d;
      return (b.created_at || '').localeCompare(a.created_at || '');
    });
  }, [historyRaw]);

  // Pending balance comes straight from the cached suppliers list (source of
  // truth is kept in sync via DairyContext delta sync). No extra DB round-trip.
  const totalPendingBalance = useMemo(() => {
    if (!selectedSupplier) return 0;
    const supplierData = suppliers.find(s => s.id === selectedSupplier.id) ?? selectedSupplier;
    const raw =
      (supplierData as any)?.pendingBalance ??
      (supplierData as any)?.pending_balance ??
      0;
    return toNumber(raw);
  }, [selectedSupplier, suppliers]);

  // Calculate remaining after paid amount input
  const remainingAfterPayment = useMemo(() => {
    const paid = parseFloat(paidAmount) || 0;
    return totalPendingBalance - paid;
  }, [totalPendingBalance, paidAmount]);

  // Reset transient inputs when the selected supplier changes.
  useEffect(() => {
    setHasInitialBalance(false);
    setInitialPendingAmount('');
    setPaidAmount('');
  }, [selectedSupplier?.id]);

  // Update hasInitialBalance when history loads
  useEffect(() => {
    // "Initial" means: already started tracking this customer (balance may be negative too)
    setHasInitialBalance(history.length > 0 || totalPendingBalance !== 0);
  }, [history.length, totalPendingBalance]);


  const handleSelectSupplier = (supplierId: string) => {
    setSelectedSupplierId(supplierId);
    const supplier = suppliers.find(s => s.id === supplierId);
    if (supplier?.code) {
      setSearchCode(supplier.code);
    }
  };

  const handleSearchCodeChange = (value: string) => {
    setSearchCode(value);
    setSelectedSupplierId('');
  };

  // Set initial pending balance (one-time)
  const handleSetInitialBalance = async () => {
    if (!selectedSupplier || !user?.dairyId) return;

    const initial = parseFloat(initialPendingAmount) || 0;
    if (initial <= 0) {
      toast({
        title: language === 'hi' ? 'त्रुटि' : 'Error',
        description: language === 'hi' ? 'बकाया राशि दर्ज करें' : 'Enter pending amount',
        variant: 'destructive',
      });
      return;
    }

    setIsSaving(true);
    try {
      // Update supplier's pending balance
      const { error: supplierError } = await supabase
        .from('suppliers')
        .update({ pending_balance: initial })
        .eq('id', selectedSupplier.id);

      if (supplierError) throw supplierError;

      // Add initial balance entry to history (return the row so we can cache it)
      const { data: inserted, error: historyError } = await supabase
        .from('payment_history')
        .insert({
          dairy_id: user.dairyId,
          supplier_id: selectedSupplier.id,
          amount_added: initial,
          amount_paid: 0,
          balance_after: initial,
          notes: language === 'hi' ? 'प्रारंभिक बकाया' : 'Initial balance',
        })
        .select('*')
        .single();

      if (historyError) throw historyError;

      if (inserted) upsertHistoryLocal(inserted as PaymentHistoryEntry);
      patchSupplierLocal(selectedSupplier.id, { pendingBalance: initial });

      setHasInitialBalance(true);
      setInitialPendingAmount('');

      toast({
        title: language === 'hi' ? 'सफल' : 'Success',
        description: language === 'hi' ? 'बकाया राशि सेट हुई' : 'Pending amount set',
      });
    } catch (error) {
      console.error('Error setting initial balance:', error);
      toast({
        title: language === 'hi' ? 'त्रुटि' : 'Error',
        description: language === 'hi' ? 'सेव नहीं हो पाया' : 'Failed to save',
        variant: 'destructive',
      });
    } finally {
      setIsSaving(false);
    }
  };

  // Add payment to history - payment record is inserted with supplier_confirmed = null
  // It will only appear in supplier's history once they confirm
  const handleAddToHistory = async () => {
    if (!selectedSupplier || !user?.dairyId) return;

    const paid = parseFloat(paidAmount) || 0;
    if (paid <= 0) {
      toast({
        title: language === 'hi' ? 'त्रुटि' : 'Error',
        description: language === 'hi' ? 'भुगतान राशि दर्ज करें' : 'Enter paid amount',
        variant: 'destructive',
      });
      return;
    }

    // Use cached user_id from supplier list — no extra DB round-trip.
    const supplierIsAppUser = !!selectedSupplier.userId;

    setIsSaving(true);
    try {
      // For app users: don't subtract yet, balance stays same until confirmed
      // For non-app users: subtract immediately
      const newBalance = supplierIsAppUser ? totalPendingBalance : totalPendingBalance - paid;


      // Insert payment history record — return row so we can cache it locally.
      const { data: inserted, error: historyError } = await supabase
        .from('payment_history')
        .insert({
          dairy_id: user.dairyId,
          supplier_id: selectedSupplier.id,
          amount_added: 0,
          amount_paid: paid,
          balance_after: newBalance,
          notes: language === 'hi' ? 'भुगतान किया' : 'Payment made',
          supplier_confirmed: supplierIsAppUser ? null : true,
          confirmed_at: supplierIsAppUser ? null : new Date().toISOString(),
        })
        .select('*')
        .single();

      if (historyError) throw historyError;
      if (inserted) upsertHistoryLocal(inserted as PaymentHistoryEntry);

      // Only update supplier's pending balance immediately if NOT an app user.
      if (!supplierIsAppUser) {
        const { error: supplierError } = await supabase
          .from('suppliers')
          .update({ pending_balance: newBalance })
          .eq('id', selectedSupplier.id);

        if (supplierError) throw supplierError;
        patchSupplierLocal(selectedSupplier.id, { pendingBalance: newBalance });
      }

      setPaidAmount('');

      toast({
        title: language === 'hi' ? 'सफल' : 'Success',
        description: supplierIsAppUser 
          ? (language === 'hi' ? 'भुगतान की पुष्टि के लिए ग्राहक को भेजा गया' : 'Sent to customer for payment confirmation')
          : (language === 'hi' ? 'हिस्ट्री में जोड़ा गया' : 'Added to history'),
      });
    } catch (error) {
      console.error('Error adding to history:', error);
      toast({
        title: language === 'hi' ? 'त्रुटि' : 'Error',
        description: language === 'hi' ? 'सेव नहीं हो पाया' : 'Failed to save',
        variant: 'destructive',
      });
    } finally {
      setIsSaving(false);
    }
  };

  const labels = {
    title: language === 'hi' ? 'ग्राहक हिस्ट्री' : language === 'gu' ? 'ગ્રાહક હિસ્ટ્રી' : 'Customer History',
    searchByCode: language === 'hi' ? 'कोड' : language === 'gu' ? 'કોડ' : 'Code',
    searchByName: language === 'hi' ? 'नाम' : language === 'gu' ? 'નામ' : 'Name',
    selectFromList: language === 'hi' ? 'सूची से चुनें' : language === 'gu' ? 'યાદીમાંથી પસંદ કરો' : 'Select from list',
    bakayaRashi: language === 'hi' ? 'बकाया राशि (एक बार)' : language === 'gu' ? 'બાકી રકમ (એકવાર)' : 'Pending Amount (One-time)',
    paidAmount: language === 'hi' ? 'भुगतान राशि' : language === 'gu' ? 'ચુકવણી રકમ' : 'Paid Amount',
    addToHistory: language === 'hi' ? 'हिस्ट्री में जोड़ें' : language === 'gu' ? 'હિસ્ટ્રીમાં ઉમેરો' : 'Add to History',
    setInitialBalance: language === 'hi' ? 'सेट करें' : language === 'gu' ? 'સેટ કરો' : 'Set',
    transactionHistory: language === 'hi' ? 'लेन-देन हिस्ट्री' : language === 'gu' ? 'વ્યવહાર હિસ્ટ્રી' : 'Transaction History',
    date: language === 'hi' ? 'तारीख' : language === 'gu' ? 'તારીખ' : 'Date',
    added: language === 'hi' ? 'जोड़ा' : language === 'gu' ? 'ઉમેર્યું' : 'Added',
    paid: language === 'hi' ? 'भुगतान' : language === 'gu' ? 'ચુકવણી' : 'Paid',
    balance: language === 'hi' ? 'शेष' : language === 'gu' ? 'બાકી' : 'Balance',
    noHistory: language === 'hi' ? 'कोई हिस्ट्री नहीं' : language === 'gu' ? 'કોઈ હિસ્ટ્રી નથી' : 'No history',
    selectCustomer: language === 'hi' ? 'ग्राहक चुनें' : language === 'gu' ? 'ગ્રાહક પસંદ કરો' : 'Select a customer',
    totalPending: language === 'hi' ? 'कुल बकाया' : language === 'gu' ? 'કુલ બાકી' : 'Total Pending',
    remainingBalance: language === 'hi' ? 'बची हुई राशि' : language === 'gu' ? 'બાકી રકમ' : 'Remaining Balance',
    enterInitialFirst: language === 'hi' ? 'पहले बकाया राशि दर्ज करें' : language === 'gu' ? 'પહેલા બાકી રકમ દાખલ કરો' : 'Enter initial pending first',
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-background to-muted/30 pb-24">
      <Header />

      <main className="px-3 py-4 max-w-lg mx-auto">
        {/* Title */}
        <div className="flex items-center gap-3 mb-4">
          <div className="w-10 h-10 bg-primary/10 rounded-xl flex items-center justify-center">
            <History className="h-5 w-5 text-primary" />
          </div>
          <h1 className="text-xl font-bold text-foreground">{labels.title}</h1>
        </div>

        {/* Search Card */}
        <div className="bg-card rounded-2xl shadow-lg border border-border/50 p-4 mb-4 animate-fade-in">
          {/* Search Type Toggle */}
          <div className="flex bg-muted rounded-full p-0.5 mb-3">
            <button
              onClick={() => setSearchType('code')}
              className={cn(
                "flex-1 px-3 py-2 rounded-full text-sm font-medium transition-all duration-200",
                searchType === 'code'
                  ? "bg-primary text-primary-foreground shadow-md"
                  : "text-muted-foreground hover:text-foreground"
              )}
            >
              {labels.searchByCode}
            </button>
            <button
              onClick={() => setSearchType('name')}
              className={cn(
                "flex-1 px-3 py-2 rounded-full text-sm font-medium transition-all duration-200",
                searchType === 'name'
                  ? "bg-primary text-primary-foreground shadow-md"
                  : "text-muted-foreground hover:text-foreground"
              )}
            >
              {labels.searchByName}
            </button>
          </div>

          {/* Search Input */}
          <div className="relative mb-3">
            <Input
              type="text"
              inputMode={searchType === 'code' ? 'numeric' : 'text'}
              placeholder={searchType === 'code' ? '1234' : labels.searchByName}
              value={searchCode}
              onChange={e => handleSearchCodeChange(e.target.value)}
              className="h-12 text-lg font-semibold text-center rounded-xl border-2 border-border/60 focus:border-primary bg-background pl-10"
            />
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-muted-foreground" />
          </div>

          {/* Dropdown List */}
          <Select value={selectedSupplierId} onValueChange={handleSelectSupplier}>
            <SelectTrigger className="w-full h-11 rounded-xl text-sm">
              <SelectValue placeholder={labels.selectFromList} />
            </SelectTrigger>
            <SelectContent className="max-h-64">
              {filteredSuppliers.map(s => (
                <SelectItem key={s.id} value={s.id}>
                  <span className="font-semibold">{s.code}</span>
                  <span className="text-muted-foreground ml-2">• {s.name}</span>
                </SelectItem>
              ))}
            </SelectContent>
          </Select>

          {/* Selected Customer Display */}
          {selectedSupplier && (
            <div className="mt-3 py-2 px-3 bg-primary/10 rounded-xl text-center">
              <p className="font-semibold text-primary">#{selectedSupplier.code} - {selectedSupplier.name}</p>
            </div>
          )}
        </div>

        {/* Customer History Section */}
        {selectedSupplier ? (
          <div className="space-y-4 animate-fade-in">
            {/* Initial Pending Amount (One-time) - Show only if no balance set */}
            {!hasInitialBalance && (
              <div className="bg-card rounded-2xl shadow-lg border border-amber-200 dark:border-amber-800 p-4 bg-amber-50/50 dark:bg-amber-900/20">
                <div className="flex items-center gap-2 mb-3">
                  <Wallet className="h-5 w-5 text-amber-600" />
                  <span className="text-sm font-semibold text-amber-800 dark:text-amber-200">{labels.bakayaRashi}</span>
                </div>
                <div className="flex gap-2">
                  <div className="relative flex-1">
                    <span className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground">₹</span>
                    <Input
                      type="number"
                      inputMode="decimal"
                      value={initialPendingAmount}
                      onChange={e => setInitialPendingAmount(e.target.value)}
                      className="h-12 text-lg font-semibold pl-8 rounded-xl"
                      placeholder="0"
                    />
                  </div>
                  <Button
                    onClick={handleSetInitialBalance}
                    disabled={isSaving || !initialPendingAmount}
                    className="h-12 px-6 rounded-xl bg-amber-600 hover:bg-amber-700"
                  >
                    <Save className="h-4 w-4 mr-2" />
                    {labels.setInitialBalance}
                  </Button>
                </div>
              </div>
            )}

            {/* Main Balance Dashboard - Shows real-time calculation */}
            {hasInitialBalance && (
              <div className="bg-gradient-to-br from-primary/10 to-primary/5 rounded-2xl shadow-lg border border-primary/20 p-4">
                <div className="text-center">
                  <p className="text-sm text-muted-foreground mb-1">{labels.totalPending}</p>
                  <p className="text-3xl font-bold text-primary">₹{remainingAfterPayment.toFixed(0)}</p>
                  {parseFloat(paidAmount) > 0 && (
                    <p className="text-xs text-muted-foreground mt-1">
                      (₹{totalPendingBalance.toFixed(0)} - ₹{parseFloat(paidAmount).toFixed(0)})
                    </p>
                  )}
                </div>
              </div>
            )}

            {/* Payment Input Section */}
            {hasInitialBalance && (
              <div className="bg-card rounded-2xl shadow-lg border border-border/50 p-4">
                {/* Paid Amount Input */}
                <div className="mb-4">
                  <label className="text-sm font-medium text-muted-foreground mb-1.5 block">{labels.paidAmount}</label>
                  <div className="relative">
                    <span className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground">₹</span>
                    <Input
                      type="number"
                      inputMode="decimal"
                      value={paidAmount}
                      onChange={e => setPaidAmount(e.target.value)}
                      className="h-12 text-lg font-semibold pl-8 rounded-xl"
                      placeholder="0"
                    />
                  </div>
                </div>





                {/* Add to History Button */}
                <Button
                  onClick={handleAddToHistory}
                  disabled={isSaving || !paidAmount || parseFloat(paidAmount) <= 0}
                  className="w-full h-12 rounded-xl text-base font-semibold bg-primary hover:bg-primary/90"
                >
                  <Plus className="h-5 w-5 mr-2" />
                  {labels.addToHistory}
                </Button>
              </div>
            )}

            {/* Transaction History Card */}
            <div className="bg-card rounded-2xl shadow-lg border border-border/50 p-4">
              <h3 className="text-sm font-semibold text-foreground mb-3 flex items-center gap-2">
                <History className="h-4 w-4" />
                {labels.transactionHistory}
              </h3>

              {isLoading ? (
                <div className="text-center py-8 text-muted-foreground">Loading...</div>
              ) : history.length === 0 ? (
                <div className="text-center py-8 text-muted-foreground text-sm">
                  {hasInitialBalance ? labels.noHistory : labels.enterInitialFirst}
                </div>
              ) : (
                <div className="space-y-2 max-h-80 overflow-y-auto">
                  {history.map((entry) => {
                    const isPaidEntry = (entry.amount_paid || 0) > 0;
                    const isPending = isPaidEntry && (entry as any).supplier_confirmed === null;
                    const isRejected = isPaidEntry && (entry as any).supplier_confirmed === false;
                    
                    return (
                    <div
                      key={entry.id}
                      className={cn(
                        "p-3 bg-muted/50 rounded-xl border border-border/30",
                        isPending && "border-amber-300 bg-amber-50/50 dark:bg-amber-900/10",
                        isRejected && "border-red-300 bg-red-50/50 dark:bg-red-900/10 opacity-60"
                      )}
                    >
                      <div className="flex items-center justify-between mb-1">
                        <span className="text-xs text-muted-foreground">
                          {format(new Date(entry.transaction_date), 'dd/MM/yyyy')}
                          {isPending && <span className="ml-1 text-amber-600 font-medium">⏳ {language === 'hi' ? 'पुष्टि बाकी' : 'Pending'}</span>}
                          {isRejected && <span className="ml-1 text-red-600 font-medium">❌ {language === 'hi' ? 'अस्वीकृत' : 'Rejected'}</span>}
                        </span>
                        <span className={cn(
                          "text-sm font-bold",
                          entry.balance_after >= 0 ? "text-amber-600" : "text-green-600"
                        )}>
                          ₹{entry.balance_after.toFixed(0)}
                        </span>
                      </div>
                      <div className="flex items-center gap-4 text-sm">
                        {entry.amount_added > 0 && (
                          <div className="flex items-center gap-1 text-red-500">
                            <ArrowUpCircle className="h-4 w-4" />
                            <span>+₹{entry.amount_added.toFixed(0)}</span>
                          </div>
                        )}
                        {entry.amount_paid > 0 && (
                          <div className="flex items-center gap-1 text-green-500">
                            <ArrowDownCircle className="h-4 w-4" />
                            <span>-₹{entry.amount_paid.toFixed(0)}</span>
                          </div>
                        )}
                      </div>
                      {entry.notes && (
                        <p className="text-xs text-muted-foreground mt-1">{entry.notes}</p>
                      )}
                    </div>
                    );
                  })}
                </div>
              )}
            </div>
          </div>
        ) : (
          <div className="text-center py-12 text-muted-foreground">
            <Search className="h-12 w-12 mx-auto mb-3 opacity-50" />
            <p className="text-sm">{labels.selectCustomer}</p>
          </div>
        )}
      </main>

      <BottomNav />
    </div>
  );
};

export default CustomerHistory;

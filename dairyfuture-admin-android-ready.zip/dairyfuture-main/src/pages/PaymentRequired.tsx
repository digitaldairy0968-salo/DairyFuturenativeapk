import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { ArrowLeft, Shield, Zap, Star } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useLanguage } from '@/contexts/LanguageContext';
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';
import { useSettingsBootstrap, loadSettingsBootstrap } from '@/lib/settingsBootstrap';
import { writeSubscriptionCache } from '@/lib/subscriptionStatus';
import PlanCards, { PlanDuration } from '@/components/PlanCards';
import { HelpVideoCard } from '@/components/HelpVideoWidget';



const PaymentRequired: React.FC = () => {
  const { language } = useLanguage();
  const { user, logout, refreshProfile } = useAuth();
  const navigate = useNavigate();

  const [activatingDemo, setActivatingDemo] = useState(false);
  const [duration, setDuration] = useState<PlanDuration>('monthly');

  // Single bootstrap RPC, cached per tab session.
  const { data: boot, loading } = useSettingsBootstrap();
  const varieties = boot?.varieties ?? [];
  const varPlans = boot?.variety_plans ?? [];
  const settings = React.useMemo<any>(
    () => ({ ...(boot?.settings || {}), ...(boot?.contact || {}) }),
    [boot]
  );

  const demoDays = (settings as any)?.demo_days || 9;

  const pickOption = (option: any) => {
    navigate(`/checkout/${option.id}`);
  };

  const activateDemo = async () => {
    if (!user?.dairyId) { toast.error(language === 'hi' ? 'डेयरी नहीं मिली' : 'Dairy not found'); return; }
    setActivatingDemo(true);
    try {
      const { error } = await supabase.rpc('activate_demo_subscription', { _dairy_id: user.dairyId });
      if (error) {
        if (error.message.includes('demo_already_used')) { toast.error(language === 'hi' ? 'डेमो पहले से उपयोग किया जा चुका है' : 'Demo already used'); return; }
        throw error;
      }
      toast.success(language === 'hi' ? `डेमो सक्रिय! ${demoDays} दिन का फ्री एक्सेस।` : `Demo activated! ${demoDays} days free.`);
      writeSubscriptionCache('active');
      await loadSettingsBootstrap(true);
      await refreshProfile();
      navigate('/dashboard');
    } catch { toast.error(language === 'hi' ? 'डेमो विफल' : 'Demo failed'); }
    finally { setActivatingDemo(false); }
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <div className="w-10 h-10 border-4 border-primary border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-background to-muted/30">
      {/* Compact Premium Header */}
      <div className="relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-primary via-primary/90 to-accent/80" />
        <div className="relative px-3 py-4">
          <div className="flex items-center gap-2 mb-3">
            <Button variant="ghost" size="icon" onClick={async () => { await logout(); navigate('/auth'); }} className="text-primary-foreground hover:bg-primary-foreground/20 h-8 w-8">
              <ArrowLeft className="h-4 w-4" />
            </Button>
            <div className="flex-1">
              <h1 className="text-lg font-bold text-primary-foreground">
                {language === 'hi' ? '⭐ प्रीमियम प्लान' : '⭐ Premium Plans'}
              </h1>
            </div>
          </div>

          <div className="text-center mb-3">
            <div className="w-12 h-12 bg-primary-foreground/20 rounded-xl flex items-center justify-center mx-auto mb-2 shadow-md">
              <span className="text-2xl">👑</span>
            </div>
            <p className="text-primary-foreground/80 text-xs font-medium">
              {language === 'hi' ? '✨ प्रीमियम डेयरी प्रबंधन' : '✨ Premium Dairy Management'}
            </p>
          </div>

          <div className="flex flex-wrap justify-center gap-1.5">
            {[
              { icon: <Zap className="h-3 w-3" />, text: language === 'hi' ? 'असीमित एंट्री' : 'Unlimited Entries' },
              { icon: <Shield className="h-3 w-3" />, text: language === 'hi' ? 'डेटा सुरक्षित' : 'Data Secure' },
              { icon: <Star className="h-3 w-3" />, text: language === 'hi' ? 'सभी फीचर्स' : 'All Features' },
            ].map((f, i) => (
              <div key={i} className="flex items-center gap-1 bg-primary-foreground/10 text-primary-foreground/90 px-2.5 py-1 rounded-full text-[10px] font-medium">
                {f.icon} {f.text}
              </div>
            ))}
          </div>
        </div>
      </div>

      <main className="px-3 py-4 max-w-md mx-auto space-y-3">
        <HelpVideoCard />

        <div className="text-center">
          <h2 className="text-base font-bold text-foreground">
            {language === 'hi' ? 'अपना प्लान चुनें' : 'Choose Your Plan'}
          </h2>
          <p className="text-[10px] text-muted-foreground">
            {language === 'hi' ? 'अपनी डेयरी के लिए सही प्लान चुनें' : 'Pick the right plan for your dairy'}
          </p>
        </div>

        <PlanCards
          plans={varieties}
          varieties={varPlans}
          onSelect={pickOption}
          hi={language === 'hi'}
          duration={duration}
          onDurationChange={setDuration}
          demo={{ days: demoDays, onStart: activateDemo, loading: activatingDemo }}
        />

      </main>

    </div>
  );
};

export default PaymentRequired;

import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { ArrowLeft, Shield, Zap, Star } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useLanguage } from '@/contexts/LanguageContext';
import { useAuth } from '@/contexts/AuthContext';
import { useSettingsBootstrap, daysLeftFrom } from '@/lib/settingsBootstrap';
import PlanCards, { PlanDuration } from '@/components/PlanCards';
import { HelpVideoCard } from '@/components/HelpVideoWidget';



const SubscriptionRenewal: React.FC = () => {
  const { language } = useLanguage();
  const { user } = useAuth();
  const navigate = useNavigate();
  const [duration, setDuration] = useState<PlanDuration>('monthly');

  // Single bootstrap RPC, cached for the whole tab session (no TTL, no refetch on revisit).
  const { data: boot } = useSettingsBootstrap();
  const daysLeft = daysLeftFrom(boot);
  const varieties = boot?.varieties ?? [];
  const varPlans = boot?.variety_plans ?? [];

  const pickOption = (option: any) => {
    navigate(`/checkout/${option.id}`);
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-background to-muted/30">
      <div className="relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-primary via-primary/90 to-accent/80" />
        <div className="relative px-3 py-4">
          <div className="flex items-center gap-2 mb-3">
            <Button variant="ghost" size="icon" onClick={() => navigate('/settings')} className="text-primary-foreground hover:bg-primary-foreground/20 h-8 w-8">
              <ArrowLeft className="h-4 w-4" />
            </Button>
            <h1 className="text-lg font-bold text-primary-foreground flex-1">
              {language === 'hi' ? '⭐ प्रीमियम प्लान' : '⭐ Premium Plans'}
            </h1>
          </div>
          {daysLeft !== null && (
            <div className="flex justify-center mb-3">
              <div className="bg-primary-foreground/15 backdrop-blur-sm rounded-xl px-5 py-2.5 text-center border border-primary-foreground/20">
                <p className="text-4xl font-black text-primary-foreground leading-none">{daysLeft}</p>
                <p className="text-primary-foreground/80 text-xs font-medium mt-1">{language === 'hi' ? 'दिन बचे हैं' : 'days remaining'}</p>
              </div>
            </div>
          )}
          <div className="flex flex-wrap justify-center gap-1.5">
            {[
              { icon: <Zap className="h-3 w-3" />, text: language === 'hi' ? 'असीमित' : 'Unlimited' },
              { icon: <Shield className="h-3 w-3" />, text: language === 'hi' ? 'सुरक्षित' : 'Secure' },
              { icon: <Star className="h-3 w-3" />, text: language === 'hi' ? 'सभी फीचर्स' : 'All Features' },
            ].map((f, i) => (
              <div key={i} className="flex items-center gap-1 bg-primary-foreground/10 text-primary-foreground/90 px-2.5 py-1 rounded-full text-[10px] font-medium">
                {f.icon} {f.text}
              </div>
            ))}
          </div>
        </div>
      </div>

      <main className="px-3 py-4 max-w-md mx-auto space-y-3">
        <HelpVideoCard />

        <div className="text-center">
          <h2 className="text-base font-bold text-foreground">
            {language === 'hi' ? 'अपना प्लान चुनें' : 'Choose Your Plan'}
          </h2>
          <p className="text-[10px] text-muted-foreground">
            {language === 'hi' ? 'अपनी डेयरी के लिए सही प्लान चुनें' : 'Pick the right plan for your dairy'}
          </p>
        </div>

        <PlanCards
          plans={varieties}
          varieties={varPlans}
          onSelect={pickOption}
          hi={language === 'hi'}
          duration={duration}
          onDurationChange={setDuration}
        />

      </main>
    </div>
  );
};

export default SubscriptionRenewal;

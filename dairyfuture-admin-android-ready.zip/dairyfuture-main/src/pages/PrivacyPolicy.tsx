import React from 'react';
import { Link } from 'react-router-dom';
import { useLanguage } from '@/contexts/LanguageContext';
import { ChevronLeft, Milk, Database, Share2, Trash2, Mail, Shield } from 'lucide-react';

const PrivacyPolicy: React.FC = () => {
  const { language } = useLanguage();

  const title =
    language === 'hi'
      ? 'गोपनीयता नीति'
      : language === 'gu'
      ? 'ગોપનીયતા નીતિ'
      : 'Privacy Policy';

  const backLabel =
    language === 'hi' ? 'वापस' : language === 'gu' ? 'પાછા' : 'Back';

  const sections = [
    {
      icon: <Milk className="w-5 h-5" />,
      heading: 'Who we are',
      content:
        'DairyFuture is a dairy management application designed for dairy owners and their suppliers. We make it easy to record daily milk collection, calculate fair fat/SNF-based rates, and keep payment records organised through a secure Supabase backend.',
    },
    {
      icon: <Shield className="w-5 h-5" />,
      heading: 'Information we collect',
      content:
        'We collect only the information needed to run the app: your name, phone number, email address, milk entry records, payment records, and — when you choose Google sign-in — the public profile information Google shares with us (such as your name and email). We do not collect sensitive personal data beyond what is required for dairy record-keeping.',
    },
    {
      icon: <Database className="w-5 h-5" />,
      heading: 'How we use your information',
      content:
        'Your information is used solely to operate and improve DairyFuture: authenticating your account, recording milk entries, calculating rates, tracking payments, and showing you the records you are authorised to see. We never sell your data, show ads, or use your information for unrelated marketing.',
    },
    {
      icon: <Database className="w-5 h-5" />,
      heading: 'Data storage',
      content:
        'All data is stored in Supabase, a secure cloud database service. We rely on Supabase authentication, encryption, and access controls to protect your information. You own your data and we only process it to provide the service.',
    },
    {
      icon: <Share2 className="w-5 h-5" />,
      heading: 'Data sharing',
      content:
        'We do not share your personal information with third parties except for the infrastructure providers required to run the app (currently Supabase for database and authentication). We do not share data with advertisers or data brokers.',
    },
    {
      icon: <Trash2 className="w-5 h-5" />,
      heading: 'Your rights',
      content:
        'You can request a copy of your data or ask us to delete your account and associated records at any time by contacting us at the email below. We will process deletion requests as quickly as possible.',
    },
    {
      icon: <Mail className="w-5 h-5" />,
      heading: 'Contact us',
      content:
        'If you have any questions about this Privacy Policy or your data, please email us at digitaldairy0968@gmail.com.',
    },
  ];

  return (
    <div className="min-h-screen bg-gradient-to-b from-background via-background to-dairy-cream">
      <div className="max-w-3xl mx-auto px-4 py-6 md:py-10">
        <Link
          to="/"
          className="inline-flex items-center gap-1 text-sm text-muted-foreground hover:text-foreground transition-colors mb-6"
        >
          <ChevronLeft className="w-4 h-4" />
          {backLabel}
        </Link>

        <div className="dairy-card p-6 md:p-8 animate-slide-up">
          <h1 className="text-2xl md:text-3xl font-bold text-foreground mb-2">{title}</h1>
          <p className="text-sm text-muted-foreground mb-8">Last updated: September 3, 2026</p>

          <div className="space-y-6">
            {sections.map((section, index) => (
              <div key={index} className="flex gap-4">
                <div className="flex-shrink-0 w-10 h-10 rounded-xl bg-primary/10 flex items-center justify-center text-primary">
                  {section.icon}
                </div>
                <div>
                  <h2 className="text-lg font-semibold text-foreground mb-1">{section.heading}</h2>
                  <p className="text-sm text-muted-foreground leading-relaxed">{section.content}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default PrivacyPolicy;

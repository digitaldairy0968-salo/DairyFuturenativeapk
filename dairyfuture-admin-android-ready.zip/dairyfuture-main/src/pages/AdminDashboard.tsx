import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Building2, Users, Milk, RefreshCw, LogOut, Search, CreditCard, Trash2, Phone, Shield, Package, Settings as SettingsIcon } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Switch } from '@/components/ui/switch';

import { useAuth } from '@/contexts/AuthContext';
import { useLanguage } from '@/contexts/LanguageContext';
import { supabase } from '@/integrations/supabase/client';
import { fetchAllRows } from '@/lib/supabasePagination';
import { readAdminCache, writeAdminCache, mergeById, cacheRemoveRow, ADMIN_DELTA_KEY } from '@/lib/adminCache';
import { toast } from 'sonner';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog';

interface DairyInfo {
  id: string;
  name: string;
  code: string;
  ownerName: string;
  ownerPhone: string;
  supplierCount: number;
  createdAt: string;
}

const CACHE_DAIRIES = 'dairies_info';

const AdminDashboard: React.FC = () => {
  const { t } = useLanguage();
  const { logout, user } = useAuth();
  const navigate = useNavigate();
  const [dairies, setDairies] = useState<DairyInfo[]>(
    () => readAdminCache<DairyInfo>(CACHE_DAIRIES) ?? []
  );
  const [loading, setLoading] = useState(() => !readAdminCache(CACHE_DAIRIES));
  const [syncing, setSyncing] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [codeFeature, setCodeFeature] = useState<Record<string, boolean>>({});
  const [togglingId, setTogglingId] = useState<string | null>(null);
  const [dayFilter, setDayFilter] = useState<'all' | number>('all');
  const [customDays, setCustomDays] = useState('');

  useEffect(() => {
    fetchAllDairies();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // Feature flags (12-digit customer code) for every dairy — shown inline.
  useEffect(() => {
    if (dairies.length === 0) return;
    let cancelled = false;
    (async () => {
      const rows = await fetchAllRows(
        supabase.from('dairy_features').select('dairy_id, is_enabled').eq('feature_key', 'customer_code')
      );
      if (cancelled) return;
      const map: Record<string, boolean> = {};
      (rows || []).forEach((r: any) => { map[r.dairy_id] = !!r.is_enabled; });
      setCodeFeature(map);
    })();
    return () => { cancelled = true; };
  }, [dairies.length]);

  const toggleCustomerCode = async (dairyId: string, enabled: boolean) => {
    setTogglingId(dairyId);
    setCodeFeature(prev => ({ ...prev, [dairyId]: enabled }));
    try {
      const { error } = await supabase
        .from('dairy_features')
        .upsert({ dairy_id: dairyId, feature_key: 'customer_code', is_enabled: enabled }, { onConflict: 'dairy_id,feature_key' });
      if (error) throw error;
      toast.success(enabled ? 'Customer code enabled' : 'Customer code disabled');
    } catch (e) {
      setCodeFeature(prev => ({ ...prev, [dairyId]: !enabled }));
      toast.error('Failed to update feature');
    } finally {
      setTogglingId(null);
    }
  };


  const fetchAllDairies = async (force = false) => {
    const cached = force ? null : readAdminCache<DairyInfo>(CACHE_DAIRIES);
    const fullSync = !cached || cached.length === 0;
    if (fullSync) setLoading(true);
    setSyncing(true);
    try {
      // 1. Delta-fetch dairies (only rows changed since last sync)
      let q = supabase.from('dairies').select('*').order('created_at', { ascending: false });
      const since = fullSync ? null : localStorage.getItem(ADMIN_DELTA_KEY(CACHE_DAIRIES));
      if (since) q = q.gt('updated_at', since);
      const dairyList = (await fetchAllRows(q)) || [];

      if (dairyList.length === 0) {
        const next = fullSync ? [] : (cached ?? []);
        setDairies(next);
        writeAdminCache(CACHE_DAIRIES, next);
        return;
      }

      const ownerIds = Array.from(new Set(dairyList.map(d => d.owner_id)));
      const dairyIds = dairyList.map(d => d.id);

      // 2. Related profiles + supplier counts, only for the changed dairies
      const [profilesData, suppliersData] = await Promise.all([
        fetchAllRows(
          supabase.from('profiles').select('user_id, name, phone').in('user_id', ownerIds)
        ),
        fetchAllRows(
          supabase.from('suppliers').select('dairy_id').in('dairy_id', dairyIds)
        ),
      ]);

      const profileMap = new Map<string, { name: string; phone: string }>();
      (profilesData || []).forEach((p: any) => {
        profileMap.set(p.user_id, { name: p.name || 'Unknown', phone: p.phone || 'N/A' });
      });

      const countMap = new Map<string, number>();
      (suppliersData || []).forEach((s: any) => {
        countMap.set(s.dairy_id, (countMap.get(s.dairy_id) || 0) + 1);
      });

      const dairyInfos: DairyInfo[] = dairyList.map(dairy => {
        const profile = profileMap.get(dairy.owner_id);
        return {
          id: dairy.id,
          name: dairy.name,
          code: dairy.code,
          ownerName: profile?.name || 'Unknown',
          ownerPhone: profile?.phone || 'N/A',
          supplierCount: countMap.get(dairy.id) || 0,
          createdAt: dairy.created_at,
        };
      });

      const merged = fullSync ? dairyInfos : mergeById(cached ?? [], dairyInfos);
      merged.sort((a, b) => (a.createdAt < b.createdAt ? 1 : -1));
      setDairies(merged);
      writeAdminCache(CACHE_DAIRIES, merged);

      let maxTs: string | null = null;
      for (const d of dairyList as any[]) {
        const ts = d?.updated_at;
        if (ts && (!maxTs || ts > maxTs)) maxTs = ts;
      }
      if (maxTs) localStorage.setItem(ADMIN_DELTA_KEY(CACHE_DAIRIES), maxTs);
    } catch (error) {
      console.error('Error:', error);
    } finally {
      setLoading(false);
      setSyncing(false);
    }
  };

  const handleLogout = async () => {
    await logout();
    navigate('/auth');
  };

  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [dairyToDelete, setDairyToDelete] = useState<DairyInfo | null>(null);
  const [deleting, setDeleting] = useState(false);
  const cutoff = dayFilter === 'all' ? null : Date.now() - dayFilter * 86400000;
  const filteredDairies = dairies
    .filter(d =>
      d.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      (d.code || '').includes(searchTerm) ||
      d.ownerName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      d.ownerPhone.includes(searchTerm)
    )
    .filter(d => (cutoff === null ? true : new Date(d.createdAt).getTime() >= cutoff))
    // Newest dairies always on top
    .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());


  const handleDeleteDairy = async () => {
    if (!dairyToDelete) return;
    
    setDeleting(true);
    try {
      // Delete related data first (due to foreign key constraints)
      // Delete milk entries
      await supabase.from('milk_entries').delete().eq('dairy_id', dairyToDelete.id);
      
      // Delete rate settings
      await supabase.from('rate_settings').delete().eq('dairy_id', dairyToDelete.id);
      
      // Delete suppliers
      await supabase.from('suppliers').delete().eq('dairy_id', dairyToDelete.id);
      
      // Delete subscriptions
      await supabase.from('subscriptions').delete().eq('dairy_id', dairyToDelete.id);
      
      // Finally delete the dairy
      const { error } = await supabase.from('dairies').delete().eq('id', dairyToDelete.id);
      
      if (error) throw error;
      
      toast.success(`Dairy "${dairyToDelete.name}" deleted successfully`);
      setDairies(prev => prev.filter(d => d.id !== dairyToDelete.id));
      cacheRemoveRow(CACHE_DAIRIES, dairyToDelete.id);
    } catch (error) {
      console.error('Error deleting dairy:', error);
      toast.error('Failed to delete dairy');
    } finally {
      setDeleting(false);
      setDeleteDialogOpen(false);
      setDairyToDelete(null);
    }
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="dairy-header px-4 py-4">
        <div className="flex items-center justify-between max-w-6xl mx-auto">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-primary-foreground/20 rounded-full flex items-center justify-center">
              <Building2 className="w-5 h-5" />
            </div>
            <div>
              <h1 className="text-xl font-bold">Admin Dashboard</h1>
              <p className="text-primary-foreground/70 text-sm">Manage all dairies</p>
            </div>
          </div>
          <div className="flex items-center gap-1">
            <Button
              variant="ghost"
              size="icon"
              onClick={() => navigate('/settings')}
              aria-label="Settings"
              className="text-primary-foreground hover:bg-primary-foreground/20"
            >
              <SettingsIcon className="h-5 w-5" />
            </Button>
            <Button
              variant="ghost"
              size="icon"
              onClick={handleLogout}
              className="text-primary-foreground hover:bg-primary-foreground/20"
            >
              <LogOut className="h-5 w-5" />
            </Button>
          </div>

        </div>
      </header>

      <main className="px-4 py-6 max-w-6xl mx-auto">
        {/* Stats */}
        <div className="grid grid-cols-2 gap-4 mb-6">
          <div className="dairy-card text-center">
            <div className="w-12 h-12 mx-auto bg-primary/10 rounded-full flex items-center justify-center mb-2">
              <Building2 className="w-6 h-6 text-primary" />
            </div>
            <p className="text-2xl font-bold">{dairies.length}</p>
            <p className="text-muted-foreground text-sm">Total Dairies</p>
          </div>
          <div className="dairy-card text-center">
            <div className="w-12 h-12 mx-auto bg-green-100 rounded-full flex items-center justify-center mb-2">
              <Users className="w-6 h-6 text-green-600" />
            </div>
            <p className="text-2xl font-bold">{dairies.reduce((sum, d) => sum + d.supplierCount, 0)}</p>
            <p className="text-muted-foreground text-sm">Total Suppliers</p>
          </div>
        </div>

        {/* Admin Action Buttons */}
        <div className="grid grid-cols-2 gap-3 mb-4">
          <Button
            onClick={() => navigate('/admin/subscriptions')}
            className="gap-2"
            variant="outline"
          >
            <CreditCard className="h-4 w-4" />
            Subscriptions
          </Button>
          <Button
            onClick={() => navigate('/admin/plans')}
            className="gap-2"
            variant="outline"
          >
            <Package className="h-4 w-4" />
            Plans
          </Button>
          <Button
            onClick={() => navigate('/admin/payments')}
            className="gap-2 col-span-2"
            variant="outline"
          >
            <CreditCard className="h-4 w-4" />
            UPI Payments
          </Button>
        </div>

        {/* Search and Refresh */}
        <div className="flex gap-3 mb-4">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              type="text"
              placeholder="Search dairies, codes, owners..."
              value={searchTerm}
              onChange={e => setSearchTerm(e.target.value)}
              className="pl-10"
            />
          </div>
          <Button
            variant="outline"
            size="icon"
            onClick={() => fetchAllDairies(true)}
            disabled={loading || syncing}
          >
            <RefreshCw className={`h-4 w-4 ${loading || syncing ? 'animate-spin' : ''}`} />
          </Button>
        </div>

        {/* Date filter */}
        <div className="flex flex-wrap items-center gap-2 mb-4">
          <Button
            variant={dayFilter === 'all' ? 'default' : 'outline'}
            size="sm"
            onClick={() => setDayFilter('all')}
          >
            All dairies
          </Button>
          {[7, 30].map(n => (
            <Button
              key={n}
              variant={dayFilter === n ? 'default' : 'outline'}
              size="sm"
              onClick={() => setDayFilter(n)}
            >
              Last {n} days
            </Button>
          ))}
          <div className="flex items-center gap-1">
            <Input
              type="number"
              min={1}
              placeholder="Days"
              value={customDays}
              onChange={e => setCustomDays(e.target.value)}
              className="w-20 h-9"
            />
            <Button
              variant="outline"
              size="sm"
              onClick={() => {
                const n = parseInt(customDays, 10);
                if (n > 0) setDayFilter(n);
              }}
            >
              Apply
            </Button>
          </div>
          <span className="text-xs text-muted-foreground ml-auto">
            {filteredDairies.length} shown
          </span>
        </div>


        {/* Dairies List */}
        <div className="space-y-3">
          {loading ? (
            <div className="text-center py-8">
              <div className="w-8 h-8 border-4 border-primary border-t-transparent rounded-full animate-spin mx-auto" />
              <p className="text-muted-foreground mt-2">Loading...</p>
            </div>
          ) : filteredDairies.length === 0 ? (
            <div className="text-center py-8 dairy-card">
              <Building2 className="w-12 h-12 mx-auto text-muted-foreground mb-2" />
              <p className="text-muted-foreground">No dairies found</p>
            </div>
          ) : (
            filteredDairies.map(dairy => (
              <div key={dairy.id} className="dairy-card">
                <div className="flex items-start justify-between">
                  <div className="flex items-start gap-3">
                    <div className="w-10 h-10 bg-primary/10 rounded-full flex items-center justify-center flex-shrink-0">
                      <Milk className="w-5 h-5 text-primary" />
                    </div>
                    <div>
                      <h3 className="font-semibold">{dairy.name}</h3>
                      <p className="text-sm text-muted-foreground">Code: {dairy.code}</p>
                      <p className="text-xs text-muted-foreground mt-1">Owner: {dairy.ownerName}</p>
                      <p className="text-xs text-muted-foreground flex items-center gap-1 mt-0.5">
                        <Phone className="w-3 h-3" />
                        <a href={`tel:${dairy.ownerPhone}`} className="hover:text-primary">
                          {dairy.ownerPhone}
                        </a>
                      </p>
                      <div className="flex items-center gap-2 mt-2">
                        <Switch
                          checked={!!codeFeature[dairy.id]}
                          onCheckedChange={(v) => toggleCustomerCode(dairy.id, v)}
                          disabled={togglingId === dairy.id}
                        />
                        <span className="text-xs text-muted-foreground">
                          12-Digit Customer Code
                        </span>
                      </div>

                    </div>
                  </div>
                  <div className="text-right flex flex-col items-end gap-2">
                    <span className="inline-flex items-center gap-1 text-sm px-2 py-1 rounded bg-green-100 text-green-700">
                      <Users className="w-3 h-3" />
                      {dairy.supplierCount}
                    </span>
                    <p className="text-xs text-muted-foreground">
                      {new Date(dairy.createdAt).toLocaleDateString()}
                    </p>
                    <div className="flex gap-1 flex-wrap justify-end">
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => navigate(`/admin/dairy-features/${dairy.id}`)}
                        className="gap-1"
                      >
                        <Shield className="w-3 h-3" />
                        Features
                      </Button>
                      <Button
                        variant="destructive"
                        size="sm"
                        onClick={() => {
                          setDairyToDelete(dairy);
                          setDeleteDialogOpen(true);
                        }}
                        className="gap-1"
                      >
                        <Trash2 className="w-3 h-3" />
                      </Button>
                    </div>
                  </div>
                </div>
              </div>
            ))
          )}
        </div>
      </main>

      {/* Delete Confirmation Dialog */}
      <AlertDialog open={deleteDialogOpen} onOpenChange={setDeleteDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete Dairy</AlertDialogTitle>
            <AlertDialogDescription>
              Are you sure you want to delete "{dairyToDelete?.name}" (Code: {dairyToDelete?.code})?
              <br /><br />
              This will permanently delete:
              <ul className="list-disc list-inside mt-2 text-destructive">
                <li>{dairyToDelete?.supplierCount} suppliers</li>
                <li>All milk entries</li>
                <li>Rate settings & subscription</li>
              </ul>
              <br />
              This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel disabled={deleting}>Cancel</AlertDialogCancel>
            <AlertDialogAction
              onClick={handleDeleteDairy}
              disabled={deleting}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
            >
              {deleting ? 'Deleting...' : 'Delete Dairy'}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

    </div>
  );
};

export default AdminDashboard;
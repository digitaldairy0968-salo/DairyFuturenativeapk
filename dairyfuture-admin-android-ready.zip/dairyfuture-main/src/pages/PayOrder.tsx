import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { ArrowLeft, Clock, Wallet, ShieldCheck, Loader2, AlertTriangle, MessageCircle } from 'lucide-react';
import { QRCodeCanvas } from 'qrcode.react';
import { toast } from 'sonner';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { useLanguage } from '@/contexts/LanguageContext';
import { loadSettingsBootstrap } from '@/lib/settingsBootstrap';
import {
  buildUpiUrl,
  fetchOrder,
  isMobileDevice,
  markPayClicked,
  openUpiApp,
  orderErrorMessage,
  submitUtr,
  type OrderBundle,
} from '@/lib/payments';


const PayOrder: React.FC = () => {
  const { orderId } = useParams<{ orderId: string }>();
  const { language } = useLanguage();
  const hi = language === 'hi';
  const navigate = useNavigate();

  const [bundle, setBundle] = useState<OrderBundle | null>(null);
  const [loading, setLoading] = useState(true);
  const [utr, setUtr] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [secondsLeft, setSecondsLeft] = useState(0);

  const load = useCallback(async () => {
    if (!orderId) return;
    try {
      const data = await fetchOrder(orderId);
      setBundle(data);
      setUtr(data.order.utr_submitted ?? '');
    } catch (e: any) {
      toast.error(orderErrorMessage(e?.message ?? '', hi));
      navigate('/payment-required', { replace: true });
    } finally {
      setLoading(false);
    }
  }, [orderId, hi, navigate]);

  useEffect(() => { load(); }, [load]);

  // 15-minute countdown, purely client-side (server re-checks expiry on verify)
  useEffect(() => {
    if (!bundle) return;
    const tick = () => {
      const diff = Math.floor((new Date(bundle.order.expires_at).getTime() - Date.now()) / 1000);
      setSecondsLeft(diff > 0 ? diff : 0);
    };
    tick();
    const t = window.setInterval(tick, 1000);
    return () => window.clearInterval(t);
  }, [bundle]);

  const status = bundle?.order.status;
  const isOpen = status === 'created' || status === 'awaiting_utr';
  const expired = isOpen && secondsLeft <= 0;

  const upiUrl = useMemo(() => {
    if (!bundle?.upi_id) return '';
    return buildUpiUrl({
      upiId: bundle.upi_id,
      payeeName: bundle.plan?.name ? 'DairyFuture' : 'DairyFuture',
      amount: bundle.order.amount,
      orderRef: bundle.order.order_ref,
    });
  }, [bundle]);

  const mobile = useMemo(() => isMobileDevice(), []);

  // On mobile, jump straight into the user's UPI app — when they come back
  // only the UTR/transaction input is shown (no intermediate payment screen).
  useEffect(() => {
    if (!mobile || !upiUrl || !bundle) return;
    if (!(status === 'created' || status === 'awaiting_utr')) return;
    if (secondsLeft <= 0) return;
    const flag = `upi_launched_${bundle.order.id}`;
    if (sessionStorage.getItem(flag)) return;
    try { sessionStorage.setItem(flag, '1'); } catch { /* ignore */ }
    openUpiApp(upiUrl);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [mobile, upiUrl, bundle, status]);

  const onSuccess = useCallback(async () => {
    localStorage.setItem('subscription_cache', JSON.stringify({ status: 'active', timestamp: Date.now() }));
    await loadSettingsBootstrap(true);
    toast.success(hi ? '✅ भुगतान सत्यापित! सब्सक्रिप्शन चालू हो गया।' : '✅ Payment verified! Subscription activated.');
    navigate('/dashboard', { replace: true });
  }, [hi, navigate]);

  // The user left for their UPI app and came back → mark this order as an
  // auto-match candidate (once per order).
  const payClickedRef = useRef(false);
  useEffect(() => {
    if (!orderId || !isOpen) return;
    const key = `pay_clicked_${orderId}`;
    if (sessionStorage.getItem(key)) return;
    let wasHidden = document.visibilityState === 'hidden';
    const onChange = async () => {
      if (document.visibilityState === 'hidden') { wasHidden = true; return; }
      if (!wasHidden || payClickedRef.current) return;
      payClickedRef.current = true;
      try {
        sessionStorage.setItem(key, '1');
        await markPayClicked(orderId);
      } catch { /* ignore */ }
    };
    document.addEventListener('visibilitychange', onChange);
    return () => document.removeEventListener('visibilitychange', onChange);
  }, [orderId, isOpen]);

  // Light polling while the order is still open — auto-match may confirm it
  // from the admin app's payment notification (no push messaging involved).
  useEffect(() => {
    if (!orderId || !isOpen) return;
    let cancelled = false;
    const t = window.setInterval(async () => {
      if (document.visibilityState !== 'visible') return;
      try {
        const data = await fetchOrder(orderId);
        if (cancelled) return;
        setBundle(data);
        if (data.order.status === 'success') {
          window.clearInterval(t);
          await onSuccess();
        }
      } catch { /* ignore transient errors */ }
    }, 4500);
    return () => { cancelled = true; window.clearInterval(t); };
  }, [orderId, isOpen, onSuccess]);



  const mmss = `${String(Math.floor(secondsLeft / 60)).padStart(2, '0')}:${String(secondsLeft % 60).padStart(2, '0')}`;

  // WhatsApp uses the same admin contact number already stored in subscription_settings.admin_phone
  const waNumber = useMemo(() => {
    const raw = (bundle?.admin_phone ?? '').replace(/\D/g, '');
    if (raw.length < 10) return '';
    return raw.length === 10 ? `91${raw}` : raw;
  }, [bundle]);


  const verify = async () => {
    if (!orderId) return;
    const clean = utr.trim().toUpperCase();
    if (clean.length < 8) {
      toast.error(hi ? 'कृपया पूरा UTR / ट्रांज़ैक्शन ID डालें' : 'Please enter the full UTR / transaction ID');
      return;
    }
    setSubmitting(true);
    try {
      const res = await submitUtr(orderId, clean);
      if (res.matched) {
        localStorage.setItem('subscription_cache', JSON.stringify({ status: 'active', timestamp: Date.now() }));
        await loadSettingsBootstrap(true);
        toast.success(hi ? '✅ भुगतान सत्यापित! सब्सक्रिप्शन चालू हो गया।' : '✅ Payment verified! Subscription activated.');
        navigate('/my-subscription', { replace: true });
        return;
      }
      toast.info(
        hi
          ? 'UTR मिल गया, अभी मैच नहीं हुआ। एडमिन जांच कर रहा है।'
          : 'UTR received but not matched yet. Admin will review it.'
      );
      await load();
    } catch (e: any) {
      toast.error(orderErrorMessage(e?.message ?? '', hi));
      await load();
    } finally {
      setSubmitting(false);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }
  if (!bundle) return null;

  const { order } = bundle;

  return (
    <div className="min-h-screen bg-gradient-to-b from-background to-muted/30">
      <div className="relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-primary via-primary/90 to-accent/80" />
        <div className="relative px-4 py-5">
          <div className="flex items-center gap-3">
            <Button variant="ghost" size="icon" onClick={() => navigate(-1)} className="text-primary-foreground hover:bg-primary-foreground/20">
              <ArrowLeft className="h-5 w-5" />
            </Button>
            <h1 className="text-xl font-bold text-primary-foreground flex-1">
              {hi ? 'UPI से भुगतान' : 'Pay via UPI'}
            </h1>
          </div>
        </div>
      </div>

      <main className="px-4 py-5 max-w-md mx-auto space-y-4 -mt-2">
        {isOpen && (
          <div className={`flex items-center justify-center gap-2 rounded-2xl px-4 py-3 text-sm font-bold border ${expired ? 'bg-destructive/10 border-destructive/30 text-destructive' : 'bg-primary/10 border-primary/20 text-primary'}`}>
            <Clock className="h-4 w-4" />
            {expired
              ? (hi ? 'समय समाप्त — नया ऑर्डर बनाएं' : 'Time up — create a new order')
              : (hi ? `बाकी समय ${mmss}` : `Time left ${mmss}`)}
          </div>
        )}

        {status === 'verifying' && (
          <div className="rounded-2xl bg-amber-50 dark:bg-amber-950/20 border-2 border-amber-200 dark:border-amber-800 p-4 flex gap-3">
            <AlertTriangle className="h-5 w-5 text-amber-600 flex-shrink-0 mt-0.5" />
            <p className="text-sm text-amber-900 dark:text-amber-200">
              {hi
                ? 'आपका UTR जांच के लिए एडमिन के पास भेज दिया गया है। मंज़ूरी मिलने पर सब्सक्रिप्शन चालू हो जाएगा।'
                : 'Your UTR is under admin review. The subscription activates once approved.'}
            </p>
          </div>
        )}

        {status === 'success' && (
          <div className="rounded-2xl bg-primary/10 border-2 border-primary/30 p-4 flex items-center gap-3">
            <ShieldCheck className="h-6 w-6 text-primary" />
            <div className="flex-1">
              <p className="font-bold text-foreground">{hi ? 'भुगतान सत्यापित' : 'Payment verified'}</p>
              <Button variant="link" className="h-auto p-0 text-sm" onClick={() => navigate('/my-subscription')}>
                {hi ? 'मेरी सब्सक्रिप्शन देखें' : 'View my subscription'}
              </Button>
            </div>
          </div>
        )}

        {status === 'failed' && (
          <div className="rounded-2xl bg-destructive/10 border-2 border-destructive/30 p-4 text-sm text-destructive font-medium">
            {hi ? 'यह भुगतान अस्वीकार कर दिया गया। कृपया एडमिन से संपर्क करें।' : 'This payment was rejected. Please contact the admin.'}
          </div>
        )}

        {/* Desktop can't open a UPI app — show a QR instead. Mobile users were
            already handed off to their UPI app, so only verification is shown. */}
        {!mobile && upiUrl && isOpen && (
          <div className="bg-card rounded-3xl shadow-xl border border-border/50 p-4 flex flex-col items-center gap-3">
            <QRCodeCanvas value={upiUrl} size={192} includeMargin={false} />
            <p className="text-xs text-muted-foreground text-center">
              {hi ? 'किसी भी UPI ऐप से यह QR स्कैन करें' : 'Scan this QR with any UPI app'}
            </p>
          </div>
        )}

        {mobile && upiUrl && isOpen && (
          <Button
            variant="outline"
            onClick={() => openUpiApp(upiUrl)}
            disabled={expired}
            className="w-full gap-2 h-12 rounded-xl font-semibold"
          >
            <Wallet className="h-4 w-4" />
            {hi ? 'UPI ऐप नहीं खुला? दोबारा खोलें' : "UPI app didn't open? Try again"}
          </Button>
        )}

        {(isOpen || status === 'verifying') && (
          <div className="bg-card rounded-3xl shadow-xl border-2 border-primary/20 overflow-hidden">
            <div className="bg-gradient-to-r from-primary/5 to-accent/5 p-4 border-b border-border/50">
              <h3 className="font-bold text-lg">{hi ? '🔎 भुगतान सत्यापित करें' : '🔎 Verify payment'}</h3>
              <p className="text-xs text-muted-foreground mt-1">
                {hi
                  ? 'भुगतान के बाद UPI ऐप में दिख रहा UTR / ट्रांज़ैक्शन ID यहाँ डालें'
                  : 'Enter the UTR / transaction ID shown in your UPI app after paying'}
              </p>
            </div>
            <div className="p-4 space-y-3">
              <Input
                value={utr}
                onChange={(e) => setUtr(e.target.value.toUpperCase().replace(/\s/g, ''))}
                placeholder={hi ? 'UTR / ट्रांज़ैक्शन ID' : 'UTR / transaction ID'}
                maxLength={24}
                inputMode="numeric"
                className="h-12 text-center text-lg font-bold tracking-widest rounded-xl"
              />
              <Button onClick={verify} disabled={submitting || expired || !utr.trim()} className="w-full h-12 rounded-xl">
                {submitting ? <Loader2 className="h-5 w-5 animate-spin" /> : (hi ? 'सत्यापित करें' : 'Verify')}
              </Button>
              {waNumber && (
                <a
                  href={`https://wa.me/${waNumber}?text=${encodeURIComponent(
                    `${hi ? 'नमस्ते, मेरा पेमेंट ऑर्डर' : 'Hello, my payment order'} ${order.order_ref} (₹${order.amount})`
                  )}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center justify-center gap-2 h-12 rounded-xl border-2 border-emerald-500/40 bg-emerald-50 dark:bg-emerald-950/20 text-emerald-700 dark:text-emerald-300 font-semibold text-sm"
                >
                  <MessageCircle className="h-4 w-4" />
                  {hi ? 'एडमिन से WhatsApp पर बात करें' : 'Chat with admin on WhatsApp'}
                </a>
              )}
            </div>

          </div>
        )}

        {(expired || status === 'expired' || status === 'failed') && (
          <Button variant="outline" className="w-full h-12 rounded-xl" onClick={() => navigate('/payment-required')}>
            {hi ? 'नया ऑर्डर बनाएं' : 'Create a new order'}
          </Button>
        )}
      </main>
    </div>
  );
};

export default PayOrder;

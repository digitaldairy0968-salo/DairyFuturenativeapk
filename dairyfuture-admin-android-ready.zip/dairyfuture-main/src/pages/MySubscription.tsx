import React from 'react';
import { useNavigate } from 'react-router-dom';
import { ArrowLeft, Sparkles } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useLanguage } from '@/contexts/LanguageContext';
import { useSettingsBootstrap, daysLeftFrom } from '@/lib/settingsBootstrap';
import { HelpVideoCard } from '@/components/HelpVideoWidget';

const MySubscription: React.FC = () => {
  const { language } = useLanguage();
  const hi = language === 'hi';
  const navigate = useNavigate();
  const { data: boot } = useSettingsBootstrap();
  const daysLeft = daysLeftFrom(boot);
  const sub = boot?.subscription ?? null;

  const isActive = sub?.status === 'active' && (!sub?.expires_at || new Date(sub.expires_at) > new Date());

  return (
    <div className="min-h-screen bg-gradient-to-b from-background to-muted/30">
      <div className="relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-primary via-primary/90 to-accent/80" />
        <div className="relative px-4 py-5">
          <div className="flex items-center gap-3">
            <Button variant="ghost" size="icon" onClick={() => navigate('/settings')} className="text-primary-foreground hover:bg-primary-foreground/20">
              <ArrowLeft className="h-5 w-5" />
            </Button>
            <h1 className="text-xl font-bold text-primary-foreground flex-1">
              {hi ? 'मेरी सब्सक्रिप्शन' : 'My Subscription'}
            </h1>
          </div>
        </div>
      </div>

      <main className="px-4 py-5 max-w-md mx-auto space-y-4 -mt-2">
        <HelpVideoCard />

        <div className="bg-card rounded-3xl shadow-xl border border-border/50 p-5">
          <div className="flex items-center gap-3 mb-3">
            <div className="w-11 h-11 rounded-2xl bg-primary/10 flex items-center justify-center">
              <Sparkles className="h-5 w-5 text-primary" />
            </div>
            <div className="flex-1">
              <p className="font-bold text-foreground">
                {isActive ? (hi ? 'सक्रिय प्लान' : 'Active plan') : (hi ? 'कोई सक्रिय प्लान नहीं' : 'No active plan')}
              </p>
              <p className="text-xs text-muted-foreground">
                {sub?.expires_at
                  ? `${hi ? 'समाप्ति' : 'Expires'}: ${new Date(sub.expires_at).toLocaleDateString('en-IN')}`
                  : (hi ? 'भुगतान करके शुरू करें' : 'Subscribe to get started')}
              </p>
            </div>
          </div>
          {daysLeft !== null && isActive && (
            <div className="rounded-2xl bg-primary/10 border border-primary/20 px-4 py-3 text-center">
              <p className="text-4xl font-black text-primary">{daysLeft}</p>
              <p className="text-xs text-muted-foreground font-medium">{hi ? 'दिन बचे हैं' : 'days remaining'}</p>
            </div>
          )}
          <Button className="w-full h-12 rounded-xl mt-4" onClick={() => navigate(isActive ? '/subscription-renewal' : '/payment-required')}>
            {isActive ? (hi ? 'प्लान बढ़ाएं' : 'Extend plan') : (hi ? 'प्लान लें' : 'Get a plan')}
          </Button>
        </div>
      </main>
    </div>
  );
};

export default MySubscription;

import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { ArrowLeft, Package, Plus, Trash2, Check, Ban, X, RefreshCw } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Switch } from '@/components/ui/switch';

import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';
import { readAdminCache, cacheRemoveRow, cachePatchRow, clearAdminDelta, writeAdminCache } from '@/lib/adminCache';

const CACHE_VARIETIES = 'subscription_varieties';
const CACHE_PLANS = 'variety_plans';


interface Variety {
  id: string;
  name: string;
  description: string | null;
  features: string[];
  excluded_features: string[];
  is_active: boolean;
  unlocks_customer_code: boolean;
}


interface VarietyPlan {
  id: string;
  variety_id: string;
  name: string;
  price: number;
  validity_days: number;
  is_active: boolean;
}

const AdminPlans: React.FC = () => {
  const navigate = useNavigate();
  const [varieties, setVarieties] = useState<Variety[]>(
    () => readAdminCache<Variety>(CACHE_VARIETIES) ?? []
  );
  const [plans, setPlans] = useState<VarietyPlan[]>(
    () => readAdminCache<VarietyPlan>(CACHE_PLANS) ?? []
  );
  const [loading, setLoading] = useState(() => !readAdminCache(CACHE_VARIETIES));
  const [syncing, setSyncing] = useState(false);

  // New variety form
  const [newName, setNewName] = useState('');
  const [newDesc, setNewDesc] = useState('');
  const [newFeaturesText, setNewFeaturesText] = useState('');
  const [newExcludedText, setNewExcludedText] = useState('');
  const [newUnlocksCode, setNewUnlocksCode] = useState(false);


  const [saving, setSaving] = useState(false);

  // New plan form
  const [selectedVariety, setSelectedVariety] = useState<string | null>(null);
  const [planPrice, setPlanPrice] = useState('');
  const [planDays, setPlanDays] = useState('30');
  const [savingPlan, setSavingPlan] = useState(false);

  useEffect(() => {
    // Cache-only: subscription_varieties / variety_plans sirf admin hi badalta hai,
    // isliye background delta-check nahi — sirf pehli baar (cache khaali) full fetch.
    const hasCache = !!readAdminCache(CACHE_VARIETIES);
    if (!hasCache) fetchData(true);
    else setLoading(false);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  /** Full fetch (pehli baar ya manual refresh). Koi background delta-check nahi. */
  const fetchData = async (_force = true) => {
    setSyncing(true);
    try {
      clearAdminDelta(CACHE_VARIETIES);
      clearAdminDelta(CACHE_PLANS);
      const [vRes, pRes] = await Promise.all([
        supabase.from('subscription_varieties').select('*').order('created_at', { ascending: true }),
        supabase.from('variety_plans').select('*').order('price', { ascending: true }),
      ]);
      if (vRes.error) throw vRes.error;
      if (pRes.error) throw pRes.error;

      const mappedVarieties: Variety[] = (vRes.data || []).map((v: any) => ({
        ...v,
        features: Array.isArray(v.features) ? v.features : [],
        excluded_features: Array.isArray(v.excluded_features) ? v.excluded_features : [],
        unlocks_customer_code: !!v.unlocks_customer_code,
      }));

      setVarieties(mappedVarieties);
      writeAdminCache(CACHE_VARIETIES, mappedVarieties);
      const sortedPlans = [...((pRes.data as VarietyPlan[]) || [])].sort((a, b) => a.price - b.price);
      setPlans(sortedPlans);
      writeAdminCache(CACHE_PLANS, sortedPlans);
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
      setSyncing(false);
    }
  };


  const addVariety = async () => {
    if (!newName.trim()) return;
    setSaving(true);
    try {
      const { error } = await supabase.from('subscription_varieties').insert({
        name: newName.trim(),
        description: newDesc.trim() || null,
        features: newFeaturesText
          .split('\n')
          .map(l => l.trim())
          .filter(Boolean),
        excluded_features: newExcludedText
          .split('\n')
          .map(l => l.trim())
          .filter(Boolean),
        unlocks_customer_code: newUnlocksCode,
      } as any);
      if (error) throw error;
      toast.success('Plan added');
      setNewName(''); setNewDesc(''); setNewFeaturesText(''); setNewExcludedText(''); setNewUnlocksCode(false);

      fetchData();

    } catch (e) {
      toast.error('Failed to add plan');
    } finally {
      setSaving(false);
    }
  };

  const deleteVariety = async (id: string) => {
    if (!confirm('Delete this plan and all its varieties?')) return;
    try {
      await supabase.from('subscription_varieties').delete().eq('id', id);
      toast.success('Plan deleted');
      cacheRemoveRow(CACHE_VARIETIES, id);
      setVarieties(prev => prev.filter(v => v.id !== id));
      const removedPlans = plans.filter(p => p.variety_id === id);
      removedPlans.forEach(p => cacheRemoveRow(CACHE_PLANS, p.id));
      setPlans(prev => prev.filter(p => p.variety_id !== id));
    } catch (e) {
      toast.error('Failed');
    }
  };

  const toggleVariety = async (id: string, active: boolean) => {
    await supabase.from('subscription_varieties').update({ is_active: active }).eq('id', id);
    cachePatchRow(CACHE_VARIETIES, id, { is_active: active });
    setVarieties(prev => prev.map(v => (v.id === id ? { ...v, is_active: active } : v)));
  };

  const toggleUnlocksCode = async (id: string, enabled: boolean) => {
    const { error } = await supabase
      .from('subscription_varieties')
      .update({ unlocks_customer_code: enabled } as any)
      .eq('id', id);
    if (error) { toast.error('Failed'); return; }
    cachePatchRow(CACHE_VARIETIES, id, { unlocks_customer_code: enabled } as any);
    setVarieties(prev => prev.map(v => (v.id === id ? { ...v, unlocks_customer_code: enabled } : v)));
  };


  const addPlan = async () => {
    if (!selectedVariety || !planPrice) return;
    setSavingPlan(true);
    try {
      const { error } = await supabase.from('variety_plans').insert({
        variety_id: selectedVariety,
        name: planDays === '365' ? '1 Year' : '1 Month',
        price: parseFloat(planPrice) || 100,
        validity_days: parseInt(planDays) || 30,
      });
      if (error) throw error;
      toast.success('Variety added');
      setPlanPrice(''); setPlanDays('30');
      fetchData();
    } catch (e) {
      toast.error('Failed');
    } finally {
      setSavingPlan(false);
    }
  };

  const deletePlan = async (id: string) => {
    await supabase.from('variety_plans').delete().eq('id', id);
    cacheRemoveRow(CACHE_PLANS, id);
    setPlans(prev => prev.filter(p => p.id !== id));
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <div className="w-12 h-12 border-4 border-primary border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <header className="dairy-header px-4 py-4">
        <div className="flex items-center gap-3">
          <Button variant="ghost" size="icon" onClick={() => navigate('/admin')} className="text-primary-foreground hover:bg-primary-foreground/20">
            <ArrowLeft className="h-5 w-5" />
          </Button>
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-primary-foreground/20 rounded-full flex items-center justify-center">
              <Package className="w-5 h-5" />
            </div>
            <div>
              <h1 className="text-xl font-bold">Subscription Plans</h1>
              <p className="text-primary-foreground/70 text-sm">Manage plans & varieties</p>
            </div>
          </div>
          <Button
            variant="ghost"
            size="icon"
            onClick={() => fetchData(true)}
            disabled={syncing}
            className="ml-auto text-primary-foreground hover:bg-primary-foreground/20"
          >
            <RefreshCw className={`h-5 w-5 ${syncing ? 'animate-spin' : ''}`} />
          </Button>
        </div>
      </header>

      <main className="px-4 py-6 max-w-2xl mx-auto space-y-6">
        {/* Add Variety */}
        <div className="dairy-card space-y-4">
          <h3 className="font-semibold flex items-center gap-2 text-base">
            <Plus className="h-4 w-4" /> Add New Plan
          </h3>

          <div className="space-y-1.5">
            <Label className="text-xs font-medium">Plan Name *</Label>
            <Input value={newName} onChange={e => setNewName(e.target.value)} placeholder="e.g. Basic, Pro, Premium" />
          </div>

          <div className="space-y-1.5">
            <Label className="text-xs font-medium">Description</Label>
            <Input value={newDesc} onChange={e => setNewDesc(e.target.value)} placeholder="Short description (optional)" />
          </div>

          <div className="space-y-1.5">
            <Label className="text-xs font-medium block">Features (one per line)</Label>
            <Textarea
              value={newFeaturesText}
              onChange={e => setNewFeaturesText(e.target.value)}
              placeholder={"All core app features\nUnlimited Suppliers\nSupplier Login\n24/7 Support"}
              rows={6}
              className="text-sm"
            />
            <p className="text-[11px] text-muted-foreground">
              Each line becomes one feature bullet on the subscription page.
            </p>
          </div>

          <div className="space-y-1.5">
            <Label className="text-xs font-medium block">Features NOT included (one per line)</Label>
            <Textarea
              value={newExcludedText}
              onChange={e => setNewExcludedText(e.target.value)}
              placeholder={"Bluetooth printer\nVoice entry\nPDF reports"}
              rows={4}
              className="text-sm"
            />
            <p className="text-[11px] text-muted-foreground">
              These show crossed-out on the subscription page.
            </p>
          </div>

          <div className="flex items-center justify-between gap-3 rounded-lg border p-3">
            <div>
              <Label className="text-xs font-medium">Unlocks 12-Digit Customer Code feature</Label>
              <p className="text-[11px] text-muted-foreground">
                On karne par is plan ko lene wali dairy me customer code feature apne aap chalu ho jayega.
              </p>
            </div>
            <Switch checked={newUnlocksCode} onCheckedChange={setNewUnlocksCode} />
          </div>



          <Button onClick={addVariety} disabled={saving || !newName.trim()} className="w-full gap-2">
            <Plus className="h-4 w-4" />
            {saving ? 'Adding...' : 'Add Plan'}
          </Button>
        </div>

        {/* Existing Varieties */}
        {varieties.map(v => (
          <div key={v.id} className="dairy-card space-y-3">
            <div className="flex items-start justify-between">
              <div>
                <h3 className="font-bold text-lg">{v.name}</h3>
                {v.description && <p className="text-sm text-muted-foreground">{v.description}</p>}
                {v.features.length > 0 && (
                  <ul className="mt-2 space-y-1">
                    {v.features.map((f: string, i: number) => (
                      <li key={i} className="text-xs text-muted-foreground flex items-start gap-1.5">
                        <Check className="h-3 w-3 mt-0.5 text-primary shrink-0" />
                        <span>{f}</span>
                      </li>
                    ))}
                  </ul>
                )}
                {v.excluded_features.length > 0 && (
                  <ul className="mt-1 space-y-1">
                    {v.excluded_features.map((f: string, i: number) => (
                      <li key={i} className="text-xs text-muted-foreground flex items-start gap-1.5">
                        <X className="h-3 w-3 mt-0.5 text-destructive shrink-0" />
                        <span className="line-through">{f}</span>
                      </li>
                    ))}
                  </ul>
                )}
              </div>
              <div className="flex gap-1">
                <Button variant="ghost" size="icon" onClick={() => toggleVariety(v.id, !v.is_active)}>
                  {v.is_active ? <Check className="h-4 w-4 text-green-600" /> : <Ban className="h-4 w-4 text-muted-foreground" />}
                </Button>
                <Button variant="ghost" size="icon" onClick={() => deleteVariety(v.id)}>
                  <Trash2 className="h-4 w-4 text-destructive" />
                </Button>
              </div>
            </div>

            <div className="flex items-center justify-between gap-3 rounded-lg border p-2.5">
              <Label className="text-xs font-medium">Unlocks 12-Digit Customer Code feature</Label>
              <Switch
                checked={!!v.unlocks_customer_code}
                onCheckedChange={(val) => toggleUnlocksCode(v.id, val)}
              />
            </div>



            {/* Plans for this variety */}
            <div className="border-t pt-3 space-y-2">
              <p className="text-sm font-semibold">Varieties:</p>
              {plans.filter(p => p.variety_id === v.id).length === 0 ? (
                <p className="text-xs text-muted-foreground">No varieties yet</p>
              ) : (
                plans.filter(p => p.variety_id === v.id).map(plan => (
                  <div key={plan.id} className="flex items-center justify-between p-2 bg-muted/50 rounded-lg">
                    <div>
                      <span className="font-medium">{plan.name}</span>
                      <span className="text-sm text-muted-foreground ml-2">₹{plan.price} • {plan.validity_days >= 365 ? '1 Year' : '1 Month'}</span>
                    </div>
                    <Button variant="ghost" size="icon" onClick={() => deletePlan(plan.id)}>
                      <Trash2 className="h-3 w-3 text-destructive" />
                    </Button>
                  </div>
                ))
              )}

              {/* Quick add plan */}
              {selectedVariety === v.id ? (
                <div className="space-y-2">
                  <Input type="number" value={planPrice} onChange={e => setPlanPrice(e.target.value)} placeholder="₹ Price" className="text-sm" />
                  <div className="flex gap-2">
                    <Select value={planDays} onValueChange={setPlanDays}>
                      <SelectTrigger className="text-sm h-9">
                        <SelectValue placeholder="Validity" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="30">1 Month</SelectItem>
                        <SelectItem value="365">1 Year</SelectItem>
                      </SelectContent>
                    </Select>
                    <Button size="sm" onClick={addPlan} disabled={savingPlan || !planPrice}>
                      <Plus className="h-3 w-3" />
                    </Button>
                  </div>
                </div>
              ) : (
                <Button variant="outline" size="sm" onClick={() => setSelectedVariety(v.id)} className="w-full text-xs gap-1">
                  <Plus className="h-3 w-3" /> Add Variety
                </Button>
              )}
            </div>
          </div>
        ))}

        {varieties.length === 0 && (
          <p className="text-center text-muted-foreground py-8">No plans created yet. Add one above.</p>
        )}
      </main>
    </div>
  );
};

export default AdminPlans;

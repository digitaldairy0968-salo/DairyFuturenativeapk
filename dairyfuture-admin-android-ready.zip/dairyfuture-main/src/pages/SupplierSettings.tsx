import React from 'react';
import { Globe, LogOut } from 'lucide-react';
import { Button } from '@/components/ui/button';
import Header from '@/components/Header';
import BottomNav from '@/components/BottomNav';
import { useLanguage } from '@/contexts/LanguageContext';
import { useAuth } from '@/contexts/AuthContext';
import { useNavigate } from 'react-router-dom';
import { cn } from '@/lib/utils';

type Language = 'hi' | 'gu' | 'en';

const SupplierSettings: React.FC = () => {
  const { t, language, setLanguage } = useLanguage();
  const { logout, user } = useAuth();
  const navigate = useNavigate();

  const languages: { code: Language; name: string; nativeName: string }[] = [
    { code: 'hi', name: 'Hindi', nativeName: 'हिंदी' },
    { code: 'gu', name: 'Gujarati', nativeName: 'ગુજરાતી' },
    { code: 'en', name: 'English', nativeName: 'English' },
  ];

  const handleLogout = () => {
    logout();
    navigate('/auth');
  };

  return (
    <div className="min-h-screen bg-background pb-24">
      <Header />

      <main className="px-4 py-6 max-w-4xl mx-auto space-y-6">
        <h2 className="text-xl font-bold">{t('settings')}</h2>

        {/* Dairy Info */}
        {user?.dairyName && (
          <div className="dairy-card animate-fade-in">
            <div className="flex items-center gap-3 mb-2">
              <span className="text-3xl">🏭</span>
              <div>
                <p className="font-semibold">{user.dairyName}</p>
                <p className="text-sm text-muted-foreground">
                  कोड: {user.dairyCode}
                </p>
              </div>
            </div>
          </div>
        )}

        {/* Language Settings */}
        <div className="dairy-card animate-fade-in">
          <div className="flex items-center gap-3 mb-4">
            <div className="p-3 bg-primary/10 rounded-xl">
              <Globe className="h-6 w-6 text-primary" />
            </div>
            <h3 className="text-lg font-semibold">{t('language')}</h3>
          </div>

          <div className="grid grid-cols-3 gap-3">
            {languages.map(lang => (
              <button
                key={lang.code}
                onClick={() => setLanguage(lang.code)}
                className={cn(
                  'py-4 px-3 rounded-xl border-2 transition-all duration-200 text-center',
                  language === lang.code
                    ? 'border-primary bg-primary/10'
                    : 'border-border hover:border-primary/50'
                )}
              >
                <p className="font-semibold text-lg">{lang.nativeName}</p>
                <p className="text-sm text-muted-foreground">{lang.name}</p>
              </button>
            ))}
          </div>
        </div>

        {/* Logout */}
        <Button
          variant="destructive"
          className="w-full py-6 text-lg animate-fade-in"
          style={{ animationDelay: '100ms' }}
          onClick={handleLogout}
        >
          <LogOut className="mr-2 h-5 w-5" />
          {t('logout')}
        </Button>
      </main>

      <BottomNav />
    </div>
  );
};

export default SupplierSettings;

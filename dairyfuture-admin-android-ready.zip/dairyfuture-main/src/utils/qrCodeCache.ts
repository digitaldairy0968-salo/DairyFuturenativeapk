// Cache QR code image in localStorage as base64. Bucket is private, so we
// mint a signed URL via the Supabase client and cache the resulting data URL.
import { supabase } from '@/integrations/supabase/client';

const CACHE_KEY = 'qr_code_data_url';
const URL_KEY = 'qr_code_source_url';
const BUCKET = 'qr-codes';

let memoryCache: string | null = null;

function extractStoragePath(url: string): string | null {
  if (!url) return null;
  // Matches both public and signed storage URLs and returns the object path
  const marker = `/object/`;
  const idx = url.indexOf(marker);
  if (idx === -1) return null;
  const rest = url.slice(idx + marker.length); // e.g. "public/qr-codes/foo.png" or "sign/qr-codes/foo.png?token=..."
  const parts = rest.split('/');
  if (parts.length < 3) return null;
  // parts[0] = "public" | "sign" | "authenticated"
  const bucket = parts[1];
  if (bucket !== BUCKET) return null;
  const pathWithQuery = parts.slice(2).join('/');
  return pathWithQuery.split('?')[0];
}

export function getCachedQRCode(sourceUrl?: string | null): string | null {
  if (!sourceUrl) return null;
  const cachedUrl = localStorage.getItem(URL_KEY);
  if (cachedUrl && cachedUrl !== sourceUrl) {
    invalidateQRCache();
  }
  if (memoryCache) return memoryCache;
  const dataUrl = localStorage.getItem(CACHE_KEY);
  if (dataUrl) {
    memoryCache = dataUrl;
    return dataUrl;
  }
  return null;
}

export async function fetchAndCacheQRCode(sourceUrl: string): Promise<string | null> {
  if (!sourceUrl) return null;

  const cachedUrl = localStorage.getItem(URL_KEY);
  if (cachedUrl !== sourceUrl) {
    invalidateQRCache();
  }

  if (memoryCache) return memoryCache;
  const cached = localStorage.getItem(CACHE_KEY);
  if (cached) {
    memoryCache = cached;
    return cached;
  }

  try {
    const path = extractStoragePath(sourceUrl);
    let fetchUrl = sourceUrl;
    if (path) {
      const { data, error } = await supabase.storage
        .from(BUCKET)
        .createSignedUrl(path, 60 * 60);
      if (!error && data?.signedUrl) fetchUrl = data.signedUrl;
    }
    const response = await fetch(fetchUrl);
    const blob = await response.blob();
    const dataUrl = await blobToDataUrl(blob);
    localStorage.setItem(CACHE_KEY, dataUrl);
    localStorage.setItem(URL_KEY, sourceUrl);
    memoryCache = dataUrl;
    return dataUrl;
  } catch {
    return null;
  }
}

function blobToDataUrl(blob: Blob): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onloadend = () => resolve(reader.result as string);
    reader.onerror = reject;
    reader.readAsDataURL(blob);
  });
}

export function invalidateQRCache() {
  memoryCache = null;
  localStorage.removeItem(CACHE_KEY);
  localStorage.removeItem(URL_KEY);
}

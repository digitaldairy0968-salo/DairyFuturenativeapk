import React from 'react';
import { Check, Sparkles, X, Play, Percent } from 'lucide-react';
import { cn } from '@/lib/utils';
import { Button } from '@/components/ui/button';

export function durationLabel(days: number, hi: boolean) {
  if (days >= 365) return hi ? '1 साल' : '1 year';
  if (days >= 28) return hi ? '1 महीना' : '1 month';
  return `${days} ${hi ? 'दिन' : 'days'}`;
}

export type PlanDuration = 'monthly' | 'yearly';

export function matchesDuration(days: number, duration: PlanDuration) {
  return duration === 'yearly' ? days >= 365 : days < 365;
}

export interface PlanCardsProps {
  /** Plans (subscription_varieties rows) */
  plans: any[];
  /** Varieties = duration/price options (variety_plans rows) */
  varieties: any[];
  selectedVarietyId?: string | null;
  onSelect: (variety: any, plan: any) => void;
  hi: boolean;
  /** monthly / yearly toggle value */
  duration?: PlanDuration;
  onDurationChange?: (d: PlanDuration) => void;
  /** Optional free-demo card rendered BELOW the plan cards */
  demo?: {
    days: number;
    onStart: () => void;
    loading?: boolean;
  };
}

const ACCENTS = [
  'from-sky-500 to-cyan-500',
  'from-blue-600 to-indigo-600',
  'from-amber-500 to-yellow-500',
  'from-emerald-500 to-teal-600',
];

const PlanCards: React.FC<PlanCardsProps> = ({
  plans, varieties, selectedVarietyId, onSelect, hi, demo,
  duration = 'monthly', onDurationChange,
}) => {
  const withOptions = plans
    .map((p) => ({
      plan: p,
      option: varieties
        .filter((v: any) => v.variety_id === p.id && matchesDuration(Number(v.validity_days) || 0, duration))
        .sort((a: any, b: any) => Number(a.price) - Number(b.price))[0] ?? null,
    }))
    .filter((x) => !!x.option);

  const cheapest = withOptions.length
    ? Math.min(...withOptions.map((x) => Number(x.option.price) || 0))
    : 0;

  // Build a map of planId -> savings when yearly is selected vs monthly equivalent
  const savingsByPlan = React.useMemo(() => {
    const map: Record<string, { amount: number; percent: number } | null> = {};
    plans.forEach((p) => {
      const monthly = varieties
        .filter((v: any) => v.variety_id === p.id && matchesDuration(Number(v.validity_days) || 0, 'monthly'))
        .sort((a: any, b: any) => Number(a.price) - Number(b.price))[0];
      const yearly = varieties
        .filter((v: any) => v.variety_id === p.id && matchesDuration(Number(v.validity_days) || 0, 'yearly'))
        .sort((a: any, b: any) => Number(a.price) - Number(b.price))[0];
      if (monthly && yearly) {
        const annualMonthly = Number(monthly.price) * 12;
        const amount = annualMonthly - Number(yearly.price);
        const percent = annualMonthly > 0 ? Math.round((amount / annualMonthly) * 100) : 0;
        map[p.id] = { amount: Math.max(0, amount), percent: Math.max(0, percent) };
      } else {
        map[p.id] = null;
      }
    });
    return map;
  }, [plans, varieties]);

  const demoFeatures = hi
    ? ['सभी फीचर्स फ्री में आज़माएं', 'कोई भुगतान नहीं', 'कभी भी प्लान अपग्रेड करें']
    : ['Try all features for free', 'No payment needed', 'Upgrade anytime'];

  return (
    <div className="space-y-3">
      {onDurationChange && (
        <div className="flex justify-center">
          <div className="inline-flex bg-muted rounded-full p-0.5">
            {(['monthly', 'yearly'] as PlanDuration[]).map((d) => (
              <button
                key={d}
                onClick={() => onDurationChange(d)}
                className={cn(
                  'px-4 py-1.5 rounded-full text-xs font-bold transition-all',
                  duration === d ? 'bg-primary text-primary-foreground shadow' : 'text-muted-foreground'
                )}
              >
                {d === 'monthly' ? (hi ? 'मासिक' : 'Monthly') : (hi ? 'वार्षिक' : 'Yearly')}
              </button>
            ))}
          </div>
        </div>
      )}

      {duration === 'yearly' && withOptions.length > 0 && (
        <p className="text-center text-xs text-emerald-600 dark:text-emerald-400 font-medium">
          {hi ? 'वार्षिक प्लान पर अतिरिक्त बचत' : 'Extra savings on yearly plans'}
        </p>
      )}

      {withOptions.length === 0 && (
        <p className="text-center text-sm text-muted-foreground py-8">
          {hi ? 'इस अवधि के लिए कोई प्लान उपलब्ध नहीं है' : 'No plans available for this duration'}
        </p>
      )}

      <div className="grid gap-3">
        {withOptions.map(({ plan, option }, idx) => {
          const accent = ACCENTS[idx % ACCENTS.length];
          const features: string[] = Array.isArray(plan.features) ? plan.features : [];
          const excluded: string[] = Array.isArray(plan.excluded_features) ? plan.excluded_features : [];
          const best = Number(option.price) > cheapest && idx === withOptions.length - 1;
          const isSel = selectedVarietyId === option.id;
          const savings = duration === 'yearly' ? savingsByPlan[plan.id] : null;

          return (
            <div
              key={plan.id}
              onClick={() => onSelect(option, plan)}
              className={cn(
                'relative rounded-2xl bg-card border shadow overflow-hidden active:scale-[0.99] transition-transform',
                best ? 'border-2 border-amber-400' : 'border-border/50',
                isSel && 'ring-2 ring-primary'
              )}
            >
              {best && (
                <div className="absolute top-2 right-2 z-10 flex items-center gap-1 rounded-full bg-amber-100 dark:bg-amber-900/40 px-2 py-0.5 text-[10px] font-bold text-amber-700 dark:text-amber-300">
                  <Sparkles className="h-3 w-3" />
                  {hi ? 'सबसे बेहतर' : 'BEST'}
                </div>
              )}

              <div className={cn('bg-gradient-to-r px-3 py-2', accent)}>
                <p className="text-sm font-extrabold uppercase tracking-wide text-white">{plan.name}</p>
                {plan.description && <p className="text-[10px] text-white/85 leading-tight">{plan.description}</p>}
              </div>

              <div className="p-3 space-y-2">
                <div className="flex items-center justify-between gap-2">
                  <div className="text-left">
                    <p className="text-2xl font-black text-foreground leading-none">
                      ₹{option.price}
                    </p>
                    <p className="text-[10px] text-muted-foreground">
                      / {durationLabel(Number(option.validity_days) || 0, hi)}
                    </p>
                  </div>
                  {savings && savings.amount > 0 && (
                    <div className="shrink-0 text-right">
                      <div className="inline-flex items-center gap-1 rounded-full bg-emerald-100 dark:bg-emerald-900/40 px-2 py-0.5 text-[10px] font-bold text-emerald-700 dark:text-emerald-300">
                        <Percent className="h-3 w-3" />
                        {hi ? `${savings.percent}% बचत` : `${savings.percent}% off`}
                      </div>
                      <p className="text-[10px] text-emerald-600 dark:text-emerald-400 mt-0.5">
                        {hi ? `₹${savings.amount} बचाएं` : `Save ₹${savings.amount}`}
                      </p>
                    </div>
                  )}
                </div>

                {(features.length > 0 || excluded.length > 0) && (
                  <ul className="grid grid-cols-1 gap-1">
                    {features.slice(0, 4).map((f, i) => (
                      <li key={i} className="flex items-start gap-1.5 text-xs text-foreground">
                        <Check className="h-3.5 w-3.5 mt-0.5 text-primary flex-shrink-0" />
                        <span className="truncate">{f}</span>
                      </li>
                    ))}
                    {excluded.slice(0, 2).map((f, i) => (
                      <li key={`x-${i}`} className="flex items-start gap-1.5 text-xs text-muted-foreground">
                        <X className="h-3.5 w-3.5 mt-0.5 text-destructive flex-shrink-0" />
                        <span className="truncate line-through">{f}</span>
                      </li>
                    ))}

                    {features.length > 4 && (
                      <li className="text-[10px] text-muted-foreground pl-5">
                        {hi ? `+${features.length - 4} और` : `+${features.length - 4} more`}
                      </li>
                    )}
                  </ul>
                )}

                <Button
                  onClick={(e) => {
                    e.stopPropagation();
                    onSelect(option, plan);
                  }}
                  className="w-full h-9 rounded-lg text-xs font-bold"
                >
                  {hi ? 'चुनें' : 'Select'}
                </Button>
              </div>
            </div>
          );
        })}
      </div>

      {demo && (
        <div
          onClick={demo.onStart}
          className="relative rounded-2xl bg-card border-2 border-dashed border-orange-300 dark:border-orange-700 shadow overflow-hidden active:scale-[0.99] transition-transform"
        >
          <div className="bg-gradient-to-r from-orange-500 to-amber-500 px-3 py-2">
            <p className="text-sm font-extrabold uppercase tracking-wide text-white">
              {hi ? 'डेमो प्लान' : 'DEMO PLAN'}
            </p>
            <p className="text-[10px] text-white/85 leading-tight">
              {hi ? 'फ्री ट्रायल — बिना भुगतान' : 'Free trial — no payment'}
            </p>
          </div>
          <div className="p-3 space-y-2">
            <div className="text-center">
              <p className="text-2xl font-black text-foreground leading-none">
                ₹0
              </p>
              <p className="text-[10px] text-muted-foreground">
                / {demo.days} {hi ? 'दिन' : 'days'}
              </p>
            </div>
            <ul className="grid grid-cols-1 gap-1">
              {demoFeatures.slice(0, 3).map((f, i) => (
                <li key={i} className="flex items-start gap-1.5 text-xs text-foreground">
                  <Check className="h-3.5 w-3.5 mt-0.5 text-primary flex-shrink-0" />
                  <span className="line-clamp-1">{f}</span>
                </li>
              ))}
            </ul>
            <Button
              variant="outline"
              onClick={(e) => {
                e.stopPropagation();
                demo.onStart();
              }}
              disabled={demo.loading}
              className="w-full h-9 rounded-lg text-xs font-bold border-orange-400 text-orange-700 hover:bg-orange-100 dark:text-orange-400 dark:hover:bg-orange-950"
            >
              {demo.loading ? (
                <div className="w-4 h-4 border-2 border-orange-600 border-t-transparent rounded-full animate-spin" />
              ) : (
                <>
                  <Play className="h-3.5 w-3.5 mr-1.5" />
                  {hi ? `${demo.days} दिन फ्री शुरू करें` : `Start ${demo.days} Days Free`}
                </>
              )}
            </Button>
          </div>
        </div>
      )}
    </div>
  );
};

export default PlanCards;

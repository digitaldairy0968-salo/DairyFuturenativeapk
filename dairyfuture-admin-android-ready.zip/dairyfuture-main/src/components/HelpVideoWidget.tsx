import React, { useState } from 'react';
import { Play, X, Youtube } from 'lucide-react';
import {
  Dialog,
  DialogContent,
  DialogTitle,
} from '@/components/ui/dialog';
import { useAuth } from '@/contexts/AuthContext';
import { useLanguage } from '@/contexts/LanguageContext';
import { readSettingsBootstrap, useSettingsBootstrap } from '@/lib/settingsBootstrap';

/** Extract the 11-char video id from any common YouTube URL form. */
export function youtubeIdFrom(url?: string | null): string | null {
  if (!url) return null;
  const m = url.match(/(?:youtu\.be\/|v=|embed\/|shorts\/)([A-Za-z0-9_-]{11})/);
  return m ? m[1] : (/^[A-Za-z0-9_-]{11}$/.test(url.trim()) ? url.trim() : null);
}

export function useHelpVideoId(): string | null {
  const { data } = useSettingsBootstrap(false); // cache-only, no extra network call
  const boot = data ?? readSettingsBootstrap();
  return youtubeIdFrom(boot?.settings?.youtube_url);
}

/** Inline card (used on the subscription page, above the plans). */
export const HelpVideoCard: React.FC<{ className?: string }> = ({ className }) => {
  const videoId = useHelpVideoId();
  const { language } = useLanguage();
  const hi = language === 'hi';
  const [play, setPlay] = useState(false);
  if (!videoId) return null;

  return (
    <div className={`rounded-2xl overflow-hidden border border-border/60 bg-card shadow-lg ${className ?? ''}`}>
      {play ? (
        <div className="relative w-full aspect-video">
          <iframe
            className="absolute inset-0 w-full h-full"
            src={`https://www.youtube.com/embed/${videoId}?autoplay=1`}
            title="Help video"
            allow="accelerometer; autoplay; clipboard-write; encrypted-media; picture-in-picture"
            allowFullScreen
          />
        </div>
      ) : (
        <button onClick={() => setPlay(true)} className="relative block w-full aspect-video">
          <img
            src={`https://img.youtube.com/vi/${videoId}/hqdefault.jpg`}
            alt={hi ? 'ऐप कैसे चलाएं — वीडियो' : 'How to use the app — video'}
            className="absolute inset-0 w-full h-full object-cover"
            loading="lazy"
          />
          <span className="absolute inset-0 flex items-center justify-center bg-foreground/25">
            <span className="w-12 h-12 rounded-full bg-destructive flex items-center justify-center shadow-xl">
              <Play className="h-6 w-6 text-primary-foreground ml-0.5" fill="currentColor" />
            </span>
          </span>
        </button>
      )}
      <div className="px-3 py-2">
        <p className="text-xs font-bold text-foreground">
          {hi ? 'ऐप कैसे इस्तेमाल करें' : 'How to use the app'}
        </p>
        <p className="text-[10px] text-muted-foreground">
          {hi ? 'छोटा वीडियो देखें' : 'Watch the short video'}
        </p>
      </div>
    </div>
  );
};

/** Tiny top-of-settings pill that opens the video in a dialog so it takes almost no space. */
export const HelpVideoMini: React.FC<{ className?: string }> = ({ className }) => {
  const videoId = useHelpVideoId();
  const { language } = useLanguage();
  const hi = language === 'hi';
  const [open, setOpen] = useState(false);
  if (!videoId) return null;

  return (
    <>
      <button
        onClick={() => setOpen(true)}
        className={`inline-flex items-center gap-2 rounded-full bg-card border border-border/60 shadow-sm pl-1 pr-3 py-1 active:scale-95 transition-transform ${className ?? ''}`}
        aria-label={hi ? 'ऐप कैसे इस्तेमाल करें' : 'How to use the app'}
      >
        <span className="relative w-9 h-9 rounded-full overflow-hidden shrink-0">
          <img
            src={`https://img.youtube.com/vi/${videoId}/default.jpg`}
            alt=""
            className="w-full h-full object-cover"
            loading="lazy"
          />
          <span className="absolute inset-0 flex items-center justify-center bg-foreground/25">
            <Play className="h-3.5 w-3.5 text-primary-foreground ml-0.5" fill="currentColor" />
          </span>
        </span>
        <span className="text-[11px] font-semibold text-foreground leading-tight text-left">
          {hi ? 'ऐप कैसे\nइस्तेमाल करें' : 'How to use\nthe app'}
        </span>
      </button>

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="max-w-md p-0 rounded-2xl overflow-hidden border-0 bg-black [&>button]:text-white">
          <DialogTitle className="sr-only">
            {hi ? 'ऐप कैसे इस्तेमाल करें' : 'How to use the app'}
          </DialogTitle>
          <div className="relative w-full aspect-video bg-black">
            <iframe
              className="absolute inset-0 w-full h-full"
              src={`https://www.youtube.com/embed/${videoId}?autoplay=1`}
              title="Help video"
              allow="accelerometer; autoplay; clipboard-write; encrypted-media; picture-in-picture"
              allowFullScreen
            />
          </div>
        </DialogContent>
      </Dialog>
    </>
  );
};

/**
 * Floating widget shown on every logged-in page (bottom-right, above the nav).
 * Collapsed it is a small thumbnail pill; tapping it opens the player.
 */
const HelpVideoWidget: React.FC = () => {
  const { isAuthenticated } = useAuth();
  const { language } = useLanguage();
  const hi = language === 'hi';
  const videoId = useHelpVideoId();
  const [open, setOpen] = useState(false);
  const [hidden, setHidden] = useState(false);

  if (!isAuthenticated || !videoId || hidden) return null;

  if (!open) {
    return (
      <button
        onClick={() => setOpen(true)}
        className="fixed right-3 bottom-24 z-40 flex items-center gap-2 rounded-2xl bg-card/95 backdrop-blur border border-border/60 shadow-xl pl-1.5 pr-2.5 py-1.5 active:scale-95 transition-transform"
      >
        <span className="relative w-14 h-9 rounded-xl overflow-hidden">
          <img
            src={`https://img.youtube.com/vi/${videoId}/default.jpg`}
            alt=""
            className="w-full h-full object-cover"
            loading="lazy"
          />
          <span className="absolute inset-0 flex items-center justify-center bg-foreground/25">
            <Play className="h-3.5 w-3.5 text-primary-foreground" fill="currentColor" />
          </span>
        </span>
        <span className="text-[10px] font-bold text-foreground leading-tight text-left">
          {hi ? 'मदद\nवीडियो' : 'Help\nvideo'}
        </span>
      </button>
    );
  }

  return (
    <div className="fixed right-3 bottom-24 z-40 w-[min(20rem,calc(100vw-1.5rem))] rounded-2xl overflow-hidden bg-card border border-border/60 shadow-2xl">
      <div className="flex items-center justify-between px-2.5 py-1.5 border-b border-border/60">
        <span className="flex items-center gap-1.5 text-[11px] font-bold text-foreground">
          <Youtube className="h-3.5 w-3.5 text-destructive" />
          {hi ? 'मदद वीडियो' : 'Help video'}
        </span>
        <div className="flex items-center gap-1">
          <button onClick={() => setOpen(false)} className="text-muted-foreground p-1 text-[10px] font-semibold">
            {hi ? 'छोटा' : 'Min'}
          </button>
          <button onClick={() => setHidden(true)} className="text-muted-foreground p-1" aria-label="close">
            <X className="h-3.5 w-3.5" />
          </button>
        </div>
      </div>
      <div className="relative w-full aspect-video">
        <iframe
          className="absolute inset-0 w-full h-full"
          src={`https://www.youtube.com/embed/${videoId}?autoplay=1`}
          title="Help video"
          allow="accelerometer; autoplay; clipboard-write; encrypted-media; picture-in-picture"
          allowFullScreen
        />
      </div>
    </div>
  );
};

export default HelpVideoWidget;

import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { LogOut, Settings, Calculator, Menu, Droplets, MessageCircle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useAuth } from '@/contexts/AuthContext';
import { useLanguage } from '@/contexts/LanguageContext';
import { getCachedAuthImage, fetchAndCacheAuthImage } from '@/utils/authImageCache';
import { readSettingsBootstrap, useSettingsBootstrap, loadSettingsBootstrap } from '@/lib/settingsBootstrap';
import SubscriptionReminder from '@/components/SubscriptionReminder';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';

const Header: React.FC = () => {
  const { user, logout, isAdmin } = useAuth();
  const { t, language } = useLanguage();
  const navigate = useNavigate();
  const [authImageUrl, setAuthImageUrl] = useState<string | null>(getCachedAuthImage);
  // cache-only read (no extra network call) for the admin's WhatsApp number
  const { data: boot } = useSettingsBootstrap(false);
  const adminPhone = ((boot ?? readSettingsBootstrap())?.contact?.admin_phone ?? '').replace(/\D/g, '');
  const waNumber = adminPhone ? (adminPhone.length === 10 ? `91${adminPhone}` : adminPhone) : '';
  const showWhatsApp = !isAdmin && user?.role === 'owner' && !!waNumber;
  const waText =
    language === 'hi'
      ? 'नमस्ते, मुझे डेयरी ऐप के बारे में मदद चाहिए।'
      : 'Hello, I need help with the Dairy app.';

  useEffect(() => {
    if (!authImageUrl) {
      fetchAndCacheAuthImage().then((url) => {
        if (url) setAuthImageUrl(url);
      });
    }
  }, []);

  // Owner ke WhatsApp button ke liye admin ka number chahiye: agar cache me nahi
  // hai to session me sirf ek baar bootstrap load karo (session-guard ke andar).
  useEffect(() => {
    if (isAdmin || user?.role !== 'owner') return;
    if (waNumber) return;
    loadSettingsBootstrap();
  }, [isAdmin, user?.role, waNumber]);


  const handleLogout = () => {
    logout();
    navigate('/auth');
  };

  return (
    <>
      <header className="dairy-header sticky top-0 z-50 px-3 py-2.5 shadow-lg">
      <div className="flex items-center justify-between max-w-4xl mx-auto">
        <div className="flex items-center gap-2.5">
          {authImageUrl ? (
            <img src={authImageUrl} alt="Dairy" className="w-9 h-9 rounded-xl object-cover shadow-sm" />
          ) : (
            <div className="w-9 h-9 bg-primary-foreground/20 rounded-xl flex items-center justify-center shadow-sm backdrop-blur-sm">
              <Droplets className="w-5 h-5 text-primary-foreground" />
            </div>
          )}
          <div>
            <h1 className="text-base font-bold flex items-center gap-1">
              {t('appName')}
              <span className="text-sm">✨</span>
            </h1>
            {user && (
              <p className="text-[10px] text-primary-foreground/80 font-medium -mt-0.5">
                {t('welcome')}, {user.name}
              </p>
            )}
          </div>
        </div>

        <div className="flex items-center gap-0.5">
          {showWhatsApp && (
            <a
              href={`https://wa.me/${waNumber}?text=${encodeURIComponent(waText)}`}
              target="_blank"
              rel="noopener noreferrer"
              aria-label="WhatsApp"
              className="h-8 w-8 rounded-xl flex items-center justify-center bg-primary-foreground/20 hover:bg-primary-foreground/35 border border-primary-foreground/25 shadow-sm active:scale-95 transition-all mr-0.5"
            >
              <MessageCircle className="h-4 w-4 text-primary-foreground" />
            </a>
          )}
          <Button
            variant="ghost"
            size="icon-sm"
            onClick={() => navigate('/calculator')}
            className="text-primary-foreground hover:bg-primary-foreground/15 rounded-xl h-8 w-8"
          >
            <Calculator className="h-4 w-4" />
          </Button>

          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button
                variant="ghost"
                size="icon-sm"
                className="text-primary-foreground hover:bg-primary-foreground/15 rounded-xl h-8 w-8"
              >
                <Menu className="h-4 w-4" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-48 p-1.5 bg-popover border border-border/60 shadow-xl rounded-2xl">
              <DropdownMenuItem 
                onClick={() => navigate('/settings')}
                className="rounded-xl py-2.5 px-3 cursor-pointer font-medium text-sm"
              >
                <Settings className="mr-2.5 h-4 w-4" />
                {t('settings')}
              </DropdownMenuItem>
              <DropdownMenuSeparator className="my-0.5" />
              <DropdownMenuItem 
                onClick={handleLogout} 
                className="rounded-xl py-2.5 px-3 cursor-pointer text-destructive font-medium text-sm focus:text-destructive"
              >
                <LogOut className="mr-2.5 h-4 w-4" />
                {t('logout')}
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </div>
      </header>
      <SubscriptionReminder />
    </>
  );
};

export default Header;

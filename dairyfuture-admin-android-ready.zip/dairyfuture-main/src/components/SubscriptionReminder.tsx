import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { AlertTriangle, X } from 'lucide-react';
import { useAuth } from '@/contexts/AuthContext';
import { useLanguage } from '@/contexts/LanguageContext';
import { readReopenStatus, reopenDaysLeft, useReopenStatus } from '@/lib/subscriptionStatus';
import { readSettingsBootstrap, daysLeftFrom } from '@/lib/settingsBootstrap';
import { Dialog, DialogContent } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';

/**
 * Expiry reminder shown to the dairy owner when 3 / 2 / 1 days are left.
 * No realtime, no polling: it reads the already-cached subscription expiry
 * (written by the once-per-session `get_reopen_status` check) and compares it
 * with the device clock. Dismissal is remembered per day-count, so the owner
 * sees it again the next day when the count drops.
 *
 * Two layers:
 *  - a popup (once per day-count, remembered in localStorage)
 *  - a slim bar under the header until dismissed for that day-count
 */
const SubscriptionReminder: React.FC = () => {
  const { user, isAdmin } = useAuth();
  const { language } = useLanguage();
  const hi = language === 'hi';
  const navigate = useNavigate();
  const reopen = useReopenStatus();
  const [dismissed, setDismissed] = useState(0);
  const [popupShown, setPopupShown] = useState<number | null>(null);
  const [popupOpen, setPopupOpen] = useState(false);

  const status = reopen ?? readReopenStatus();
  const daysLeft = reopenDaysLeft(status) ?? daysLeftFrom(readSettingsBootstrap());
  const isActive = status ? status.status === 'active' : true;
  const inWindow = daysLeft !== null && daysLeft >= 1 && daysLeft <= 3;
  const isOwner = !isAdmin && user?.role === 'owner';

  useEffect(() => {
    try {
      const raw = localStorage.getItem('sub_reminder_dismissed_days');
      setDismissed(raw ? parseInt(raw, 10) || 0 : 0);
      const p = localStorage.getItem('sub_reminder_popup_days');
      setPopupShown(p ? parseInt(p, 10) || 0 : 0);
    } catch { /* ignore */ }
  }, []);

  // popup: sirf ek baar per day-count
  useEffect(() => {
    if (!isOwner || !isActive || !inWindow || popupShown === null) return;
    if (popupShown === daysLeft) return;
    setPopupOpen(true);
    try { localStorage.setItem('sub_reminder_popup_days', String(daysLeft)); } catch { /* ignore */ }
    setPopupShown(daysLeft);
  }, [isOwner, isActive, inWindow, daysLeft, popupShown]);

  if (!isOwner) return null;
  if (!isActive) return null;
  if (!inWindow) return null;
  if (daysLeft === null) return null;

  const hide = () => {
    try { localStorage.setItem('sub_reminder_dismissed_days', String(daysLeft)); } catch { /* ignore */ }
    setDismissed(daysLeft);
  };

  const title = hi
    ? `आपका प्लान ${daysLeft} दिन में खत्म हो रहा है`
    : `Your plan expires in ${daysLeft} day${daysLeft > 1 ? 's' : ''}`;

  return (
    <>
      <Dialog open={popupOpen} onOpenChange={setPopupOpen}>
        <DialogContent className="w-[calc(100vw-2rem)] max-w-sm rounded-2xl border-0 p-6 text-center shadow-2xl [&>button]:hidden">
          <div className="w-16 h-16 rounded-full bg-destructive/10 flex items-center justify-center mx-auto">
            <AlertTriangle className="h-8 w-8 text-destructive" />
          </div>
          <p className="text-lg font-bold text-foreground mt-2">{title}</p>
          <p className="text-sm leading-relaxed text-muted-foreground">
            {hi
              ? 'रिन्यू न करने पर ऐप बंद हो जाएगा। अभी रिन्यू करें।'
              : 'The app will stop working after expiry. Renew now.'}
          </p>
          <div className="grid grid-cols-2 gap-3 mt-3">
            <Button variant="outline" className="h-11 rounded-xl" onClick={() => setPopupOpen(false)}>
              {hi ? 'बाद में' : 'Later'}
            </Button>
            <Button
              className="h-11 rounded-xl shadow-md"
              onClick={() => { setPopupOpen(false); navigate('/subscription-renewal'); }}
            >
              {hi ? 'रिन्यू करें' : 'Renew'}
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      {dismissed !== daysLeft && (
        <div className="px-3 pt-2">
          <div className="max-w-4xl mx-auto flex items-center gap-2.5 rounded-2xl border border-destructive/30 bg-destructive/10 px-3 py-2.5">
            <div className="w-8 h-8 rounded-xl bg-destructive/15 flex items-center justify-center shrink-0">
              <AlertTriangle className="h-4 w-4 text-destructive" />
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-xs font-bold text-foreground leading-tight">{title}</p>
              <p className="text-[10px] text-muted-foreground leading-tight">
                {hi ? 'सेवा जारी रखने के लिए अभी रिन्यू करें' : 'Renew now to keep using the app'}
              </p>
            </div>
            <button
              onClick={() => navigate('/subscription-renewal')}
              className="shrink-0 rounded-xl bg-primary text-primary-foreground text-[11px] font-bold px-3 py-2 active:scale-95 transition-transform"
            >
              {hi ? 'रिन्यू करें' : 'Renew'}
            </button>
            <button onClick={hide} className="shrink-0 text-muted-foreground p-1" aria-label="close">
              <X className="h-3.5 w-3.5" />
            </button>
          </div>
        </div>
      )}
    </>
  );
};

export default SubscriptionReminder;

import { createRoot } from "react-dom/client";
import App from "./App.tsx";
import "./index.css";

// Capture password-recovery links BEFORE the Supabase client consumes the URL hash.
if (typeof window !== "undefined") {
  try {
    const hashParams = new URLSearchParams(window.location.hash.replace(/^#/, ""));
    const searchParams = new URLSearchParams(window.location.search);
    const isRecovery =
      hashParams.get("type") === "recovery" ||
      searchParams.get("type") === "recovery";
    if (isRecovery) {
      sessionStorage.setItem("pw_recovery", "1");
    }
  } catch {
    // ignore
  }
}

if (
  typeof window !== "undefined" &&
  window.location.hostname.includes("preview")
) {
  try {
    void navigator.serviceWorker?.getRegistrations?.().then((registrations) => {
      registrations.forEach((registration) => {
        void registration.unregister();
      });
    });

    void caches?.keys?.().then((keys) => {
      keys.forEach((key) => {
        void caches.delete(key);
      });
    });
  } catch {
    // Ignore preview-only cache clear failures.
  }
}

createRoot(document.getElementById("root")!).render(<App />);

import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { User, Session } from '@supabase/supabase-js';
import { clearSettingsBootstrap, primeSettingsBootstrap } from '@/lib/settingsBootstrap';

type UserRole = 'owner' | 'supplier' | 'admin';

const ADMIN_EMAIL = 'vishnugurjarsimal0968@gmail.com';

interface UserProfile {
  id: string;
  phone: string;
  name: string;
  role: UserRole;
  dairyId?: string;
  dairyName?: string;
  dairyCode?: string;
  hasSeenOnboarding?: boolean;
}

interface AuthDiagnostics {
  supabaseUrl: string;
  anonKeyLength: number;
  envOk: boolean;
  preAuthFetchUrl: string;
  preAuthFetchStatus: 'pending' | 'success' | 'failed';
  preAuthFetchHttpStatus?: number;
  preAuthFetchError?: string;
  lastRequestUrl?: string;
  lastRequestStatus?: number;
  lastRequestError?: string;
  lastRequestBlockedHint?: string;
}

interface AuthContextType {
  user: UserProfile | null;
  authUser: User | null;
  isAuthenticated: boolean;
  isLoading: boolean;
  isAdmin: boolean;
  authDiagnostics: AuthDiagnostics;
  login: (email: string, password: string) => Promise<{ success: boolean; error?: string }>;
  signup: (email: string, password: string, name: string, phone: string, role: UserRole, referralCode?: string) => Promise<{ success: boolean; error?: string }>;
  setupDairy: (dairyName: string, dairyCode: string) => Promise<boolean>;
  joinDairy: (dairyCode: string) => Promise<boolean | string>;
  logout: () => Promise<void>;
  refreshProfile: () => Promise<void>;
  setHasSeenOnboarding: () => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

// Local storage cache keys
const CACHE_KEY_USER = 'dairy_app_user_cache';
const CACHE_KEY_AUTH = 'dairy_app_auth_cache';
/** Stores the last user id for whom `get_app_bootstrap` succeeded. Persists across app reopens in localStorage. */
const BOOTSTRAP_USER_KEY = 'auth_bootstrap_user_id_v1';

// Shared in-flight bootstrap promise (module scope so every trigger point,
// even across re-renders, sees the same pending call).
let bootstrapInFlight: Promise<void> | null = null;
// Tracks whether the next SIGNED_IN event comes from our own login()/signup()
// call. Supabase can emit SIGNED_IN on multi-tab session sync or token refresh,
// so we must not treat every SIGNED_IN as a fresh login.
let justSignedIn = false;

const CACHE_KEY_ONBOARDING = 'dairy_app_onboarding_seen';
const CACHE_KEY_USER_TIMESTAMP = 'dairy_app_user_cache_timestamp';
const PROFILE_CACHE_TTL_MS = 30 * 60 * 1000; // 30 minutes

const SUPABASE_URL_RUNTIME = import.meta.env.VITE_SUPABASE_URL || '';
const SUPABASE_ANON_KEY_RUNTIME = import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY || '';

export const AuthProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  // Load from cache immediately - no waiting
  const cachedUser = localStorage.getItem(CACHE_KEY_USER);
  const cachedAuth = localStorage.getItem(CACHE_KEY_AUTH);

  const safeParse = <T,>(value: string | null): T | null => {
    if (!value) return null;
    try {
      return JSON.parse(value) as T;
    } catch {
      return null;
    }
  };

  // IMPORTANT: prevent mismatched cached profile (old user) from being used with a new auth session.
  const initialAuthUser = safeParse<User>(cachedAuth);
  const initialUser = safeParse<UserProfile>(cachedUser);
  const cacheUserIsValid = !!initialAuthUser && !!initialUser && initialUser.id === initialAuthUser.id;

  const [authUser, setAuthUser] = useState<User | null>(() => initialAuthUser);
  const [session, setSession] = useState<Session | null>(null);
  const [user, setUser] = useState<UserProfile | null>(() => (cacheUserIsValid ? initialUser : null));
  const [isAuthReady, setIsAuthReady] = useState(false);
  const [authDiagnostics, setAuthDiagnostics] = useState<AuthDiagnostics>({
    supabaseUrl: SUPABASE_URL_RUNTIME,
    anonKeyLength: SUPABASE_ANON_KEY_RUNTIME.length,
    envOk: Boolean(SUPABASE_URL_RUNTIME && SUPABASE_ANON_KEY_RUNTIME),
    preAuthFetchUrl: SUPABASE_URL_RUNTIME ? `${SUPABASE_URL_RUNTIME}/rest/v1/` : '',
    preAuthFetchStatus: 'pending',
  });

  const isLoading = !isAuthReady;

  const detectBlockingHint = (message?: string) => {
    const raw = (message || '').toLowerCase();
    if (raw.includes('cors')) return 'Possible CORS blocking';
    if (raw.includes('iframe')) return 'Possible iframe/network policy blocking';
    if (raw.includes('failed to fetch') || raw.includes('network')) return 'Network or environment injection issue';
    return undefined;
  };

  const updateLastAuthRequest = (
    url: string,
    status?: number,
    error?: string,
    blockedHint?: string
  ) => {
    setAuthDiagnostics((prev) => ({
      ...prev,
      lastRequestUrl: url,
      lastRequestStatus: status,
      lastRequestError: error,
      lastRequestBlockedHint: blockedHint,
    }));
  };

  // If we detect bad cache at startup, clear it so routing can't misidentify role.
  useEffect(() => {
    if (initialAuthUser && initialUser && initialUser.id !== initialAuthUser.id) {
      localStorage.removeItem(CACHE_KEY_USER);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // Save user and authUser to cache whenever they change
  useEffect(() => {
    if (user) {
      localStorage.setItem(CACHE_KEY_USER, JSON.stringify(user));
      localStorage.setItem(CACHE_KEY_USER_TIMESTAMP, String(Date.now()));
    } else {
      localStorage.removeItem(CACHE_KEY_USER);
      localStorage.removeItem(CACHE_KEY_USER_TIMESTAMP);
    }
  }, [user]);

  // If auth user changes (e.g., switching accounts or immediate login after signup),
  // ensure we don't keep an old cached profile that would mis-route the user.
  useEffect(() => {
    if (authUser && user && user.id !== authUser.id) {
      setUser(null);
      localStorage.removeItem(CACHE_KEY_USER);
    }
  }, [authUser?.id]);

  useEffect(() => {
    if (authUser) {
      localStorage.setItem(CACHE_KEY_AUTH, JSON.stringify(authUser));
    } else {
      localStorage.removeItem(CACHE_KEY_AUTH);
    }
  }, [authUser]);

  // Clear all cached data when session is invalid
  const clearAllCache = () => {
    setUser(null);
    setAuthUser(null);
    setSession(null);
    localStorage.removeItem(CACHE_KEY_USER);
    localStorage.removeItem(CACHE_KEY_AUTH);
    localStorage.removeItem('subscription_cache');
    localStorage.removeItem(BOOTSTRAP_USER_KEY);
    clearSettingsBootstrap();
  };

  const getSupabaseAuthStorageKeys = () =>
    Object.keys(localStorage).filter((key) => key.startsWith('sb-') && key.endsWith('-auth-token'));

  const clearSupabaseAuthStorage = () => {
    getSupabaseAuthStorageKeys().forEach((key) => localStorage.removeItem(key));
  };

  const runPreAuthFetchTest = async () => {
    console.log('[AUTH_DIAG] SUPABASE_URL:', SUPABASE_URL_RUNTIME || '(empty)');
    console.log('[AUTH_DIAG] SUPABASE_ANON_KEY_LENGTH:', SUPABASE_ANON_KEY_RUNTIME.length);

    const envOk = Boolean(SUPABASE_URL_RUNTIME && SUPABASE_ANON_KEY_RUNTIME);
    const testUrl = SUPABASE_URL_RUNTIME ? `${SUPABASE_URL_RUNTIME}/rest/v1/` : '';

    // If we recently tested connectivity with the same env config, reuse the result
    // to avoid an API call on every app open.
    const cacheKey = 'dairy_app_preauth_cache';
    const cachedRaw = localStorage.getItem(cacheKey);
    if (cachedRaw && envOk) {
      try {
        const cached = JSON.parse(cachedRaw);
        if (
          cached?.url === testUrl &&
          cached?.anonKeyLength === SUPABASE_ANON_KEY_RUNTIME.length &&
          cached?.timestamp &&
          (Date.now() - cached.timestamp) < PROFILE_CACHE_TTL_MS
        ) {
          setAuthDiagnostics((prev) => ({
            ...prev,
            supabaseUrl: SUPABASE_URL_RUNTIME,
            anonKeyLength: SUPABASE_ANON_KEY_RUNTIME.length,
            envOk,
            preAuthFetchUrl: testUrl,
            preAuthFetchStatus: cached.status,
            preAuthFetchHttpStatus: cached.httpStatus,
            preAuthFetchError: cached.error,
          }));
          return cached.status !== 'failed';
        }
      } catch { /* ignore stale cache */ }
    }

    setAuthDiagnostics((prev) => ({
      ...prev,
      supabaseUrl: SUPABASE_URL_RUNTIME,
      anonKeyLength: SUPABASE_ANON_KEY_RUNTIME.length,
      envOk,
      preAuthFetchUrl: testUrl,
      preAuthFetchStatus: 'pending',
      preAuthFetchHttpStatus: undefined,
      preAuthFetchError: undefined,
    }));

    if (!envOk) {
      setAuthDiagnostics((prev) => ({
        ...prev,
        envOk: false,
        preAuthFetchStatus: 'failed',
        preAuthFetchError: 'Missing runtime env vars (SUPABASE_URL or SUPABASE_ANON_KEY).',
      }));
      return false;
    }

    try {
      updateLastAuthRequest(testUrl);
      console.log('[AUTH_DIAG] Pre-auth fetch URL:', testUrl);
      const response = await fetch(testUrl);
      console.log('[AUTH_DIAG] Pre-auth fetch status:', response.status);
      updateLastAuthRequest(testUrl, response.status);

      // For connectivity diagnostics, any HTTP response means network path is working.
      // 401 is expected for /rest/v1/ without auth headers.
      const status = 'success';
      const error = response.status === 401
        ? 'HTTP 401 is expected for plain /rest/v1/ without auth headers.'
        : undefined;
      setAuthDiagnostics((prev) => ({
        ...prev,
        preAuthFetchStatus: status,
        preAuthFetchHttpStatus: response.status,
        preAuthFetchError: error,
      }));
      localStorage.setItem(cacheKey, JSON.stringify({
        url: testUrl,
        anonKeyLength: SUPABASE_ANON_KEY_RUNTIME.length,
        status,
        httpStatus: response.status,
        error,
        timestamp: Date.now(),
      }));
      return true;
    } catch (error: any) {
      const rawMessage = error?.message || String(error);
      const blockedHint = detectBlockingHint(rawMessage);
      console.error('[AUTH_DIAG] Pre-auth fetch network error:', error);
      updateLastAuthRequest(testUrl, undefined, rawMessage, blockedHint);
      setAuthDiagnostics((prev) => ({
        ...prev,
        preAuthFetchStatus: 'failed',
        preAuthFetchError: rawMessage,
      }));
      localStorage.setItem(cacheKey, JSON.stringify({
        url: testUrl,
        anonKeyLength: SUPABASE_ANON_KEY_RUNTIME.length,
        status: 'failed',
        httpStatus: undefined,
        error: rawMessage,
        timestamp: Date.now(),
      }));
      return false;
    }
  };

  useEffect(() => {
    let isMounted = true;
    let authSubscription: { unsubscribe: () => void } | null = null;

    // If we have valid cached data, mark auth ready immediately for instant UI
    if (cacheUserIsValid && initialAuthUser && initialUser) {
      setIsAuthReady(true);
    }

    const initializeSession = async () => {
      // Run pre-auth test in background — don't block initialization
      runPreAuthFetchTest().then((ok) => {
        if (!ok && isMounted) {
          console.warn('[AUTH] Pre-auth fetch failed, but continuing with cached data if available');
        }
      });

      const { data: { subscription } } = supabase.auth.onAuthStateChange(
        (event, currentSession) => {
          if (event === 'SIGNED_OUT') {
            clearAllCache();
            setIsAuthReady(true);
            return;
          }

          setSession(currentSession);
          setAuthUser(currentSession?.user ?? null);

          if (currentSession?.user) {
            // A fresh sign-in / user switch must re-bootstrap; INITIAL_SESSION
            // and token refreshes reuse the session cache.
            const forceFetch = justSignedIn || event === 'USER_UPDATED';
            if (justSignedIn) justSignedIn = false;
            setTimeout(() => {
              fetchUserProfile(currentSession.user.id, currentSession.user.email, currentSession.user.user_metadata, forceFetch);
            }, 0);
          } else if (event === 'INITIAL_SESSION') {
            clearAllCache();
          }

          if (event === 'INITIAL_SESSION') {
            setIsAuthReady(true);
          }
        }
      );

      authSubscription = subscription;

      try {
        const { data: { session: currentSession }, error } = await supabase.auth.getSession();

        if (error) {
          console.error('[AUTH] getSession error:', error);
          clearAllCache();
          return;
        }

        if (!currentSession) {
          if (cachedAuth || cachedUser) {
            clearAllCache();
          }
          return;
        }

        setSession(currentSession);
        setAuthUser(currentSession.user);
        await fetchUserProfile(currentSession.user.id, currentSession.user.email, currentSession.user.user_metadata);
      } catch (error: any) {
        console.error('[AUTH] Error restoring auth session:', error);
        clearAllCache();
      } finally {
        if (isMounted) setIsAuthReady(true);
      }
    };

    initializeSession();

    return () => {
      isMounted = false;
      authSubscription?.unsubscribe();
    };
  }, []);

  // Extra safety: if the provider is hot-reloaded or state is preserved,
  // ensure we still fetch (and backfill) the profile/role for the current auth user.
  useEffect(() => {
    if (authUser && (!user || user.id !== authUser.id)) {
      fetchUserProfile(authUser.id, authUser.email, authUser.user_metadata);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [authUser?.id]);

  // Module-scope-like in-flight guard (same pattern as settingsBootstrap /
  // subscriptionStatus): concurrent triggers (onAuthStateChange SIGNED_IN,
  // getSession, safety useEffect) all await the SAME bootstrap promise, so
  // get_app_bootstrap can never run twice near-simultaneously.
  const fetchUserProfile = (
    userId: string,
    email?: string | null,
    userMetadata?: Record<string, unknown> | null,
    force = false
  ): Promise<void> => {
    if (bootstrapInFlight) return bootstrapInFlight;
    const p = (async () => {
      try {
        await fetchUserProfileImpl(userId, email, userMetadata, force);
      } finally {
        bootstrapInFlight = null;
      }
    })();
    bootstrapInFlight = p;
    return p;
  };

  const fetchUserProfileImpl = async (
    userId: string,
    email?: string | null,
    userMetadata?: Record<string, unknown> | null,
    force = false
  ) => {
    try {
      const metaName = (userMetadata?.name as string | undefined) ?? '';
      const metaPhone = (userMetadata?.phone as string | undefined) ?? '';
      const metaRole = (userMetadata?.role as UserRole | undefined) ?? undefined;

      // Hydrate UI instantly from cache.
      const cachedUserRaw = localStorage.getItem(CACHE_KEY_USER);
      let cachedMatches = false;
      if (cachedUserRaw) {
        try {
          const cached = JSON.parse(cachedUserRaw) as UserProfile;
          if (cached?.id === userId) { setUser(cached); cachedMatches = true; }
        } catch { /* ignore */ }
      }

      // Persistent bootstrap guard: the bootstrap RPC only runs on a fresh
      // install/app open, a new login/signup, or an explicit force (no TTL,
      // no timers). Every other reopen with the same user id is served purely
      // from the local cache.
      const alreadyBootstrapped =
        localStorage.getItem(BOOTSTRAP_USER_KEY) === userId;
      if (!force && alreadyBootstrapped && cachedMatches) return;



      // Single bootstrap RPC — replaces 3 parallel REST calls (profiles + user_roles + dairies/suppliers).
      // Falls back to individual queries if RPC fails (older server / network issue).
      let profileData: any = null;
      let roleData: { role: UserRole } | null = null;
      let ownedDairy: { id: string; name: string; code: string } | null = null;
      let supplierBoot: { id: string; dairy_id: string; dairy_name?: string; dairy_code?: string } | null = null;
      let rpcOk = false;

      try {
        // Single merged bootstrap: auth (profile/role/dairy) + settings
        // (subscription/features/plans) in one round-trip.
        let combined: any = null;
        const { data: appBoot, error: appErr } = await supabase.rpc('get_app_bootstrap' as any);
        if (!appErr && appBoot) {
          combined = appBoot;
        } else {
          if (appErr) console.warn('[auth] merged bootstrap unavailable, using auth-only RPC:', appErr.message);
          const { data: boot, error: bootErr } = await supabase.rpc('get_auth_bootstrap' as any);
          if (!bootErr && boot) combined = { auth: boot, settings: null };
          else if (bootErr) console.warn('[auth] bootstrap RPC failed, falling back:', bootErr.message);
        }

        if (combined?.auth) {
          rpcOk = true;
          const b: any = combined.auth;
          profileData = b.profile ?? null;
          roleData = b.role ? { role: b.role as UserRole } : null;
          ownedDairy = b.dairy ?? null;
          supplierBoot = b.supplier ?? null;
          // owner_phone is login-time data — cached so payment pages never refetch it.
          if (b.owner_phone) { try { localStorage.setItem('dairy_owner_phone', b.owner_phone); } catch {} }
          // Seed the settings cache so `get_settings_bootstrap` never fires separately.
          if (combined.settings) primeSettingsBootstrap(combined.settings);
        }
      } catch (e) {
        console.warn('[auth] bootstrap RPC threw, falling back:', e);
      }

      if (!rpcOk) {
        const [profileResult, roleResult, ownedDairyResult] = await Promise.all([
          supabase.from('profiles').select('*').eq('user_id', userId).maybeSingle(),
          supabase.from('user_roles').select('role').eq('user_id', userId).maybeSingle(),
          email !== ADMIN_EMAIL
            ? supabase.from('dairies').select('id, name, code').eq('owner_id', userId).maybeSingle()
            : Promise.resolve({ data: null, error: null }),
        ]);
        profileData = profileResult.data;
        roleData = roleResult.data as any;
        ownedDairy = ownedDairyResult.data as any;
        if (profileResult.error) console.error('Error fetching profile:', profileResult.error);
        if (roleResult.error) console.error('Error fetching role:', roleResult.error);
      }

      // Backfill profile if missing (rare — signup trigger usually handles it)
      if (!profileData) {
        const { error: insertProfileError } = await supabase
          .from('profiles')
          .insert({ user_id: userId, name: metaName, phone: metaPhone });

        if (insertProfileError && !String(insertProfileError.message).toLowerCase().includes('duplicate')) {
          console.error('Error creating profile:', insertProfileError);
        }

        const retry = await supabase.from('profiles').select('*').eq('user_id', userId).maybeSingle();
        profileData = retry.data ?? null;
      }

      // Backfill role if missing
      if (!roleData && metaRole) {
        const { error: upsertRoleError } = await supabase
          .from('user_roles')
          .upsert({ user_id: userId, role: metaRole as any }, { onConflict: 'user_id,role' });

        if (upsertRoleError && !String(upsertRoleError.message).toLowerCase().includes('duplicate')) {
          console.error('Error creating role:', upsertRoleError);
        }

        const retryRole = await supabase.from('user_roles').select('role').eq('user_id', userId).maybeSingle();
        roleData = retryRole.data as any;
      }

      // Determine role
      let role: UserRole = (roleData?.role as UserRole) || metaRole || 'owner';
      if (email === ADMIN_EMAIL) {
        role = 'admin';
      }

      // Dairy info
      let dairyId: string | undefined;
      let dairyName: string | undefined;
      let dairyCode: string | undefined;

      if (role !== 'admin') {
        if (ownedDairy) {
          dairyId = ownedDairy.id;
          dairyName = ownedDairy.name;
          dairyCode = ownedDairy.code;
        } else if (supplierBoot) {
          dairyId = supplierBoot.dairy_id;
          dairyName = supplierBoot.dairy_name;
          dairyCode = supplierBoot.dairy_code;
        } else {
          // Fallback (mainly non-RPC path): try suppliers lookup + unlinked phone match
          const { data: supplierData } = await supabase
            .from('suppliers')
            .select('dairy_id, dairies(name, code)')
            .eq('user_id', userId)
            .maybeSingle();

          if (supplierData) {
            dairyId = supplierData.dairy_id;
            const dairy = supplierData.dairies as unknown as { name: string; code: string };
            dairyName = dairy?.name;
            dairyCode = dairy?.code;
          } else if (role === 'supplier' && profileData?.phone) {
            const { data: unlinkedSupplier } = await supabase
              .from('suppliers')
              .select('id, dairy_id, dairies(name, code)')
              .eq('phone', profileData.phone)
              .is('user_id', null)
              .maybeSingle();

            if (unlinkedSupplier) {
              await supabase.from('suppliers').update({ user_id: userId }).eq('id', unlinkedSupplier.id);
              dairyId = unlinkedSupplier.dairy_id;
              const dairy = unlinkedSupplier.dairies as unknown as { name: string; code: string };
              dairyName = dairy?.name;
              dairyCode = dairy?.code;
            }
          }
        }
      }

      const hasSeenOnboarding = localStorage.getItem(CACHE_KEY_ONBOARDING) === 'true';

      setUser({
        id: userId,
        phone: (profileData as any)?.phone || metaPhone || '',
        name: (profileData as any)?.name || metaName || '',
        role,
        dairyId,
        dairyName,
        dairyCode,
        hasSeenOnboarding,
      });

      // Fresh login / signup / first app open: refresh subscription status right
      // away so Settings shows the live plan state instead of waiting for TTL.
      if (role !== 'admin' && dairyId && (force || !alreadyBootstrapped)) {
        import('@/lib/subscriptionStatus')
          .then((m) => m.checkSubscriptionStatus(dairyId, true))
          .catch(() => { /* ignore */ });
      }

      // Mark this user as bootstrapped in localStorage so no further RPC runs on
      // a simple app reopen with the same user id.
      try { localStorage.setItem(BOOTSTRAP_USER_KEY, userId); } catch { /* ignore */ }

    } catch (error) {
      console.error('Error in fetchUserProfile:', error);
    }
  };

  const login = async (email: string, password: string): Promise<{ success: boolean; error?: string }> => {
    if (authDiagnostics.preAuthFetchStatus === 'failed') {
      return {
        success: false,
        error: `Pre-auth fetch failed: ${authDiagnostics.preAuthFetchError || 'Unknown network error'}`,
      };
    }

    try {
      const requestUrl = `${SUPABASE_URL_RUNTIME}/auth/v1/token?grant_type=password`;
      console.log('[AUTH_DIAG] Login request URL:', requestUrl);
      updateLastAuthRequest(requestUrl);


      const { error } = await supabase.auth.signInWithPassword({ email, password });

      if (error) {
        const status = (error as any)?.status;
        const blockedHint = detectBlockingHint(error.message);
        console.error('[AUTH_DIAG] Login error:', { url: requestUrl, status, error: error.message, blockedHint });
        updateLastAuthRequest(requestUrl, status, error.message, blockedHint);
        return { success: false, error: error.message };
      }

      updateLastAuthRequest(requestUrl, 200);
      // Fresh login → allow ONE rate_settings fetch (never on plain reopen).
      try { localStorage.setItem('dairy_fresh_login_rates', '1'); } catch { /* ignore */ }
      justSignedIn = true;
      return { success: true };
    } catch (error: any) {
      const serialized = error instanceof Error
        ? { name: error.name, message: error.message, stack: error.stack }
        : error;
      const message = error?.message || String(error);
      const blockedHint = detectBlockingHint(message);
      const requestUrl = `${SUPABASE_URL_RUNTIME}/auth/v1/token?grant_type=password`;

      console.error('[AUTH_DIAG] Login network exception:', { url: requestUrl, error: message, blockedHint });
      updateLastAuthRequest(requestUrl, undefined, message, blockedHint);
      return { success: false, error: message };
    }
  };

  const signup = async (email: string, password: string, name: string, phone: string, role: UserRole, referralCode?: string): Promise<{ success: boolean; error?: string }> => {
    if (authDiagnostics.preAuthFetchStatus === 'failed') {
      return {
        success: false,
        error: `Pre-auth fetch failed: ${authDiagnostics.preAuthFetchError || 'Unknown network error'}`,
      };
    }

    try {
      const requestUrl = `${SUPABASE_URL_RUNTIME}/auth/v1/signup`;
      console.log('[AUTH_DIAG] Signup request URL:', requestUrl);
      updateLastAuthRequest(requestUrl);

      // Prevent duplicate signup with the same phone number
      const normalizedPhone = (phone || '').replace(/\D/g, '').slice(-10);
      if (normalizedPhone.length === 10) {
        const { data: exists } = await supabase.rpc('phone_exists' as any, { _phone: normalizedPhone });
        if (exists === true) {
          return { success: false, error: 'यह फोन नंबर पहले से रजिस्टर्ड है / This phone number is already registered' };
        }
      }

      const metaData: Record<string, string> = {
        phone,
        name,
        role,
      };
      if (referralCode) {
        metaData.referred_by_code = referralCode.toUpperCase();
      }

      const { data, error } = await supabase.auth.signUp({
        email,
        password,
        options: {
          data: metaData,
        },
      });

      if (error) {
        const status = (error as any)?.status;
        console.error('[AUTH_DIAG] Signup error:', { url: requestUrl, status, error: error.message });
        updateLastAuthRequest(requestUrl, status, error.message);
        return { success: false, error: error.message };
      }

      if (!data.user) {
        return { success: false, error: 'Could not create account' };
      }

      if (data.user.identities && data.user.identities.length === 0) {
        return { success: false, error: 'This email is already registered' };
      }

      updateLastAuthRequest(requestUrl, 200);
      console.log('[AUTH_DIAG] Signup status: 200');
      justSignedIn = true;
      return { success: true };
    } catch (error: any) {
      const serialized = error instanceof Error
        ? { name: error.name, message: error.message, stack: error.stack }
        : error;
      const message = error?.message || String(error);
      const blockedHint = detectBlockingHint(message);
      const requestUrl = `${SUPABASE_URL_RUNTIME}/auth/v1/signup`;

      console.error('[AUTH_DIAG] Signup network exception:', { url: requestUrl, error: message });
      updateLastAuthRequest(requestUrl, undefined, message);
      return { success: false, error: message };
    }
  };

  const setupDairy = async (dairyName: string, dairyCode: string): Promise<boolean> => {
    if (!authUser || user?.role !== 'owner') return false;

    try {
      // Check if user already owns a dairy
      const { data: existingOwned } = await supabase
        .from('dairies')
        .select('id')
        .eq('owner_id', authUser.id)
        .maybeSingle();

      if (existingOwned) {
        console.log('User already owns a dairy');
        return false;
      }

      // If code is provided, check uniqueness
      const actualCode = dairyCode.trim() || null;
      if (actualCode) {
        const { data: codeExists, error: checkError } = await supabase
          .rpc('check_dairy_code_exists', { dairy_code: actualCode });

        if (checkError) {
          console.error('Error checking dairy code:', checkError);
          return false;
        }

        if (codeExists) {
          console.log('Dairy code already exists');
          return false;
        }
      }

      // Create new dairy (code can be null - admin will generate it later)
      const insertPayload: any = {
        name: dairyName,
        owner_id: authUser.id,
      };
      if (actualCode) {
        insertPayload.code = actualCode;
      }

      const { data: newDairy, error } = await supabase
        .from('dairies')
        .insert(insertPayload)
        .select()
        .single();

      if (error) {
        console.error('Error creating dairy:', error);
        return false;
      }

      // Update rate settings with values from RateSetup (trigger already created defaults)
      const initialFatRate = parseFloat(localStorage.getItem('initial_fat_rate') || '8');
      const initialLiterRate = parseFloat(localStorage.getItem('initial_liter_rate') || '50');
      const pendingOwnerSettings = JSON.parse(localStorage.getItem('pending_owner_settings') || 'null');

      await supabase
        .from('rate_settings')
        .update({
          rate_type: 'per_fat',
          rate_value: initialFatRate,
          liter_rate: initialLiterRate,
          calculation_method: pendingOwnerSettings?.calculationSystem ?? 'avg_fat',
        })
        .eq('dairy_id', newDairy.id);
      
      // Clear the temporary localStorage values AFTER successful update
      localStorage.removeItem('initial_fat_rate');
      localStorage.removeItem('initial_liter_rate');

      // Refresh profile to get dairy info (real state change → force)
      await fetchUserProfile(authUser.id, authUser.email, authUser.user_metadata, true);

      return true;
    } catch (error) {
      console.error('Error in setupDairy:', error);
      return false;
    }
  };

  const joinDairy = async (dairyCode: string): Promise<boolean | string> => {
    if (!authUser || user?.role !== 'supplier') return 'अमान्य उपयोगकर्ता / Invalid user';

    try {
      // Use SECURITY DEFINER RPC that bypasses RLS to find dairy + match phone + link supplier
      const { data: rpcResult, error: rpcError } = await supabase
        .rpc('link_supplier_to_dairy_by_code' as any, { _dairy_code: dairyCode });

      if (rpcError) {
        console.error('Error in link_supplier_to_dairy_by_code:', rpcError);
        return 'डेयरी से जुड़ने में त्रुटि / Error joining dairy';
      }

      // RPC returns TABLE(linked boolean, error_code text) — array of rows
      const result = Array.isArray(rpcResult) ? rpcResult[0] : rpcResult;
      const linked = result?.linked;
      const errorCode = result?.error_code;

      if (linked === true) {
        // Successfully linked! Refresh profile to get dairy info (force)
        await fetchUserProfile(authUser.id, authUser.email, authUser.user_metadata, true);
        return true;
      }

      // Handle specific error codes with user-friendly messages
      if (errorCode === 'invalid_code') {
        return 'यह डेयरी कोड गलत है। कृपया सही 12 अंकों का कोड डालें। / Invalid dairy code. Please enter the correct 12-digit code.';
      }
      if (errorCode === 'phone_not_found') {
        return `आपका फोन नंबर इस डेयरी में नहीं मिला। पहले मालिक से अपना नंबर जुड़वाएं। / Your phone number is not found in this dairy. Ask the owner to add your number first.`;
      }
      if (errorCode === 'already_linked_other') {
        return 'यह नंबर पहले से किसी और अकाउंट से जुड़ा है। / This number is already linked to another account.';
      }
      if (errorCode === 'phone_missing') {
        return 'आपके अकाउंट में फोन नंबर नहीं है। / Phone number missing in your account.';
      }
      if (errorCode === 'not_supplier') {
        return 'आपका अकाउंट सप्लायर नहीं है। / Your account is not a supplier.';
      }
      if (errorCode === 'code_disabled') {
        return 'इस डेयरी का कोड अभी बंद है। डेयरी मालिक या एडमिन से संपर्क करें। / This dairy code is currently disabled. Contact dairy owner or admin.';
      }

      return 'कुछ गलत हो गया / Something went wrong';
    } catch (error) {
      console.error('Error in joinDairy:', error);
      return 'कुछ गलत हो गया / Something went wrong';
    }
  };

  const logout = async () => {
    // Return directly to the login form after logout. Without this hint Auth
    // starts at role selection, where the Google button is intentionally not
    // rendered, which makes the provider look as if it disappeared.
    if (user?.role === 'owner' || user?.role === 'supplier') {
      try { sessionStorage.setItem('post_logout_auth_role', user.role); } catch { /* ignore */ }
    }

    // Clear state and cache FIRST for instant UI response
    setUser(null);
    setAuthUser(null);
    setSession(null);
    localStorage.removeItem(CACHE_KEY_USER);
    localStorage.removeItem(CACHE_KEY_AUTH);
    localStorage.removeItem(CACHE_KEY_ONBOARDING);
    localStorage.removeItem('subscription_cache');
    localStorage.removeItem('pending_rate_setup');
    localStorage.removeItem('pending_owner_onboarding');
    localStorage.removeItem('pending_google_profile');
    localStorage.removeItem('google_oauth_pending');
    localStorage.removeItem('google_oauth_role');

    // DairyContext ki cache bhi clear karo — warna agla login (chahe
    // dusra role ho ya dusra device-share) purani suppliers list dikhata
    // reh jaata hai, kyunki reopen-sync sirf tab chalta hai jab cache khali ho.
    localStorage.removeItem('dairy_app_suppliers_cache');
    localStorage.removeItem('dairy_app_rates_cache');
    localStorage.removeItem('dairy_app_fat_snf_settings');
    localStorage.removeItem('dairy_app_payment_history_cache');
    localStorage.removeItem('dairy_app_cache_timestamp');
    localStorage.removeItem('dairy_fresh_login_rates');
    localStorage.removeItem('cached_owner_settings');
    localStorage.removeItem(BOOTSTRAP_USER_KEY);
    Object.keys(localStorage).forEach((key) => {
      if (key.startsWith('dairy_delta_v1_') || key.startsWith('dairy_cq_session_v1_')) {
        localStorage.removeItem(key);
      }
    });

    // Also remove persisted auth tokens directly to prevent stale refresh_token loops
    clearSupabaseAuthStorage();
    // Use local scope to avoid waiting for network call to Supabase
    try {
      await supabase.auth.signOut({ scope: 'local' });
    } catch {
      // Ignore errors - we already cleared local state
    }
  };

  const setHasSeenOnboarding = () => {
    localStorage.setItem(CACHE_KEY_ONBOARDING, 'true');
    if (user) {
      setUser({ ...user, hasSeenOnboarding: true });
    }
  };

  const refreshProfile = async () => {
    if (authUser) {
      // Explicit refresh after a real state change — bypasses the session guard.
      localStorage.removeItem(CACHE_KEY_USER_TIMESTAMP);
      await fetchUserProfile(authUser.id, authUser.email, authUser.user_metadata, true);
    }
  };

  // Admin-only native build: hand the current access token to the native
  // AdminNotification plugin (notification listener). The plugin only exists in
  // the sideloaded admin APK, so failures here are expected and ignored.
  useEffect(() => {
    const token = session?.access_token;
    if (!token || user?.role !== 'admin') return;
    (async () => {
      try {
        const { registerPlugin, Capacitor } = await import('@capacitor/core');
        if (!Capacitor.isNativePlatform()) return;
        const AdminNotification = registerPlugin('AdminNotification');
        await (AdminNotification as any).setAccessToken({ token });
      } catch {
        /* plugin not present in this build — fine, ignore */
      }
    })();
  }, [session?.access_token, user?.role]);

  return (
    <AuthContext.Provider
      value={{
        user,
        authUser,
        // Must match ids; otherwise a stale cached profile could incorrectly show owner screens to suppliers.
        isAuthenticated: !!authUser && !!user && user.id === authUser.id,
        isLoading,
        isAdmin: user?.role === 'admin',
        authDiagnostics,
        login,
        signup,
        setupDairy,
        joinDairy,
        logout,
        refreshProfile,
        setHasSeenOnboarding,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = (): AuthContextType => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
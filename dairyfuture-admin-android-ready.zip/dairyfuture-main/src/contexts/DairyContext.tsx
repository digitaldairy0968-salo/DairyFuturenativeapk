import React, { createContext, useContext, useState, useEffect, ReactNode, useCallback, useRef } from 'react';
// Keep one canonical module URL for AuthContext. Mixing relative and `@/` imports
// can create two context instances during Vite hot updates, leaving this provider
// subscribed to a different instance than the mounted AuthProvider.
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/integrations/supabase/client';
import { fetchAllRows } from '@/lib/supabasePagination';
import { showNotification, requestNotificationPermission } from '@/utils/notifications';
import { addToSyncQueue, processSyncQueue, getSyncQueueCount, getSyncQueue } from '@/utils/offlineSyncQueue';
import { FatSnfRateSettings, defaultFatSnfSettings } from '@/utils/fatSnfCalculation';
import { OwnerSettings, defaultOwnerSettings, mapOwnerSettingsRow, OWNER_SETTINGS_CACHE_KEY } from '@/hooks/useOwnerSettings';
import { toast as sonnerToast } from 'sonner';

export interface MilkEntry {
  date: string;
  morningMilk: number | null;
  morningFat: number | null;
  morningSNF: number | null;
  morningLR: number | null;
  morningPrice: number | null;
  eveningMilk: number | null;
  eveningFat: number | null;
  eveningSNF: number | null;
  eveningLR: number | null;
  eveningPrice: number | null;
}

export interface Supplier {
  id: string;
  dairyId: string;
  name: string;
  phone: string;
  code?: string;
  animalType: 'cow' | 'buffalo' | 'both' | 'goat' | 'buyer';
  animalName?: string;
  villageName?: string;
  address?: string;
  entries: MilkEntry[];
  createdAt: string;
  pendingBalance?: number;
  canSeeCalculations?: boolean;
  personalRate?: number;
  /** Per-customer rate system: dairy default, FAT-only, or FAT+SNF. */
  rateSystem?: 'default' | 'fat' | 'fat_snf';
  userId?: string;
}

interface RateSettings {
  fatRate: number;
  literRate: number;
  showCalculationsToSuppliers: boolean;
  calculationMethod: 'avg_fat' | 'daily_total';
}

export interface PaymentHistoryRecord {
  id: string;
  supplier_id: string;
  transaction_date: string;
  amount_added: number;
  amount_paid: number;
  balance_after: number;
  notes: string | null;
  supplier_confirmed: boolean | null;
  created_at: string;
  updated_at?: string;
  deleted_at?: string | null;
}

interface DairyContextType {
  suppliers: Supplier[];
  addSupplier: (supplier: Omit<Supplier, 'id' | 'dairyId' | 'entries' | 'createdAt'>) => Promise<void>;
  updateSupplier: (id: string, supplier: Partial<Supplier>) => Promise<void>;
  deleteSupplier: (id: string) => Promise<void>;
  addMilkEntry: (supplierId: string, entry: MilkEntry) => Promise<void>;
  updateMilkEntry: (supplierId: string, date: string, entry: Partial<MilkEntry>) => Promise<void>;
  rateSettings: RateSettings;
  updateRateSettings: (settings: Partial<RateSettings>) => Promise<void>;
  /** FAT/SNF rate settings — synced on fresh login only, cached locally after that. */
  fatSnfSettings: FatSnfRateSettings;
  /** Local-optimistic update after the owner saves FAT/SNF settings. */
  setFatSnfSettingsLocal: (settings: FatSnfRateSettings) => void;
  /** Owner settings — synced on fresh login only, cached locally after that. */
  ownerSettings: OwnerSettings;
  /** Local-optimistic update after the owner saves settings. */
  setOwnerSettingsLocal: (settings: Partial<OwnerSettings>) => void;
  getSupplierStats: (supplierId: string, days: number) => {
    totalMilk: number;
    totalFat: number;
    avgFat: number;
    totalAmount: number;
    fatEntryCount: number;
  };
  getTodayStats: () => {
    totalMilk: number;
    totalFat: number;
    avgFat: number;
    morningMilk: number;
    eveningMilk: number;
    morningAvgFat: number;
    eveningAvgFat: number;
    suppliers: number;
  };
  getSupplierByPhone: (phone: string) => Supplier | undefined;
  updateDairy: (name: string) => Promise<boolean>;
  loading: boolean;
  isOnline: boolean;
  pendingSyncCount: number;
  refreshData: () => Promise<void>;
  
  patchSupplierLocal: (id: string, updates: Partial<Supplier>) => void;
  enableNotifications: () => Promise<boolean>;
  /** Delta-sync milk entries for ONE supplier (called when a supplier page opens). */
  syncSupplierEntries: (supplierId: string) => Promise<void>;
  /** Delta-sync payment history for the whole dairy (called on Customer History page). */
  syncPaymentHistoryDelta: (supplierId?: string) => Promise<void>;
  /** App-wide payment history (all suppliers), cached + delta-synced. */
  paymentHistory: PaymentHistoryRecord[];
  getSupplierPayments: (supplierId: string) => PaymentHistoryRecord[];
  upsertPaymentLocal: (row: PaymentHistoryRecord) => void;
}

const DairyContext = createContext<DairyContextType | undefined>(undefined);

// Cache keys (versioned so a schema change safely invalidates)
const CACHE_KEY_SUPPLIERS = 'dairy_app_suppliers_cache';
const CACHE_KEY_RATES = 'dairy_app_rates_cache';
const CACHE_KEY_FAT_SNF = 'dairy_app_fat_snf_settings';

// Column sets for milk_entries. A supplier/customer login only ever renders
// milk + fat (SNF/CLR are never shown on their card), so we don't download them.
const ENTRY_COLS_FULL = '*';
const ENTRY_COLS_SUPPLIER =
  'id,supplier_id,dairy_id,date,time_of_day,quantity,fat,price,updated_at,deleted_at';
const CACHE_KEY_TIMESTAMP = 'dairy_app_cache_timestamp';
const CACHE_KEY_PAYMENTS = 'dairy_app_payment_history_cache';
// Delta-sync keys: max(updated_at) seen per (dairy, table)
const DELTA_KEY = (dairyId: string, table: string) => `dairy_delta_v1_${dairyId}_${table}`;
// Per-supplier milk-entry watermark (supplier page delta). Dairy-scoped so a
// different dairy/login never reuses another dairy's watermark.
const SUPPLIER_DELTA_KEY = (dairyId: string, supplierId: string) =>
  `dairy_delta_v1_${dairyId}_milk_entries_${supplierId}`;
// Per-tab-session guard: one supplier → at most ONE network call per session.
const SUPPLIER_SESSION_KEY = (dairyId: string, supplierId: string) =>
  `dairy_cq_session_v1_milk_entries_${dairyId}_${supplierId}`;
// Set by AuthContext on a fresh password login — rate_settings syncs only then.
const FRESH_LOGIN_KEY = 'dairy_fresh_login_rates';
// First run is authoritative (no watermark → fetches everything). After that,
// only delta rows come through. Soft-delete via deleted_at makes deletions
// propagate through updated_at, so no periodic full sync is needed.

export const DairyProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const { user, authUser } = useAuth();
  const [suppliers, setSuppliers] = useState<Supplier[]>(() => {
    const cached = localStorage.getItem(CACHE_KEY_SUPPLIERS);
    return cached ? JSON.parse(cached) : [];
  });
  const [rateSettings, setRateSettings] = useState<RateSettings>(() => {
    const cached = localStorage.getItem(CACHE_KEY_RATES);
    return cached ? JSON.parse(cached) : { fatRate: 8, literRate: 50, showCalculationsToSuppliers: true, calculationMethod: 'avg_fat' };
  });
  const [fatSnfSettings, setFatSnfSettings] = useState<FatSnfRateSettings>(() => {
    try {
      const cached = localStorage.getItem(CACHE_KEY_FAT_SNF);
      return cached ? JSON.parse(cached) : defaultFatSnfSettings;
    } catch {
      return defaultFatSnfSettings;
    }
  });
  const [ownerSettings, setOwnerSettings] = useState<OwnerSettings>(() => {
    try {
      const cached = localStorage.getItem(OWNER_SETTINGS_CACHE_KEY);
      return cached ? { ...defaultOwnerSettings, ...JSON.parse(cached) } : defaultOwnerSettings;
    } catch {
      return defaultOwnerSettings;
    }
  });
  const [loading, setLoading] = useState(() => {
    const cached = localStorage.getItem(CACHE_KEY_SUPPLIERS);
    return !cached;
  });
  const [isOnline, setIsOnline] = useState(navigator.onLine);
  const [paymentHistory, setPaymentHistory] = useState<PaymentHistoryRecord[]>(() => {
    try {
      const cached = localStorage.getItem(CACHE_KEY_PAYMENTS);
      return cached ? JSON.parse(cached) : [];
    } catch { return []; }
  });
  const [pendingSyncCount, setPendingSyncCount] = useState(0);
  const syncInFlightRef = useRef(false);
  const fetchDataRef = useRef<(() => void) | null>(null);
  const fetchInFlightRef = useRef(false);

  const applyPendingSupplierQueue = useCallback(async (baseSuppliers: Supplier[]) => {
    if (!user?.dairyId) return baseSuppliers;

    try {
      const queue = await getSyncQueue();
      const supplierMap = new Map(baseSuppliers.map(supplier => [supplier.id, supplier]));

      for (const action of queue) {
        if (action.table !== 'suppliers') continue;

        const data = (action.data ?? {}) as Record<string, any>;

        if (action.type === 'insert' || action.type === 'upsert') {
          if (data.dairy_id !== user.dairyId || !data.id) continue;

          const existing = supplierMap.get(data.id);
          supplierMap.set(data.id, {
            id: data.id,
            dairyId: data.dairy_id,
            name: data.name ?? existing?.name ?? '',
            phone: data.phone ?? existing?.phone ?? '',
            code: data.code ? String(data.code) : existing?.code,
            animalType: (data.animal_type as Supplier['animalType']) ?? existing?.animalType ?? 'cow',
            animalName: data.animal_name ?? existing?.animalName,
            villageName: data.village_name ?? existing?.villageName,
            address: data.address ?? existing?.address,
            entries: existing?.entries ?? [],
            createdAt: data.created_at ?? existing?.createdAt ?? new Date().toISOString(),
            pendingBalance: Number(data.pending_balance ?? existing?.pendingBalance ?? 0),
            canSeeCalculations: data.can_see_calculations ?? existing?.canSeeCalculations ?? true,
            personalRate: data.personal_rate != null ? Number(data.personal_rate) : existing?.personalRate,
            rateSystem: (data.rate_system as Supplier['rateSystem']) ?? existing?.rateSystem ?? 'default',
          });
          continue;
        }

        const targetId = action.matchColumn === 'id' ? action.matchValue : undefined;
        if (!targetId) continue;

        if (action.type === 'delete') {
          supplierMap.delete(targetId);
          continue;
        }

        if (action.type === 'update') {
          const existing = supplierMap.get(targetId);
          if (!existing) continue;

          supplierMap.set(targetId, {
            ...existing,
            name: data.name ?? existing.name,
            phone: data.phone ?? existing.phone,
            code: data.code !== undefined ? (data.code || undefined) : existing.code,
            animalType: (data.animal_type as Supplier['animalType']) ?? existing.animalType,
            animalName: data.animal_name !== undefined ? data.animal_name || undefined : existing.animalName,
            villageName: data.village_name !== undefined ? data.village_name || undefined : existing.villageName,
            address: data.address !== undefined ? data.address || undefined : existing.address,
            pendingBalance: data.pending_balance !== undefined ? Number(data.pending_balance) : existing.pendingBalance,
            canSeeCalculations: data.can_see_calculations ?? existing.canSeeCalculations,
            personalRate: data.personal_rate !== undefined ? (data.personal_rate != null ? Number(data.personal_rate) : undefined) : existing.personalRate,
            rateSystem: (data.rate_system as Supplier['rateSystem']) ?? existing.rateSystem ?? 'default',
          });
        }
      }

      return Array.from(supplierMap.values());
    } catch {
      return baseSuppliers;
    }
  }, [user?.dairyId]);

  // Monitor online status + external sync refreshes
  useEffect(() => {
    const handleOnline = () => setIsOnline(true);
    const handleOffline = () => setIsOnline(false);
    const handleVisibilityChange = () => {
      if (document.visibilityState === 'visible') {
        setIsOnline(navigator.onLine);
        // Resume from background (screen off→on / tab switch): React never
        // remounts, so re-run the delta-sync explicitly. `fetchInFlightRef`
        // keeps mount + resume from firing two parallel syncs.
        if (navigator.onLine && user?.dairyId) fetchDataRef.current?.();
      }
    };

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);
    document.addEventListener('visibilitychange', handleVisibilityChange);

    // Listen for sync-complete events from OfflineIndicator
    const handleSyncComplete = () => {
      if (user?.dairyId) fetchDataRef.current?.();
    };
    window.addEventListener('sync-complete', handleSyncComplete);

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
      document.removeEventListener('visibilitychange', handleVisibilityChange);
      window.removeEventListener('sync-complete', handleSyncComplete);
    };
  }, [user?.dairyId]);

  // Event-driven sync count (no polling)
  useEffect(() => {
    const updateCount = async () => {
      try {
        const count = await getSyncQueueCount();
        setPendingSyncCount(count);
      } catch { /* ignore */ }
    };
    updateCount();
    const onQueueChanged = () => updateCount();
    window.addEventListener('sync-queue-changed', onQueueChanged);
    window.addEventListener('focus', onQueueChanged);
    window.addEventListener('online', onQueueChanged);
    return () => {
      window.removeEventListener('sync-queue-changed', onQueueChanged);
      window.removeEventListener('focus', onQueueChanged);
      window.removeEventListener('online', onQueueChanged);
    };
  }, []);

  // Save to cache whenever data changes
  useEffect(() => {
    if (suppliers.length > 0) {
      localStorage.setItem(CACHE_KEY_SUPPLIERS, JSON.stringify(suppliers));
    }
  }, [suppliers]);

  useEffect(() => {
    localStorage.setItem(CACHE_KEY_RATES, JSON.stringify(rateSettings));
  }, [rateSettings]);

  // Local-optimistic sync: settings pages dispatch these after a successful save,
  // so the centralized state updates without any extra network call.
  useEffect(() => {
    const onOwner = (e: Event) => {
      const detail = (e as CustomEvent).detail as Partial<OwnerSettings> | undefined;
      if (detail) setOwnerSettings(prev => ({ ...prev, ...detail }));
    };
    const onFatSnf = (e: Event) => {
      const detail = (e as CustomEvent).detail as FatSnfRateSettings | undefined;
      if (detail) setFatSnfSettings(detail);
    };
    window.addEventListener('owner-settings-updated', onOwner);
    window.addEventListener('fat-snf-settings-updated', onFatSnf);
    return () => {
      window.removeEventListener('owner-settings-updated', onOwner);
      window.removeEventListener('fat-snf-settings-updated', onFatSnf);
    };
  }, []);

  const fetchData = useCallback(async (force = false) => {
    if (!user?.dairyId) {
      setSuppliers([]);
      setLoading(false);
      return;
    }

    // No network → cache-only path (state already hydrated from localStorage).
    if (!navigator.onLine) {
      setLoading(false);
      return;
    }

    // Duplicate-call guard: mount-effect and resume/visibility can fire together.
    if (fetchInFlightRef.current) return;
    fetchInFlightRef.current = true;

    const dairyId = user.dairyId;
    // Role-based path: a SUPPLIER/customer login must never run the owner's
    // dairy-wide sync. It only needs its own supplier row (+ its own entries).
    const isSupplier = user.role === 'supplier';
    // Decide whether this run is a FULL refresh (first time OR >24h old) or a
    // cheap DELTA refresh (only rows changed since last sync). Delta is what
    // makes the app scale on the Supabase free tier — after the first load,
    // repeat opens transfer near-zero rows.
    const cachedSuppliersRaw = localStorage.getItem(CACHE_KEY_SUPPLIERS);
    const hasCache = !!cachedSuppliersRaw && cachedSuppliersRaw !== '[]';
    const doFullSync = !hasCache;

    // No realtime subscriptions exist in this app — freshness comes purely from
    // these delta checks on app open/reopen (cache renders first, delta merges).



    // Only show the blocking spinner on the very first load. Delta refreshes
    // happen in the background while the cached UI stays visible.
    if (!hasCache) setLoading(true);

    try {
      const suppliersDeltaKey = DELTA_KEY(dairyId, 'suppliers');
      const entriesDeltaKey = DELTA_KEY(dairyId, 'milk_entries');

      // ---------- SUPPLIERS (first-time login / explicit force ONLY) ----------
      // On plain reopen we never re-query suppliers — the Dashboard's customer
      // count and balances render from the localStorage cache. Owner writes patch
      // the cache optimistically; Customer History's delta refreshes balances.
      let suppliersDelta: any[] = [];
      if (doFullSync || force) {
        let suppliersQuery = supabase
          .from('suppliers')
          .select('*')
          .eq('dairy_id', dairyId);
        // Supplier login → only their OWN record, never the whole dairy.
        if (isSupplier && authUser?.id) suppliersQuery = suppliersQuery.eq('user_id', authUser.id);
        const suppliersSince = doFullSync ? null : localStorage.getItem(suppliersDeltaKey);
        if (suppliersSince) suppliersQuery = suppliersQuery.gt('updated_at', suppliersSince);
        suppliersDelta = await fetchAllRows(suppliersQuery);
      }

      // ---------- MILK ENTRIES ----------
      const cachedSuppliers: Supplier[] = hasCache ? JSON.parse(cachedSuppliersRaw!) : [];
      // Universe of supplier ids we care about: cache + delta.
      const supplierIdSet = new Set<string>([
        ...cachedSuppliers.map(s => s.id),
        ...(suppliersDelta || []).map((s: any) => s.id),
      ]);
      const allSupplierIds = Array.from(supplierIdSet);

      // MILK ENTRIES:
      //  - Owner login: only on the FIRST full sync (empty cache) or explicit force;
      //    each supplier page delta-syncs its own entries on open.
      //  - Supplier login: delta-check on EVERY app open/reopen, scoped to their own
      //    supplier id(s), so entries added by the owner show up after a reopen.
      //    Cache renders instantly; this runs in the background and merges.
      let entriesDelta: any[] = [];
      const entriesRequestedAt = new Date().toISOString();
      const shouldSyncEntries = (doFullSync || force || isSupplier) && allSupplierIds.length > 0;
      if (shouldSyncEntries) {
        let entriesQuery = supabase
          .from('milk_entries')
          .select(isSupplier ? ENTRY_COLS_SUPPLIER : ENTRY_COLS_FULL)
          .in('supplier_id', allSupplierIds)
          .order('date', { ascending: true });
        const entriesSince = doFullSync ? null : localStorage.getItem(entriesDeltaKey);
        if (entriesSince) entriesQuery = entriesQuery.gt('updated_at', entriesSince);
        entriesDelta = await fetchAllRows(entriesQuery);
      }


      // ---------- MERGE / MAP ----------
      // Start from cached suppliers (only for delta runs). On full sync, we
      // rebuild from scratch — this is what prunes rows deleted on other devices.
      const supplierById = new Map<string, Supplier>(
        doFullSync ? [] : cachedSuppliers.map(s => [s.id, s])
      );

      // Apply supplier delta (upserts) — preserve existing entries.
      // Soft-deleted rows (deleted_at IS NOT NULL) are removed from the map.
      for (const s of (suppliersDelta || []) as any[]) {
        if (s.deleted_at) {
          supplierById.delete(s.id);
          continue;
        }
        const existing = supplierById.get(s.id);
        supplierById.set(s.id, {
          id: s.id,
          dairyId: s.dairy_id,
          name: s.name,
          phone: s.phone,
          code: s.code || undefined,
          animalType: (s.animal_type as Supplier['animalType']) || 'cow',
          villageName: s.village_name || undefined,
          address: s.address || undefined,
          entries: existing?.entries ?? [],
          createdAt: s.created_at,
          pendingBalance: Number(s.pending_balance) || 0,
          canSeeCalculations: s.can_see_calculations ?? true,
          personalRate: s.personal_rate != null ? Number(s.personal_rate) : undefined,
          rateSystem: ((s as any).rate_system as Supplier['rateSystem']) || 'default',
          userId: (s as any).user_id || undefined,
        });
      }

      // Apply milk-entry delta — merge by (supplierId, date, timeOfDay).
      // Soft-deleted rows clear the corresponding shift's values.
      const applyEntryToSupplier = (row: any) => {
        const sup = supplierById.get(row.supplier_id);
        if (!sup) return;
        const isDeleted = !!row.deleted_at;
        let entry = sup.entries.find(e => e.date === row.date);
        if (!entry) {
          if (isDeleted) return; // nothing to remove
          entry = {
            date: row.date,
            morningMilk: null, morningFat: null, morningSNF: null, morningLR: null, morningPrice: null,
            eveningMilk: null, eveningFat: null, eveningSNF: null, eveningLR: null, eveningPrice: null,
          };
          sup.entries = [...sup.entries, entry];
        }
        if (row.time_of_day === 'morning') {
          entry.morningMilk = isDeleted ? null : row.quantity;
          entry.morningFat = isDeleted ? null : row.fat;
          entry.morningSNF = isDeleted ? null : row.snf ?? null;
          entry.morningLR = isDeleted ? null : row.lr ?? null;
          entry.morningPrice = isDeleted ? null : row.price;
        } else {
          entry.eveningMilk = isDeleted ? null : row.quantity;
          entry.eveningFat = isDeleted ? null : row.fat;
          entry.eveningSNF = isDeleted ? null : row.snf ?? null;
          entry.eveningLR = isDeleted ? null : row.lr ?? null;
          entry.eveningPrice = isDeleted ? null : row.price;
        }
        // If both shifts are null after applying, drop the empty entry row.
        if (
          entry.morningMilk == null && entry.morningFat == null && entry.morningPrice == null &&
          entry.eveningMilk == null && entry.eveningFat == null && entry.eveningPrice == null
        ) {
          sup.entries = sup.entries.filter(e => e.date !== entry!.date);
        }
      };

      if (doFullSync) {
        // Full run: entriesDelta is authoritative → rebuild entries per supplier.
        for (const sup of supplierById.values()) sup.entries = [];
        for (const row of entriesDelta) if (!row.deleted_at) applyEntryToSupplier(row);
      } else {
        for (const row of entriesDelta) applyEntryToSupplier(row);
      }


      const mappedSuppliers = Array.from(supplierById.values());
      const mergedSuppliers = await applyPendingSupplierQueue(mappedSuppliers);
      setSuppliers(mergedSuppliers);
      localStorage.setItem(CACHE_KEY_SUPPLIERS, JSON.stringify(mergedSuppliers));

      // Advance delta watermarks (max updated_at we've seen).
      const maxUpdated = (rows: any[]) =>
        rows.reduce<string | null>((acc, r) => (!acc || r.updated_at > acc ? r.updated_at : acc), null);
      const supMax = maxUpdated(suppliersDelta || []);
      if (supMax) localStorage.setItem(suppliersDeltaKey, supMax);
      const entMax = maxUpdated(entriesDelta || []);
      if (entMax) localStorage.setItem(entriesDeltaKey, entMax);
      else if (shouldSyncEntries && !localStorage.getItem(entriesDeltaKey)) {
        // No rows at all → seed a watermark so the next reopen is a cheap delta.
        localStorage.setItem(entriesDeltaKey, entriesRequestedAt);
      }


      // On a full sync we just pulled EVERY supplier's entries, so seed each
      // supplier's own watermark too. Without this, the first time a supplier
      // card opens in a session, syncSupplierEntries() finds no watermark and
      // re-downloads data that is already cached.
      if (doFullSync && allSupplierIds.length > 0) {
        const perSupplierMax = new Map<string, string>();
        for (const row of entriesDelta || []) {
          if (!row?.supplier_id || !row?.updated_at) continue;
          const prev = perSupplierMax.get(row.supplier_id);
          if (!prev || row.updated_at > prev) perSupplierMax.set(row.supplier_id, row.updated_at);
        }
        for (const sid of allSupplierIds) {
          try {
            localStorage.setItem(
              SUPPLIER_DELTA_KEY(dairyId, sid),
              perSupplierMax.get(sid) || entriesRequestedAt
            );
          } catch { /* quota */ }
        }
      }

      // ---------- PAYMENT HISTORY (all suppliers in ONE query, delta-synced) ----------
      // First run (no watermark) pulls the whole dairy's history with only the
      // columns the UI needs; every later open transfers just changed rows.
      // Only on the first full sync (or force). Reopen reads from cache; the
      // Customer History page runs its own delta.
      const paymentsDeltaKey = DELTA_KEY(dairyId, 'payment_history');
      let paymentsDelta: any[] = [];
      // Supplier login: payment_history is fetched from exactly ONE place —
      // SupplierDashboard's per-supplier cached query. Never here.
      if (doFullSync && !isSupplier) {
        let paymentsQuery = supabase
          .from('payment_history')
          .select('id,supplier_id,transaction_date,amount_added,amount_paid,balance_after,notes,supplier_confirmed,created_at,updated_at,deleted_at')
          .eq('dairy_id', dairyId);
        paymentsDelta = await fetchAllRows(paymentsQuery);
      }

      if (doFullSync && paymentsDelta) {
        const cachedPaymentsRaw = localStorage.getItem(CACHE_KEY_PAYMENTS);
        const cachedPayments: PaymentHistoryRecord[] =
          !doFullSync && cachedPaymentsRaw ? JSON.parse(cachedPaymentsRaw) : [];
        const payMap = new Map<string, PaymentHistoryRecord>(cachedPayments.map(p => [p.id, p]));
        for (const row of (paymentsDelta || []) as any[]) {
          if (row.deleted_at) { payMap.delete(row.id); continue; }
          payMap.set(row.id, row as PaymentHistoryRecord);
        }
        const mergedPayments = Array.from(payMap.values());
        setPaymentHistory(mergedPayments);
        try { localStorage.setItem(CACHE_KEY_PAYMENTS, JSON.stringify(mergedPayments)); } catch { /* quota */ }
      }
      const payMax = maxUpdated((paymentsDelta || []) as any[]);
      if (payMax) localStorage.setItem(paymentsDeltaKey, payMax);

      // ---------- DAIRY CONFIG (rate + fat/snf + owner settings) — fresh LOGIN only ----------
      const freshLogin = localStorage.getItem(FRESH_LOGIN_KEY) === '1';
      const needConfig = doFullSync || freshLogin || force;
      let cfg: any = null;
      if (needConfig) {
        const { data, error } = await supabase.rpc('get_dairy_config_bootstrap' as any);
        if (error) console.error('Error fetching dairy config:', error);
        cfg = data ?? null;
      }
      const rateData: any = cfg?.rate_settings ?? null;
      if (freshLogin) localStorage.removeItem(FRESH_LOGIN_KEY);

      if (rateData) {
        const cachedRates = localStorage.getItem(CACHE_KEY_RATES);
        const existingRates = cachedRates ? JSON.parse(cachedRates) : { literRate: 50, showCalculationsToSuppliers: true, calculationMethod: 'avg_fat' };
        const newRates = {
          fatRate: Number(rateData.rate_value) || 8,
          literRate: Number((rateData as any).liter_rate) || existingRates.literRate || 50,
          showCalculationsToSuppliers: (rateData as any).show_calculations_to_suppliers ?? existingRates.showCalculationsToSuppliers ?? true,
          calculationMethod: ((rateData as any).calculation_method as 'avg_fat' | 'daily_total') || existingRates.calculationMethod || 'avg_fat',
        };
        setRateSettings(newRates);
        localStorage.setItem(CACHE_KEY_RATES, JSON.stringify(newRates));
      }

      if (needConfig) {
        const fatSnfData: any = cfg?.fat_snf_rate_settings ?? null;
        if (fatSnfData) {
          const newFatSnf: FatSnfRateSettings = {
            isEnabled: fatSnfData.is_enabled ?? false,
            baseFatRate: Number(fatSnfData.base_fat_rate),
            baseSNF: Number(fatSnfData.base_snf),
            snfDeductionPerPoint: Number(fatSnfData.snf_deduction_per_point),
            fatMin: Number(fatSnfData.fat_min),
            fatMax: Number(fatSnfData.fat_max),
            fatStep: Number(fatSnfData.fat_step),
            snfMin: Number(fatSnfData.snf_min),
            snfMax: Number(fatSnfData.snf_max),
          };
          setFatSnfSettings(newFatSnf);
          localStorage.setItem(CACHE_KEY_FAT_SNF, JSON.stringify(newFatSnf));
        }

        const ownerData: any = cfg?.owner_settings ?? null;
        if (ownerData) {
          const newOwner = mapOwnerSettingsRow(ownerData);
          setOwnerSettings(newOwner);
          try { localStorage.setItem(OWNER_SETTINGS_CACHE_KEY, JSON.stringify(newOwner)); } catch { /* quota */ }
        }
      }

      localStorage.setItem(CACHE_KEY_TIMESTAMP, new Date().toISOString());
      
      
    } catch (error) {
      console.error('Error fetching data:', error);
    } finally {
      fetchInFlightRef.current = false;
      setLoading(false);
    }
  }, [applyPendingSupplierQueue, user?.dairyId, user?.role, authUser?.id]);

  const syncPendingChanges = useCallback(async () => {
    if (!user?.dairyId || !navigator.onLine || syncInFlightRef.current) return;

    try {
      const queuedBeforeSync = await getSyncQueueCount();
      setPendingSyncCount(queuedBeforeSync);

      if (queuedBeforeSync === 0) return;

      syncInFlightRef.current = true;
      const result = await processSyncQueue();
      const remaining = await getSyncQueueCount();

      setPendingSyncCount(remaining);

      if (result.synced > 0 || remaining !== queuedBeforeSync) {
        await fetchData();
      }
    } catch (error) {
      console.error('Error syncing offline changes:', error);
      try {
        const remaining = await getSyncQueueCount();
        setPendingSyncCount(remaining);
      } catch {
        // ignore count refresh failure
      }
    } finally {
      syncInFlightRef.current = false;
    }
  }, [fetchData, user?.dairyId]);

  /**
   * Supplier page open → delta-query THIS supplier's milk entries only and merge
   * them into the cached supplier record (no full rewrite, no other suppliers).
   */
  const syncSupplierEntries = useCallback(async (supplierId: string) => {
    const dairyId = user?.dairyId;
    if (!supplierId || !dairyId || !navigator.onLine) return;

    // ---- Session guard: only the FIRST open of this supplier in this tab-session
    // hits the network. Reopening the same card in the same session is cache-only.
    // sessionStorage clears itself on a new tab-session (reopen) → fresh delta then.
    const sessKey = SUPPLIER_SESSION_KEY(dairyId, supplierId);
    try {
      if (sessionStorage.getItem(sessKey)) return;
      sessionStorage.setItem(sessKey, '1');
    } catch { /* sessionStorage unavailable → fall through */ }

    const wmKey = SUPPLIER_DELTA_KEY(dairyId, supplierId);
    try {
      const cols = user?.role === 'supplier' ? ENTRY_COLS_SUPPLIER : ENTRY_COLS_FULL;
      let q = supabase.from('milk_entries').select(cols).eq('supplier_id', supplierId).order('date', { ascending: true });
      const since = localStorage.getItem(wmKey);
      if (since) q = q.gt('updated_at', since);
      const requestedAt = new Date().toISOString();
      const rows = await fetchAllRows(q);
      if (!rows || rows.length === 0) {
        // Nothing new — still persist a watermark so the next session can delta.
        if (!since) { try { localStorage.setItem(wmKey, requestedAt); } catch { /* quota */ } }
        return;
      }

      setSuppliers(prev => {
        const next = prev.map(s => {
          if (s.id !== supplierId) return s;
          const byDate = new Map<string, MilkEntry>(s.entries.map(e => [e.date, { ...e }]));
          for (const row of rows as any[]) {
            const isDeleted = !!row.deleted_at;
            let entry = byDate.get(row.date);
            if (!entry) {
              if (isDeleted) continue;
              entry = {
                date: row.date,
                morningMilk: null, morningFat: null, morningSNF: null, morningLR: null, morningPrice: null,
                eveningMilk: null, eveningFat: null, eveningSNF: null, eveningLR: null, eveningPrice: null,
              };
              byDate.set(row.date, entry);
            }
            if (row.time_of_day === 'morning') {
              entry.morningMilk = isDeleted ? null : row.quantity;
              entry.morningFat = isDeleted ? null : row.fat;
              entry.morningSNF = isDeleted ? null : row.snf ?? null;
              entry.morningLR = isDeleted ? null : row.lr ?? null;
              entry.morningPrice = isDeleted ? null : row.price;
            } else {
              entry.eveningMilk = isDeleted ? null : row.quantity;
              entry.eveningFat = isDeleted ? null : row.fat;
              entry.eveningSNF = isDeleted ? null : row.snf ?? null;
              entry.eveningLR = isDeleted ? null : row.lr ?? null;
              entry.eveningPrice = isDeleted ? null : row.price;
            }
            if (
              entry.morningMilk == null && entry.morningFat == null && entry.morningPrice == null &&
              entry.eveningMilk == null && entry.eveningFat == null && entry.eveningPrice == null
            ) {
              byDate.delete(row.date);
            }
          }
          const entries = Array.from(byDate.values()).sort((a, b) => a.date.localeCompare(b.date));
          return { ...s, entries };
        });
        try { localStorage.setItem(CACHE_KEY_SUPPLIERS, JSON.stringify(next)); } catch { /* quota */ }
        return next;
      });

      // ---- WRITE SIDE: always advance the watermark (same key as the read side).
      const max = (rows as any[]).reduce<string | null>(
        (acc, r) => (r?.updated_at && (!acc || r.updated_at > acc) ? r.updated_at : acc),
        null,
      );
      try { localStorage.setItem(wmKey, max || requestedAt); } catch { /* quota */ }
    } catch (err) {
      console.error('Error syncing supplier entries:', err);
      // Failed attempt shouldn't burn the session guard.
      try { sessionStorage.removeItem(sessKey); } catch { /* ignore */ }
    }
  }, [user?.dairyId]);

  /** Customer History page open → delta-query payment_history and merge in cache. */
  const syncPaymentHistoryDelta = useCallback(async (supplierId?: string) => {
    if (!user?.dairyId || !navigator.onLine) return;
    // Owner-only path (Customer History page). Suppliers read their own history
    // from SupplierDashboard's single cached query.
    if (user.role === 'supplier') return;
    const dairyId = user.dairyId;
    // Per-supplier watermark when scoped, dairy-wide watermark otherwise.
    const wmKey = supplierId
      ? DELTA_KEY(`${dairyId}:${supplierId}`, 'payment_history')
      : DELTA_KEY(dairyId, 'payment_history');
    try {
      let q = supabase
        .from('payment_history')
        .select('id,supplier_id,transaction_date,amount_added,amount_paid,balance_after,notes,supplier_confirmed,created_at,updated_at,deleted_at')
        .eq('dairy_id', dairyId);
      if (supplierId) q = q.eq('supplier_id', supplierId);
      const since = localStorage.getItem(wmKey);
      if (since) q = q.gt('updated_at', since);
      const rows = await fetchAllRows(q);
      if (!rows || rows.length === 0) return;

      setPaymentHistory(prev => {
        const map = new Map<string, PaymentHistoryRecord>(prev.map(p => [p.id, p]));
        for (const row of rows as any[]) {
          if (row.deleted_at) { map.delete(row.id); continue; }
          map.set(row.id, row as PaymentHistoryRecord);
        }
        const next = Array.from(map.values());
        try { localStorage.setItem(CACHE_KEY_PAYMENTS, JSON.stringify(next)); } catch { /* quota */ }
        return next;
      });

      const max = (rows as any[]).reduce<string | null>((acc, r) => (!acc || r.updated_at > acc ? r.updated_at : acc), null);
      if (max) localStorage.setItem(wmKey, max);
    } catch (err) {
      console.error('Error syncing payment history:', err);
    }
  }, [user?.dairyId, user?.role]);

  useEffect(() => {
    fetchDataRef.current = fetchData;
  }, [fetchData]);

  useEffect(() => {
    fetchData();
  }, [fetchData]);

  useEffect(() => {
    if (isOnline) {
      syncPendingChanges();
    }
  }, [isOnline, syncPendingChanges]);

  // Sync pending changes once shortly after coming online (no continuous polling — saves battery & edge requests)
  useEffect(() => {
    if (!isOnline || pendingSyncCount === 0) return;

    const retryTimeout = window.setTimeout(() => {
      syncPendingChanges();
    }, 1200);

    return () => {
      window.clearTimeout(retryTimeout);
    };
  }, [isOnline, pendingSyncCount, syncPendingChanges]);

  // Sync on tab focus (covers cases where user returns to app)
  useEffect(() => {
    const handleFocus = () => {
      if (navigator.onLine) syncPendingChanges();
    };
    window.addEventListener('focus', handleFocus);
    document.addEventListener('visibilitychange', handleFocus);
    return () => {
      window.removeEventListener('focus', handleFocus);
      document.removeEventListener('visibilitychange', handleFocus);
    };
  }, [syncPendingChanges]);

  // Realtime removed — data freshness relies on delta-sync on page mount.
  const patchSupplierLocal = useCallback((id: string, updates: Partial<Supplier>) => {
    setSuppliers(prev => {
      const next = prev.map(s => s.id === id ? { ...s, ...updates } : s);
      try { localStorage.setItem(CACHE_KEY_SUPPLIERS, JSON.stringify(next)); } catch { /* ignore */ }
      return next;
    });
  }, []);

  const upsertPaymentLocal = useCallback((row: PaymentHistoryRecord) => {
    setPaymentHistory(prev => {
      const next = prev.some(p => p.id === row.id)
        ? prev.map(p => (p.id === row.id ? { ...p, ...row } : p))
        : [...prev, row];
      try { localStorage.setItem(CACHE_KEY_PAYMENTS, JSON.stringify(next)); } catch { /* quota */ }
      return next;
    });
  }, []);

  const getSupplierPayments = useCallback(
    (supplierId: string) => paymentHistory.filter(p => p.supplier_id === supplierId),
    [paymentHistory]
  );

  // ==================== OFFLINE-FIRST MUTATIONS ====================

  const addSupplier = async (supplier: Omit<Supplier, 'id' | 'dairyId' | 'entries' | 'createdAt'>) => {
    if (!user?.dairyId) return;


    const tempId = crypto.randomUUID();
    const newSupplier: Supplier = {
      id: tempId,
      dairyId: user.dairyId,
      name: supplier.name,
      phone: supplier.phone,
      code: supplier.code,
      animalType: supplier.animalType,
      villageName: supplier.villageName,
      address: supplier.address,
      entries: [],
      createdAt: new Date().toISOString(),
      pendingBalance: 0,
      canSeeCalculations: true,
      personalRate: supplier.personalRate,
      rateSystem: supplier.rateSystem ?? 'default',
    };

    // Update local state immediately
    setSuppliers(prev => [...prev, newSupplier]);

    const dbData = {
      id: tempId,
      dairy_id: user.dairyId,
      name: supplier.name,
      phone: supplier.phone,
      animal_type: supplier.animalType,
      village_name: supplier.villageName || null,
      address: supplier.address || null,
      code: supplier.code || '',
      personal_rate: supplier.personalRate ?? null,
      rate_system: supplier.rateSystem ?? 'default',
    };

    if (navigator.onLine) {
      try {
        const { data, error } = await supabase
          .from('suppliers')
          .insert(dbData as any)
          .select()
          .single();

        if (error) {
          console.error('Error adding supplier:', error);
          // Queue for later sync
          await addToSyncQueue({ type: 'insert', table: 'suppliers', data: dbData });
          setPendingSyncCount(prev => prev + 1);
        } else if (data) {
          // Update with real server data
          setSuppliers(prev => prev.map(s => s.id === tempId ? {
            ...s,
            id: data.id,
            createdAt: data.created_at,
          } : s));
        }
      } catch (err: any) {
        await addToSyncQueue({ type: 'insert', table: 'suppliers', data: dbData });
        setPendingSyncCount(prev => prev + 1);
      }
    } else {
      await addToSyncQueue({ type: 'insert', table: 'suppliers', data: dbData });
      setPendingSyncCount(prev => prev + 1);
    }
  };

  const updateSupplier = async (id: string, updates: Partial<Supplier>) => {
    if (!user?.dairyId) throw new Error('No dairy ID');


    // Update local state immediately
    setSuppliers(prev => prev.map(s => s.id === id ? { ...s, ...updates } : s));

    const updateData: any = {};
    if (updates.name) updateData.name = updates.name;
    if (updates.phone) updateData.phone = updates.phone;
    if (updates.code !== undefined) updateData.code = updates.code;
    if (updates.animalType) updateData.animal_type = updates.animalType;
    if (updates.villageName !== undefined) updateData.village_name = updates.villageName;
    if (updates.address !== undefined) updateData.address = updates.address;
    if (updates.personalRate !== undefined) updateData.personal_rate = updates.personalRate ?? null;
    if (updates.rateSystem !== undefined) updateData.rate_system = updates.rateSystem ?? 'default';

    if (navigator.onLine) {
      const { error } = await supabase
        .from('suppliers')
        .update(updateData)
        .eq('id', id)
        .eq('dairy_id', user.dairyId);

      if (error) {
        console.error('Error updating supplier:', error);
        await addToSyncQueue({
          type: 'update', table: 'suppliers', data: updateData,
          matchColumn: 'id', matchValue: id,
          matchColumn2: 'dairy_id', matchValue2: user.dairyId,
        });
        setPendingSyncCount(prev => prev + 1);
      }
    } else {
      await addToSyncQueue({
        type: 'update', table: 'suppliers', data: updateData,
        matchColumn: 'id', matchValue: id,
        matchColumn2: 'dairy_id', matchValue2: user.dairyId,
      });
      setPendingSyncCount(prev => prev + 1);
    }
  };

  const deleteSupplier = async (id: string) => {
    if (!user?.dairyId) throw new Error('No dairy ID');


    // Update local state immediately
    setSuppliers(prev => prev.filter(s => s.id !== id));

    const nowIso = new Date().toISOString();
    const supplierPatch = { deleted_at: nowIso };
    const entriesPatch = { deleted_at: nowIso };

    if (navigator.onLine) {
      // Soft-delete milk entries first, then supplier — matches the delta-sync
      // model: rows still exist server-side with deleted_at set, so any device's
      // delta-sync will pick up the removal on next open.
      await supabase.from('milk_entries').update(entriesPatch).eq('supplier_id', id).eq('dairy_id', user.dairyId);
      const { error } = await supabase.from('suppliers').update(supplierPatch).eq('id', id).eq('dairy_id', user.dairyId);

      if (error) {
        console.error('Error deleting supplier:', error);
        await addToSyncQueue({
          type: 'update', table: 'suppliers', data: supplierPatch,
          matchColumn: 'id', matchValue: id,
          matchColumn2: 'dairy_id', matchValue2: user.dairyId,
          prerequisiteActions: [{
            id: '', timestamp: 0,
            type: 'update', table: 'milk_entries',
            data: entriesPatch,
            matchColumn: 'supplier_id', matchValue: id,
            matchColumn2: 'dairy_id', matchValue2: user.dairyId,
          }],
        });
        setPendingSyncCount(prev => prev + 1);
      }
    } else {
      await addToSyncQueue({
        type: 'update', table: 'suppliers', data: supplierPatch,
        matchColumn: 'id', matchValue: id,
        matchColumn2: 'dairy_id', matchValue2: user.dairyId,
        prerequisiteActions: [{
          id: '', timestamp: 0,
          type: 'update', table: 'milk_entries',
          data: entriesPatch,
          matchColumn: 'supplier_id', matchValue: id,
          matchColumn2: 'dairy_id', matchValue2: user.dairyId,
        }],
      });
      setPendingSyncCount(prev => prev + 1);
    }
  };

  const addMilkEntry = async (supplierId: string, entry: MilkEntry) => {
    if (!user?.dairyId) return;


    // Update local state immediately
    setSuppliers(prev => prev.map(supplier => {
      if (supplier.id === supplierId) {
        const existingEntryIndex = supplier.entries.findIndex(e => e.date === entry.date);
        if (existingEntryIndex >= 0) {
          const updatedEntries = [...supplier.entries];
          updatedEntries[existingEntryIndex] = { ...updatedEntries[existingEntryIndex], ...entry };
          return { ...supplier, entries: updatedEntries };
        } else {
          return { ...supplier, entries: [...supplier.entries, entry] };
        }
      }
      return supplier;
    }));

    const entries = [];

    if (entry.morningMilk !== null || entry.morningFat !== null || entry.morningPrice !== null) {
      entries.push({
        supplier_id: supplierId,
        dairy_id: user.dairyId,
        date: entry.date,
        time_of_day: 'morning',
        quantity: entry.morningMilk,
        fat: entry.morningFat,
        snf: entry.morningSNF,
        lr: entry.morningLR,
        price: entry.morningPrice,
      });
    }

    if (entry.eveningMilk !== null || entry.eveningFat !== null || entry.eveningPrice !== null) {
      entries.push({
        supplier_id: supplierId,
        dairy_id: user.dairyId,
        date: entry.date,
        time_of_day: 'evening',
        quantity: entry.eveningMilk,
        fat: entry.eveningFat,
        snf: entry.eveningSNF,
        lr: entry.eveningLR,
        price: entry.eveningPrice,
      });
    }

    if (navigator.onLine) {
      // Try online, queue on failure
      Promise.all(
        entries.map(entryData =>
          supabase.from('milk_entries').upsert(entryData, { onConflict: 'supplier_id,date,time_of_day' })
        )
      ).then(async results => {
        const hasError = results.some(r => r.error);
        if (hasError) {
          console.error('Error saving milk entries:', results.filter(r => r.error));
          // Queue failed entries
          for (const entryData of entries) {
            await addToSyncQueue({
              type: 'upsert', table: 'milk_entries',
              data: entryData, onConflict: 'supplier_id,date,time_of_day',
            });
          }
          setPendingSyncCount(prev => prev + entries.length);
        }
      }).catch(async () => {
        for (const entryData of entries) {
          await addToSyncQueue({
            type: 'upsert', table: 'milk_entries',
            data: entryData, onConflict: 'supplier_id,date,time_of_day',
          });
        }
        setPendingSyncCount(prev => prev + entries.length);
      });
    } else {
      // Queue all entries for sync
      for (const entryData of entries) {
        await addToSyncQueue({
          type: 'upsert', table: 'milk_entries',
          data: entryData, onConflict: 'supplier_id,date,time_of_day',
        });
      }
      setPendingSyncCount(prev => prev + entries.length);
    }
  };

  const updateMilkEntry = async (supplierId: string, date: string, entry: Partial<MilkEntry>) => {
    if (!user?.dairyId) return;


    // Update local state immediately
    setSuppliers(prev => prev.map(supplier => {
      if (supplier.id === supplierId) {
        const existingEntryIndex = supplier.entries.findIndex(e => e.date === date);
        if (existingEntryIndex >= 0) {
          const updatedEntries = [...supplier.entries];
          updatedEntries[existingEntryIndex] = { ...updatedEntries[existingEntryIndex], ...entry };
          return { ...supplier, entries: updatedEntries };
        }
      }
      return supplier;
    }));

    const upsertAndQueue = async (timeOfDay: string, data: any) => {
      if (navigator.onLine) {
        const { error } = await supabase
          .from('milk_entries')
          .upsert(data, { onConflict: 'supplier_id,date,time_of_day' });
        if (error) {
          console.error('Error updating milk entry:', error);
          await addToSyncQueue({ type: 'upsert', table: 'milk_entries', data, onConflict: 'supplier_id,date,time_of_day' });
          setPendingSyncCount(prev => prev + 1);
        }
      } else {
        await addToSyncQueue({ type: 'upsert', table: 'milk_entries', data, onConflict: 'supplier_id,date,time_of_day' });
        setPendingSyncCount(prev => prev + 1);
      }
    };

    if (entry.morningMilk !== undefined || entry.morningFat !== undefined) {
      await upsertAndQueue('morning', {
        supplier_id: supplierId, dairy_id: user.dairyId, date,
        time_of_day: 'morning',
        quantity: entry.morningMilk, fat: entry.morningFat,
        snf: entry.morningSNF, lr: entry.morningLR,
        deleted_at: null, // resurrect if this shift was soft-deleted earlier
      });
    }

    if (entry.eveningMilk !== undefined || entry.eveningFat !== undefined) {
      await upsertAndQueue('evening', {
        supplier_id: supplierId, dairy_id: user.dairyId, date,
        time_of_day: 'evening',
        quantity: entry.eveningMilk, fat: entry.eveningFat,
        snf: entry.eveningSNF, lr: entry.eveningLR,
        deleted_at: null,
      });
    }
  };

  const updateRateSettings = async (settings: Partial<RateSettings>) => {
    const newSettings = { ...rateSettings, ...settings };
    setRateSettings(newSettings);

    if (!user?.dairyId) return;

    const dbData = {
      dairy_id: user.dairyId,
      rate_value: newSettings.fatRate,
      liter_rate: newSettings.literRate,
      show_calculations_to_suppliers: newSettings.showCalculationsToSuppliers,
      calculation_method: newSettings.calculationMethod,
    };

    if (navigator.onLine) {
      const { error } = await supabase
        .from('rate_settings')
        .upsert(dbData as any, { onConflict: 'dairy_id' });

      if (error) {
        console.error('Error updating rate settings:', error);
        await addToSyncQueue({ type: 'upsert', table: 'rate_settings', data: dbData, onConflict: 'dairy_id' });
        setPendingSyncCount(prev => prev + 1);
      }
    } else {
      await addToSyncQueue({ type: 'upsert', table: 'rate_settings', data: dbData, onConflict: 'dairy_id' });
      setPendingSyncCount(prev => prev + 1);
    }
  };


  const updateDairy = async (name: string) => {


    if (!user?.dairyId) return false;

    if (navigator.onLine) {
      const { error } = await supabase.from('dairies').update({ name }).eq('id', user.dairyId);
      if (error) {
        console.error('Error updating dairy:', error);
        await addToSyncQueue({ type: 'update', table: 'dairies', data: { name }, matchColumn: 'id', matchValue: user.dairyId });
        setPendingSyncCount(prev => prev + 1);
        return true; // Optimistic
      }
    } else {
      await addToSyncQueue({ type: 'update', table: 'dairies', data: { name }, matchColumn: 'id', matchValue: user.dairyId });
      setPendingSyncCount(prev => prev + 1);
    }

    return true;
  };

  // ==================== READ-ONLY COMPUTED DATA ====================

  const getSupplierStats = (supplierId: string, days: number) => {
    const supplier = suppliers.find(s => s.id === supplierId);
    if (!supplier) return { totalMilk: 0, totalFat: 0, avgFat: 0, totalAmount: 0, fatEntryCount: 0 };

    const cutoffDate = new Date();
    cutoffDate.setDate(cutoffDate.getDate() - days);
    const cutoffStr = cutoffDate.toISOString().split('T')[0];

    const recentEntries = supplier.entries.filter(e => e.date >= cutoffStr);
    
    let totalMilk = 0;
    let totalFat = 0;
    let fatEntryCount = 0;

    recentEntries.forEach(entry => {
      if (entry.morningMilk) totalMilk += entry.morningMilk;
      if (entry.eveningMilk) totalMilk += entry.eveningMilk;
      if (entry.morningFat) { totalFat += entry.morningFat; fatEntryCount++; }
      if (entry.eveningFat) { totalFat += entry.eveningFat; fatEntryCount++; }
    });

    const avgFat = fatEntryCount > 0 ? totalFat / fatEntryCount : 0;
    const isBuyer = supplier.animalType === 'buyer';
    const effectiveFatRate = supplier.personalRate ?? rateSettings.fatRate;
    const totalAmount = isBuyer 
      ? totalMilk * (rateSettings.literRate || 50)
      : avgFat * totalMilk * effectiveFatRate;

    return { totalMilk, totalFat, avgFat, totalAmount, fatEntryCount };
  };

  const getTodayStats = () => {
    const today = new Date().toISOString().split('T')[0];
    
    let totalMilk = 0;
    let totalFat = 0;
    let morningMilk = 0;
    let eveningMilk = 0;
    let morningFatSum = 0;
    let eveningFatSum = 0;
    let morningFatCount = 0;
    let eveningFatCount = 0;
    let activeSuppliers = 0;

    suppliers.forEach(supplier => {
      const todayEntry = supplier.entries.find(e => e.date === today);
      if (todayEntry) {
        let hasData = false;
        if (todayEntry.morningMilk) { morningMilk += todayEntry.morningMilk; totalMilk += todayEntry.morningMilk; hasData = true; }
        if (todayEntry.eveningMilk) { eveningMilk += todayEntry.eveningMilk; totalMilk += todayEntry.eveningMilk; hasData = true; }
        if (todayEntry.morningFat) { morningFatSum += todayEntry.morningFat; morningFatCount++; totalFat += todayEntry.morningFat; }
        if (todayEntry.eveningFat) { eveningFatSum += todayEntry.eveningFat; eveningFatCount++; totalFat += todayEntry.eveningFat; }
        if (hasData) activeSuppliers++;
      }
    });

    const fatCount = morningFatCount + eveningFatCount;
    return {
      totalMilk, totalFat,
      avgFat: fatCount > 0 ? totalFat / fatCount : 0,
      morningMilk, eveningMilk,
      morningAvgFat: morningFatCount > 0 ? morningFatSum / morningFatCount : 0,
      eveningAvgFat: eveningFatCount > 0 ? eveningFatSum / eveningFatCount : 0,
      suppliers: activeSuppliers,
    };
  };

  const getSupplierByPhone = (phone: string) => suppliers.find(s => s.phone === phone);

  const enableNotifications = async () => {
    const granted = await requestNotificationPermission();
    if (granted) {
      showNotification('Notifications Enabled', {
        body: 'You will now receive notifications for important events.',
      });
    }
    return granted;
  };

  const value: DairyContextType = {
    suppliers, addSupplier, updateSupplier, deleteSupplier,
    addMilkEntry, updateMilkEntry,
    rateSettings, updateRateSettings,
    fatSnfSettings,
    setFatSnfSettingsLocal: (s: FatSnfRateSettings) => {
      setFatSnfSettings(s);
      try { localStorage.setItem(CACHE_KEY_FAT_SNF, JSON.stringify(s)); } catch { /* quota */ }
    },
    ownerSettings,
    setOwnerSettingsLocal: (updates: Partial<OwnerSettings>) => {
      setOwnerSettings(prev => {
        const next = { ...prev, ...updates };
        try { localStorage.setItem(OWNER_SETTINGS_CACHE_KEY, JSON.stringify(next)); } catch { /* quota */ }
        return next;
      });
    },
    getSupplierStats, getTodayStats, getSupplierByPhone,
    updateDairy,
    loading, isOnline, pendingSyncCount,
    refreshData: () => fetchData(true),

    patchSupplierLocal,
    enableNotifications,
    syncSupplierEntries,
    syncPaymentHistoryDelta,
    paymentHistory,
    getSupplierPayments,
    upsertPaymentLocal,
  };

  return (
    <DairyContext.Provider value={value}>
      {children}
    </DairyContext.Provider>
  );
};

export const useDairy = () => {
  const context = useContext(DairyContext);
  if (context === undefined) {
    throw new Error('useDairy must be used within a DairyProvider');
  }
  return context;
};

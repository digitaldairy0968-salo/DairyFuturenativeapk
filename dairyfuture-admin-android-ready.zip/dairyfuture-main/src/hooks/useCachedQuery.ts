/**
 * useCachedQuery — cache-first read with `updated_at` delta sync + 24h full refresh.
 *
 * How it works:
 *   1. Hydrate state instantly from localStorage (no network wait).
 *   2. In the background, fetch only rows with `updated_at > lastSync` (delta).
 *      This makes repeat opens near-free on the Supabase free tier.
 *   3. Once every 24 hours, do a full authoritative fetch — this prunes rows
 *      that were deleted on another device (delta can't see deletes).
 *
 * Writes are unchanged — they go through the existing offline sync queue in
 * DairyContext / page code, and just update the cache locally after success.
 */
import { useEffect, useState, useCallback, useRef } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { fetchAllRows } from '@/lib/supabasePagination';

// Soft-delete pattern: delta-sync catches inserts/updates/deletes via updated_at
// (a delete flips deleted_at, which bumps updated_at). No periodic full sync
// needed — the very first fetch (no watermark) is authoritative, everything
// after that is delta-only.

interface Options<T> {
  /** Stable cache key: e.g. `sup_payments_${supplierId}`. */
  cacheKey: string;
  /** Filter column for scope + delta. Almost always `dairy_id` or `supplier_id`. */
  scope: string | null | undefined;
  /** Table name in Supabase. */
  table: string;
  /**
   * Returns the base `.select()` query WITHOUT any `.gt('updated_at', ...)`.
   * The hook adds delta filter on top when doing a delta fetch.
   */
  buildQuery: () => any;
  /** Map DB row → app shape. Called once per row. */
  mapRow?: (row: any) => T;
  /** Unique id extractor. Default: `row.id`. */
  idOf?: (row: T) => string;
  /** Skip network entirely. */
  enabled?: boolean;
  /** Return single row (uses maybeSingle) instead of an array. */
  single?: boolean;
  /**
   * Per-scope session guard: once a delta fetch has run for this exact
   * scope in the current tab-session (and cache has data), skip the network
   * entirely until the app/tab is reopened. `refetch()` always bypasses it.
   */
  sessionGuard?: boolean;
}

const CACHE_PREFIX = 'dairy_cq_v1_';
const DELTA_PREFIX = 'dairy_cq_delta_v1_';
const FULLSYNC_PREFIX = 'dairy_cq_full_v1_';
const LASTCHECK_PREFIX = 'dairy_cq_check_v1_';
const SESSION_PREFIX = 'dairy_cq_session_v1_';

function readCache<T>(key: string): T[] | null {
  try {
    const raw = localStorage.getItem(CACHE_PREFIX + key);
    return raw ? (JSON.parse(raw) as T[]) : null;
  } catch { return null; }
}

function writeCache<T>(key: string, rows: T[]) {
  try { localStorage.setItem(CACHE_PREFIX + key, JSON.stringify(rows)); } catch { /* ignore quota */ }
}

export function useCachedQuery<T = any>(opts: Options<T>) {
  const {
    cacheKey, scope, table, buildQuery,
    mapRow = (r: any) => r as T,
    idOf = (r: any) => r?.id,
    enabled = true,
    sessionGuard = false,
  } = opts;

  const fullKey = `${cacheKey}_${scope ?? 'none'}_${table}`;
  const [data, setData] = useState<T[]>(() => readCache<T>(fullKey) ?? []);
  const [loading, setLoading] = useState<boolean>(() => !readCache<T>(fullKey));
  const mountedRef = useRef(true);

  useEffect(() => () => { mountedRef.current = false; }, []);

  const fetchDelta = useCallback(async (force = false) => {
    if (!enabled || !scope) {
      setLoading(false);
      return;
    }
    if (!navigator.onLine) {
      setLoading(false);
      return;
    }

    const sessKey = SESSION_PREFIX + fullKey;
    if (!force && sessionGuard) {
      const cachedNow = readCache<T>(fullKey);
      if (sessionStorage.getItem(sessKey) && cachedNow !== null) {
        setLoading(false);
        return;
      }
    }

    const deltaKey = DELTA_PREFIX + fullKey;
    const cached = readCache<T>(fullKey);
    const hasCache = !!cached && cached.length > 0;
    // First run (no cache/no watermark) is authoritative; every run after is delta-only.
    const doFullSync = !hasCache;

    try {
      let q = buildQuery();
      const since = doFullSync ? null : localStorage.getItem(deltaKey);
      if (since) q = q.gt('updated_at', since);
      const rows: any[] = await fetchAllRows(q);

      // Split rows into soft-deleted vs live before mapping.
      const liveRows = rows.filter(r => !r?.deleted_at);
      const deletedIds = new Set<string>(
        rows.filter(r => r?.deleted_at).map(r => r?.id).filter(Boolean)
      );
      const mapped = liveRows.map(mapRow);
      let next: T[];

      if (doFullSync) {
        next = mapped.filter(r => !deletedIds.has(idOf(r)));
      } else {
        const byId = new Map<string, T>((cached ?? []).map(r => [idOf(r as T), r]));
        for (const r of mapped) byId.set(idOf(r), r);
        for (const id of deletedIds) byId.delete(id);
        next = Array.from(byId.values());
      }

      if (!mountedRef.current) return;
      setData(next);
      writeCache(fullKey, next);

      // Advance watermark
      let maxUpdated: string | null = null;
      for (const r of rows) {
        const u = r?.updated_at;
        if (u && (!maxUpdated || u > maxUpdated)) maxUpdated = u;
      }
      if (maxUpdated) localStorage.setItem(deltaKey, maxUpdated);
      try { sessionStorage.setItem(sessKey, '1'); } catch { /* ignore */ }

    } catch (err) {
      console.error(`[useCachedQuery:${table}] fetch failed`, err);
    } finally {
      if (mountedRef.current) setLoading(false);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [fullKey, enabled, scope, table, sessionGuard]);

  useEffect(() => {
    fetchDelta();
  }, [fetchDelta]);

  // Realtime removed — refresh happens on next mount via delta-sync.


  const refetch = useCallback(async () => {
    // Force full sync on manual refetch
    localStorage.removeItem(FULLSYNC_PREFIX + fullKey);
    localStorage.removeItem(DELTA_PREFIX + fullKey);
    try { sessionStorage.removeItem(SESSION_PREFIX + fullKey); } catch { /* ignore */ }
    await fetchDelta(true);
  }, [fullKey, fetchDelta]);

  /** Merge a locally-known row into the cache (after a mutation). */
  const upsertLocal = useCallback((row: T) => {
    setData(prev => {
      const id = idOf(row);
      const next = [...prev];
      const idx = next.findIndex(r => idOf(r) === id);
      if (idx >= 0) next[idx] = row; else next.push(row);
      writeCache(fullKey, next);
      return next;
    });
  }, [fullKey, idOf]);

  const removeLocal = useCallback((id: string) => {
    setData(prev => {
      const next = prev.filter(r => idOf(r) !== id);
      writeCache(fullKey, next);
      return next;
    });
  }, [fullKey, idOf]);

  return { data, loading, refetch, upsertLocal, removeLocal };
}

/**
 * useCachedSingle — same idea but for tables that always return one row for
 * a given scope (e.g. `owner_settings`, `dairy_features` rows).
 */
export function useCachedSingle<T = any>(opts: {
  cacheKey: string;
  scope: string | null | undefined;
  table: string;
  buildQuery: () => any;
  mapRow?: (row: any) => T;
  enabled?: boolean;
}) {
  const { cacheKey, scope, table, buildQuery, mapRow = (r: any) => r as T, enabled = true } = opts;
  const singleKey = `single_${cacheKey}_${scope ?? 'none'}_${table}`;

  const [data, setData] = useState<T | null>(() => {
    try {
      const raw = localStorage.getItem(CACHE_PREFIX + singleKey);
      return raw ? (JSON.parse(raw) as T) : null;
    } catch { return null; }
  });
  const [loading, setLoading] = useState<boolean>(() => !data);
  const mountedRef = useRef(true);

  useEffect(() => () => { mountedRef.current = false; }, []);

  useEffect(() => {
    if (!enabled || !scope) { setLoading(false); return; }
    if (!navigator.onLine) { setLoading(false); return; }

    // Skip network within the same tab session — settings tables rarely change,
    // realtime pushes cover in-session updates. Refreshes on next app open.
    const sessKey = 'dairy_cs_session_v1_' + singleKey;
    if (sessionStorage.getItem(sessKey) && data) { setLoading(false); return; }

    let cancelled = false;
    (async () => {
      try {
        const q = buildQuery().maybeSingle();
        const { data: row, error } = await q;
        if (cancelled || !mountedRef.current) return;
        if (error) { console.error(`[useCachedSingle:${table}]`, error); return; }
        const mapped = row ? mapRow(row) : null;
        setData(mapped);
        try {
          if (mapped) localStorage.setItem(CACHE_PREFIX + singleKey, JSON.stringify(mapped));
        } catch { /* ignore */ }
        sessionStorage.setItem(sessKey, '1');
      } finally {
        if (!cancelled && mountedRef.current) setLoading(false);
      }
    })();

    return () => { cancelled = true; };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [singleKey, enabled, scope, table]);

  return { data, loading };
}

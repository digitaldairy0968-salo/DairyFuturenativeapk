import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';

export interface OwnerSettings {
  usesPrinter: boolean;
  milkBuyingBasis: 'fat' | 'fat_snf';
  calculationSystem: 'avg_fat' | 'daily_total';
  onboardingCompleted: boolean;
  dairyNameForPdf: string | null;
  autoPrintEnabled: boolean;
  bluetoothFatMachineConnected: boolean;
  bluetoothPrinterConnected: boolean;
  showRakamToCustomers: boolean;
  bhugtanOutputType: 'print' | 'pdf' | 'nothing';
  codeDirection: 'off' | 'forward' | 'reverse';
  prefillEnabled: boolean;
  prefillFat: number | null;
  prefillSnf: number | null;
  prefillLr: number | null;
  predictMilkEnabled: boolean;
  showVoiceEntry: boolean;
  voiceSupplierSelectEnabled: boolean;
}

export const OWNER_SETTINGS_CACHE_KEY = 'cached_owner_settings';

export const defaultOwnerSettings: OwnerSettings = {
  usesPrinter: false,
  milkBuyingBasis: 'fat',
  calculationSystem: 'avg_fat',
  onboardingCompleted: false,
  dairyNameForPdf: null,
  autoPrintEnabled: false,
  bluetoothFatMachineConnected: false,
  bluetoothPrinterConnected: false,
  showRakamToCustomers: true,
  bhugtanOutputType: 'print',
  codeDirection: 'off',
  prefillEnabled: false,
  prefillFat: null,
  prefillSnf: null,
  prefillLr: null,
  predictMilkEnabled: false,
  showVoiceEntry: true,
  voiceSupplierSelectEnabled: true,
};

const defaultSettings = defaultOwnerSettings;

/** Map an owner_settings DB row to the client shape (shared with DairyContext). */
export function mapOwnerSettingsRow(data: any): OwnerSettings {
  return {
    usesPrinter: data.uses_printer ?? false,
    milkBuyingBasis: data.milk_buying_basis ?? 'fat',
    calculationSystem: data.calculation_system ?? 'avg_fat',
    onboardingCompleted: data.onboarding_completed ?? false,
    dairyNameForPdf: data.dairy_name_for_pdf ?? null,
    autoPrintEnabled: data.auto_print_enabled ?? false,
    bluetoothFatMachineConnected: data.bluetooth_fat_machine_connected ?? false,
    bluetoothPrinterConnected: data.bluetooth_printer_connected ?? false,
    showRakamToCustomers: data.show_rakam_to_customers ?? true,
    bhugtanOutputType: data.bhugtan_output_type ?? 'print',
    codeDirection: data.code_direction ?? 'off',
    prefillEnabled: data.prefill_enabled ?? false,
    prefillFat: data.prefill_fat ?? null,
    prefillSnf: data.prefill_snf ?? null,
    prefillLr: data.prefill_lr ?? null,
    predictMilkEnabled: data.predict_milk_enabled ?? false,
    showVoiceEntry: data.show_voice_entry ?? true,
    voiceSupplierSelectEnabled: data.voice_supplier_select_enabled ?? true,
  };
}

/**
 * @param options.fetchOnMount Set false when the caller reads the centralized
 * DairyContext state (fresh-login synced) and only needs updateSettings().
 */
export function useOwnerSettings(options: { fetchOnMount?: boolean } = {}) {
  const { fetchOnMount = true } = options;
  const { user } = useAuth();
  const [settings, setSettings] = useState<OwnerSettings>(() => {
    const cached = localStorage.getItem('cached_owner_settings');
    return cached ? { ...defaultSettings, ...JSON.parse(cached) } : defaultSettings;
  });
  const [loading, setLoading] = useState(() => {
    return !localStorage.getItem('cached_owner_settings');
  });
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (!fetchOnMount) {
      setLoading(false);
      return;
    }
    const fetchSettings = async () => {
      if (!user?.dairyId) {
        setLoading(false);
        return;
      }

      // Skip refetch within the same tab session if cache exists — owner_settings
      // only changes when the owner saves it locally (which also updates cache).
      const sessKey = `sess_owner_settings_${user.dairyId}`;
      if (localStorage.getItem('cached_owner_settings') && sessionStorage.getItem(sessKey)) {
        setLoading(false);
        return;
      }

      try {
        const { data, error } = await supabase
          .from('owner_settings')
          .select('*')
          .eq('dairy_id', user.dairyId)
          .maybeSingle();

        if (error) throw error;

        if (data) {
          const newSettings = mapOwnerSettingsRow(data);
          setSettings(newSettings);
          localStorage.setItem('cached_owner_settings', JSON.stringify(newSettings));
        }
        sessionStorage.setItem(sessKey, '1');
      } catch (error) {
        console.error('Error fetching owner settings:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchSettings();
  }, [user?.dairyId, fetchOnMount]);

  const updateSettings = async (updates: Partial<OwnerSettings>) => {
    if (!user?.dairyId) return false;

    setSaving(true);
    try {
      const dbUpdates: any = {};
      if (updates.usesPrinter !== undefined) dbUpdates.uses_printer = updates.usesPrinter;
      if (updates.milkBuyingBasis !== undefined) dbUpdates.milk_buying_basis = updates.milkBuyingBasis;
      if (updates.calculationSystem !== undefined) dbUpdates.calculation_system = updates.calculationSystem;
      if (updates.onboardingCompleted !== undefined) dbUpdates.onboarding_completed = updates.onboardingCompleted;
      if (updates.dairyNameForPdf !== undefined) dbUpdates.dairy_name_for_pdf = updates.dairyNameForPdf;
      if (updates.autoPrintEnabled !== undefined) dbUpdates.auto_print_enabled = updates.autoPrintEnabled;
      if (updates.bluetoothFatMachineConnected !== undefined) dbUpdates.bluetooth_fat_machine_connected = updates.bluetoothFatMachineConnected;
      if (updates.bluetoothPrinterConnected !== undefined) dbUpdates.bluetooth_printer_connected = updates.bluetoothPrinterConnected;
      if (updates.showRakamToCustomers !== undefined) dbUpdates.show_rakam_to_customers = updates.showRakamToCustomers;
      if (updates.bhugtanOutputType !== undefined) dbUpdates.bhugtan_output_type = updates.bhugtanOutputType;
      if (updates.codeDirection !== undefined) dbUpdates.code_direction = updates.codeDirection;
      if (updates.prefillEnabled !== undefined) dbUpdates.prefill_enabled = updates.prefillEnabled;
      if (updates.prefillFat !== undefined) dbUpdates.prefill_fat = updates.prefillFat;
      if (updates.prefillSnf !== undefined) dbUpdates.prefill_snf = updates.prefillSnf;
      if (updates.prefillLr !== undefined) dbUpdates.prefill_lr = updates.prefillLr;
      if (updates.predictMilkEnabled !== undefined) dbUpdates.predict_milk_enabled = updates.predictMilkEnabled;
      if (updates.showVoiceEntry !== undefined) dbUpdates.show_voice_entry = updates.showVoiceEntry;
      if (updates.voiceSupplierSelectEnabled !== undefined) dbUpdates.voice_supplier_select_enabled = updates.voiceSupplierSelectEnabled;

      const { error } = await supabase
        .from('owner_settings')
        .upsert({
          dairy_id: user.dairyId,
          ...dbUpdates,
        } as any, { onConflict: 'dairy_id' });

      if (error) throw error;

      setSettings(prev => {
        const updated = { ...prev, ...updates };
        localStorage.setItem('cached_owner_settings', JSON.stringify(updated));
        // Keep the centralized DairyContext cache in sync (local-optimistic).
        window.dispatchEvent(new CustomEvent('owner-settings-updated', { detail: updated }));
        return updated;
      });
      return true;
    } catch (error) {
      console.error('Error updating owner settings:', error);
      return false;
    } finally {
      setSaving(false);
    }
  };

  return {
    settings,
    loading,
    saving,
    updateSettings,
  };
}

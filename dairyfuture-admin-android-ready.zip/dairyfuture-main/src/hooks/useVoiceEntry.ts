import { useCallback, useEffect, useRef, useState } from 'react';
import { SpeechRecognition as NativeSpeechRecognition } from '@capacitor-community/speech-recognition';
import { Capacitor } from '@capacitor/core';

/**
 * Voice milk entry — browser ka built-in Web Speech API use karta hai.
 * Koi backend / edge function / network call nahi.
 *
 * User bolta hai "पांच पॉइंट चार लीटर" → onValueDetected(5.4).
 */

// ---------- number parsing ----------

const WORDS: Record<string, number> = {
  // English / transliterated
  zero: 0, o: 0, oh: 0, one: 1, two: 2, to: 2, too: 2, three: 3, tree: 3, four: 4, for: 4,
  five: 5, six: 6, seven: 7, eight: 8, ate: 8, nine: 9, ten: 10, eleven: 11, twelve: 12,
  thirteen: 13, fourteen: 14, fifteen: 15, sixteen: 16, seventeen: 17, eighteen: 18,
  nineteen: 19, twenty: 20, thirty: 30, forty: 40, fifty: 50,
  ek: 1, do: 2, teen: 3, tin: 3, char: 4, chaar: 4, panch: 5, paanch: 5, chhe: 6, che: 6,
  chah: 6, saat: 7, sat: 7, aath: 8, ath: 8, nau: 9, no: 9, das: 10, dus: 10,
  gyarah: 11, egarah: 11, barah: 12, bara: 12, terah: 13, tera: 13, chaudah: 14, chauda: 14,
  pandrah: 15, pandra: 15, solah: 16, sola: 16, satrah: 17, satra: 17, atharah: 18, athara: 18,
  unnis: 19, bees: 20, bis: 20, ikkis: 21, bais: 22, teis: 23, chaubis: 24, pachchis: 25,
  pachees: 25, chhabbis: 26, sattais: 27, atthais: 28, untis: 29, tees: 30,
  // Devanagari
  'शून्य': 0, 'एक': 1, 'दो': 2, 'तीन': 3, 'चार': 4, 'पांच': 5, 'पाँच': 5, 'छह': 6, 'छः': 6,
  'सात': 7, 'आठ': 8, 'नौ': 9, 'दस': 10, 'ग्यारह': 11, 'बारह': 12, 'तेरह': 13, 'चौदह': 14,
  'पंद्रह': 15, 'पन्द्रह': 15, 'सोलह': 16, 'सत्रह': 17, 'अठारह': 18, 'उन्नीस': 19, 'बीस': 20,
  'इक्कीस': 21, 'बाईस': 22, 'तेईस': 23, 'चौबीस': 24, 'पच्चीस': 25, 'छब्बीस': 26,
  'सत्ताईस': 27, 'अट्ठाईस': 28, 'उनतीस': 29, 'तीस': 30, 'चालीस': 40, 'पचास': 50,
  // Urdu script is sometimes returned for spoken Hindi/Hinglish by STT.
  'صفر': 0, 'ایک': 1, 'دو': 2, 'تین': 3, 'چار': 4, 'پانچ': 5, 'چھ': 6,
  'سات': 7, 'آٹھ': 8, 'نو': 9, 'دس': 10, 'گیارہ': 11, 'بارہ': 12,
  'تیرہ': 13, 'چودہ': 14, 'پندرہ': 15, 'سولہ': 16, 'سترہ': 17,
  'اٹھارہ': 18, 'انیس': 19, 'بیس': 20, 'پچیس': 25, 'تیس': 30,
};

const POINT_WORDS = new Set([
  'point', 'poin', 'pint', 'dashamlav', 'decimal',
  'पॉइंट', 'पोइंट', 'पाइंट', 'पॉइन्ट', 'प्वाइंट', 'पॉईंट', 'दशमलव', 'बिंदु',
  'پوائنٹ', 'پوینٹ', 'اعشاریہ',
]);

const HALF_WORDS = new Set(['aadha', 'adha', 'आधा', 'आधे', 'half']);

// Milk quantity tabhi fill karte hain jab user number ke saath "liter" bhi bole.
const LITER_WORDS = new Set([
  'liter', 'litre', 'liters', 'litres', 'ltr', 'litr', 'litar',
  'लीटर', 'लिटर', 'लीटरों', 'ली',
  'لیٹر',
]);

const DEV_DIGITS = '०१२३४५६७८९';

const SUPPLIER_KEYWORDS = new Set([
  // English / transliterated
  'supplier', 'suplyar', 'suplyer', 'supplier', 'suppplier', 'suplier',
  // Hindi
  'सप्लायर', 'सप्लायर', 'सप्लायर्स', 'सप्लायर',
  // Urdu
  'سپلائر', 'سپلائرز',
]);

function normalize(raw: string): string[] {
  let s = raw.toLowerCase();
  // Devanagari digits → ASCII
  s = s.replace(/[०-९]/g, (d) => String(DEV_DIGITS.indexOf(d)));
  // separators
  s = s.replace(/[,;!?।]/g, ' ');
  // keep digits, dot, Latin, Devanagari and Urdu/Arabic-script letters
  s = s.replace(/[^0-9.\sa-z\u0900-\u097F\u0600-\u06FF]/g, ' ');
  return s.split(/\s+/).filter(Boolean);
}

// ---------- fuzzy matching (misheard words ke liye) ----------

function levenshtein(a: string, b: string): number {
  const m = a.length, n = b.length;
  if (!m) return n;
  if (!n) return m;
  let prev = new Array<number>(n + 1);
  let curr = new Array<number>(n + 1);
  for (let j = 0; j <= n; j++) prev[j] = j;
  for (let i = 1; i <= m; i++) {
    curr[0] = i;
    for (let j = 1; j <= n; j++) {
      curr[j] = Math.min(
        prev[j] + 1,
        curr[j - 1] + 1,
        prev[j - 1] + (a[i - 1] === b[j - 1] ? 0 : 1)
      );
    }
    [prev, curr] = [curr, prev];
  }
  return prev[n];
}

const WORD_KEYS = Object.keys(WORDS);

/**
 * Exact match fail hone par nearest dictionary word dhundhta hai.
 * Chhote shabdon ke liye 1 char, lambe ke liye proportionally zyada
 * farak allow hai. Barabar-close candidates me 1-25 range (90% entries)
 * wale number ko priority milti hai. Bahut door ka match → null (galat
 * guess nahi karte).
 */
function fuzzyValue(t: string): number | null {
  if (t.length < 2) return null;
  const maxDist = t.length <= 4 ? 1 : t.length <= 7 ? 2 : 3;
  let best: number | null = null;
  let bestDist = Infinity;
  let bestInRange = false;
  for (const key of WORD_KEYS) {
    if (Math.abs(key.length - t.length) > maxDist) continue;
    const d = levenshtein(t, key);
    if (d > maxDist) continue;
    const v = WORDS[key];
    const inRange = v >= 1 && v <= 25;
    if (d < bestDist || (d === bestDist && inRange && !bestInRange)) {
      best = v;
      bestDist = d;
      bestInRange = inRange;
    }
  }
  return best;
}

/**
 * Supplier code ke liye fuzzy fallback — priority range dynamic hai
 * (1..totalSuppliers) kyunki supplier code milk quantity ki tarah fixed 1-25
 * range me nahi hota, balki dairy ke total supplier count tak hota hai.
 */
function fuzzySupplierValue(t: string, totalSuppliers: number): number | null {
  if (t.length < 2) return null;
  const maxDist = t.length <= 4 ? 1 : t.length <= 7 ? 2 : 3;
  let best: number | null = null;
  let bestDist = Infinity;
  let bestInRange = false;
  for (const key of WORD_KEYS) {
    if (Math.abs(key.length - t.length) > maxDist) continue;
    const d = levenshtein(t, key);
    if (d > maxDist) continue;
    const v = WORDS[key];
    const inRange = totalSuppliers > 0 && v >= 1 && v <= totalSuppliers;
    if (d < bestDist || (d === bestDist && inRange && !bestInRange)) {
      best = v;
      bestDist = d;
      bestInRange = inRange;
    }
  }
  return best;
}

export function parseSpokenNumber(raw: string): number | null {
  if (!raw) return null;
  const tokens = normalize(raw);
  if (!tokens.length) return null;

  // Sirf number bola gaya ho (bina "liter" bole) to milk input fill mat karo.
  if (!tokens.some((t) => LITER_WORDS.has(t))) return null;

  // 1) Direct numeric like "5.4" / "5,4" / "5.4 लीटर"
  for (const t of tokens) {
    const m = t.match(/^(\d{1,3})(?:\.(\d{1,2}))?$/);
    if (m) {
      // could be split as "5" "." "4" too — handled below; here full match wins
      if (m[2] !== undefined) return clamp(Number(`${m[1]}.${m[2]}`));
    }
  }

  // 2) Word / digit sequence with an optional point marker
  let intPart: number | null = null;
  let decDigits = '';
  let seenPoint = false;
  let halfBonus = 0;

  const valueOf = (t: string): number | null => {
    if (/^\d{1,3}$/.test(t)) return Number(t);
    if (t in WORDS) return WORDS[t];
    // Exact match fail — halki/dheemi awaaz ke misheard shabd ke liye
    // nearest-match fallback (sirf tabhi jab exact completely fail ho).
    return fuzzyValue(t);
  };

  for (const t of tokens) {
    if (POINT_WORDS.has(t) || t === '.') {
      seenPoint = true;
      continue;
    }
    if (HALF_WORDS.has(t)) {
      halfBonus = 0.5;
      continue;
    }
    const v = valueOf(t);
    if (v === null) continue;

    if (!seenPoint) {
      if (intPart === null) intPart = v;
      // extra integers before point ignore (e.g. "code 12 paanch")
    } else {
      // after point: digits one by one
      if (v <= 9) decDigits += String(v);
      else decDigits += String(v); // e.g. "point 25"
      if (decDigits.length >= 2) break;
    }
  }

  if (intPart === null && !decDigits && !halfBonus) return null;
  const base = intPart ?? 0;
  const dec = decDigits ? Number(`0.${decDigits}`) : 0;
  const value = base + dec + (dec ? 0 : halfBonus);
  return clamp(value);
}

function clamp(v: number): number | null {
  if (!Number.isFinite(v)) return null;
  const r = Math.round(v * 100) / 100;
  if (r <= 0 || r > 999) return null;
  return r;
}

/**
 * Voice command se supplier code nikaalta hai — "सप्लायर सात", "supplier number 7".
 * Keyword nahi milta ya number nahi milta to null.
 *
 * totalSuppliers dairy ke current supplier count hai; fuzzy matching me barabar
 * close candidates milne par 1..totalSuppliers range ko priority milti hai.
 * Agar totalSuppliers 0 ho to range-based priority skip hoti hai (sirf generic
 * nearest match use hoga, jaise fuzzyValue me hota hai).
 */
export function parseSupplierCommand(
  raw: string,
  totalSuppliers: number
): string | null {
  if (!raw) return null;
  const tokens = normalize(raw);
  let afterKeyword = false;

  for (const t of tokens) {
    if (!afterKeyword) {
      if (SUPPLIER_KEYWORDS.has(t)) afterKeyword = true;
      continue;
    }
    // filler words like "number" / "code" skip karo
    if (/^(number|nambar|nmbr|code|num|no|n|नंबर|नम्बर|नमबर|कोड|नुम्बर|کوڈ)$/.test(t)) continue;

    let v: number | null = null;
    if (/^\d{1,3}$/.test(t)) v = Number(t);
    else if (t in WORDS) v = WORDS[t];
    else v = fuzzySupplierValue(t, totalSuppliers);

    if (v !== null && v > 0 && v < 1000) return String(Math.round(v));
  }
  return null;
}

/**
 * Interim transcript me "complete" number pattern dikh raha hai ya nahi —
 * sirf tabhi early-fire karte hain, warna "पांच" bolte hi 5 fill ho jayega
 * jabki user "पांच पॉइंट चार" bol raha ho.
 */
function looksComplete(raw: string): boolean {
  if (!raw) return false;
  const s = raw.toLowerCase();
  if (/\d+\.\d/.test(s)) return true;
  return s.split(/\s+/).some((t) => POINT_WORDS.has(t));
}

// ---------- hook ----------

interface Options {
  /** Optional: jab quantity-voice toggle OFF ho to undefined pass kiya jata hai. */
  onValueDetected?: (value: number) => void;
  onSupplierCodeDetected?: (code: string) => void;
  language?: string;
  totalSuppliers?: number;
}

type SpeechRecognitionLike = {
  lang: string;
  continuous: boolean;
  interimResults: boolean;
  maxAlternatives: number;
  start: () => void;
  stop: () => void;
  abort: () => void;
  onresult: ((ev: any) => void) | null;
  onerror: ((ev: any) => void) | null;
  onend: (() => void) | null;
};

function getRecognitionCtor(): (new () => SpeechRecognitionLike) | null {
  if (typeof window === 'undefined') return null;
  return (
    (window as any).SpeechRecognition ||
    (window as any).webkitSpeechRecognition ||
    null
  );
}

export function useVoiceEntry({ onValueDetected, onSupplierCodeDetected, language = 'hi', totalSuppliers = 0 }: Options) {
  const [isListening, setIsListening] = useState(false);
  const [lastValue, setLastValue] = useState<number | null>(null);
  const [error, setError] = useState<string | null>(null);

  const isSupported = Capacitor.isNativePlatform() || !!getRecognitionCtor();

  const recRef = useRef<SpeechRecognitionLike | null>(null);
  const wantRef = useRef(false);
  const restartTimerRef = useRef<number | null>(null);
  const bestInterimRef = useRef('');
  const noSpeechRef = useRef(false);
  const pausedByHiddenRef = useRef(false);

  const lastFireRef = useRef<{ v: number; t: number }>({ v: -1, t: 0 });

  const cbRef = useRef(onValueDetected);
  cbRef.current = onValueDetected;
  const supplierCbRef = useRef(onSupplierCodeDetected);
  supplierCbRef.current = onSupplierCodeDetected;
  const langRef = useRef(language);
  langRef.current = language;
  const totalSuppliersRef = useRef(totalSuppliers);
  totalSuppliersRef.current = totalSuppliers;

  // Dedupe: interim early-fire ke baad final result same value dobara na bheje.
  const fire = useCallback((v: number) => {
    // Quantity-voice OFF (callback undefined) → value kabhi fill nahi karte.
    if (!cbRef.current) return;
    const now = Date.now();
    const last = lastFireRef.current;
    if (last.v === v && now - last.t < 1500) return;
    lastFireRef.current = { v, t: now };
    setLastValue(v);
    setError(null);
    cbRef.current(v);
  }, []);

  const stopListening = useCallback(() => {
    wantRef.current = false;
    if (restartTimerRef.current) {
      clearTimeout(restartTimerRef.current);
      restartTimerRef.current = null;
    }
    if (Capacitor.isNativePlatform()) {
      try {
        NativeSpeechRecognition.stop();
        NativeSpeechRecognition.removeAllListeners();
      } catch {
        /* ignore */
      }
    }
    const rec = recRef.current;
    recRef.current = null;
    if (rec) {
      rec.onresult = null;
      rec.onerror = null;
      rec.onend = null;
      try { rec.stop(); } catch { /* noop */ }
      try { rec.abort(); } catch { /* noop */ }
    }
    setIsListening(false);
  }, []);

  const startListening = useCallback(async () => {
    if (Capacitor.isNativePlatform()) {
      try {
        const hasPerm = await NativeSpeechRecognition.hasPermissions();
        if (!hasPerm?.speechRecognition) {
          const req = await NativeSpeechRecognition.requestPermissions();
          if (!req?.speechRecognition) {
            setError(
              langRef.current === 'en' ? 'Microphone permission needed' : 'माइक की अनुमति दें'
            );
            setIsListening(false);
            return;
          }
        }
        wantRef.current = true;
        setIsListening(true);
        setError(null);

        await NativeSpeechRecognition.removeAllListeners();

        await NativeSpeechRecognition.addListener('partialResults', (data: { matches?: string[] }) => {
          const matches = data.matches || [];
          if (!matches.length) return;

          // Check supplier command first
          let supplierMatched = false;
          for (const transcript of matches) {
            const code = parseSupplierCommand(transcript, totalSuppliersRef.current);
            if (code !== null) {
              supplierCbRef.current?.(code);
              setError(null);
              supplierMatched = true;
              break;
            }
          }
          if (supplierMatched) return;

          // Check milk quantity
          for (const transcript of matches) {
            const value = parseSpokenNumber(transcript);
            if (value !== null) {
              fire(value);
              break;
            }
          }
        });

        await NativeSpeechRecognition.start({
          language: langRef.current === 'en' ? 'en-IN' : 'hi-IN',
          maxResults: 3,
          prompt: '',
          partialResults: true,
          popup: false,
        });
      } catch (err: any) {
        setIsListening(false);
        setError(err?.message || (langRef.current === 'en' ? 'Voice entry failed' : 'माइक त्रुटि'));
      }
      return;
    }

    const Ctor = getRecognitionCtor();
    if (!Ctor) {
      setError(
        langRef.current === 'en' ? 'Microphone permission needed' : 'माइक की अनुमति दें'
      );
      return;
    }
    if (recRef.current) return;

    wantRef.current = true;

    // Mic pre-flight: permission maangna + OS-level constraints set karna.
    // autoGainControl ON → halki/door ki awaaz ko boost karta hai;
    // noiseSuppression/echoCancellation OFF → OS halki awaaz ko noise samajh
    // kar kaat nahi deta. Stream ko recognition se PEHLE band karte hain —
    // active getUserMedia stream ke saath SpeechRecognition start karne par
    // Android Chrome me mic conflict ho jata hai aur recognition kaam nahi karta.
    if (navigator.mediaDevices?.getUserMedia) {
      try {
        const stream = await navigator.mediaDevices.getUserMedia({
          audio: {
            autoGainControl: true,
            noiseSuppression: false,
            echoCancellation: false,
          },
        });
        stream.getTracks().forEach((t) => t.stop());
      } catch (e: any) {
        if (e?.name === 'NotAllowedError' || e?.name === 'SecurityError') {
          setError(
            langRef.current === 'en' ? 'Microphone permission needed' : 'माइक की अनुमति दें'
          );
          wantRef.current = false;
          setIsListening(false);
          return;
        }
        // any other error (device busy etc.) — recognition khud try karega
      }
    }

    if (!wantRef.current) return;

    const spawn = () => {
      if (!wantRef.current) return;
      let rec: SpeechRecognitionLike;
      try {
        rec = new Ctor();
      } catch {
        return;
      }
      recRef.current = rec;
      rec.lang = langRef.current === 'en' ? 'en-IN' : 'hi-IN';
      rec.continuous = true;
      // Interim results ON — halki/dheemi awaaz ka partial transcript bhi
      // turant milta hai; complete pattern dikhte hi early-fire karte hain.
      rec.interimResults = true;
      rec.maxAlternatives = 3;

      rec.onresult = (ev: any) => {
        for (let i = ev.resultIndex; i < ev.results.length; i++) {
          const result = ev.results[i];

          if (!result.isFinal) {
            // Interim: best-guess transcript store karo (fallback ke liye) aur
            // agar complete decimal pattern dikh jaye to quantity early-fire karo.
            const transcript: string = result[0]?.transcript ?? '';
            if (transcript) bestInterimRef.current = transcript;
            if (transcript && looksComplete(transcript)) {
              const v = parseSpokenNumber(transcript);
              if (v !== null) fire(v);
            }
            continue;
          }

          // Final: pehle supplier command try karo ("सप्लायर सात") — saare
          // alternatives + best interim fallback.
          let supplierMatched = false;
          for (let a = 0; a < result.length; a++) {
            const code = parseSupplierCommand(
              result[a]?.transcript ?? '',
              totalSuppliersRef.current
            );
            if (code !== null) {
              supplierCbRef.current?.(code);
              setError(null);
              supplierMatched = true;
              break;
            }
          }
          if (!supplierMatched && bestInterimRef.current) {
            const code = parseSupplierCommand(
              bestInterimRef.current,
              totalSuppliersRef.current
            );
            if (code !== null) {
              supplierCbRef.current?.(code);
              setError(null);
              supplierMatched = true;
            }
          }
          if (supplierMatched) {
            bestInterimRef.current = '';
            continue;
          }

          // Final: quantity ke liye saare alternatives try karo…
          let value: number | null = null;
          for (let a = 0; a < result.length; a++) {
            value = parseSpokenNumber(result[a]?.transcript ?? '');
            if (value !== null) break;
          }
          // …phir bhi na mile to best interim transcript ko ek baar try karo.
          if (value === null && bestInterimRef.current) {
            value = parseSpokenNumber(bestInterimRef.current);
          }
          bestInterimRef.current = '';

          if (value !== null) {
            fire(value);
          } else if (cbRef.current) {
            // Quantity-voice OFF ho to "dobara bolein" error nahi dikhate.
            setError(
              langRef.current === 'en'
                ? 'Please say the quantity again'
                : 'मात्रा दोबारा बोलें'
            );
          }
        }
      };

      rec.onerror = (ev: any) => {
        const code = ev?.error;
        if (code === 'not-allowed' || code === 'service-not-allowed') {
          setError(
            langRef.current === 'en' ? 'Microphone permission needed' : 'माइक की अनुमति दें'
          );
          wantRef.current = false;
          setIsListening(false);
        } else if (code === 'no-speech') {
          // Engine ko awaaz nahi mili — onend me jaldi restart karenge.
          noSpeechRef.current = true;
        }
        // 'aborted' / 'network': onend restart sambhal lega
      };

      rec.onend = () => {
        if (recRef.current !== rec) return;
        recRef.current = null;
        if (!wantRef.current) {
          setIsListening(false);
          return;
        }
        // Chrome silence ya 60s ke baad khud ruk jata hai — turant dobara start.
        // no-speech ke baad 150ms (fast) taaki bola hua shabd miss na ho.
        const delay = noSpeechRef.current ? 150 : 200;
        noSpeechRef.current = false;
        restartTimerRef.current = window.setTimeout(spawn, delay);
      };

      try {
        rec.start();
        setError(null);
        setIsListening(true);
      } catch {
        recRef.current = null;
        restartTimerRef.current = window.setTimeout(spawn, 300);
      }
    };

    spawn();
  }, [fire]);

  useEffect(() => () => stopListening(), [stopListening]);

  // App background me jane par Android/Chrome mic chheen leta hai aur
  // 'not-allowed' error aa jata hai — wapas aane par wo stale error dikhta
  // rehta tha. Isliye hidden hone par saaf-suthra stop, visible hone par
  // error clear karke dobara start.
  useEffect(() => {
    const onVisibility = () => {
      if (document.visibilityState === 'hidden') {
        if (wantRef.current) {
          pausedByHiddenRef.current = true;
          stopListening();
        }
      } else if (pausedByHiddenRef.current) {
        pausedByHiddenRef.current = false;
        setError(null);
        void startListening();
      }
    };
    document.addEventListener('visibilitychange', onVisibility);
    window.addEventListener('pagehide', onVisibility);
    return () => {
      document.removeEventListener('visibilitychange', onVisibility);
      window.removeEventListener('pagehide', onVisibility);
    };
  }, [stopListening, startListening]);

  // Language badle to naye lang ke saath restart.
  useEffect(() => {
    const rec = recRef.current;
    if (rec && wantRef.current) {
      try { rec.stop(); } catch { /* onend restart karega */ }
    }
  }, [language]);


  return {
    isSupported,
    isListening,
    isProcessing: false,
    lastValue,
    error,
    startListening,
    stopListening,
  };
}

import { Capacitor } from '@capacitor/core';
import { supabase } from '@/integrations/supabase/client';

/** Custom URL scheme = appId from capacitor.config.ts */
export const NATIVE_APP_SCHEME = 'com.dairyfuture.app';
export const NATIVE_OAUTH_REDIRECT = `${NATIVE_APP_SCHEME}://auth`;

/** Set while a Google OAuth round-trip is in progress (survives the browser redirect). */
export const GOOGLE_OAUTH_PENDING_KEY = 'google_oauth_pending';
/** Role the user picked in Step 2 before tapping "Sign in with Google". */
export const GOOGLE_OAUTH_ROLE_KEY = 'google_oauth_role';
/** Set when a brand-new Google user still has to enter Name + Phone. */
export const PENDING_GOOGLE_PROFILE_KEY = 'pending_google_profile';

export type GoogleRole = 'owner' | 'supplier';

export const isNativeApp = (): boolean => {
  try {
    return Capacitor.isNativePlatform();
  } catch {
    return false;
  }
};

/**
 * Starts the Google OAuth flow.
 * - Web: full-page redirect back to `${origin}/auth`.
 * - Native (Capacitor): opens the system browser via @capacitor/browser and
 *   redirects back to the app's custom scheme; `handleNativeOAuthCallback`
 *   finishes the session exchange when the app receives the deep link.
 */
export const startGoogleSignIn = async (role: GoogleRole): Promise<{ error: string | null }> => {
  try {
    localStorage.setItem(GOOGLE_OAUTH_PENDING_KEY, '1');
    localStorage.setItem(GOOGLE_OAUTH_ROLE_KEY, role);
  } catch { /* ignore */ }

  const native = isNativeApp();
  const redirectTo = native ? NATIVE_OAUTH_REDIRECT : `${window.location.origin}/auth`;

  const { data, error } = await supabase.auth.signInWithOAuth({
    provider: 'google',
    options: {
      redirectTo,
      // On native we must open the URL ourselves in the in-app browser.
      skipBrowserRedirect: native,
      queryParams: { prompt: 'select_account' },
    },
  });

  if (error) {
    clearGoogleOAuthPending();
    return { error: error.message };
  }

  if (native && data?.url) {
    try {
      const { Browser } = await import('@capacitor/browser');
      await Browser.open({ url: data.url, presentationStyle: 'popover' });
    } catch (e: any) {
      clearGoogleOAuthPending();
      return { error: e?.message || 'Could not open browser' };
    }
  }

  return { error: null };
};

export const clearGoogleOAuthPending = () => {
  try {
    localStorage.removeItem(GOOGLE_OAUTH_PENDING_KEY);
    localStorage.removeItem(GOOGLE_OAUTH_ROLE_KEY);
  } catch { /* ignore */ }
};

/**
 * Handles the deep link the native app receives after Google OAuth
 * (`com.dairyfuture.app://auth#access_token=...` or `?code=...`).
 * Returns true if the URL was an OAuth callback (handled or errored).
 */
export const handleNativeOAuthCallback = async (
  url: string
): Promise<{ handled: boolean; error?: string }> => {
  if (!url.startsWith(NATIVE_OAUTH_REDIRECT)) return { handled: false };

  try {
    const { Browser } = await import('@capacitor/browser');
    await Browser.close().catch(() => {});
  } catch { /* ignore */ }

  const hashIndex = url.indexOf('#');
  const queryIndex = url.indexOf('?');
  const hashParams = new URLSearchParams(hashIndex >= 0 ? url.substring(hashIndex + 1) : '');
  const queryParams = new URLSearchParams(
    queryIndex >= 0 ? url.substring(queryIndex + 1, hashIndex > queryIndex ? hashIndex : undefined) : ''
  );

  const errorDesc = hashParams.get('error_description') || queryParams.get('error_description');
  if (errorDesc) {
    clearGoogleOAuthPending();
    return { handled: true, error: decodeURIComponent(errorDesc.replace(/\+/g, ' ')) };
  }

  const code = queryParams.get('code');
  if (code) {
    const { error } = await supabase.auth.exchangeCodeForSession(code);
    if (error) { clearGoogleOAuthPending(); return { handled: true, error: error.message }; }
    return { handled: true };
  }

  const access_token = hashParams.get('access_token');
  const refresh_token = hashParams.get('refresh_token');
  if (access_token && refresh_token) {
    const { error } = await supabase.auth.setSession({ access_token, refresh_token });
    if (error) { clearGoogleOAuthPending(); return { handled: true, error: error.message }; }
    return { handled: true };
  }

  clearGoogleOAuthPending();
  return { handled: true, error: 'Invalid OAuth callback' };
};

/**
 * Reads an OAuth error Supabase may have appended to the web callback URL
 * (e.g. identity-linking conflicts) and cleans the URL.
 */
export const consumeWebOAuthError = (): string | null => {
  try {
    const hash = new URLSearchParams(window.location.hash.replace(/^#/, ''));
    const search = new URLSearchParams(window.location.search);
    const desc = hash.get('error_description') || search.get('error_description');
    const code = hash.get('error') || search.get('error');
    if (!desc && !code) return null;
    window.history.replaceState({}, '', window.location.pathname);
    return desc ? desc.replace(/\+/g, ' ') : code;
  } catch {
    return null;
  }
};

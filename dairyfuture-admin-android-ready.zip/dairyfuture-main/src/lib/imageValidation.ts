/**
 * Content-based image validation.
 * Never trust the `accept` attribute, the filename extension, or the
 * browser-reported MIME type — all three are attacker-controlled.
 * We sniff the real magic bytes of the file before it is uploaded.
 */

export const MAX_IMAGE_BYTES = 5 * 1024 * 1024; // 5 MB

export type SafeImageType = 'image/jpeg' | 'image/png' | 'image/webp' | 'image/gif';

const EXT_BY_TYPE: Record<SafeImageType, string> = {
  'image/jpeg': 'jpg',
  'image/png': 'png',
  'image/webp': 'webp',
  'image/gif': 'gif',
};

function matches(bytes: Uint8Array, sig: number[], offset = 0): boolean {
  return sig.every((b, i) => bytes[offset + i] === b);
}

/** Detects the true type from magic bytes. SVG is intentionally NOT allowed (script-capable). */
export function sniffImageType(bytes: Uint8Array): SafeImageType | null {
  if (matches(bytes, [0xff, 0xd8, 0xff])) return 'image/jpeg';
  if (matches(bytes, [0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a])) return 'image/png';
  if (matches(bytes, [0x47, 0x49, 0x46, 0x38])) return 'image/gif';
  if (matches(bytes, [0x52, 0x49, 0x46, 0x46]) && matches(bytes, [0x57, 0x45, 0x42, 0x50], 8)) return 'image/webp';
  return null;
}

export interface ValidatedImage {
  type: SafeImageType;
  extension: string;
  /** Safe filename built only from our own values — never from user input. */
  buildFileName: (prefix: string) => string;
}

export type ImageValidationError =
  | 'too_large'
  | 'empty'
  | 'unsupported_type';

export interface ImageValidationResult {
  ok: boolean;
  image?: ValidatedImage;
  error?: ImageValidationError;
}

export async function validateImageFile(file: File): Promise<ImageValidationResult> {
  if (!file.size) return { ok: false, error: 'empty' };
  if (file.size > MAX_IMAGE_BYTES) return { ok: false, error: 'too_large' };

  const head = new Uint8Array(await file.slice(0, 16).arrayBuffer());
  const type = sniffImageType(head);
  if (!type) return { ok: false, error: 'unsupported_type' };

  const extension = EXT_BY_TYPE[type];
  return {
    ok: true,
    image: {
      type,
      extension,
      buildFileName: (prefix: string) =>
        `${prefix.replace(/[^a-z0-9-]/gi, '')}-${Date.now()}.${extension}`,
    },
  };
}

export function imageValidationMessage(error: ImageValidationError | undefined, hi = false): string {
  switch (error) {
    case 'too_large':
      return hi ? 'फाइल 5MB से बड़ी है' : 'File is larger than 5MB';
    case 'empty':
      return hi ? 'फाइल खाली है' : 'File is empty';
    default:
      return hi
        ? 'सिर्फ JPG, PNG, WEBP या GIF इमेज ही मान्य है'
        : 'Only real JPG, PNG, WEBP or GIF images are allowed';
  }
}

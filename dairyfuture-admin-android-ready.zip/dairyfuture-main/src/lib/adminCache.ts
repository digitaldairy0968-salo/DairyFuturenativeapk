/**
 * adminCache — cache-first + delta-sync helpers for the Admin Panel.
 *
 * Mirrors the pattern already used in `src/contexts/DairyContext.tsx`:
 *   1. Read the last known rows from localStorage and render instantly.
 *   2. In the background fetch only rows whose timestamp column is newer than
 *      the stored watermark, then merge them into the cache by `id`.
 *   3. A forced (manual "refresh") run ignores cache + watermark and fetches
 *      everything again.
 *
 * Tables without an `updated_at` column (sms_inbox) use `created_at` plus an
 * `overlapMs` re-fetch window — see `deltaFetch` below.
 */
import { fetchAllRows } from '@/lib/supabasePagination';

const CACHE_PREFIX = 'admin_cache_v1_';
const DELTA_PREFIX = 'admin_delta_v1_';

export const ADMIN_CACHE_KEY = (name: string) => `${CACHE_PREFIX}${name}`;
export const ADMIN_DELTA_KEY = (name: string) => `${DELTA_PREFIX}${name}`;

/** Read cached rows for a logical cache name. Returns null when nothing cached. */
export function readAdminCache<T = any>(name: string): T[] | null {
  try {
    const raw = localStorage.getItem(ADMIN_CACHE_KEY(name));
    if (!raw) return null;
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? (parsed as T[]) : null;
  } catch {
    return null;
  }
}

/** Overwrite the cached rows for a logical cache name. */
export function writeAdminCache<T = any>(name: string, rows: T[]) {
  try {
    localStorage.setItem(ADMIN_CACHE_KEY(name), JSON.stringify(rows));
  } catch {
    /* quota — ignore */
  }
}

/** Single-object cache (e.g. subscription_settings row). */
export function readAdminObject<T = any>(name: string): T | null {
  try {
    const raw = localStorage.getItem(ADMIN_CACHE_KEY(name));
    return raw ? (JSON.parse(raw) as T) : null;
  } catch {
    return null;
  }
}

export function writeAdminObject<T = any>(name: string, obj: T | null) {
  try {
    if (obj == null) localStorage.removeItem(ADMIN_CACHE_KEY(name));
    else localStorage.setItem(ADMIN_CACHE_KEY(name), JSON.stringify(obj));
  } catch {
    /* ignore */
  }
}

export function clearAdminDelta(name: string) {
  try {
    localStorage.removeItem(ADMIN_DELTA_KEY(name));
  } catch {
    /* ignore */
  }
}

/** Merge `incoming` rows into `base` by id (replace existing, append new). */
export function mergeById<T extends { id: string }>(base: T[], incoming: T[]): T[] {
  if (incoming.length === 0) return base;
  const byId = new Map<string, T>(base.map(r => [r.id, r]));
  for (const row of incoming) byId.set(row.id, row);
  return Array.from(byId.values());
}

/** Optimistic cache patch helpers (used right after a mutation). */
export function cacheUpsertRow<T extends { id: string }>(name: string, row: T) {
  const cached = readAdminCache<T>(name) ?? [];
  writeAdminCache(name, mergeById(cached, [row]));
}

export function cacheRemoveRow(name: string, id: string) {
  const cached = readAdminCache<any>(name);
  if (!cached) return;
  writeAdminCache(name, cached.filter(r => r?.id !== id));
}

export function cachePatchRow(name: string, id: string, patch: Record<string, any>) {
  const cached = readAdminCache<any>(name);
  if (!cached) return;
  writeAdminCache(name, cached.map(r => (r?.id === id ? { ...r, ...patch } : r)));
}

interface DeltaFetchOptions {
  /** Logical cache/watermark name, e.g. `payment_orders`. */
  name: string;
  /** Builds the base query WITHOUT any timestamp filter. */
  buildQuery: () => any;
  /** Timestamp column used for the delta. Default `updated_at`. */
  tsColumn?: string;
  /** Ignore cache + watermark and fetch everything. */
  force?: boolean;
  /**
   * Re-fetch window (ms) subtracted from the stored watermark. Used for tables
   * whose rows can change without a bumped timestamp (sms_inbox.matched_order_id).
   */
  overlapMs?: number;
}

export interface DeltaFetchResult<T> {
  /** Full merged row set (cache + delta), also written back to the cache. */
  rows: T[];
  /** Rows returned by this fetch only. */
  fresh: T[];
  /** True when the whole table was re-fetched (first run or forced). */
  fullSync: boolean;
}

/**
 * Cache-first delta fetch. Returns the merged row set and persists it.
 */
export async function deltaFetch<T extends { id: string }>(
  opts: DeltaFetchOptions
): Promise<DeltaFetchResult<T>> {
  const { name, buildQuery, tsColumn = 'updated_at', force = false, overlapMs = 0 } = opts;

  const cached = force ? null : readAdminCache<T>(name);
  const hasCache = !!cached && cached.length > 0;
  const fullSync = !hasCache;

  let since: string | null = null;
  if (!fullSync) {
    const stored = localStorage.getItem(ADMIN_DELTA_KEY(name));
    if (stored) {
      since = overlapMs > 0
        ? new Date(new Date(stored).getTime() - overlapMs).toISOString()
        : stored;
    }
  }

  let q = buildQuery();
  if (since) q = q.gt(tsColumn, since);

  const fresh: T[] = await fetchAllRows(q);

  const rows = fullSync ? fresh : mergeById(cached ?? [], fresh);
  writeAdminCache(name, rows);

  // Advance the watermark to the newest timestamp we have actually seen.
  let maxTs: string | null = null;
  for (const r of fresh as any[]) {
    const ts = r?.[tsColumn];
    if (ts && (!maxTs || ts > maxTs)) maxTs = ts;
  }
  if (maxTs) {
    try { localStorage.setItem(ADMIN_DELTA_KEY(name), maxTs); } catch { /* ignore */ }
  }

  return { rows, fresh, fullSync };
}

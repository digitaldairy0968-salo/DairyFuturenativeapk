import { supabase } from '@/integrations/supabase/client';

export type OrderStatus = 'created' | 'awaiting_utr' | 'verifying' | 'success' | 'failed' | 'expired';

export interface PaymentOrderRow {
  id: string;
  user_id: string;
  dairy_id: string;
  variety_plan_id: string;
  amount: number;
  order_ref: string;
  status: OrderStatus;
  utr_submitted: string | null;
  created_at: string;
  expires_at: string;
}

export interface OrderBundle {
  order: PaymentOrderRow;
  plan: { id: string; name: string; price: number; validity_days: number } | null;
  upi_id: string | null;
  admin_phone: string | null;
}

/** Creates a payment order server-side (amount always derived from the plan). */
export async function createPaymentOrder(planId: string): Promise<string> {
  const { data, error } = await supabase.rpc('create_payment_order', { _plan_id: planId });
  if (error) throw error;
  const row = Array.isArray(data) ? data[0] : data;
  if (!row?.order_id) throw new Error('order_create_failed');
  return row.order_id as string;
}

export async function fetchOrder(orderId: string): Promise<OrderBundle> {
  const { data, error } = await supabase.rpc('get_payment_order', { _order_id: orderId });
  if (error) throw error;
  return data as unknown as OrderBundle;
}

export async function submitUtr(orderId: string, utr: string): Promise<{ status: OrderStatus; matched: boolean }> {
  const { data, error } = await supabase.rpc('submit_payment_utr', { _order_id: orderId, _utr: utr });
  if (error) throw error;
  const row = Array.isArray(data) ? data[0] : data;
  return { status: (row?.status ?? 'verifying') as OrderStatus, matched: !!row?.matched };
}

/** Records that the user opened their UPI app and came back (auto-match candidate). */
export async function markPayClicked(orderId: string): Promise<void> {
  const { error } = await supabase.rpc('mark_order_pay_clicked', { _order_id: orderId });
  if (error) throw error;
}


export function buildUpiUrl(opts: { upiId: string; payeeName: string; amount: number; orderRef: string }) {
  const { upiId, payeeName, amount, orderRef } = opts;
  return `upi://pay?pa=${encodeURIComponent(upiId)}&pn=${encodeURIComponent(payeeName)}&tr=${encodeURIComponent(orderRef)}&am=${encodeURIComponent(
    Number(amount).toFixed(2)
  )}&cu=INR&tn=${encodeURIComponent('DairyFuture Subscription')}`;
}

/** Same payload, app-specific schemes for one-tap on mobile. */
export function buildAppUrls(upiUrl: string) {
  const query = upiUrl.replace('upi://pay?', '');
  return {
    gpay: `tez://upi/pay?${query}`,
    phonepe: `phonepe://pay?${query}`,
    paytm: `paytmmp://pay?${query}`,
  };
}

export function isMobileDevice() {
  return /android|iphone|ipad|ipod|mobile/i.test(navigator.userAgent);
}

/**
 * Opens a `upi://` (or app-specific) deep link.
 * A plain `window.location.href = 'upi://...'` is blocked inside iframes/previews and
 * silently ignored by some Android webviews, so we try a real user-gesture anchor click
 * first, then top-level navigation, then an Android intent:// fallback.
 */
export function openUpiApp(url: string): void {
  // 1) anchor click (works in most browsers, preserves the user gesture)
  try {
    const a = document.createElement('a');
    a.href = url;
    a.rel = 'noopener';
    a.style.display = 'none';
    document.body.appendChild(a);
    a.click();
    setTimeout(() => a.remove(), 0);
  } catch {
    /* ignore */
  }

  // 2) top-level navigation (breaks out of the preview iframe)
  setTimeout(() => {
    try {
      const top = window.top ?? window;
      top.location.href = url;
    } catch {
      try {
        window.location.href = url;
      } catch {
        /* ignore */
      }
    }
  }, 120);

  // 3) Android intent fallback when no handler picked the upi:// scheme
  if (/android/i.test(navigator.userAgent) && url.startsWith('upi://')) {
    setTimeout(() => {
      try {
        const intent = `intent://${url.slice('upi://'.length)}#Intent;scheme=upi;action=android.intent.action.VIEW;end`;
        (window.top ?? window).location.href = intent;
      } catch {
        /* ignore */
      }
    }, 900);
  }
}

export function orderErrorMessage(raw: string, hi: boolean): string {
  const m = raw || '';
  return orderErrorMessageInner(m, hi);
}

/**
 * Creates the order and, on mobile, immediately hands the user off to their UPI
 * app inside the same click gesture — no intermediate payment screen.
 * Returns the order id so the caller can navigate to the verify screen.
 */
export async function startUpiPayment(planId: string): Promise<string> {
  const orderId = await createPaymentOrder(planId);
  try {
    const bundle = await fetchOrder(orderId);
    if (bundle?.upi_id && isMobileDevice()) {
      const url = buildUpiUrl({
        upiId: bundle.upi_id,
        payeeName: 'DairyFuture',
        amount: bundle.order.amount,
        orderRef: bundle.order.order_ref,
      });
      try { sessionStorage.setItem(`upi_launched_${orderId}`, '1'); } catch { /* ignore */ }
      openUpiApp(url);
    }
  } catch { /* verify screen can still launch it manually */ }
  return orderId;
}

function orderErrorMessageInner(raw: string, hi: boolean): string {
  const m = raw || '';
  if (m.includes('invalid_utr')) return hi ? 'UTR / ट्रांज़ैक्शन ID सही नहीं है' : 'Invalid UTR / transaction ID';
  if (m.includes('order_expired')) return hi ? 'ऑर्डर की समय-सीमा खत्म हो गई, नया ऑर्डर बनाएं' : 'Order expired, please create a new one';
  if (m.includes('duplicate_utr')) return hi ? 'यह UTR पहले इस्तेमाल हो चुका है' : 'This UTR has already been used';
  if (m.includes('not_order_owner')) return hi ? 'यह ऑर्डर आपका नहीं है' : 'This order is not yours';
  if (m.includes('order_not_found')) return hi ? 'ऑर्डर नहीं मिला' : 'Order not found';
  if (m.includes('not_dairy_owner')) return hi ? 'आप डेयरी मालिक नहीं हैं' : 'You are not a dairy owner';
  if (m.includes('plan_not_found')) return hi ? 'प्लान उपलब्ध नहीं है' : 'Plan not available';
  if (m.includes('not_authenticated')) return hi ? 'कृपया दोबारा लॉगिन करें' : 'Please sign in again';
  if (m.includes('expires_at') && m.includes('ambiguous')) return hi ? 'पेमेंट सेवा अपडेट हो रही है, दोबारा कोशिश करें' : 'Payment service is updating, please retry';
  const generic = hi ? 'कुछ गलत हुआ, दोबारा कोशिश करें' : 'Something went wrong, please try again';
  // Unknown/unmapped error: show the raw reason too so it can be diagnosed.
  return m ? `${generic}\n(${m})` : generic;
}

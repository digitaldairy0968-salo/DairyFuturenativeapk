/**
 * Dedicated, lightweight reopen check — ONE rpc (`get_reopen_status`) that
 * returns subscription status/expiry, dairy feature toggles and (only when the
 * customer-code feature is ON) the dairy's 12-digit code.
 *
 * This is the ONLY settings-ish network call allowed on app reopen/resume.
 * Everything else is served from localStorage.
 */
import { useEffect, useState } from 'react';
import { supabase } from '@/integrations/supabase/client';

export type SubStatus = 'active' | 'expired' | 'none';

const CACHE_KEY = 'subscription_cache';
const TTL_MS = 24 * 60 * 60 * 1000;

/** Timestamp of the last successful RPC check (written by write()). */
function getLastCheckedAt(): number | null {
  try {
    const raw = localStorage.getItem(CACHE_KEY);
    if (!raw) return null;
    const p = JSON.parse(raw);
    return typeof p?.timestamp === 'number' ? p.timestamp : null;
  } catch {
    return null;
  }
}

export interface ReopenStatus {
  status: SubStatus;
  expires_at: string | null;
  features: Record<string, boolean>;
  dairy_code: string | null;
}

type Listener = (d: ReopenStatus | null) => void;
const listeners = new Set<Listener>();

export function readReopenStatus(): ReopenStatus | null {
  try {
    const raw = localStorage.getItem(CACHE_KEY);
    if (!raw) return null;
    const p = JSON.parse(raw);
    if (!p?.status) return null;
    return {
      status: p.status as SubStatus,
      expires_at: p.expires_at ?? null,
      features: p.features ?? {},
      dairy_code: p.dairy_code ?? null,
    };
  } catch {
    return null;
  }
}

export function readSubscriptionCache(): SubStatus | null {
  return readReopenStatus()?.status ?? null;
}

function write(data: ReopenStatus) {
  try {
    localStorage.setItem(CACHE_KEY, JSON.stringify({ ...data, timestamp: Date.now() }));
  } catch { /* ignore quota */ }
  listeners.forEach((l) => l(data));
}

/** Used by the demo-activation flow to flip the local cache instantly. */
export function writeSubscriptionCache(status: SubStatus, expiresAt?: string | null) {
  const cur = readReopenStatus();
  write({
    status,
    expires_at: expiresAt ?? cur?.expires_at ?? null,
    features: cur?.features ?? {},
    dairy_code: cur?.dairy_code ?? null,
  });
}

/** Patch a single feature flag locally after an owner/admin write. */
export function patchReopenFeature(key: string, enabled: boolean) {
  const cur = readReopenStatus();
  if (!cur) return;
  write({ ...cur, features: { ...cur.features, [key]: enabled } });
}

let inFlight: Promise<SubStatus | null> | null = null;

/** One RPC: subscription + features + dairy code. Caches the result. */
export async function checkSubscriptionStatus(dairyId?: string, force = false): Promise<SubStatus | null> {
  if (!navigator.onLine) return readSubscriptionCache();
  if (!force) {
    const last = getLastCheckedAt();
    if (last !== null && Date.now() - last < TTL_MS) return readSubscriptionCache();
  }
  if (inFlight) return inFlight;

  inFlight = (async () => {
    try {
      const { data, error } = await supabase.rpc('get_reopen_status' as any);
      if (error) {
        console.warn('[reopen] check failed', error.message);
        return readSubscriptionCache();
      }
      const payload: any = data;
      if (!payload) return readSubscriptionCache();

      const sub = payload.subscription ?? null;
      let status: SubStatus = 'none';
      if (sub) {
        const expired = sub.expires_at && new Date(sub.expires_at) < new Date();
        status = sub.status === 'active' && !expired ? 'active' : 'expired';
      }
      write({
        status,
        expires_at: sub?.expires_at ?? null,
        features: payload.features ?? {},
        dairy_code: payload.dairy_code ?? null,
      });
      return status;
    } finally {
      inFlight = null;
    }
  })();

  return inFlight;
}

/** React binding — cache-only, no network (the reopen check does the fetching). */
export function useReopenStatus() {
  const [data, setData] = useState<ReopenStatus | null>(() => readReopenStatus());
  useEffect(() => {
    const l: Listener = (d) => setData(d);
    listeners.add(l);
    return () => { listeners.delete(l); };
  }, []);
  return data;
}

export function reopenDaysLeft(d: ReopenStatus | null): number | null {
  if (!d?.expires_at) return null;
  return Math.max(0, Math.ceil((new Date(d.expires_at).getTime() - Date.now()) / 86400000));
}

export function reopenFeatureEnabled(d: ReopenStatus | null, key: string) {
  return !!d?.features?.[key];
}

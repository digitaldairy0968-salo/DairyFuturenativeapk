/**
 * settingsBootstrap — one RPC (`get_settings_bootstrap`) that replaces the
 * subscription / subscription_settings / admin contact /
 * varieties / variety_plans / dairy_features / dairies reads.
 *
 * Policy: network call happens ONCE per tab session (i.e. on app/tab reopen).
 * After that everything is served from localStorage — no TTL, no timers, no
 * manual refresh button. Local writes patch the cache in place.
 */
import { useEffect, useState } from 'react';
import { supabase } from '@/integrations/supabase/client';

export interface SettingsBootstrap {
  dairy: { id: string; name: string; code: string | null; owner_id: string } | null;
  subscription: { status: string; expires_at: string | null } | null;
  settings: Record<string, any>;
  contact: { admin_phone?: string; upi_id?: string };
  varieties: any[];
  variety_plans: any[];
  features: Record<string, boolean>;
  owner_phone: string;
}

const CACHE_KEY = 'dairy_settings_bootstrap_v1';
const SESSION_KEY = 'sess_dairy_settings_bootstrap_v1';

type Listener = (data: SettingsBootstrap | null) => void;
const listeners = new Set<Listener>();
let inFlight: Promise<SettingsBootstrap | null> | null = null;

export function readSettingsBootstrap(): SettingsBootstrap | null {
  try {
    const raw = localStorage.getItem(CACHE_KEY);
    return raw ? (JSON.parse(raw) as SettingsBootstrap) : null;
  } catch {
    return null;
  }
}

function writeCache(data: SettingsBootstrap | null) {
  try {
    if (data) localStorage.setItem(CACHE_KEY, JSON.stringify(data));
    else localStorage.removeItem(CACHE_KEY);
  } catch { /* ignore quota */ }
  listeners.forEach((l) => l(data));
}

/** Clear on logout / account switch so the next session bootstraps fresh. */
export function clearSettingsBootstrap() {
  try {
    localStorage.removeItem(CACHE_KEY);
    sessionStorage.removeItem(SESSION_KEY);
  } catch { /* ignore */ }
  listeners.forEach((l) => l(null));
}

/** Merge a locally-known change (e.g. a feature toggle) into the cache. */
export function patchSettingsBootstrap(patch: Partial<SettingsBootstrap>) {
  const current = readSettingsBootstrap();
  if (!current) return;
  writeCache({ ...current, ...patch });
}

/**
 * Seed the cache from a combined bootstrap RPC (`get_app_bootstrap`), so the
 * separate `get_settings_bootstrap` call never has to run in this session.
 */
export function primeSettingsBootstrap(data: SettingsBootstrap | null) {
  if (!data) return;
  writeCache(data);
  try { sessionStorage.setItem(SESSION_KEY, '1'); } catch { /* ignore */ }
}

/** Patch a single dairy feature flag locally after an owner/admin write. */
export function patchBootstrapFeature(featureKey: string, enabled: boolean) {
  const current = readSettingsBootstrap();
  if (!current) return;
  writeCache({ ...current, features: { ...(current.features || {}), [featureKey]: enabled } });
}

/** Fallback: build the bootstrap payload from plain table reads (used when the RPC is unavailable). */
async function fetchBootstrapFallback(): Promise<SettingsBootstrap | null> {
  const { data: auth } = await supabase.auth.getUser();
  const uid = auth?.user?.id;
  if (!uid) return null;

  let dairyId: string | null = null;
  let dairy: SettingsBootstrap['dairy'] = null;

  const { data: ownedDairy } = await supabase
    .from('dairies')
    .select('id,name,code,owner_id')
    .eq('owner_id', uid)
    .maybeSingle();

  if (ownedDairy) {
    dairy = ownedDairy as any;
    dairyId = ownedDairy.id;
  } else {
    const { data: sup } = await supabase
      .from('suppliers')
      .select('dairy_id')
      .eq('user_id', uid)
      .maybeSingle();
    dairyId = sup?.dairy_id ?? null;
    if (dairyId) {
      const { data: d } = await supabase
        .from('dairies')
        .select('id,name,code,owner_id')
        .eq('id', dairyId)
        .maybeSingle();
      dairy = (d as any) ?? null;
    }
  }

  const [subRes, settingsRes, contactRes, varietiesRes, varietyPlansRes, featuresRes] = await Promise.all([
    dairyId
      ? supabase.from('subscriptions').select('status,expires_at').eq('dairy_id', dairyId).order('created_at', { ascending: false }).limit(1)
      : Promise.resolve({ data: [] } as any),
    // admin_phone / upi_id columns are REVOKEd for authenticated — never select *
    supabase.from('subscription_settings').select('id,monthly_price,demo_days,default_validity_days,qr_code_url,auth_page_image_url,created_at,updated_at').limit(1),
    supabase.rpc('get_admin_payment_contact' as any),
    supabase.from('subscription_varieties').select('*').eq('is_active', true).order('created_at'),
    supabase.from('variety_plans').select('*').eq('is_active', true).order('price'),
    dairyId
      ? supabase.from('dairy_features').select('feature_key,is_enabled').eq('dairy_id', dairyId)
      : Promise.resolve({ data: [] } as any),
  ]);

  const subRows: any[] = (subRes as any)?.data ?? [];
  const active = subRows.find((s) => s.status === 'active') ?? subRows[0] ?? null;
  const settingsRow: any = ((settingsRes as any)?.data ?? [])[0] ?? {};
  const contactRaw: any = (contactRes as any)?.data;
  const contactRow: any = Array.isArray(contactRaw) ? (contactRaw[0] ?? {}) : (contactRaw ?? {});
  const { admin_phone, upi_id, ...restSettings } = { ...settingsRow };

  const features: Record<string, boolean> = {};
  for (const f of ((featuresRes as any)?.data ?? [])) features[f.feature_key] = !!f.is_enabled;

  let ownerPhone = '';
  if (dairy?.owner_id) {
    const { data: prof } = await supabase.from('profiles').select('phone').eq('user_id', dairy.owner_id).maybeSingle();
    ownerPhone = prof?.phone ?? '';
  }

  return {
    dairy,
    subscription: active ? { status: active.status, expires_at: active.expires_at } : null,
    settings: restSettings ?? {},
    contact: {
      admin_phone: contactRow?.admin_phone || admin_phone || '',
      upi_id: contactRow?.upi_id || upi_id || '',
    },
    varieties: ((varietiesRes as any)?.data ?? []),
    variety_plans: ((varietyPlansRes as any)?.data ?? []),
    features,
    owner_phone: ownerPhone,
  };
}

/**
 * Fetch once per tab session. `force` is only for real state changes
 * (subscription activated, dairy created) — never for timers.
 */
export async function loadSettingsBootstrap(force = false): Promise<SettingsBootstrap | null> {
  const cached = readSettingsBootstrap();
  // Self-heal: an old cache missing payment contact info must be refetched once.
  const cacheIncomplete = !!cached && !cached.contact?.upi_id && !cached.contact?.admin_phone;
  const alreadyHealed = sessionStorage.getItem(SESSION_KEY + '_healed') === '1';
  if (!force && (!cacheIncomplete || alreadyHealed) && cached && sessionStorage.getItem(SESSION_KEY)) return cached;
  if (cacheIncomplete) { try { sessionStorage.setItem(SESSION_KEY + '_healed', '1'); } catch {} }
  if (!navigator.onLine) return cached;
  if (inFlight) return inFlight;

  inFlight = (async () => {
    try {
      const { data, error } = await supabase.rpc('get_settings_bootstrap' as any);
      if (error || !data) {
        if (error) console.warn('[settingsBootstrap] rpc unavailable, using table fallback', error.message);
        const fb = await fetchBootstrapFallback();
        if (fb) {
          writeCache(fb);
          sessionStorage.setItem(SESSION_KEY, '1');
          return fb;
        }
        return cached;
      }
      const boot = data as unknown as SettingsBootstrap;
      writeCache(boot);
      sessionStorage.setItem(SESSION_KEY, '1');
      return boot;
    } catch (err) {
      console.error('[settingsBootstrap] rpc threw', err);
      try {
        const fb = await fetchBootstrapFallback();
        if (fb) { writeCache(fb); sessionStorage.setItem(SESSION_KEY, '1'); return fb; }
      } catch {}
      return cached;
    } finally {
      inFlight = null;
    }
  })();

  return inFlight;
}

/**
 * React binding: instant cache render, and a network call ONLY when `enabled`
 * (i.e. on the Settings / SubscriptionRenewal / PaymentRequired pages). There is
 * no resume/visibility refresh here — reopen must not hit this RPC.
 */
export function useSettingsBootstrap(enabled = true) {
  const [data, setData] = useState<SettingsBootstrap | null>(() => readSettingsBootstrap());
  const [loading, setLoading] = useState<boolean>(() => !readSettingsBootstrap());

  useEffect(() => {
    const listener: Listener = (d) => setData(d);
    listeners.add(listener);
    return () => { listeners.delete(listener); };
  }, []);

  useEffect(() => {
    if (!enabled) { setLoading(false); return; }
    let cancelled = false;
    loadSettingsBootstrap().then((d) => {
      if (cancelled) return;
      if (d) setData(d);
      setLoading(false);
    });
    return () => { cancelled = true; };
  }, [enabled]);

  return { data, loading };
}

export function isFeatureEnabled(boot: SettingsBootstrap | null, key: string) {
  return !!boot?.features?.[key];
}

export function daysLeftFrom(boot: SettingsBootstrap | null): number | null {
  const exp = boot?.subscription?.expires_at;
  if (!exp) return null;
  return Math.max(0, Math.ceil((new Date(exp).getTime() - Date.now()) / (1000 * 60 * 60 * 24)));
}

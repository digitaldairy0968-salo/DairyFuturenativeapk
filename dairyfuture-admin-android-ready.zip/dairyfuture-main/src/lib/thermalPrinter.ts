// Web / Native Bluetooth ESC/POS Thermal Printer Utility
// Silent, direct printing - no browser print dialog
//
// Compatible with most 58mm/80mm BLE thermal printers (RPP02, MTP-II, etc.)
import { BleClient, numberToUUID } from '@capacitor-community/bluetooth-le';
import { Capacitor } from '@capacitor/core';
// that expose the common nordic/printer service.

// Common BLE printer services (we attempt them in order)
const PRINTER_SERVICES: any[] = [
  0x18f0,
  0xff00,
  0xfee7,
  0xffe0,
  0xfff0,
  0xffe5,
  0xae30,
  0xae3a,
  0xabf0,
  0xab00,
  '49535343-fe7d-4ae5-8fa9-9fafd205e455',
  '0000ff00-0000-1000-8000-00805f9b34fb',
  '000018f0-0000-1000-8000-00805f9b34fb',
  '0000ffe0-0000-1000-8000-00805f9b34fb',
  '0000ffe5-0000-1000-8000-00805f9b34fb',
  '0000fff0-0000-1000-8000-00805f9b34fb',
  '0000ae30-0000-1000-8000-00805f9b34fb',
  '0000ae3a-0000-1000-8000-00805f9b34fb',
  '0000abf0-0000-1000-8000-00805f9b34fb',
  '0000ab00-0000-1000-8000-00805f9b34fb',
  'e7810a71-73ae-499d-8c15-faa9aef0c3f2',
];

interface PrinterRef {
  device: any;
  characteristic: any;
  characteristics: any[];
}

let printerRef: PrinterRef | null = null;

const STORAGE_KEY = 'thermal_printer_device_name';
const DEVICE_ID_KEY = 'thermal_printer_device_id';
const CONNECT_TIMEOUT_MS = 12000;

const enc = new TextEncoder();

// ESC/POS commands
const ESC = 0x1b;
const GS = 0x1d;
const INIT = new Uint8Array([ESC, 0x40]);
const LF = new Uint8Array([0x0a]);
const DEFAULT_LINE_SPACING = new Uint8Array([ESC, 0x32]);
const CODEPAGE_USA = new Uint8Array([ESC, 0x52, 0x00, ESC, 0x74, 0x00]);
const ALIGN_CENTER = new Uint8Array([ESC, 0x61, 0x01]);
const ALIGN_LEFT = new Uint8Array([ESC, 0x61, 0x00]);
const BOLD_ON = new Uint8Array([ESC, 0x45, 0x01]);
const BOLD_OFF = new Uint8Array([ESC, 0x45, 0x00]);
const DOUBLE_ON = new Uint8Array([GS, 0x21, 0x11]);
const DOUBLE_OFF = new Uint8Array([GS, 0x21, 0x00]);
// Font A = default (12x24, ~32 chars on 58mm). Font B = smaller (9x17, ~42 chars).
const FONT_A = new Uint8Array([ESC, 0x4d, 0x00]);
const FONT_B = new Uint8Array([ESC, 0x4d, 0x01]);
// Most low-cost 58mm BLE printers do not have a cutter. Sending cut commands to
// those printers can intermittently disturb the next receipt, so feed only.
const FEED_END = new Uint8Array([0x0a, 0x0a, 0x0a, 0x0a, 0x0a]);

let printQueue: Promise<void> = Promise.resolve();
let lastPrintFinishedAt = 0;
const PRINT_COOLDOWN_MS = 1400;

function concat(chunks: Uint8Array[]): Uint8Array {
  const total = chunks.reduce((s, c) => s + c.length, 0);
  const out = new Uint8Array(total);
  let off = 0;
  for (const c of chunks) { out.set(c, off); off += c.length; }
  return out;
}

function sortWritableCharacteristics(chars: any[]): any[] {
  // Prefer write-with-response when available: it is slower, but Android BLE
  // printers are more reliable because the browser waits for ACKs.
  return chars.sort((a, b) => Number(!!b.properties.write) - Number(!!a.properties.write));
}

async function findWritableCharacteristics(server: any): Promise<any[]> {
  const found: any[] = [];
  const seen = new Set<string>();

  const addWritable = (chars: any[]) => {
    for (const ch of chars) {
      if (!(ch.properties.write || ch.properties.writeWithoutResponse)) continue;
      const id = ch.uuid || `${found.length}`;
      if (seen.has(id)) continue;
      seen.add(id);
      found.push(ch);
    }
  };

  // Try known services first
  for (const svc of PRINTER_SERVICES) {
    try {
      const service = await server.getPrimaryService(svc);
      const chars = await service.getCharacteristics();
      addWritable(chars);
    } catch (_) { /* try next */ }
  }
  // Fallback: enumerate all
  try {
    const services = await server.getPrimaryServices();
    for (const service of services) {
      const chars = await service.getCharacteristics();
      addWritable(chars);
    }
  } catch (_) { /* ignore */ }
  return sortWritableCharacteristics(found);
}

async function wait(ms: number): Promise<void> {
  await new Promise(resolve => setTimeout(resolve, ms));
}

async function enqueuePrint<T>(task: () => Promise<T>): Promise<T> {
  let release!: () => void;
  const previous = printQueue;
  printQueue = new Promise<void>(resolve => { release = resolve; });

  await previous.catch(() => undefined);
  try {
    const elapsed = Date.now() - lastPrintFinishedAt;
    if (elapsed > 0 && elapsed < PRINT_COOLDOWN_MS) {
      await wait(PRINT_COOLDOWN_MS - elapsed);
    }
    return await task();
  } finally {
    lastPrintFinishedAt = Date.now();
    release();
  }
}

async function withTimeout<T>(promise: Promise<T>, ms: number, message: string): Promise<T> {
  let timer: ReturnType<typeof setTimeout> | null = null;
  try {
    return await Promise.race([
      promise,
      new Promise<T>((_, reject) => {
        timer = setTimeout(() => reject(new Error(message)), ms);
      }),
    ]);
  } finally {
    if (timer) clearTimeout(timer);
  }
}

function rememberDevice(device: any) {
  try {
    localStorage.setItem(STORAGE_KEY, device.name || 'printer');
    if (device?.id) localStorage.setItem(DEVICE_ID_KEY, device.id);
  } catch {}
}

function getStoredDeviceId(): string | null {
  try {
    return localStorage.getItem(DEVICE_ID_KEY);
  } catch {
    return null;
  }
}

async function getPreviouslyGrantedDevice(): Promise<any | null> {
  const bt: any = (navigator as any).bluetooth;
  if (!bt?.getDevices) return null;

  try {
    const devices = await bt.getDevices();
    if (!Array.isArray(devices) || devices.length === 0) return null;

    const storedId = getStoredDeviceId();
    if (storedId) {
      const exact = devices.find((device: any) => device?.id === storedId);
      if (exact) return exact;
    }

    const storedName = getStoredPrinterName();
    if (storedName) {
      const byName = devices.find((device: any) => device?.name === storedName);
      if (byName) return byName;
    }

    return devices[0] ?? null;
  } catch (e) {
    console.warn('[printer] getDevices failed', e);
    return null;
  }
}

async function connectGattWithRetry(device: any, attempts = 4): Promise<any> {
  let lastErr: any;
  for (let i = 0; i < attempts; i++) {
    try {
      if (device.gatt?.connected) return device.gatt;
      // Android BLE printers often need a brief settle time after picker/pair.
      await wait(i === 0 ? 900 : 900 + 700 * i);

      const server = await withTimeout(
        device.gatt.connect(),
        CONNECT_TIMEOUT_MS,
        'gatt_connect_timeout'
      );
      return server;
    } catch (e) {
      console.warn('[printer] gatt.connect attempt', i + 1, 'failed', e);
      lastErr = e;
      try { device.gatt.disconnect(); } catch {}
    }
  }
  throw lastErr || new Error('gatt_connect_failed');
}

async function openPrinterPicker(): Promise<any> {
  const bt: any = (navigator as any).bluetooth;
  if (!bt) throw new Error('bluetooth_unsupported');

  try {
    return await bt.requestDevice({
      acceptAllDevices: true,
      optionalServices: PRINTER_SERVICES,
    });
  } catch (e: any) {
    if (e?.name === 'NotFoundError') throw new Error('cancelled');
    throw new Error(e?.message || 'picker_failed');
  }
}
const attachedDevices = new WeakSet<any>();
let reconnectingSilently = false;

function attachAutoReconnect(device: any) {
  if (!device || attachedDevices.has(device)) return;
  attachedDevices.add(device);
  device.addEventListener('gattserverdisconnected', () => {
    console.warn('[printer] gatt disconnected, will try silent reconnect');
    if (reconnectingSilently) return;
    reconnectingSilently = true;
    setTimeout(async () => {
      try {
        if (printerRef?.device === device && !device.gatt?.connected) {
          const server = await connectGattWithRetry(device, 3);
          const chars = await findWritableCharacteristics(server);
          if (chars.length && printerRef) {
            printerRef.characteristics = chars;
            printerRef.characteristic = chars[0];
            try { await writeBytes(INIT); } catch {}
            console.log('[printer] silent reconnect ok');
          }
        }
      } catch (e) {
        console.warn('[printer] silent reconnect failed', e);
      } finally {
        reconnectingSilently = false;
      }
    }, 1500);
  });
}

interface NativePrinterRef {
  deviceId: string;
  name?: string;
  serviceUuid: string;
  characteristicUuid: string;
  writeWithResponse: boolean;
}
let nativePrinterRef: NativePrinterRef | null = null;

export async function connectThermalPrinter(options: { silent?: boolean } = {}): Promise<{ ok: boolean; name?: string; error?: string }> {
  if (Capacitor.isNativePlatform()) {
    try {
      await BleClient.initialize();
      const storedId = getStoredDeviceId();
      const storedName = getStoredPrinterName();

      if (storedId) {
        try {
          await BleClient.connect(storedId, () => {
            nativePrinterRef = null;
          });
          const services = await BleClient.getServices(storedId);
          for (const s of services) {
            for (const ch of s.characteristics) {
              if (ch.properties.write || ch.properties.writeWithoutResponse) {
                nativePrinterRef = {
                  deviceId: storedId,
                  name: storedName || 'Thermal Printer',
                  serviceUuid: s.uuid,
                  characteristicUuid: ch.uuid,
                  writeWithResponse: !!ch.properties.write,
                };
                await writeBytes(INIT);
                return { ok: true, name: nativePrinterRef.name };
              }
            }
          }
        } catch {
          if (options.silent) return { ok: false, error: 'reconnect_failed' };
        }
      }

      if (options.silent) return { ok: false, error: 'no_remembered_device' };

      const serviceUuids = PRINTER_SERVICES.map(s => (typeof s === 'number' ? numberToUUID(s) : String(s)));
      const device = await BleClient.requestDevice({
        optionalServices: serviceUuids,
      });

      if (!device) return { ok: false, error: 'no_device' };

      await BleClient.connect(device.deviceId, () => {
        nativePrinterRef = null;
      });

      const services = await BleClient.getServices(device.deviceId);
      for (const s of services) {
        for (const ch of s.characteristics) {
          if (ch.properties.write || ch.properties.writeWithoutResponse) {
            nativePrinterRef = {
              deviceId: device.deviceId,
              name: device.name || 'Thermal Printer',
              serviceUuid: s.uuid,
              characteristicUuid: ch.uuid,
              writeWithResponse: !!ch.properties.write,
            };
            if (device.name) localStorage.setItem(STORAGE_KEY, device.name);
            localStorage.setItem(DEVICE_ID_KEY, device.deviceId);
            await writeBytes(INIT);
            return { ok: true, name: nativePrinterRef.name };
          }
        }
      }
      return { ok: false, error: 'no_writable_characteristic' };
    } catch (e: any) {
      if (e?.message?.includes('cancelled') || e?.name === 'NotFoundError') {
        return { ok: false, error: 'cancelled' };
      }
      return { ok: false, error: e?.message || 'connect_failed' };
    }
  }

  const bt: any = (navigator as any).bluetooth;
  if (!bt) return { ok: false, error: 'bluetooth_unsupported' };

  let device: any = printerRef?.device ?? await getPreviouslyGrantedDevice();
  const usingRememberedDevice = !!device;

  if (!device) {
    if (options.silent) return { ok: false, error: 'no_remembered_device' };
    try {
      device = await openPrinterPicker();
    } catch (e: any) {
      return { ok: false, error: e?.message || 'picker_failed' };
    }
  }

  if (!device) return { ok: false, error: 'no_device' };

  try {
    const server = await connectGattWithRetry(device);
    const characteristics = await findWritableCharacteristics(server);
    if (!characteristics.length) {
      try { device.gatt.disconnect(); } catch {}
      return { ok: false, error: 'no_writable_characteristic' };
    }

    printerRef = { device, characteristic: characteristics[0], characteristics };
    await writeBytes(INIT);
    rememberDevice(device);
    attachAutoReconnect(device);

    return { ok: true, name: device.name };
  } catch (e: any) {
    if (options.silent) {
      console.error('[printer] silent reconnect failed', e);
      const msg = String(e?.message || e?.name || 'connect_failed');
      return { ok: false, error: msg };
    }

    if (usingRememberedDevice) {
      try {
        const pickedDevice = await openPrinterPicker();
        const server = await connectGattWithRetry(pickedDevice);
        const characteristics = await findWritableCharacteristics(server);

        if (!characteristics.length) {
          try { pickedDevice.gatt.disconnect(); } catch {}
          return { ok: false, error: 'no_writable_characteristic' };
        }

        printerRef = { device: pickedDevice, characteristic: characteristics[0], characteristics };
        await writeBytes(INIT);
        rememberDevice(pickedDevice);
        attachAutoReconnect(pickedDevice);

        return { ok: true, name: pickedDevice.name };
      } catch (retryError: any) {
        if (retryError?.message === 'cancelled') return { ok: false, error: 'cancelled' };
        e = retryError;
      }
    }

    console.error('[printer] connect failed', e);
    const msg = String(e?.message || e?.name || '');
    if (/GATT|Network|connection/i.test(msg)) {
      return { ok: false, error: 'gatt_failed: ' + msg };
    }
    return { ok: false, error: msg || 'connect_failed' };
  }
}

async function ensureConnected(): Promise<boolean> {
  if (Capacitor.isNativePlatform()) {
    if (nativePrinterRef) return true;
    const res = await connectThermalPrinter({ silent: true });
    return res.ok;
  }
  if (!printerRef) return false;
  try {
    if (!printerRef.device.gatt.connected) {
      const server = await connectGattWithRetry(printerRef.device, 2);
      const characteristics = await findWritableCharacteristics(server);
      if (!characteristics.length) return false;
      printerRef.characteristics = characteristics;
      printerRef.characteristic = characteristics[0];
    }
    return !!printerRef.characteristic;
  } catch (e) {
    console.error('[printer] ensureConnected failed', e);
    return false;
  }
}

export function isPrinterReady(): boolean {
  if (Capacitor.isNativePlatform()) {
    return !!nativePrinterRef;
  }
  return !!printerRef && !!printerRef.device?.gatt?.connected;
}

export function isPrinterPaired(): boolean {
  if (Capacitor.isNativePlatform()) {
    return !!nativePrinterRef || !!getStoredPrinterName() || !!getStoredDeviceId();
  }
  return !!printerRef || !!getStoredPrinterName() || !!getStoredDeviceId();
}

async function writeBytesToCharacteristic(ch: any, data: Uint8Array): Promise<void> {
  // 20-byte chunks are the safest BLE MTU size for low-cost printers.
  // Larger chunks often connect but intermittently fail to print on Android.
  const CHUNK = 20;
  for (let i = 0; i < data.length; i += CHUNK) {
    const slice = data.slice(i, i + CHUNK);
    if (ch.properties.write) {
      await ch.writeValue(slice);
    } else if (ch.properties.writeWithoutResponse) {
      await ch.writeValueWithoutResponse(slice);
    } else {
      throw new Error('characteristic_not_writable');
    }
    // Give the tiny printer buffer enough time. Missing/half receipts usually
    // happen when Android sends chunks faster than the printer can consume them.
    await wait(ch.properties.write ? 55 : 105);
  }
}

async function writeBytes(data: Uint8Array): Promise<void> {
  if (Capacitor.isNativePlatform()) {
    if (!nativePrinterRef) throw new Error('not_connected');
    const CHUNK = 20;
    for (let i = 0; i < data.length; i += CHUNK) {
      const slice = data.slice(i, i + CHUNK);
      const dv = new DataView(slice.buffer, slice.byteOffset, slice.byteLength);
      if (nativePrinterRef.writeWithResponse) {
        await BleClient.write(nativePrinterRef.deviceId, nativePrinterRef.serviceUuid, nativePrinterRef.characteristicUuid, dv);
      } else {
        await BleClient.writeWithoutResponse(nativePrinterRef.deviceId, nativePrinterRef.serviceUuid, nativePrinterRef.characteristicUuid, dv);
      }
      await wait(nativePrinterRef.writeWithResponse ? 55 : 105);
    }
    return;
  }

  if (!printerRef?.characteristic) throw new Error('not_connected');
  const candidates = printerRef.characteristics?.length ? printerRef.characteristics : [printerRef.characteristic];
  let lastErr: any;

  for (const ch of candidates) {
    try {
      await writeBytesToCharacteristic(ch, data);
      printerRef.characteristic = ch;
      return;
    } catch (e) {
      lastErr = e;
      console.warn('[printer] write failed on characteristic', ch?.uuid, e);
    }
  }

  throw lastErr || new Error('write_failed');
}

async function writeBytesStrict(data: Uint8Array): Promise<void> {
  if (Capacitor.isNativePlatform()) {
    return writeBytes(data);
  }
  if (!printerRef?.characteristic) throw new Error('not_connected');
  await writeBytesToCharacteristic(printerRef.characteristic, data);
}

export interface ReceiptLine {
  text: string;
  align?: 'left' | 'center' | 'right';
  bold?: boolean;
  double?: boolean;
}

// Width in characters for 58mm printers
const LINE_WIDTH = 32;

function padBetween(left: string, right: string, width = LINE_WIDTH): string {
  if (left.length > width - 2) left = left.slice(0, width - 2);
  if (right.length > width - left.length - 1) right = right.slice(0, width - left.length - 1);
  const space = Math.max(1, width - left.length - right.length);
  return left + ' '.repeat(space) + right;
}

function divider(char = '-'): string {
  return char.repeat(LINE_WIDTH);
}

function escposText(value: string, fallback = ''): string {
  const cleaned = String(value || '')
    .replace(/₹/g, 'Rs ')
    .replace(/[“”]/g, '"')
    .replace(/[‘’]/g, "'")
    .replace(/[^\x20-\x7E\n]/g, '')
    .replace(/\s+/g, ' ')
    .trim();
  return cleaned || fallback;
}

function formatReceiptNumber(value: number | null | undefined, decimals = 2): string {
  if (value == null || Number.isNaN(value)) return '-';
  return Number(value).toFixed(decimals).replace(/\.00$/, '');
}

function row(label: string, value: string | number | null | undefined): string {
  return padBetween(escposText(label), escposText(String(value ?? '-')));
}

type PrintPacket = { data: Uint8Array; delay: number };

function packet(data: Uint8Array, delay = 90): PrintPacket {
  return { data, delay };
}

function textPacket(text: string, delay = 120): PrintPacket {
  return packet(enc.encode(text), delay);
}

export interface MilkReceiptInput {
  dairyName?: string;
  date: string;
  time?: string;
  supplierCode?: string;
  supplierName: string;
  milkType?: string;
  shift: 'morning' | 'evening';
  quantity: number;
  fat?: number | null;
  snf?: number | null;
  lr?: number | null;
  rate: number;
  amount: number;
}

export async function printMilkReceipt(r: MilkReceiptInput): Promise<{ ok: boolean; error?: string }> {
  return enqueuePrint(async () => {
    if (!(await ensureConnected())) return { ok: false, error: 'not_connected' };

    const dairyName = escposText(r.dairyName || '', 'DAIRY').slice(0, 16);
    const supplierName = escposText(r.supplierName, 'Customer').slice(0, 22);
    const total = `Rs ${Math.round(r.amount || 0)}`;

    // Honor user-selected receipt fields from Settings
    let fields: any = {
      showDate: true, showTime: true, showCode: true, showName: true,
      showMilkType: true, showQuantity: true, showFat: true, showSnf: true,
      showLr: true, showRate: true, showAmount: true,
    };
    try {
      const raw = localStorage.getItem('entryReceiptFields');
      if (raw) fields = { ...fields, ...JSON.parse(raw) };
    } catch {}

    const packets: PrintPacket[] = [
      packet(LF, 120),
      packet(INIT, 180),
      packet(DEFAULT_LINE_SPACING, 80),
      packet(CODEPAGE_USA, 80),
      packet(ALIGN_CENTER, 80),
      packet(BOLD_ON, 80),
      textPacket(`${dairyName}\n`, 180),
      packet(BOLD_OFF, 80),
      textPacket('Milk Receipt\n', 140),
      textPacket(`${divider()}\n`, 140),
      packet(ALIGN_LEFT, 80),
      ...(fields.showDate ? [textPacket(`${row('Date', r.date)}\n`)] : []),
      ...(fields.showTime && r.time ? [textPacket(`${row('Time', r.time)}\n`)] : []),
      ...(fields.showCode && r.supplierCode ? [textPacket(`${row('Code', r.supplierCode)}\n`)] : []),
      ...(fields.showName ? [textPacket(`${row('Name', supplierName)}\n`)] : []),
      textPacket(`${row('Shift', r.shift)}\n`),
      ...(fields.showMilkType && r.milkType ? [textPacket(`${row('Type', r.milkType)}\n`)] : []),
      textPacket(`${divider()}\n`, 140),
      ...(fields.showQuantity ? [textPacket(`${row('Qty (L)', formatReceiptNumber(r.quantity, 2))}\n`)] : []),
      ...(fields.showFat && r.fat != null ? [textPacket(`${row('FAT %', formatReceiptNumber(r.fat, 1))}\n`)] : []),
      ...(fields.showSnf && r.snf != null ? [textPacket(`${row('SNF %', formatReceiptNumber(r.snf, 1))}\n`)] : []),
      ...(fields.showLr && r.lr != null ? [textPacket(`${row('CLR', formatReceiptNumber(r.lr, 1))}\n`)] : []),
      ...(fields.showRate ? [textPacket(`${row('Rate', formatReceiptNumber(r.rate, 2))}\n`)] : []),
      textPacket(`${divider('=')}\n`, 150),
      ...(fields.showAmount ? [
        packet(BOLD_ON, 80),
        textPacket(`${padBetween('TOTAL', total)}\n`, 220),
        packet(BOLD_OFF, 80),
        textPacket(`${divider()}\n`, 150),
      ] : []),
      packet(ALIGN_CENTER, 80),
      textPacket('Thank you!\n', 180),
      packet(ALIGN_LEFT, 80),
      packet(FEED_END, 500),
    ];

    try {
      // Use fallback only before the receipt starts. If the real receipt write
      // fails midway, do not resend the full receipt; that creates duplicate or
      // half-overlapped receipts like the broken sample photo.
      try {
        await writeBytes(INIT);
      } catch (preflightError) {
        console.warn('[printer] preflight failed, reconnecting once', preflightError);
        try { printerRef?.device?.gatt?.disconnect(); } catch {}
        if (!(await ensureConnected())) throw preflightError;
        await writeBytes(INIT);
      }

      for (const p of packets) {
        await writeBytesStrict(p.data);
        await wait(p.delay);
      }

      return { ok: true };
    } catch (e: any) {
      return { ok: false, error: e?.message || 'write_failed' };
    }
  });
}

export function getStoredPrinterName(): string | null {
  try { return localStorage.getItem(STORAGE_KEY); } catch { return null; }
}

export function forgetPrinter() {
  if (Capacitor.isNativePlatform()) {
    if (nativePrinterRef) {
      try { BleClient.disconnect(nativePrinterRef.deviceId); } catch {}
    }
    nativePrinterRef = null;
  }
  try {
    if (printerRef?.device?.gatt?.connected) printerRef.device.gatt.disconnect();
  } catch {}
  printerRef = null;
  try {
    localStorage.removeItem(STORAGE_KEY);
    localStorage.removeItem(DEVICE_ID_KEY);
  } catch {}
}

export interface ReportReceiptInput {
  dairyName?: string;
  supplierCode?: string;
  supplierName: string;
  startDate: string;
  endDate: string;
  totalMilk: number;
  avgFat: number;
  totalFat: number;
  totalAmount: number;
  rate: number;
  entries?: Array<{
    date: string;
    morningMilk?: number | null;
    morningFat?: number | null;
    morningSnf?: number | null;
    morningClr?: number | null;
    morningAmount?: number | null;
    eveningMilk?: number | null;
    eveningFat?: number | null;
    eveningSnf?: number | null;
    eveningClr?: number | null;
    eveningAmount?: number | null;
  }>;
}

function shortDay(d: string): string {
  const iso = /^(\d{4})-(\d{2})-(\d{2})/.exec(d);
  if (iso) return `${iso[3]}/${iso[2]}`;
  const dmy = /^(\d{2})[\/\-](\d{2})/.exec(d);
  if (dmy) return `${dmy[1]}/${dmy[2]}`;
  return d.slice(0, 5);
}

function nz(v: number | null | undefined, dec = 1): string {
  if (v == null || Number.isNaN(v) || v === 0) return '-';
  return Number(v).toFixed(dec);
}

export async function printReportReceipt(r: ReportReceiptInput): Promise<{ ok: boolean; error?: string }> {
  return enqueuePrint(async () => {
    if (!(await ensureConnected())) return { ok: false, error: 'not_connected' };

    let fields: any = {
      showCode: true, showName: true, showDates: true,
      showTotalMilk: true, showTotalFat: true, showAvgFat: true,
      showRate: true, showAmount: true, showRakam: true,
      showEntryTable: true, showMorning: true, showEvening: true,
      showMilkCol: true, showFatCol: true, showSnfCol: false, showClrCol: false,
    };
    try {
      const raw = localStorage.getItem('bhugtanReceiptFields');
      if (raw) fields = { ...fields, ...JSON.parse(raw) };
    } catch {}

    const dairyName = escposText(r.dairyName || '', 'DAIRY').slice(0, 20);
    const supplierName = escposText(r.supplierName, 'Customer').slice(0, 22);
    const total = `Rs ${Math.round(r.totalAmount || 0)}`;

    const packets: PrintPacket[] = [
      packet(LF, 120),
      packet(INIT, 180),
      packet(DEFAULT_LINE_SPACING, 80),
      packet(CODEPAGE_USA, 80),
      packet(ALIGN_CENTER, 80),
      packet(BOLD_ON, 80),
      textPacket(`${dairyName}\n`, 180),
      packet(BOLD_OFF, 80),
      textPacket('Payment Report\n', 140),
      textPacket(`${divider()}\n`, 140),
      packet(ALIGN_LEFT, 80),
      ...(fields.showCode && r.supplierCode ? [textPacket(`${row('Code', r.supplierCode)}\n`)] : []),
      ...(fields.showName ? [textPacket(`${row('Name', supplierName)}\n`)] : []),
      ...(fields.showDates ? [
        textPacket(`${row('From', r.startDate)}\n`),
        textPacket(`${row('To', r.endDate)}\n`),
      ] : []),
      textPacket(`${divider()}\n`, 140),
      ...(fields.showTotalMilk ? [textPacket(`${row('Total Milk', formatReceiptNumber(r.totalMilk, 2) + ' L')}\n`)] : []),
      ...(fields.showTotalFat ? [textPacket(`${row('Total FAT', formatReceiptNumber(r.totalFat, 2))}\n`)] : []),
      ...(fields.showAvgFat ? [textPacket(`${row('Avg FAT', formatReceiptNumber(r.avgFat, 2))}\n`)] : []),
      ...(fields.showRate ? [textPacket(`${row('Rate', formatReceiptNumber(r.rate, 2))}\n`)] : []),
      textPacket(`${divider('=')}\n`, 150),
      ...(fields.showAmount || fields.showRakam ? [
        packet(BOLD_ON, 80),
        textPacket(`${padBetween('TOTAL', total)}\n`, 220),
        packet(BOLD_OFF, 80),
        textPacket(`${divider()}\n`, 150),
      ] : []),
      ...((fields.showEntryTable !== false) && r.entries && r.entries.length > 0 ? (() => {
        const showM = fields.showMorning !== false;
        const showE = fields.showEvening !== false;
        const showRakam = fields.showRakam !== false;
        const showMRakam = showRakam && showM && fields.showMorningRakam !== false;
        const showERakam = showRakam && showE && fields.showEveningRakam !== false;
        const cols: Array<{ key: 'milk' | 'fat' | 'snf' | 'clr'; head: string }> = [];
        if (fields.showMilkCol !== false) cols.push({ key: 'milk', head: 'L' });
        if (fields.showFatCol !== false) cols.push({ key: 'fat', head: 'F' });
        if (fields.showSnfCol) cols.push({ key: 'snf', head: 'S' });
        if (fields.showClrCol) cols.push({ key: 'clr', head: 'C' });
        const sorted = [...r.entries!].sort((a, b) => a.date.localeCompare(b.date));
        // Use Font B for the entries table so wider content fits and small
        // Rakam columns (ERs/MRs) never get truncated. Font B ≈ 42 chars wide.
        // Side-by-side is already tight but safe at 39; stacked keeps a larger
        // right margin because several 58mm printers clip the paper edge.
        const SMALL_WIDTH = 39;
        const STACKED_WIDTH = 36;
        const lines: PrintPacket[] = [];
        // Read layout preference: 'stacked' (M and E on separate lines) or
        // 'sidebyside' (M and E on the same row).
        let layout: 'stacked' | 'sidebyside' = 'stacked';
        try {
          const saved = localStorage.getItem('entriesPrintLayout');
          if (saved === 'sidebyside' || saved === 'stacked') layout = saved;
        } catch {}
        lines.push(packet(FONT_B, 80));
        lines.push(packet(new Uint8Array([0x1d, 0x21, 0x00]), 80));
        lines.push(textPacket('Entries\n', 120));
        const amountText = (value: number) => (value > 0 ? Math.round(value).toString() : '-');
        const cellVal = (e: any, shift: 'm' | 'e', key: string) => {
          const map: any = {
            milk: shift === 'm' ? e.morningMilk : e.eveningMilk,
            fat: shift === 'm' ? e.morningFat : e.eveningFat,
            snf: shift === 'm' ? e.morningSnf : e.eveningSnf,
            clr: shift === 'm' ? e.morningClr : e.eveningClr,
          };
          return nz(map[key]).padStart(4);
        };
        let totalM = 0;
        let totalE = 0;

        if (layout === 'sidebyside' && (showM && showE)) {
          // Header: Dt   | M: L F Rs | E: L F Rs
          const colHead = cols.map(c => c.head.padStart(4)).join('');
          const shiftBlockWidth = colHead.length + 5; // + space + Rs(4)
          const dateCol = 'Dt   '; // 5 chars
          const header = dateCol +
            'M' + colHead + (showMRakam ? ' ' + 'Rs'.padStart(4) : '') +
            ' E' + colHead + (showERakam ? ' ' + 'Rs'.padStart(4) : '');
          lines.push(textPacket(header.slice(0, SMALL_WIDTH) + '\n', 100));
          lines.push(textPacket('-'.repeat(SMALL_WIDTH) + '\n', 100));
          for (const e of sorted) {
            const d = shortDay(e.date).padEnd(5, ' ').slice(0, 5);
            const mAmt = e.morningAmount || 0;
            const eAmt = e.eveningAmount || 0;
            totalM += mAmt;
            totalE += eAmt;
            const mVals = cols.map(c => cellVal(e, 'm', c.key)).join('');
            const eVals = cols.map(c => cellVal(e, 'e', c.key)).join('');
            const mRs = showMRakam ? ' ' + amountText(mAmt).padStart(4).slice(-4) : '';
            const eRs = showERakam ? ' ' + amountText(eAmt).padStart(4).slice(-4) : '';
            const line = `${d}M${mVals}${mRs} E${eVals}${eRs}`;
            lines.push(textPacket(line.slice(0, SMALL_WIDTH) + '\n', 80));
          }
        } else {
          // Stacked layout (existing behavior) — one line per shift
          const baseWidth = 7 + (cols.length * 5); // DD/MM + shift + spaced value columns
          const amountWidth = Math.max(6, STACKED_WIDTH - baseWidth - 1);
          const makeShiftLine = (date: string, shift: 'M' | 'E', values: string[], amount?: string) => {
            let line = `${date} ${shift}`;
            for (const value of values) line += ' ' + value.padStart(4).slice(-4);
            if (amount != null) {
              const compactAmount = amount.trim();
              if (compactAmount.length <= amountWidth) line += ' ' + compactAmount.padStart(amountWidth);
            }
            return line.length <= STACKED_WIDTH ? line : line.slice(0, STACKED_WIDTH).trimEnd();
          };
          const makeAmountOverflowLine = (label: string, amount: string) => {
            const prefix = `${label}: `;
            return prefix + amount.slice(0, Math.max(0, STACKED_WIDTH - prefix.length));
          };
          const headerCols = cols.map(c => c.head.padStart(4)).join(' ');
          const header = `Dt    S${headerCols ? ' ' + headerCols : ''} ${'Rs'.padStart(amountWidth)}`;
          lines.push(textPacket(header.slice(0, STACKED_WIDTH) + '\n', 100));
          lines.push(textPacket('-'.repeat(STACKED_WIDTH) + '\n', 100));
          const pushShift = (date: string, shiftLabel: 'M' | 'E', values: string[], rakamLabel: string, amount: string, showAmount: boolean) => {
            const line = makeShiftLine(date, shiftLabel, values, showAmount ? amount : undefined);
            lines.push(textPacket(line + '\n', 80));
            if (showAmount && amount.length > amountWidth) {
              lines.push(textPacket(makeAmountOverflowLine(rakamLabel, amount) + '\n', 80));
            }
          };
          for (const e of sorted) {
            const d = shortDay(e.date).padEnd(5, ' ').slice(0, 5);
            const mAmt = e.morningAmount || 0;
            const eAmt = e.eveningAmount || 0;
            totalM += mAmt;
            totalE += eAmt;
            if (showM) pushShift(d, 'M', cols.map(c => cellVal(e, 'm', c.key)), 'MRs', amountText(mAmt), showMRakam);
            if (showE) pushShift(d, 'E', cols.map(c => cellVal(e, 'e', c.key)), 'ERs', amountText(eAmt), showERakam);
          }
        }

        const tableWidth = layout === 'stacked' ? STACKED_WIDTH : SMALL_WIDTH;
        lines.push(textPacket('-'.repeat(tableWidth) + '\n', 100));
        if (showMRakam || showERakam) {
          if (showMRakam) {
            lines.push(textPacket(`${padBetween('M Total', Math.round(totalM).toString(), tableWidth)}\n`, 100));
          }
          if (showERakam) {
            lines.push(textPacket(`${padBetween('E Total', Math.round(totalE).toString(), tableWidth)}\n`, 100));
          }
          const grand = Math.round(totalM + totalE);
          lines.push(textPacket(`${padBetween('Total Rakam', 'Rs ' + grand, tableWidth)}\n`, 130));
          lines.push(textPacket('-'.repeat(tableWidth) + '\n', 100));
        }
        // Restore default font & size for anything printed after the table.
        lines.push(packet(new Uint8Array([0x1d, 0x21, 0x00]), 80));
        lines.push(packet(FONT_A, 80));
        return lines;
      })() : []),
      packet(ALIGN_CENTER, 80),
      textPacket('Thank you!\n', 180),
      packet(ALIGN_LEFT, 80),
      packet(FEED_END, 500),
    ];

    try {
      try { await writeBytes(INIT); }
      catch (preflightError) {
        try { printerRef?.device?.gatt?.disconnect(); } catch {}
        if (!(await ensureConnected())) throw preflightError;
        await writeBytes(INIT);
      }
      for (const p of packets) {
        await writeBytesStrict(p.data);
        await wait(p.delay);
      }
      return { ok: true };
    } catch (e: any) {
      return { ok: false, error: e?.message || 'write_failed' };
    }
  });
}


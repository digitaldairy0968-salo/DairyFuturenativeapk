import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route, Navigate, useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { checkSubscriptionStatus, readSubscriptionCache } from "@/lib/subscriptionStatus";
import { LanguageProvider } from "@/contexts/LanguageContext";
import { AuthProvider, useAuth } from "@/contexts/AuthContext";
import { DairyProvider } from "@/contexts/DairyContext";
import React, { Suspense, useState, useEffect, lazy } from "react";
import OfflineIndicator from "@/components/OfflineIndicator";
import { toast } from "sonner";
import {
  isNativeApp,
  handleNativeOAuthCallback,
  GOOGLE_OAUTH_PENDING_KEY,
  PENDING_GOOGLE_PROFILE_KEY,
} from "@/lib/googleAuth";

import Index from "./pages/Index";
import Auth from "./pages/Auth";
import DairySetup from "./pages/DairySetup";
import ResetPassword from "./pages/ResetPassword";
import PrivacyPolicy from "./pages/PrivacyPolicy";


// Lazy load all heavy pages
const Dashboard = lazy(() => import("./pages/Dashboard"));
const SupplierDashboard = lazy(() => import("./pages/SupplierDashboard"));
const Suppliers = lazy(() => import("./pages/Suppliers"));
const AddSupplier = lazy(() => import("./pages/AddSupplier"));
const SupplierCard = lazy(() => import("./pages/SupplierCard"));
const SupplierViewCard = lazy(() => import("./pages/SupplierViewCard"));
const MilkEntry = lazy(() => import("./pages/MilkEntry"));
const HisaabReport = lazy(() => import("./pages/HisaabReport"));
const CustomerHistory = lazy(() => import("./pages/CustomerHistory"));
const Calculator = lazy(() => import("./pages/Calculator"));
const Reports = lazy(() => import("./pages/Reports"));
const Settings = lazy(() => import("./pages/Settings"));
const FatSnfRateSetup = lazy(() => import("./pages/FatSnfRateSetup"));
const SupplierSettings = lazy(() => import("./pages/SupplierSettings"));
const AdminDashboard = lazy(() => import("./pages/AdminDashboard"));
const AdminSubscriptions = lazy(() => import("./pages/AdminSubscriptions"));
const AdminDairyFeatures = lazy(() => import("./pages/AdminDairyFeatures"));
const AdminPlans = lazy(() => import("./pages/AdminPlans"));
const PaymentRequired = lazy(() => import("./pages/PaymentRequired"));
const SubscriptionRenewal = lazy(() => import("./pages/SubscriptionRenewal"));
const PayOrder = lazy(() => import("./pages/PayOrder"));
const Checkout = lazy(() => import("./pages/Checkout"));
const MySubscription = lazy(() => import("./pages/MySubscription"));
const AdminPayments = lazy(() => import("./pages/AdminPayments"));
const NotFound = lazy(() => import("./pages/NotFound"));


const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      staleTime: 1000 * 60 * 5, // 5 minutes
      gcTime: 1000 * 60 * 30, // 30 minutes
      refetchOnWindowFocus: false,
      retry: 1,
    },
  },
});

// No loading screen - use cached data for instant access

// Protected Route Component for Admin - with loading check
const AdminRoute = ({ children }: { children: React.ReactNode }) => {
  const { isAuthenticated, user, authUser } = useAuth();
  
  if (authUser && !user) {
    return null; // Don't show spinner, wait silently
  }
  
  if (!isAuthenticated) {
    return <Navigate to="/auth" replace />;
  }
  
  return <>{children}</>;
};

// Protected Route Component for Owner (with subscription check)
// Uses cache-first approach — show content immediately, check in background
const OwnerRoute = ({ children }: { children: React.ReactNode }) => {
  const { isAuthenticated, user, authUser, isAdmin } = useAuth();
  
  // Initialize from cache. If no cache exists (e.g. fresh signup), use 'checking'
  // so we don't briefly render the dashboard before redirecting to /payment-required.
  const [subStatus, setSubStatus] = useState<'active' | 'expired' | 'none' | 'checking'>(() => {
    if (isAdmin) return 'active';
    return readSubscriptionCache() ?? 'checking'; // No cache — verify before rendering
  });

  useEffect(() => {
    let isMounted = true;
    const checkSubscription = async () => {
      if (!user?.dairyId || isAdmin) return;
      const status = await checkSubscriptionStatus(user.dairyId);
      if (!isMounted || !status) return;
      setSubStatus(status);
    };

    // Once per tab session on reopen, plus again whenever the app resumes
    // (screen unlock / tab switch) so an expired user is redirected promptly.
    const sessKey = `sess_sub_check_${user?.dairyId ?? ''}`;
    if (!sessionStorage.getItem(sessKey) || !readSubscriptionCache()) {
      try { sessionStorage.setItem(sessKey, '1'); } catch {}
      checkSubscription();
    }

    const onVisible = () => {
      if (document.visibilityState === 'visible' && navigator.onLine) checkSubscription();
    };
    document.addEventListener('visibilitychange', onVisible);
    return () => {
      isMounted = false;
      document.removeEventListener('visibilitychange', onVisible);
    };
  }, [user?.dairyId, isAdmin]);


  if (authUser && !user) {
    return null; // Don't show spinner
  }

  if (!isAuthenticated) {
    return <Navigate to="/auth" replace />;
  }

  // Wait until we know subscription status before rendering (prevents dashboard flash for new signups)
  if (subStatus === 'checking') {
    return null;
  }

  if (subStatus === 'expired' || subStatus === 'none') {
    return <Navigate to="/payment-required" replace />;
  }

  return <>{children}</>;
};

// Protected Route Component for Supplier
const SupplierRoute = ({ children }: { children: React.ReactNode }) => {
  const { isAuthenticated, user, authUser } = useAuth();

  if (authUser && !user) return null;
  if (!isAuthenticated) return <Navigate to="/auth" replace />;
  return <>{children}</>;
};

// Protected Route for authenticated users (any role)
const ProtectedRoute = ({ children }: { children: React.ReactNode }) => {
  const { isAuthenticated, authUser, user } = useAuth();
  if (authUser && !user) return null;
  if (!isAuthenticated) return <Navigate to="/auth" replace />;
  return <>{children}</>;
};

// Dairy Setup Route - only for users without dairy
const DairySetupRoute = () => {
  const { isAuthenticated, user, isAdmin, refreshProfile, authUser } = useAuth();
  const [hasRefreshed, setHasRefreshed] = useState(false);
  
  useEffect(() => {
    let isMounted = true;
    const refresh = async () => {
      if (isAuthenticated && !hasRefreshed) {
        await refreshProfile();
        if (isMounted) {
          setHasRefreshed(true);
        }
      }
    };
    refresh();
    return () => { isMounted = false; };
  }, [isAuthenticated, hasRefreshed]);
  
  if (authUser && !user) return null;
  
  if (!isAuthenticated) {
    return <Navigate to="/auth" replace />;
  }

  if (isAdmin) {
    return <Navigate to="/admin" replace />;
  }
  
  // If user already has a dairy, redirect to appropriate dashboard
  if (user?.dairyId) {
    if (user.role === 'supplier') {
      return <Navigate to="/supplier-dashboard" replace />;
    }
    return <Navigate to="/dashboard" replace />;
  }
  
  return <DairySetup />;
};

// Smart redirect after login - with loading state
const AuthRedirect = () => {
  const { isAuthenticated, user, authUser, isAdmin } = useAuth();
  
  // Password recovery link (flag is captured in main.tsx before the hash is consumed)
  const hashParams = new URLSearchParams(window.location.hash.substring(1));
  const isRecovery =
    sessionStorage.getItem('pw_recovery') === '1' ||
    hashParams.get('type') === 'recovery';
  if (isRecovery) {
    return <Navigate to="/reset-password" replace />;
  }

  // Check if onboarding steps are pending (rate-setup, owner-onboarding, or Google name/phone step)
  const pendingRateSetup = localStorage.getItem('pending_rate_setup');
  const pendingOnboarding = localStorage.getItem('pending_owner_onboarding');
  const googlePending =
    localStorage.getItem(GOOGLE_OAUTH_PENDING_KEY) === '1' ||
    localStorage.getItem(PENDING_GOOGLE_PROFILE_KEY) === 'true';
  if (pendingRateSetup || pendingOnboarding || googlePending) {
    return <Auth />;
  }
  
  if (authUser && !user) return null;
  if (!isAuthenticated) return <Auth />;

  // Route based on role
  if (isAdmin) {
    return <Navigate to="/admin" replace />;
  }
  
  if (user?.role === 'supplier') {
    return <Navigate to={user.dairyId ? '/supplier-dashboard' : '/dairy-setup'} replace />;
  }
  
  if (user?.role === 'owner') {
    if (!user.dairyId) {
      return <Navigate to="/dairy-setup" replace />;
    }
    return <Navigate to="/dashboard" replace />;
  }
  
  return <Navigate to="/dashboard" replace />;
};

const AppRoutes = () => {
  return (
    <Suspense fallback={null}>
      <Routes>
        <Route path="/" element={<Index />} />
        <Route path="/privacy-policy" element={<PrivacyPolicy />} />
        <Route path="/auth" element={<AuthRedirect />} />

        <Route path="/reset-password" element={<ResetPassword />} />
        <Route path="/dairy-setup" element={<DairySetupRoute />} />
        
        {/* Admin Routes */}
        <Route path="/admin" element={<AdminRoute><AdminDashboard /></AdminRoute>} />
        <Route path="/admin/subscriptions" element={<AdminRoute><AdminSubscriptions /></AdminRoute>} />
        <Route path="/admin/dairy-features/:dairyId" element={<AdminRoute><AdminDairyFeatures /></AdminRoute>} />
        <Route path="/admin/plans" element={<AdminRoute><AdminPlans /></AdminRoute>} />
        <Route path="/admin/payments" element={<AdminRoute><AdminPayments /></AdminRoute>} />
        
        {/* Payment Required Route */}
        <Route path="/payment-required" element={<ProtectedRoute><PaymentRequired /></ProtectedRoute>} />
        <Route path="/checkout/:planId" element={<ProtectedRoute><Checkout /></ProtectedRoute>} />
        <Route path="/pay/:orderId" element={<ProtectedRoute><PayOrder /></ProtectedRoute>} />
        <Route path="/my-subscription" element={<ProtectedRoute><MySubscription /></ProtectedRoute>} />
        <Route path="/subscription-renewal" element={<OwnerRoute><SubscriptionRenewal /></OwnerRoute>} />
        
        {/* Owner Routes */}
        <Route path="/dashboard" element={<OwnerRoute><Dashboard /></OwnerRoute>} />
        <Route path="/suppliers" element={<OwnerRoute><Suppliers /></OwnerRoute>} />
        <Route path="/add-supplier" element={<OwnerRoute><AddSupplier /></OwnerRoute>} />
        <Route path="/supplier/:id" element={<OwnerRoute><SupplierCard /></OwnerRoute>} />
        <Route path="/milk-entry" element={<OwnerRoute><MilkEntry /></OwnerRoute>} />
        <Route path="/reports" element={<OwnerRoute><Reports /></OwnerRoute>} />
        <Route path="/hisaab-report" element={<OwnerRoute><HisaabReport /></OwnerRoute>} />
        <Route path="/customer-history" element={<OwnerRoute><CustomerHistory /></OwnerRoute>} />
        <Route path="/settings" element={<OwnerRoute><Settings /></OwnerRoute>} />
        <Route path="/fat-snf-rate-setup" element={<OwnerRoute><FatSnfRateSetup /></OwnerRoute>} />
        
        {/* Supplier Routes */}
        <Route path="/supplier-dashboard" element={<SupplierRoute><SupplierDashboard /></SupplierRoute>} />
        <Route path="/supplier-view/:id" element={<SupplierRoute><SupplierViewCard /></SupplierRoute>} />
        <Route path="/supplier-settings" element={<SupplierRoute><SupplierSettings /></SupplierRoute>} />
        
        {/* Shared Routes */}
        <Route path="/calculator" element={<ProtectedRoute><Calculator /></ProtectedRoute>} />
        
        <Route path="*" element={<NotFound />} />
      </Routes>
    </Suspense>
  );
};

// Native (Capacitor) only: finish Google OAuth when the system browser deep-links
// back into the app via com.dairyfuture.app://auth
const NativeOAuthListener = () => {
  const navigate = useNavigate();
  useEffect(() => {
    if (!isNativeApp()) return;
    let remove: (() => void) | undefined;
    (async () => {
      try {
        const { App: CapApp } = await import('@capacitor/app');
        const handle = await CapApp.addListener('appUrlOpen', async ({ url }) => {
          const res = await handleNativeOAuthCallback(url);
          if (!res.handled) return;
          if (res.error) {
            toast.error(res.error);
          }
          // Auth page picks up the session and resolves existing vs new Google user
          navigate('/auth', { replace: true });
        });
        remove = () => { handle.remove(); };
      } catch {
        // plugin unavailable — ignore
      }
    })();
    return () => { remove?.(); };
  }, [navigate]);
  return null;
};

const PrinterAutoReconnect = () => {
  useEffect(() => {
    let cancelled = false;
    let retryTimer: number | null = null;
    let attempts = 0;

    const tryReconnect = async (isRetryChain = false) => {
      if (cancelled) return;
      try {
        const mod = await import('@/lib/thermalPrinter');
        if (cancelled) return;
        if (mod.isPrinterReady && mod.isPrinterReady()) {
          attempts = 0;
          return;
        }
        // Only attempt silent reconnect if a printer was previously paired
        if (!mod.isPrinterPaired || !mod.isPrinterPaired()) return;
        const res = await mod.connectThermalPrinter({ silent: true });
        if (!cancelled && !res.ok && isRetryChain && attempts < 6) {
          attempts += 1;
          if (retryTimer) window.clearTimeout(retryTimer);
          retryTimer = window.setTimeout(() => tryReconnect(true), 2500 + attempts * 1000);
        } else if (res.ok) {
          attempts = 0;
        }
      } catch {}
    };

    // Initial attempt after app mounts, then keep retrying in background
    const t = window.setTimeout(() => tryReconnect(true), 600);
    const onVisible = () => {
      if (document.visibilityState === 'visible') {
        attempts = 0;
        tryReconnect(true);
      }
    };
    const onFocus = () => { attempts = 0; tryReconnect(true); };
    document.addEventListener('visibilitychange', onVisible);
    window.addEventListener('focus', onFocus);
    window.addEventListener('online', onFocus);
    return () => {
      cancelled = true;
      window.clearTimeout(t);
      if (retryTimer) window.clearTimeout(retryTimer);
      document.removeEventListener('visibilitychange', onVisible);
      window.removeEventListener('focus', onFocus);
      window.removeEventListener('online', onFocus);
    };
  }, []);
  return null;
};

const App = () => (
  <QueryClientProvider client={queryClient}>
    <LanguageProvider>
      <AuthProvider>
        <DairyProvider>
          <TooltipProvider>
            <Toaster />
            <Sonner />
            <BrowserRouter>
              <OfflineIndicator />
              <PrinterAutoReconnect />
              <NativeOAuthListener />
              <AppRoutes />
            </BrowserRouter>
          </TooltipProvider>
        </DairyProvider>
      </AuthProvider>
    </LanguageProvider>
  </QueryClientProvider>
);

export default App;
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { ArrowLeft } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useLanguage } from '@/contexts/LanguageContext';
import { useSettingsBootstrap } from '@/lib/settingsBootstrap';
import PlanCards, { PlanDuration } from '@/components/PlanCards';
import { HelpVideoMini } from '@/components/HelpVideoWidget';



const SubscriptionRenewal: React.FC = () => {
  const { language } = useLanguage();
  const navigate = useNavigate();
  const [duration, setDuration] = useState<PlanDuration>('monthly');

  // Single bootstrap RPC, cached for the whole tab session (no TTL, no refetch on revisit).
  const { data: boot } = useSettingsBootstrap();
  const varieties = boot?.varieties ?? [];
  const varPlans = boot?.variety_plans ?? [];

  const pickOption = (option: any) => {
    navigate(`/checkout/${option.id}`);
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-background to-muted/30">
      <header className="flex items-center gap-2 px-3 py-3 max-w-md mx-auto">
        <Button variant="ghost" size="icon" onClick={() => navigate('/settings')} className="h-8 w-8 shrink-0" aria-label={language === 'hi' ? 'वापस' : 'Back'}>
          <ArrowLeft className="h-4 w-4" />
        </Button>
        <h1 className="text-lg font-bold text-foreground">
          {language === 'hi' ? 'प्रीमियम प्लान' : 'Premium Plans'}
        </h1>
      </header>

      <main className="px-3 pb-4 max-w-md mx-auto space-y-3">
        <div className="flex justify-end"><HelpVideoMini /></div>

        <div className="text-center">
          <h2 className="text-base font-bold text-foreground">
            {language === 'hi' ? 'अपना प्लान चुनें' : 'Choose Your Plan'}
          </h2>
          <p className="text-[10px] text-muted-foreground">
            {language === 'hi' ? 'अपनी डेयरी के लिए सही प्लान चुनें' : 'Pick the right plan for your dairy'}
          </p>
        </div>

        <PlanCards
          plans={varieties}
          varieties={varPlans}
          onSelect={pickOption}
          hi={language === 'hi'}
          duration={duration}
          onDurationChange={setDuration}
        />

      </main>
    </div>
  );
};

export default SubscriptionRenewal;

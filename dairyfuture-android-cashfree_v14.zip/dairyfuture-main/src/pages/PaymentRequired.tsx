import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { ArrowLeft } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useLanguage } from '@/contexts/LanguageContext';
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';
import { useSettingsBootstrap, loadSettingsBootstrap } from '@/lib/settingsBootstrap';
import { writeSubscriptionCache } from '@/lib/subscriptionStatus';
import PlanCards, { PlanDuration } from '@/components/PlanCards';
import { HelpVideoMini } from '@/components/HelpVideoWidget';



const PaymentRequired: React.FC = () => {
  const { language } = useLanguage();
  const { user, logout, refreshProfile } = useAuth();
  const navigate = useNavigate();

  const [activatingDemo, setActivatingDemo] = useState(false);
  const [duration, setDuration] = useState<PlanDuration>('monthly');

  // Single bootstrap RPC, cached per tab session.
  const { data: boot, loading } = useSettingsBootstrap();
  const varieties = boot?.varieties ?? [];
  const varPlans = boot?.variety_plans ?? [];
  const settings = React.useMemo<any>(
    () => ({ ...(boot?.settings || {}), ...(boot?.contact || {}) }),
    [boot]
  );

  const demoDays = (settings as any)?.demo_days || 9;

  const pickOption = (option: any) => {
    navigate(`/checkout/${option.id}`);
  };

  const activateDemo = async () => {
    if (!user?.dairyId) { toast.error(language === 'hi' ? 'डेयरी नहीं मिली' : 'Dairy not found'); return; }
    setActivatingDemo(true);
    try {
      const { error } = await supabase.rpc('activate_demo_subscription', { _dairy_id: user.dairyId });
      if (error) {
        if (error.message.includes('demo_already_used')) { toast.error(language === 'hi' ? 'डेमो पहले से उपयोग किया जा चुका है' : 'Demo already used'); return; }
        throw error;
      }
      toast.success(language === 'hi' ? `डेमो सक्रिय! ${demoDays} दिन का फ्री एक्सेस।` : `Demo activated! ${demoDays} days free.`);
      writeSubscriptionCache('active');
      await loadSettingsBootstrap(true);
      await refreshProfile();
      navigate('/dashboard');
    } catch { toast.error(language === 'hi' ? 'डेमो विफल' : 'Demo failed'); }
    finally { setActivatingDemo(false); }
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <div className="w-10 h-10 border-4 border-primary border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-background to-muted/30">
      {/* Compact Premium Header */}
      <header className="flex items-center gap-2 px-3 py-3 max-w-md mx-auto">
        <Button variant="ghost" size="icon" onClick={async () => { await logout(); navigate('/auth'); }} className="h-8 w-8 shrink-0" aria-label={language === 'hi' ? 'वापस' : 'Back'}>
          <ArrowLeft className="h-4 w-4" />
        </Button>
        <h1 className="text-lg font-bold text-foreground">
          {language === 'hi' ? 'प्रीमियम प्लान' : 'Premium Plans'}
        </h1>
      </header>

      <main className="px-3 pb-4 max-w-md mx-auto space-y-3">
        <div className="flex justify-end"><HelpVideoMini /></div>

        <div className="text-center">
          <h2 className="text-base font-bold text-foreground">
            {language === 'hi' ? 'अपना प्लान चुनें' : 'Choose Your Plan'}
          </h2>
          <p className="text-[10px] text-muted-foreground">
            {language === 'hi' ? 'अपनी डेयरी के लिए सही प्लान चुनें' : 'Pick the right plan for your dairy'}
          </p>
        </div>

        <PlanCards
          plans={varieties}
          varieties={varPlans}
          onSelect={pickOption}
          hi={language === 'hi'}
          duration={duration}
          onDurationChange={setDuration}
          demo={{ days: demoDays, onStart: activateDemo, loading: activatingDemo }}
        />

      </main>

    </div>
  );
};

export default PaymentRequired;

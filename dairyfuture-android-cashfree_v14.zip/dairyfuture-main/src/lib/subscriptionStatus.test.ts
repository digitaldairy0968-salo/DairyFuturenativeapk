/// <reference types="bun" />
import { describe, it, expect } from 'bun:test';
import { checkedToday, needsCustomerCodeRefresh } from './subscriptionStatus';

describe('subscription check once per day', () => {
  it('skips a second check later the same day', () => {
    expect(checkedToday(new Date(2026, 10, 14, 7, 0).getTime(), new Date(2026, 10, 14, 22, 0).getTime())).toBe(true);
  });
  it('checks again on the next day even if under 24 hours passed', () => {
    expect(checkedToday(new Date(2026, 10, 14, 23, 0).getTime(), new Date(2026, 10, 15, 0, 30).getTime())).toBe(false);
  });
  it('checks when never checked', () => {
    expect(checkedToday(null)).toBe(false);
  });
});

describe('enabled customer code cache repair', () => {
  it('refreshes when the enabled 12-digit code is missing', () => {
    expect(needsCustomerCodeRefresh({ status: 'active', expires_at: null, features: { customer_code: true }, dairy_code: null })).toBe(true);
  });
  it('keeps the daily check schedule when the code is present', () => {
    expect(needsCustomerCodeRefresh({ status: 'active', expires_at: null, features: { customer_code: true }, dairy_code: '123456789012' })).toBe(false);
  });
  it('does not request a code for a disabled feature', () => {
    expect(needsCustomerCodeRefresh({ status: 'active', expires_at: null, features: { customer_code: false }, dairy_code: null })).toBe(false);
  });
});

# Active tasks

8. ~~Supplier daily customer-code check on background reopen: add visibility resume handling and verify same-day/next-day request counts.~~ Done; 12 tests pass, build OK. Authenticated supplier/device verification unavailable on external Supabase.

1. ~~SupplierCard.tsx edit-request branch: remove unnecessary network round-trips.~~ Done.
2. ~~Add PhonePe/GPay/Paytm payment buttons and enlarge the Monthly/Yearly toggle.~~ Done.
3. ~~Remove only the listed legacy UPI gateway code, deployed ingestion function/secret, and database objects.~~ Done; build and signed-out route guards verified. Authenticated checkout verification unavailable on external Supabase.
4. ~~Enlarge the Monthly/Yearly selector further and remove the advance-renewal confirmation popup.~~ Done; payment activation logic unchanged.

5. ~~Fix Cashfree "https://localhost is not enabled" error in the Android app (open checkout on whitelisted website).~~ Done; needs website redeploy + new APK, device test pending.

6. ~~Repair enabled-but-missing dairy customer codes and verify Gurjar's code.~~ Done; Gurjar now has a valid enabled 12-digit code; cache-repair tests pass. Signed-in owner/device verification unavailable on external Supabase.
7. ~~Remove oversized subscription headers and use a compact help-video control so plans appear earlier.~~ Done; build OK. Signed-in phone layout verification unavailable on external Supabase.

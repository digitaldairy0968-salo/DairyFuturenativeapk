/// <reference types="bun" />
import { describe, it, expect, beforeEach } from 'bun:test';
const store = new Map<string, string>();
(globalThis as any).localStorage = {
  getItem: (k: string) => store.get(k) ?? null,
  setItem: (k: string, v: string) => { store.set(k, v); },
  clear: () => store.clear(),
};
import { checkDailySupplierCode, codeCheckedToday, writeDailyCodeCache } from './supplierCodeCheck';

describe('supplier customer-code daily check', () => {
  beforeEach(() => localStorage.clear());
  it('needs a check when never checked', () => {
    expect(codeCheckedToday('d1')).toBe(false);
  });
  it('skips repeat checks the same day', () => {
    writeDailyCodeCache('d1', true);
    expect(codeCheckedToday('d1')).toBe(true);
  });
  it('checks again the next day', () => {
    writeDailyCodeCache('d1', true);
    expect(codeCheckedToday('d1', Date.now() + 86400000)).toBe(false);
  });
  it('calls once on first open, skips same-day resumes, and checks next-day resume', async () => {
    let calls = 0;
    const fetchEnabled = async () => { calls++; return calls === 1; };
    const morning = new Date(2026, 10, 18, 7).getTime();
    const evening = new Date(2026, 10, 18, 23).getTime();
    const tomorrow = new Date(2026, 10, 19, 11).getTime();
    expect(await checkDailySupplierCode('d1', fetchEnabled, morning)).toEqual({ is_enabled: true });
    expect(calls).toBe(1);
    await checkDailySupplierCode('d1', fetchEnabled, evening);
    expect(calls).toBe(1);
    expect(await checkDailySupplierCode('d1', fetchEnabled, tomorrow)).toEqual({ is_enabled: false });
    expect(calls).toBe(2);
  });
  it('does not duplicate simultaneous first-open and resume calls', async () => {
    let calls = 0;
    const fetchEnabled = async () => { calls++; return true; };
    await Promise.all([
      checkDailySupplierCode('d1', fetchEnabled),
      checkDailySupplierCode('d1', fetchEnabled),
    ]);
    expect(calls).toBe(1);
  });
  it('retries a failed request rather than marking the day checked', async () => {
    await expect(checkDailySupplierCode('d1', async () => { throw new Error('offline'); })).rejects.toThrow('offline');
    expect(codeCheckedToday('d1')).toBe(false);
    expect(await checkDailySupplierCode('d1', async () => false)).toEqual({ is_enabled: false });
    expect(codeCheckedToday('d1')).toBe(true);
  });
});

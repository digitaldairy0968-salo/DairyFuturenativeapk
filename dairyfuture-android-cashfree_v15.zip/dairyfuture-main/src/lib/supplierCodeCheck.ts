/** Supplier-side customer_code check: one network call per local calendar day. */
import { checkedToday } from '@/lib/subscriptionStatus';

const KEY = (dairyId: string) => `supplier_code_check_v1_${dairyId}`;

interface Cached { enabled: boolean; at: number }

function read(dairyId?: string | null): Cached | null {
  if (!dairyId) return null;
  try {
    const p = JSON.parse(localStorage.getItem(KEY(dairyId)) || 'null');
    return typeof p?.at === 'number' ? p : null;
  } catch { return null; }
}

export function readDailyCodeCache(dairyId?: string | null): { is_enabled: boolean } | null {
  const c = read(dairyId);
  return c ? { is_enabled: c.enabled } : null;
}

export function codeCheckedToday(dairyId: string, now = Date.now()): boolean {
  return checkedToday(read(dairyId)?.at ?? null, now);
}

export function writeDailyCodeCache(dairyId: string, enabled: boolean, at = Date.now()) {
  try { localStorage.setItem(KEY(dairyId), JSON.stringify({ enabled, at })); } catch { /* quota */ }
}

const pendingChecks = new Map<string, Promise<{ is_enabled: boolean }>>();

/** Reuse today's result and coalesce overlapping mount/resume checks. */
export async function checkDailySupplierCode(
  dairyId: string,
  fetchEnabled: () => Promise<boolean>,
  now = Date.now(),
): Promise<{ is_enabled: boolean }> {
  const cached = readDailyCodeCache(dairyId);
  if (cached && codeCheckedToday(dairyId, now)) return cached;
  const pending = pendingChecks.get(dairyId);
  if (pending) return pending;
  const request = (async () => {
    const enabled = await fetchEnabled();
    writeDailyCodeCache(dairyId, enabled, now);
    return { is_enabled: enabled };
  })();
  pendingChecks.set(dairyId, request);
  try {
    return await request;
  } finally {
    pendingChecks.delete(dairyId);
  }
}

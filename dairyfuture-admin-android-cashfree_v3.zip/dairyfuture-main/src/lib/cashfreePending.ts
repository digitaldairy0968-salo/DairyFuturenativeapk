/**
 * Remembers an in-progress Cashfree order so that, if the app is reloaded
 * while the user is inside their UPI app, we can still confirm the payment
 * on return and send them straight to the dashboard.
 */
import { supabase } from '@/integrations/supabase/client';
import { checkSubscriptionStatus } from '@/lib/subscriptionStatus';

const KEY = 'pending_cf_order';
const MAX_AGE_MS = 30 * 60 * 1000;

export function setPendingOrder(orderRef: string) {
  try { localStorage.setItem(KEY, JSON.stringify({ orderRef, at: Date.now() })); } catch { /* ignore */ }
}

export function clearPendingOrder() {
  try { localStorage.removeItem(KEY); } catch { /* ignore */ }
}

export function readPendingOrder(): string | null {
  try {
    const p = JSON.parse(localStorage.getItem(KEY) || 'null');
    if (!p?.orderRef || Date.now() - Number(p.at) > MAX_AGE_MS) {
      localStorage.removeItem(KEY);
      return null;
    }
    return String(p.orderRef);
  } catch {
    return null;
  }
}

/** Ask the server once; when paid, refresh plan + 12-digit code state. */
export async function verifyOrder(orderRef: string): Promise<string> {
  const r = await supabase.functions.invoke('cashfree-payment', { body: { action: 'verify', order_ref: orderRef } });
  const status = r.data?.status ?? 'created';
  if (status === 'paid') {
    clearPendingOrder();
    // Forced refresh: new subscription expiry + customer_code feature + dairy code.
    await checkSubscriptionStatus(undefined, true);
  }
  return status;
}

import { Capacitor, registerPlugin } from '@capacitor/core';

interface CashfreeNativePlugin {
  pay(options: { sessionId: string; orderId: string; mode: string }): Promise<{ status: 'verify' | 'failed'; message?: string }>;
}

const CashfreeNative = registerPlugin<CashfreeNativePlugin>('CashfreeNative');

/** True when the installed APK contains the Cashfree Android SDK plugin. */
export const hasNativeCashfree = () =>
  Capacitor.isNativePlatform() && Capacitor.isPluginAvailable('CashfreeNative');

/** Runs Cashfree checkout inside the app; resolves when the user finishes or cancels. Server verifies the result. */
export const payWithNativeCashfree = async (sessionId: string, orderId: string, mode: string) => {
  try {
    return await CashfreeNative.pay({ sessionId, orderId, mode: mode === 'production' ? 'production' : 'sandbox' });
  } catch {
    return { status: 'failed' as const };
  }
};

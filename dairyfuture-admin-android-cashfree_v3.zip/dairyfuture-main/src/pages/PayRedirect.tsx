import React, { useEffect, useState } from 'react';
import { useLocation } from 'react-router-dom';
import { CheckCircle2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { PAY_RETURN_DEEPLINK } from '@/lib/payHost';

/**
 * Hosted on the whitelisted website and opened by the native app in a browser tab.
 * /pay?sid=...&mode=...  -> starts Cashfree checkout on this (approved) domain.
 * /pay/done              -> Cashfree return page; sends the user back to the app.
 */
const PayRedirect: React.FC = () => {
  const { pathname, search } = useLocation();
  const done = pathname.startsWith('/pay/done');
  const [failed, setFailed] = useState(false);

  useEffect(() => {
    if (done) {
      // Try to jump straight back into the app.
      window.location.href = PAY_RETURN_DEEPLINK;
      return;
    }
    const q = new URLSearchParams(search);
    const sid = q.get('sid');
    const mode = q.get('mode') === 'production' ? 'production' : 'sandbox';
    if (!sid) { setFailed(true); return; }
    const s = document.createElement('script');
    s.src = 'https://sdk.cashfree.com/js/v3/cashfree.js';
    s.onload = () => {
      try {
        (window as any).Cashfree({ mode }).checkout({ paymentSessionId: sid, redirectTarget: '_self' });
      } catch { setFailed(true); }
    };
    s.onerror = () => setFailed(true);
    document.head.appendChild(s);
  }, [done, search]);

  return (
    <div className="min-h-screen flex items-center justify-center bg-background px-6">
      <div className="max-w-sm w-full text-center space-y-4">
        {done ? (
          <>
            <CheckCircle2 className="h-14 w-14 text-primary mx-auto" />
            <p className="text-lg font-bold text-foreground">पेमेंट प्रोसेस हो गया</p>
            <p className="text-sm text-muted-foreground">ऐप पर वापस जाएँ — आपका प्लान अपने आप चालू हो जाएगा। / Return to the app.</p>
            <Button className="w-full h-12 rounded-2xl" onClick={() => { window.location.href = PAY_RETURN_DEEPLINK; }}>
              ऐप पर वापस जाएँ / Back to app
            </Button>
            <p className="text-xs text-muted-foreground">ऐप न खुले तो ऊपर ✕ या फ़ोन का Back बटन दबाएँ।</p>
          </>
        ) : failed ? (
          <p className="text-sm text-destructive">पेमेंट पेज नहीं खुला। ऐप पर वापस जाकर दोबारा कोशिश करें।</p>
        ) : (
          <>
            <div className="w-10 h-10 border-4 border-primary border-t-transparent rounded-full animate-spin mx-auto" />
            <p className="text-sm text-muted-foreground">पेमेंट पेज खुल रहा है… / Opening payment…</p>
          </>
        )}
      </div>
    </div>
  );
};

export default PayRedirect;

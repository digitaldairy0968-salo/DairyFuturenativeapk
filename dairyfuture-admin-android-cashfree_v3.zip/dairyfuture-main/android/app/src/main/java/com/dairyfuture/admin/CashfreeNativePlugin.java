package com.dairyfuture.admin;

import com.cashfree.pg.api.CFPaymentGatewayService;
import com.cashfree.pg.core.api.CFSession;
import com.cashfree.pg.core.api.callback.CFCheckoutResponseCallback;
import com.cashfree.pg.core.api.utils.CFErrorResponse;
import com.cashfree.pg.core.api.webcheckout.CFWebCheckoutPayment;
import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;

/** Opens Cashfree checkout natively (no website). Payment is confirmed server-side afterwards. */
@CapacitorPlugin(name = "CashfreeNative")
public class CashfreeNativePlugin extends Plugin implements CFCheckoutResponseCallback {
    private PluginCall pending;

    @PluginMethod
    public void pay(PluginCall call) {
        String sessionId = call.getString("sessionId");
        String orderId = call.getString("orderId");
        String mode = call.getString("mode", "sandbox");
        if (sessionId == null || orderId == null) { call.reject("sessionId and orderId required"); return; }
        pending = call;
        getActivity().runOnUiThread(() -> {
            try {
                CFPaymentGatewayService.getInstance().setCheckoutCallback(this);
                CFSession session = new CFSession.CFSessionBuilder()
                        .setEnvironment("production".equals(mode) ? CFSession.Environment.PRODUCTION : CFSession.Environment.SANDBOX)
                        .setPaymentSessionID(sessionId)
                        .setOrderId(orderId)
                        .build();
                CFWebCheckoutPayment payment = new CFWebCheckoutPayment.CFWebCheckoutPaymentBuilder()
                        .setSession(session)
                        .build();
                CFPaymentGatewayService.getInstance().doPayment(getActivity(), payment);
            } catch (Exception e) {
                finish("failed", e.getMessage());
            }
        });
    }

    private void finish(String status, String message) {
        if (pending == null) return;
        JSObject ret = new JSObject();
        ret.put("status", status);
        if (message != null) ret.put("message", message);
        pending.resolve(ret);
        pending = null;
    }

    @Override
    public void onPaymentVerify(String orderID) { finish("verify", null); }

    @Override
    public void onPaymentFailure(CFErrorResponse error, String orderID) {
        finish("failed", error != null ? error.getMessage() : null);
    }
}

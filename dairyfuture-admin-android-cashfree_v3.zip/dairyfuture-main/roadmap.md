# Active tasks

1. ~~SupplierCard.tsx edit-request branch: remove unnecessary network round-trips.~~ Done.
2. ~~Add PhonePe/GPay/Paytm payment buttons and enlarge the Monthly/Yearly toggle.~~ Done.
3. ~~Remove only the listed legacy UPI gateway code, deployed ingestion function/secret, and database objects.~~ Done; build and signed-out route guards verified. Authenticated checkout verification unavailable on external Supabase.
4. ~~Enlarge the Monthly/Yearly selector further and remove the advance-renewal confirmation popup.~~ Done; payment activation logic unchanged.


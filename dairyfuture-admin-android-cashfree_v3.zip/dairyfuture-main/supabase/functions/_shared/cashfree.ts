import { createClient } from 'npm:@supabase/supabase-js@2';

export const cfEnv = () => ((Deno.env.get('CASHFREE_ENV') ?? 'production').toLowerCase().startsWith('prod') ? 'production' : 'sandbox');
export const cfBase = () => (cfEnv() === 'production' ? 'https://api.cashfree.com/pg' : 'https://sandbox.cashfree.com/pg');
export const cfHeaders = () => ({
  'Content-Type': 'application/json',
  'x-api-version': '2023-08-01',
  'x-client-id': Deno.env.get('CASHFREE_APP_ID') ?? '',
  'x-client-secret': Deno.env.get('CASHFREE_SECRET_KEY') ?? '',
});

export const adminClient = () =>
  createClient(Deno.env.get('SUPABASE_URL')!, Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!, { auth: { persistSession: false } });

/** Marks an order paid exactly once and activates the subscription. Returns final status. */
export async function settleOrder(orderRef: string, via: string): Promise<string> {
  const db = adminClient();
  const { data: order } = await db.from('payment_orders').select('id,status,amount').eq('order_ref', orderRef).maybeSingle();
  if (!order) return 'not_found';
  if (order.status === 'paid') return 'paid';

  const res = await fetch(`${cfBase()}/orders/${encodeURIComponent(orderRef)}`, { headers: cfHeaders() });
  const cf = await res.json().catch(() => ({}));
  if (!res.ok) return order.status;
  const cfStatus = String(cf.order_status ?? '');
  if (cfStatus !== 'PAID' || Number(cf.order_amount) !== Number(order.amount)) {
    if (cfStatus === 'EXPIRED' || cfStatus === 'TERMINATED') {
      await db.from('payment_orders').update({ status: 'expired' }).eq('id', order.id).neq('status', 'paid');
      return 'expired';
    }
    return order.status;
  }

  // Atomic claim: only one caller transitions to paid.
  const { data: claimed } = await db
    .from('payment_orders')
    .update({ status: 'paid', verification_method: via })
    .eq('id', order.id)
    .neq('status', 'paid')
    .select('id');
  if (!claimed?.length) return 'paid';

  const { error } = await db.rpc('activate_subscription_from_order', { p_order_id: order.id });
  if (error) {
    console.error('activation failed', error.message);
    await db.from('payment_orders').update({ status: 'activation_failed' }).eq('id', order.id);
    return 'activation_failed';
  }
  await db.from('payment_audit_log').insert({ order_id: order.id, matched_via: via, signal_ids: [] });
  return 'paid';
}

import { settleOrder } from '../_shared/cashfree.ts';

async function validSignature(raw: string, ts: string, sig: string) {
  const key = await crypto.subtle.importKey(
    'raw', new TextEncoder().encode(Deno.env.get('CASHFREE_SECRET_KEY') ?? ''),
    { name: 'HMAC', hash: 'SHA-256' }, false, ['sign'],
  );
  const mac = await crypto.subtle.sign('HMAC', key, new TextEncoder().encode(ts + raw));
  const expected = btoa(String.fromCharCode(...new Uint8Array(mac)));
  return expected === sig;
}

Deno.serve(async (req) => {
  if (req.method !== 'POST') return new Response('ok');
  const raw = await req.text();
  const ts = req.headers.get('x-webhook-timestamp') ?? '';
  const sig = req.headers.get('x-webhook-signature') ?? '';
  if (!ts || !sig || !(await validSignature(raw, ts, sig))) return new Response('bad signature', { status: 401 });

  try {
    const body = JSON.parse(raw);
    const orderRef = body?.data?.order?.order_id;
    // Status is re-fetched from Cashfree inside settleOrder; webhook only triggers it.
    if (orderRef) await settleOrder(String(orderRef), 'cashfree_webhook');
  } catch (e) {
    console.error('webhook error', e);
  }
  return new Response('ok');
});

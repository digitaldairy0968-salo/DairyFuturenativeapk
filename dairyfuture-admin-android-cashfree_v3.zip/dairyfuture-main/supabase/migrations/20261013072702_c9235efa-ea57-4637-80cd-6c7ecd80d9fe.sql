CREATE OR REPLACE FUNCTION public.activate_subscription_from_order(p_order_id uuid)
 RETURNS void
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
DECLARE
  v_order RECORD;
  v_validity integer;
  v_unlocks boolean := false;
  v_cur_expiry timestamptz;
  v_base timestamptz;
  v_period interval;
  v_new_expiry timestamptz;
BEGIN
  SELECT * INTO v_order FROM public.payment_orders WHERE id = p_order_id;
  IF NOT FOUND THEN
    RAISE EXCEPTION 'order_not_found';
  END IF;

  SELECT vp.validity_days, COALESCE(sv.unlocks_customer_code, false)
    INTO v_validity, v_unlocks
  FROM public.variety_plans vp
  LEFT JOIN public.subscription_varieties sv ON sv.id = vp.variety_id
  WHERE vp.id = v_order.variety_plan_id;

  IF v_validity IS NULL THEN
    RAISE EXCEPTION 'plan_not_found';
  END IF;

  -- Calendar-based period: yearly → same date next year, monthly → same date next month.
  IF v_validity >= 365 THEN
    v_period := make_interval(years => GREATEST(1, round(v_validity / 365.0)::int));
  ELSIF v_validity >= 28 THEN
    v_period := make_interval(months => GREATEST(1, round(v_validity / 30.0)::int));
  ELSE
    v_period := make_interval(days => v_validity);
  END IF;

  -- Advance renewal: extend from the current expiry if still active.
  SELECT expires_at INTO v_cur_expiry
  FROM public.subscriptions
  WHERE dairy_id = v_order.dairy_id AND status = 'active';

  v_base := GREATEST(now(), COALESCE(v_cur_expiry, now()));
  v_new_expiry := v_base + v_period;

  INSERT INTO public.subscriptions (dairy_id, status, started_at, expires_at, variety_plan_id)
  VALUES (v_order.dairy_id, 'active', now(), v_new_expiry, v_order.variety_plan_id)
  ON CONFLICT (dairy_id) DO UPDATE
    SET status = 'active',
        started_at = CASE WHEN v_cur_expiry IS NOT NULL AND v_cur_expiry > now()
                          THEN public.subscriptions.started_at ELSE now() END,
        expires_at = v_new_expiry,
        variety_plan_id = v_order.variety_plan_id,
        updated_at = now();

  INSERT INTO public.dairy_features (dairy_id, feature_key, is_enabled)
  VALUES (v_order.dairy_id, 'customer_code', v_unlocks)
  ON CONFLICT (dairy_id, feature_key) DO UPDATE
    SET is_enabled = v_unlocks, updated_at = now();
END;
$function$;
DO $$
DECLARE f text;
BEGIN
  -- Backend/internal only: nobody from the app may call directly
  FOREACH f IN ARRAY ARRAY[
    'public.activate_subscription_from_order(uuid)',
    'public.expire_customer_code(uuid)',
    'public.admin_revoke_subscription(uuid,uuid)',
    'public.purchase_plan_with_coins(uuid,uuid)',
    'public.apply_referral_reward(uuid)',
    'public.get_dairy_by_code(text)',
    'public.handle_new_user()',
    'public.apply_approved_edit_request()',
    'public.auto_create_dairy_defaults()',
    'public.track_referral()',
    'public.rls_auto_enable()'
  ] LOOP
    EXECUTE format('REVOKE EXECUTE ON FUNCTION %s FROM PUBLIC, anon, authenticated', f);
    EXECUTE format('GRANT EXECUTE ON FUNCTION %s TO service_role', f);
  END LOOP;

  -- Signed-in only (no anonymous access)
  FOREACH f IN ARRAY ARRAY[
    'public.activate_demo_subscription(uuid)',
    'public.admin_save_subscription_settings(jsonb)',
    'public.check_dairy_code_exists(text)',
    'public.complete_google_signup(text,text,text)',
    'public.confirm_supplier_payment(uuid)',
    'public.confirm_supplier_payment(uuid,boolean)',
    'public.get_admin_payment_contact()',
    'public.get_app_bootstrap()',
    'public.get_auth_bootstrap()',
    'public.get_dairy_config_bootstrap()',
    'public.get_reopen_status()',
    'public.get_settings_bootstrap()',
    'public.get_subscription_settings_admin()',
    'public.link_supplier_to_dairy_by_code(text)',
    'public.phone_exists(text)',
    'public.has_role(uuid,app_role)',
    'public.is_admin(uuid)',
    'public.get_user_dairy_id(uuid)',
    'public.get_supplier_dairy_id(uuid)'
  ] LOOP
    EXECUTE format('REVOKE EXECUTE ON FUNCTION %s FROM PUBLIC, anon', f);
    EXECUTE format('GRANT EXECUTE ON FUNCTION %s TO authenticated, service_role', f);
  END LOOP;
END $$;
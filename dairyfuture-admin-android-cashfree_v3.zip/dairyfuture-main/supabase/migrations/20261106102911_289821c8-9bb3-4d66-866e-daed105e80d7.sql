ALTER TABLE public.dairy_features ADD COLUMN IF NOT EXISTS expires_at timestamptz;

CREATE OR REPLACE FUNCTION public.activate_subscription_from_order(p_order_id uuid)
 RETURNS void LANGUAGE plpgsql SECURITY DEFINER SET search_path TO 'public'
AS $function$
DECLARE
  v_order RECORD; v_validity integer; v_unlocks boolean := false;
  v_cur_expiry timestamptz; v_period interval; v_new_expiry timestamptz;
  v_code_exp timestamptz; v_code_on boolean;
BEGIN
  SELECT * INTO v_order FROM public.payment_orders WHERE id = p_order_id;
  IF NOT FOUND THEN RAISE EXCEPTION 'order_not_found'; END IF;

  SELECT vp.validity_days, COALESCE(sv.unlocks_customer_code, false) INTO v_validity, v_unlocks
  FROM public.variety_plans vp LEFT JOIN public.subscription_varieties sv ON sv.id = vp.variety_id
  WHERE vp.id = v_order.variety_plan_id;
  IF v_validity IS NULL THEN RAISE EXCEPTION 'plan_not_found'; END IF;

  IF v_validity >= 365 THEN v_period := make_interval(years => GREATEST(1, round(v_validity / 365.0)::int));
  ELSIF v_validity >= 28 THEN v_period := make_interval(months => GREATEST(1, round(v_validity / 30.0)::int));
  ELSE v_period := make_interval(days => v_validity); END IF;

  SELECT expires_at INTO v_cur_expiry FROM public.subscriptions
  WHERE dairy_id = v_order.dairy_id AND status = 'active';
  v_new_expiry := GREATEST(now(), COALESCE(v_cur_expiry, now())) + v_period;

  INSERT INTO public.subscriptions (dairy_id, status, started_at, expires_at, variety_plan_id)
  VALUES (v_order.dairy_id, 'active', now(), v_new_expiry, v_order.variety_plan_id)
  ON CONFLICT (dairy_id) DO UPDATE
    SET status = 'active',
        started_at = CASE WHEN v_cur_expiry IS NOT NULL AND v_cur_expiry > now()
                          THEN public.subscriptions.started_at ELSE now() END,
        expires_at = v_new_expiry, variety_plan_id = v_order.variety_plan_id, updated_at = now();

  -- 12-digit code has its own expiry; a plan without code never extends it.
  IF v_unlocks THEN
    SELECT is_enabled, expires_at INTO v_code_on, v_code_exp FROM public.dairy_features
    WHERE dairy_id = v_order.dairy_id AND feature_key = 'customer_code';
    IF NOT COALESCE(v_code_on, false) OR v_code_exp IS NULL OR v_code_exp < now() THEN
      v_code_exp := now();
    END IF;
    INSERT INTO public.dairy_features (dairy_id, feature_key, is_enabled, expires_at)
    VALUES (v_order.dairy_id, 'customer_code', true, v_code_exp + v_period)
    ON CONFLICT (dairy_id, feature_key) DO UPDATE
      SET is_enabled = true, expires_at = v_code_exp + v_period, updated_at = now();
  END IF;
END;
$function$;

CREATE OR REPLACE FUNCTION public.expire_customer_code(_dairy_id uuid)
 RETURNS void LANGUAGE sql SECURITY DEFINER SET search_path TO 'public'
AS $$
  UPDATE public.dairy_features SET is_enabled = false, updated_at = now()
  WHERE dairy_id = _dairy_id AND feature_key = 'customer_code'
    AND is_enabled = true AND expires_at IS NOT NULL AND expires_at < now();
$$;
REVOKE ALL ON FUNCTION public.expire_customer_code(uuid) FROM PUBLIC, anon, authenticated;

CREATE OR REPLACE FUNCTION public.get_reopen_status()
 RETURNS jsonb LANGUAGE plpgsql SECURITY DEFINER SET search_path TO 'public'
AS $function$
DECLARE
  v_uid uuid := auth.uid(); v_dairy_id uuid; v_code text;
  v_features jsonb := '{}'::jsonb; v_sub jsonb; v_code_enabled boolean := false;
BEGIN
  IF v_uid IS NULL THEN RETURN NULL; END IF;
  SELECT d.id, d.code INTO v_dairy_id, v_code FROM public.dairies d WHERE d.owner_id = v_uid LIMIT 1;
  IF v_dairy_id IS NULL THEN
    SELECT s.dairy_id INTO v_dairy_id FROM public.suppliers s WHERE s.user_id = v_uid ORDER BY s.created_at DESC LIMIT 1;
    IF v_dairy_id IS NOT NULL THEN SELECT d.code INTO v_code FROM public.dairies d WHERE d.id = v_dairy_id; END IF;
  END IF;
  IF v_dairy_id IS NULL THEN RETURN NULL; END IF;

  PERFORM public.expire_customer_code(v_dairy_id);

  SELECT COALESCE(jsonb_object_agg(f.feature_key, f.is_enabled), '{}'::jsonb) INTO v_features
  FROM public.dairy_features f WHERE f.dairy_id = v_dairy_id;
  v_code_enabled := COALESCE((v_features->>'customer_code')::boolean, false);

  SELECT jsonb_build_object('status', s.status, 'expires_at', s.expires_at) INTO v_sub
  FROM public.subscriptions s WHERE s.dairy_id = v_dairy_id
  ORDER BY (s.status = 'active') DESC, s.created_at DESC LIMIT 1;

  RETURN jsonb_build_object('dairy_id', v_dairy_id, 'subscription', v_sub, 'features', v_features,
    'dairy_code', CASE WHEN v_code_enabled THEN v_code ELSE NULL END);
END;
$function$;

CREATE OR REPLACE FUNCTION public.link_supplier_to_dairy_by_code(_dairy_code text)
 RETURNS TABLE(linked boolean, error_code text) LANGUAGE plpgsql SECURITY DEFINER SET search_path TO 'public'
AS $function$
DECLARE
  v_user_id uuid := auth.uid(); v_profile_phone text; v_profile_name text; v_user_phone_10 text;
  v_dairy_id uuid; v_supplier_id uuid; v_supplier_user_id uuid; v_feature_enabled boolean;
BEGIN
  IF v_user_id IS NULL THEN RETURN QUERY SELECT false, 'not_authenticated'; RETURN; END IF;
  IF NOT public.has_role(v_user_id, 'supplier'::public.app_role) THEN RETURN QUERY SELECT false, 'not_supplier'; RETURN; END IF;
  IF _dairy_code IS NULL OR _dairy_code !~ '^\d{12}$' THEN RETURN QUERY SELECT false, 'invalid_code'; RETURN; END IF;

  SELECT p.phone, p.name INTO v_profile_phone, v_profile_name FROM public.profiles p WHERE p.user_id = v_user_id LIMIT 1;
  v_user_phone_10 := RIGHT(regexp_replace(COALESCE(v_profile_phone, ''), '\D', '', 'g'), 10);
  IF length(v_user_phone_10) <> 10 THEN RETURN QUERY SELECT false, 'phone_missing'; RETURN; END IF;

  SELECT d.id INTO v_dairy_id FROM public.dairies d WHERE d.code = _dairy_code LIMIT 1;
  IF v_dairy_id IS NULL THEN RETURN QUERY SELECT false, 'invalid_code'; RETURN; END IF;

  PERFORM public.expire_customer_code(v_dairy_id);
  SELECT COALESCE(df.is_enabled, false) INTO v_feature_enabled FROM public.dairy_features df
  WHERE df.dairy_id = v_dairy_id AND df.feature_key = 'customer_code';
  IF v_feature_enabled IS NULL OR v_feature_enabled = false THEN RETURN QUERY SELECT false, 'code_disabled'; RETURN; END IF;

  IF EXISTS (SELECT 1 FROM public.suppliers s WHERE s.dairy_id = v_dairy_id AND s.user_id = v_user_id) THEN
    RETURN QUERY SELECT true, NULL::text; RETURN;
  END IF;

  SELECT s.id, s.user_id INTO v_supplier_id, v_supplier_user_id FROM public.suppliers s
  WHERE s.dairy_id = v_dairy_id AND RIGHT(regexp_replace(COALESCE(s.phone, ''), '\D', '', 'g'), 10) = v_user_phone_10
  ORDER BY s.created_at DESC LIMIT 1;

  IF v_supplier_id IS NULL THEN
    BEGIN
      INSERT INTO public.suppliers (dairy_id, name, phone, user_id)
      VALUES (v_dairy_id, COALESCE(NULLIF(v_profile_name, ''), 'नया सप्लायर'), v_user_phone_10, v_user_id)
      RETURNING id INTO v_supplier_id;
    EXCEPTION WHEN OTHERS THEN RETURN QUERY SELECT false, 'phone_not_found'; RETURN; END;
    RETURN QUERY SELECT true, NULL::text; RETURN;
  END IF;

  IF v_supplier_user_id IS NOT NULL AND v_supplier_user_id <> v_user_id THEN
    RETURN QUERY SELECT false, 'already_linked_other'; RETURN;
  END IF;
  UPDATE public.suppliers SET user_id = v_user_id, updated_at = now() WHERE id = v_supplier_id;
  RETURN QUERY SELECT true, NULL::text;
END;
$function$;

-- Backfill: existing enabled codes follow the current subscription expiry.
UPDATE public.dairy_features f SET expires_at = s.expires_at
FROM public.subscriptions s
WHERE f.dairy_id = s.dairy_id AND f.feature_key = 'customer_code' AND f.is_enabled = true
  AND f.expires_at IS NULL AND s.status = 'active' AND s.variety_plan_id IS NOT NULL;
/// <reference types="bun" />
import { describe, expect, test } from 'bun:test';
import { calculateSupplierStats } from './supplierCalculation';
import { defaultFatSnfSettings } from './fatSnfCalculation';

const emptyShift = {
  morningMilk: null, morningFat: null, morningSNF: null, morningPrice: null,
  eveningMilk: null, eveningFat: null, eveningSNF: null, eveningPrice: null,
};
const octoberEntries = [
  { ...emptyShift, date: '2026-10-03', eveningMilk: 5, eveningFat: 6 },
  { ...emptyShift, date: '2026-10-04', morningMilk: 5, morningFat: 6 },
  { ...emptyShift, date: '2026-10-09', eveningMilk: 12, eveningFat: 3 },
];
const params = {
  entries: octoberEntries,
  startDate: '2026-10-01', endDate: '2026-10-31',
  shiftFilter: 'both' as const,
  rate: 9, calculationMethod: 'daily_total',
  fatSnfSettings: { ...defaultFatSnfSettings, isEnabled: true, baseFatRate: 9 },
};

describe('supplier amount calculation', () => {
  test('October daily total is ₹864 for 22 liters when legacy prices and SNF are missing', () => {
    const stats = calculateSupplierStats(params);
    expect(stats.totalAmount).toBe(864);
    expect(stats.totalMilk).toBe(22);
    expect(stats.avgFat).toBe(5);
  });

  test('both shifts use the fallback and honor the selected date range', () => {
    expect(calculateSupplierStats({ ...params, shiftFilter: 'morning' }).totalAmount).toBe(270);
    expect(calculateSupplierStats({ ...params, shiftFilter: 'evening' }).totalAmount).toBe(594);
    expect(calculateSupplierStats({ ...params, endDate: '2026-10-04' }).totalAmount).toBe(540);
  });

  test('missing prices with SNF use the existing SNF deduction formula', () => {
    const entries = [{ ...emptyShift, date: '2026-10-04', morningMilk: 5, morningFat: 6, morningSNF: 9.4 }];
    expect(calculateSupplierStats({ ...params, entries }).totalAmount).toBe(269);
  });

  test('saved prices are preserved, including an explicit zero', () => {
    const entries = [
      { ...octoberEntries[0], eveningPrice: 250 },
      { ...octoberEntries[1], morningPrice: 0 },
    ];
    expect(calculateSupplierStats({ ...params, entries }).totalAmount).toBe(250);
  });

  test('plain FAT average and daily-total methods remain distinct', () => {
    const fatSnfSettings = { ...params.fatSnfSettings, isEnabled: false };
    expect(calculateSupplierStats({ ...params, fatSnfSettings }).totalAmount).toBe(864);
    expect(calculateSupplierStats({ ...params, fatSnfSettings, calculationMethod: 'avg_fat' }).totalAmount).toBe(990);
  });

  test('buyer amounts still use liters instead of FAT or SNF', () => {
    expect(calculateSupplierStats({ ...params, animalType: 'buyer', literRate: 50 }).totalAmount).toBe(1100);
  });
});
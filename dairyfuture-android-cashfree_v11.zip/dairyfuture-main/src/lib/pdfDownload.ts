import { Capacitor, registerPlugin } from '@capacitor/core';
import { Filesystem, Directory } from '@capacitor/filesystem';
import { Share } from '@capacitor/share';
import { toast } from 'sonner';
import type jsPDF from 'jspdf';

const DownloadsSaver = registerPlugin<{ savePdf(o: { filename: string; base64: string }): Promise<{ location: string }> }>('DownloadsSaver');

const safeName = (name: string) =>
  name.replace(/[^a-zA-Z0-9._-]+/g, '_').replace(/_+/g, '_') || 'report.pdf';

/** Website: normal browser download. App: save to phone, then open the share/view menu. */
export async function downloadPdf(doc: jsPDF, filename: string) {
  const name = safeName(filename);
  if (!Capacitor.isNativePlatform()) {
    const url = URL.createObjectURL(doc.output('blob'));
    const a = document.createElement('a');
    a.href = url; a.download = name;
    document.body.appendChild(a); a.click(); a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 30_000);
    return;
  }
  const base64 = doc.output('datauristring').split(',')[1];
  try {
    if (Capacitor.isPluginAvailable('DownloadsSaver')) {
      await DownloadsSaver.savePdf({ filename: name, base64 });
      toast.success(`PDF Downloads में सेव हो गई: ${name}`);
    }
    const file = await Filesystem.writeFile({ path: name, data: base64, directory: Directory.Cache });
    if (!Capacitor.isPluginAvailable('DownloadsSaver')) toast.success('PDF तैयार है');
    await Share.share({ title: name, url: file.uri, dialogTitle: 'PDF खोलें / भेजें' });
  } catch (e: any) {
    if (String(e?.message || e).toLowerCase().includes('cancel')) return;
    console.error('PDF save failed', e);
    toast.error('PDF सेव नहीं हो पाई');
  }
}

- Native app runs Cashfree checkout on the whitelisted website (`/pay` page opened via @capacitor/browser), never inside the WebView — Cashfree rejects the WebView's https://localhost origin.

- Native app always pays on the website `/pay` page (www.dairyfuture.com) — Cashfree's Android SDK blocks sideloaded (non-Play-Store) APKs in production, so the in-app SDK plugin is unused.

- Keep date-range supplier amounts in the shared supplier calculation utility; missing Fat/SNF prices must use the existing SNF formula when SNF is present or the selected FAT rate otherwise, so payment and report totals agree for legacy entries.
- Native app PDF: use src/lib/pdfDownload.ts (Filesystem + Share sheet) for every PDF export; WebView ignores anchor downloads.

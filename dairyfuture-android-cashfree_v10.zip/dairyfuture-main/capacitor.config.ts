import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.dairyfuture.app',
  appName: 'DairyFuture',
  webDir: 'dist',
  server: {
    // Cashfree checkout (payment page / UPI return) must stay inside the app WebView
    allowNavigation: ['*.cashfree.com'],
  },
  plugins: {
    SplashScreen: {
      launchShowDuration: 2000,
      backgroundColor: '#2d7a4f',
      showSpinner: false,
    },
  },
  android: {
    // Microphone permission for voice entry
    // These are also declared in AndroidManifest.xml
  },
};

export default config;

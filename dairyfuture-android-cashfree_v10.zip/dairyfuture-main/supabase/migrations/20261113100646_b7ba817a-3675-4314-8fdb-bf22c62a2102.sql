DROP POLICY IF EXISTS "Dairy owners can insert subscription" ON public.subscriptions;
DROP POLICY IF EXISTS "Dairy owners can update own subscription" ON public.subscriptions;
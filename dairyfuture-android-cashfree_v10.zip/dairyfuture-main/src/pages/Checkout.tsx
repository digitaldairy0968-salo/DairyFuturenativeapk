import React, { useEffect, useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { ArrowLeft, Wallet } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useLanguage } from '@/contexts/LanguageContext';
import { useSettingsBootstrap } from '@/lib/settingsBootstrap';
import { durationLabel } from '@/components/PlanCards';
import { toast } from 'sonner';
import { setPendingOrder, verifyOrder } from '@/lib/cashfreePending';

import { supabase } from '@/integrations/supabase/client';
import { isNativeApp } from '@/lib/googleAuth';
import { PAY_HOST } from '@/lib/payHost';

let sdkPromise: Promise<void> | null = null;
const loadSdk = () => {
  if ((window as any).Cashfree) return Promise.resolve();
  sdkPromise ??= new Promise<void>((resolve, reject) => {
      const s = document.createElement('script');
      s.src = 'https://sdk.cashfree.com/js/v3/cashfree.js';
      s.onload = () => resolve();
      s.onerror = () => { sdkPromise = null; reject(new Error('sdk')); };
      document.head.appendChild(s);
    });
  return sdkPromise;
};
const loadCashfree = async (mode: string) => {
  await loadSdk();
  return (window as any).Cashfree({ mode: mode === 'production' ? 'production' : 'sandbox' });
};

/** Native only: open checkout on the whitelisted website; resolves when the user is back in the app. */
const openHostedCheckout = async (sessionId: string, mode: string) => {
  const [{ Browser }, { App: CapApp }] = await Promise.all([
    import('@capacitor/browser'),
    import('@capacitor/app'),
  ]);
  const url = `${PAY_HOST}/pay?sid=${encodeURIComponent(sessionId)}&mode=${mode === 'production' ? 'production' : 'sandbox'}`;
  await new Promise<void>((resolve) => {
    const handles: Array<{ remove: () => void }> = [];
    let finished = false;
    const finish = () => {
      if (finished) return;
      finished = true;
      handles.forEach((h) => h.remove());
      resolve();
    };
    Promise.all([
      Browser.addListener('browserFinished', finish),
      CapApp.addListener('resume', finish),
    ]).then((hs) => {
      handles.push(...hs);
      if (finished) hs.forEach((h) => h.remove());
      return Browser.open({ url, toolbarColor: '#0DA2E7' });
    }).catch(finish);
  });
};

/** Step 2 of the purchase flow: plan summary + a single Pay button. */
const Checkout: React.FC = () => {
  const { planId } = useParams<{ planId: string }>();
  const { language } = useLanguage();
  const hi = language === 'hi';
  const navigate = useNavigate();
  const { data: boot } = useSettingsBootstrap();
  const [loadingPay, setLoadingPay] = useState(false);

  // Preload the Cashfree SDK as soon as the page opens so Pay opens instantly.
  useEffect(() => {
    if (isNativeApp()) {
      // Warm up the browser plugin so the website opens instantly on Pay.
      import('@capacitor/browser').catch(() => {});
      import('@capacitor/app').catch(() => {});
    } else {
      loadSdk().catch(() => {});
    }
  }, []);

  const option = (boot?.variety_plans ?? []).find((v: any) => v.id === planId) ?? null;
  const plan = (boot?.varieties ?? []).find((p: any) => p.id === option?.variety_id) ?? null;

  const [phone, setPhone] = useState('');
  const [needPhone, setNeedPhone] = useState(false);

  const pay = async () => {
    if (!option) return;
    if (needPhone && !/^[6-9]\d{9}$/.test(phone)) {
      toast.error(hi ? 'सही 10 अंकों का मोबाइल नंबर डालें' : 'Enter a valid 10-digit mobile number');
      return;
    }
    setLoadingPay(true);
    try {
      // Advance renewal is handled server-side; proceed without a confirmation popup.
      // Create the order and finish loading the SDK in parallel.
      const native = isNativeApp();
      const [{ data, error }] = await Promise.all([
        supabase.functions.invoke('cashfree-payment', { body: { action: 'create', plan_id: option.id, native, native_sdk: false, ...(needPhone ? { phone } : {}) } }),
        native ? Promise.resolve() : loadSdk().catch(() => {}),
      ]);
      if (data?.error === 'need_phone') {
        setNeedPhone(true);
        toast(hi ? 'पेमेंट के लिए अपना मोबाइल नंबर डालें' : 'Enter your mobile number to pay');
        return;
      }
      if (error || !data?.payment_session_id) throw new Error(data?.message || 'create failed');
      setPendingOrder(data.order_ref);
      if (native) {
        // App: Cashfree blocks the in-app SDK for non-Play-Store installs and rejects the WebView origin,
        // so checkout always runs on the approved website in a browser tab; wait until the user is back.
        await openHostedCheckout(data.payment_session_id, data.mode);
      } else {
        const cashfree = await loadCashfree(data.mode);
        await cashfree.checkout({ paymentSessionId: data.payment_session_id, redirectTarget: '_modal' });
      }
      // Checkout closed: confirm right away, then retry quickly a few times.
      let status = 'created';
      for (let i = 0; i < 10 && status !== 'paid'; i++) {
        status = await verifyOrder(data.order_ref);
        if (status !== 'paid') await new Promise((res) => setTimeout(res, 1500));
      }
      if (status === 'paid') {
        toast.success(hi ? 'पेमेंट सफल! प्लान चालू हो गया' : 'Payment successful! Plan activated');
        navigate('/dashboard', { replace: true });
      } else {
        toast.error(hi ? 'पेमेंट पूरा नहीं हुआ' : 'Payment not completed');
      }
    } catch (e: any) {
      toast.error(hi ? 'कुछ गलत हुआ, दोबारा कोशिश करें' : 'Something went wrong, please try again');
    } finally {
      setLoadingPay(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-background to-muted/30">
      <div className="bg-gradient-to-br from-primary via-primary/90 to-accent/80 px-4 py-5">
        <div className="flex items-center gap-3">
          <Button variant="ghost" size="icon" onClick={() => navigate(-1)} className="text-primary-foreground hover:bg-primary-foreground/20">
            <ArrowLeft className="h-5 w-5" />
          </Button>
          <h1 className="text-xl font-bold text-primary-foreground">
            {hi ? 'भुगतान' : 'Payment'}
          </h1>
        </div>
      </div>

      <main className="px-4 py-6 max-w-md mx-auto space-y-4">
        {!option ? (
          <p className="text-center text-sm text-muted-foreground py-10">
            {hi ? 'प्लान नहीं मिला' : 'Plan not found'}
          </p>
        ) : (
          <>
            <div className="bg-card rounded-3xl border-2 border-primary/30 p-5">
              <p className="text-xs text-muted-foreground mb-1">{hi ? 'चुना हुआ प्लान' : 'Selected plan'}</p>
              <div className="flex items-center justify-between">
                <div>
                  <p className="font-bold text-lg text-foreground">{plan?.name ?? '-'}</p>
                  <p className="text-sm text-muted-foreground">
                    {durationLabel(Number(option.validity_days) || 0, hi)}
                  </p>
                </div>
                <p className="text-3xl font-black text-primary">₹{option.price}</p>
              </div>
            </div>

            {needPhone && (
              <input
                type="tel"
                inputMode="numeric"
                maxLength={10}
                value={phone}
                onChange={(e) => setPhone(e.target.value.replace(/\D/g, '').slice(0, 10))}
                placeholder={hi ? 'मोबाइल नंबर (10 अंक)' : 'Mobile number (10 digits)'}
                className="w-full h-12 rounded-md border border-input bg-background px-3 text-base mb-3"
              />
            )}
            <Button
              onClick={() => pay()}
              disabled={loadingPay}
              className="w-full gap-2 h-14 rounded-2xl text-lg font-bold bg-gradient-to-r from-primary to-accent shadow-glow"
            >
              {loadingPay
                ? <div className="w-5 h-5 border-2 border-primary-foreground border-t-transparent rounded-full animate-spin" />
                : <><Wallet className="h-5 w-5" />{hi ? `पेमेंट करें ₹${option.price}` : `Pay Now ₹${option.price}`}</>}
            </Button>
          </>
        )}
      </main>
    </div>
  );
};

export default Checkout;

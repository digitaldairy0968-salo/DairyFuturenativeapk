/**
 * Public website domain approved in Cashfree whitelisting.
 * The native app cannot run Cashfree checkout inside its WebView
 * (origin https://localhost is rejected), so it opens checkout on this site.
 */
export const PAY_HOST = 'https://www.dairyfuture.com';
/** Deep link the hosted "payment done" page uses to bring the user back to the app. */
export const PAY_RETURN_DEEPLINK = 'com.dairyfuture.app://payment-done';

- Native app runs Cashfree checkout on the whitelisted website (`/pay` page opened via @capacitor/browser), never inside the WebView — Cashfree rejects the WebView's https://localhost origin.

- Native app always pays on the website `/pay` page (www.dairyfuture.com) — Cashfree's Android SDK blocks sideloaded (non-Play-Store) APKs in production, so the in-app SDK plugin is unused.

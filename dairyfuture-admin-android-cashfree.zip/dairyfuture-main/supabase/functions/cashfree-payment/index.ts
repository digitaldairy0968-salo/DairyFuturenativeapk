import { corsHeaders } from 'npm:@supabase/supabase-js@2/cors';
import { createClient } from 'npm:@supabase/supabase-js@2';
import { z } from 'npm:zod@3';
import { adminClient, cfBase, cfEnv, cfHeaders, settleOrder } from '../_shared/cashfree.ts';

const Body = z.discriminatedUnion('action', [
  z.object({ action: z.literal('create'), plan_id: z.string().uuid() }),
  z.object({ action: z.literal('verify'), order_ref: z.string().min(5).max(60) }),
]);

const json = (b: unknown, status = 200) =>
  new Response(JSON.stringify(b), { status, headers: { ...corsHeaders, 'Content-Type': 'application/json' } });

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: corsHeaders });
  try {
    const auth = req.headers.get('Authorization') ?? '';
    const userClient = createClient(Deno.env.get('SUPABASE_URL')!, Deno.env.get('SUPABASE_ANON_KEY')!, {
      global: { headers: { Authorization: auth } },
    });
    const { data: u } = await userClient.auth.getUser(auth.replace('Bearer ', ''));
    const user = u?.user;
    if (!user) return json({ error: 'unauthorized' }, 401);

    const parsed = Body.safeParse(await req.json());
    if (!parsed.success) return json({ error: parsed.error.flatten().fieldErrors }, 400);
    const db = adminClient();

    if (parsed.data.action === 'verify') {
      const { data: o } = await db.from('payment_orders').select('user_id').eq('order_ref', parsed.data.order_ref).maybeSingle();
      if (!o || o.user_id !== user.id) return json({ error: 'not_found' }, 404);
      return json({ status: await settleOrder(parsed.data.order_ref, 'cashfree_verify') });
    }

    // create
    // Run the three lookups in parallel to open checkout faster.
    const [{ data: dairy }, { data: plan }, { data: prof }] = await Promise.all([
      db.from('dairies').select('id').eq('owner_id', user.id).maybeSingle(),
      db.from('variety_plans').select('id,price,is_active').eq('id', parsed.data.plan_id).maybeSingle(),
      db.from('profiles').select('name,phone').eq('user_id', user.id).maybeSingle(),
    ]);
    if (!dairy) return json({ error: 'no_dairy' }, 400);
    if (!plan || plan.is_active === false || !(Number(plan.price) > 0)) return json({ error: 'invalid_plan' }, 400);
    const digits = String(prof?.phone ?? '').replace(/\D/g, '').slice(-10);
    const phone = /^[6-9]\d{9}$/.test(digits) ? digits : '9999999999';

    const orderRef = `DF_${Date.now()}_${crypto.randomUUID().slice(0, 8)}`;
    const amount = Number(plan.price);
    const projectRef = new URL(Deno.env.get('SUPABASE_URL')!).hostname.split('.')[0];

    const res = await fetch(`${cfBase()}/orders`, {
      method: 'POST',
      headers: cfHeaders(),
      body: JSON.stringify({
        order_id: orderRef,
        order_amount: amount,
        order_currency: 'INR',
        customer_details: {
          customer_id: user.id.replace(/-/g, '').slice(0, 40),
          customer_phone: phone,
          customer_name: prof?.name ?? undefined,
          customer_email: user.email ?? undefined,
        },
        order_meta: { notify_url: `https://${projectRef}.supabase.co/functions/v1/cashfree-webhook` },
      }),
    });
    const cf = await res.json().catch(() => ({}));
    if (!res.ok || !cf.payment_session_id) {
      console.error('cashfree create failed', res.status, cf?.message);
      return json({ error: 'gateway_error', message: cf?.message ?? 'Cashfree error' }, 502);
    }

    const { error } = await db.from('payment_orders').insert({
      user_id: user.id,
      dairy_id: dairy.id,
      variety_plan_id: plan.id,
      amount,
      order_ref: orderRef,
      status: 'created',
      expires_at: new Date(Date.now() + 30 * 60 * 1000).toISOString(),
      verification_method: 'cashfree',
    });
    if (error) return json({ error: 'db_error' }, 500);

    return json({ order_ref: orderRef, payment_session_id: cf.payment_session_id, mode: cfEnv() });
  } catch (e) {
    console.error(e);
    return json({ error: 'server_error' }, 500);
  }
});
